import { CommonNotificationPopupComponent } from './../../forex-common/common-notification-popup/common-notification-popup.component';
import { Component, OnInit, ElementRef, Inject, ViewChild, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UUID } from 'angular2-uuid';
import { Observable } from 'rxjs/Observable';
import { Location } from '../../../app/helpers/location';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { LocationStrategy } from '@angular/common';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { TimerService } from '../../services/timer.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { SharedService } from '../../../app/services/shared.service';
import { environment } from '../../../environments/environment';
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;

declare var $: any;
declare var Snackbar: any;

@Component({
    selector: 'app-buy-overview',
    templateUrl: './buy-overview.component.html',
    styleUrls: ['./buy-overview.component.css']
})
export class BuyOverviewComponent implements OnInit, AfterViewInit {

    public userSessionInfo: any;
    public navigate: any = true;
    public branchOptions: any;
    public destinationOptions: any;
    public currencyList: any;
    public currencyListCash: any;
    public currencyListTravellerCheque: any;
    public currencyListDemandDraft: any;
    public purposeOptions: any;
    public bankOptions = [];
    public CurrentBranchId: any;
    private currentTravellerIndex: number;
    public isLoggedIn: boolean;
    public travellerList: any;
    public newTravellerCount: number;
    public invalidsubmitted: boolean;
    public _primaryComp: any;
    public AgentTheme: any;
    public textContents: any = {};
    public overviewPage: any;
    public specialOffers: any = [];
    public products: any = [];
    public testimonials: any = [];
    public backGroungImage: any = 'assets/images/forex-bg-img.jpg';
    public PromotionalData: any;
    public defaultissuercode: any = environment.DEFAULT_ISSUER_CODE;
    @ViewChild(CommonNotificationPopupComponent) CommonNotificationPopupComponent;
    public agentId: any;
    Promoter: any;
    // tslint:disable-next-line:max-line-length
    constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _router: ActivatedRoute, private _elementRef: ElementRef, private location: LocationStrategy, private meta: Meta, @Inject(DOCUMENT) private _document: any, public _TimerService: TimerService, public _SharedService: SharedService) {
        this._primaryComp = '/' + navUrl.navUrl();
        this.location.onPopState(() => {
            this.navigate = false;
            return false;
        });
        this.Promoter = SessionHelper.getSession('promotion');
        if (this.Promoter && SessionHelper.getSession('PromotionalData')) {
            this.PromotionalData = JSON.parse(SessionHelper.getSession('PromotionalData'));
        }
        this._document.title = 'Buy Forex from Cox and Kings';
        // tslint:disable-next-line:max-line-length
        // this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
        // this.meta.addTag({ name: 'keywords', content: 'Buy, Sell, Send Money Abroad, Reload Card, Cash, Prepaid Card, Demand Draft, Check Exchange Rates, Live Forex Rates. exchange rates, currency exchange, currency rates, currency services, currency traders, currency trading, currency transfers, best exchange rates, rates, convert, currencies, currency, forex, forex news, forex terms, charts, discount, efficient, foreign exchange, foreign exchange payment, save money, save time, fx, global, global economy, graphs, guaranteed, headlines, introduction to forex, live, mid-market, trade currency, xe money transfer, accurate rates, accounting, expense management, forex markets'});
        this.userSessionInfo = {
            'sessionId': '',
            'mode': 'b2c',
            'type': 'buyScreen',
            'isActive': true,
            'LeadID': SessionHelper.getSession('LeadID') ? SessionHelper.getSession('LeadID') : null,
            'AgentID': SessionHelper.getSession('AgentID') ? SessionHelper.getSession('AgentID') : null,
            'IExhangeAgentId': SessionHelper.getSession('IExhangeAgentId') ? SessionHelper.getSession('IExhangeAgentId') : null,
            'created_On': new Date(),
            'buyScreen': {
                'budgetAmount': '',
                'usedAmount': '0',
                'tranId': '',
                'balanceAmount': '0',
                'currentLocation': '',
                'branch': '',
                'destination': '',
                'deliveryInfo': {
                    'Mode': 'Home Delivery',
                    'type': 'Standard',
                    'DeliverySchedule': {
                        'date': '',
                        'time': ''
                    },
                    'rate': 0
                },
                'traveller': [{
                    'selected': true,
                    'lead': true,
                    'prepaidCard': false,
                    'purpose': '',
                    'serviceCharge': 0,
                    'loadFees': 0,
                    'activationFees': 0,
                    'discount': 0,
                    'ddCharges': 0,
                    'charges': 0,
                    'gst': 0,
                    'prepaidCardDetails': [{
                        'currencyCode': '',
                        'forexAmount': '',
                        'bankname': '',
                        'startTime': ''
                    }],
                    'cash': false,
                    'cashDetails': [{
                        'currencyCode': '',
                        'forexAmount': '',
                        'startTime': ''
                    }],
                    'travellerCheque': false,
                    'travellerChequeDetails': [{
                        'currencyCode': '',
                        'forexAmount': '',
                        'startTime': ''
                    }],
                    'demandDraft': false,
                    'demandDraftDetails': [{
                        'currencyCode': '',
                        'forexAmount': '',
                        'startTime': ''
                    }],
                    'registrationInfo': {
                        'userId': '',
                        'invoiceNo': null,
                        'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                        'middleName': '',
                        'lastName': '',
                        'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
                        'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                        'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                        // "nationality": { "id": "", "name": "" } ,
                        'nationality': '',
                        'mothersMaidenName': {
                            'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                                + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                                + 'event.target.style.background=\'#f8f8f8\'}'
                        },
                        'PAN': {
                            'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                                + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                                + 'event.target.style.background=\'#f8f8f8\'}'
                        },
                        'passportNumber': '',
                        'ParentId': true,
                        'dateOfIssue': '',
                        'placeOfIssue': '',
                        'expiryDate': '',
                        'address': '101 5A Galaxy apartment',
                        'isPassportAddressAsAdhar': 'yes',
                        'adharAddress': {
                            'flatNumber': '',
                            'buildingName': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': '',
                        },
                        'passportAddress': {
                            'flatNumber': '',
                            'buildingName': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': '',
                        },
                        'currentAddressAs': 'asPerAdhar',
                        'otherAddress': {
                            'flatNumber': '',
                            'buildingName': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': '',
                        },
                        'contactDetails': {
                            'mobileNo': '',
                            'emailId': ''
                        },
                        'alternateContactDetails': {
                            'countryCode': '',
                            'mobileNo': '',
                            'countryCode2': '',
                            'cityCode': '',
                            'telephoneNo': '',
                            'emailId': '',
                        },
                        'officeAddress': {
                            'designation': '',
                            'conpanyName': '',
                            'companyDivision': '',
                            'flatNumber': '',
                            'building': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': ''
                        },
                        'officeContactDetails': {
                            'countryCode': '',
                            'telephoneNumber': '',
                            'officeExtension': '',
                        },
                        'password': '',
                        'confirmPassword': '',
                    },
                    'travellingDetails': {
                        'dateOfTravel': '',
                        'dateOfArrival': '',
                        'airlineName': '',
                        'ticketNumber': ''
                    },
                    'transactionDetails': [{
                        'beneficiaryFirstName': '',
                        'beneficiaryBlockNumber': '',
                        'beneficiaryBuilding': '',
                        'beneficiaryStreet': '',
                        'beneficiaryLandMark': '',
                        'beneficiaryArea': '',
                        'beneficiaryCity': '',
                        'beneficiaryState': '',
                        'beneficiaryPincode': '',
                        'beneficiaryCountry': '',
                        'beneficiaryAccountNo': '',
                        'beneficiaryBankName': '',
                        'beneficiarySwiftCode': '',
                        'beneficiaryRoutingNo': '',
                        'beneficiaryBankAddress': ''
                    }],
                    'selfTransaction': {
                        'beneficiaryTransSelf': '',
                        'beneficiaryTravellerName': '',
                        'beneficiaryTravellerRelationship': '',
                        'beneficiaryTravellerArrivalDate': '',
                        'beneficiaryTravellerEducation': '',
                        'beneficiaryTravellerCountry': ''
                    }
                }
                ]
            }
        };

        if (SessionHelper.getSession('userInfo')) {
            const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
            // Added after Aadhaar implementation
            if (userInfo.uid) {
                this.isLoggedIn = userInfo.loggedin;
                this.masterService.getLoggedInUserInfo(userInfo.uid)
                    .subscribe(data => {
                        const result: any = data;
                        this.travellerList = [];
                        this.travellerList.push({
                            name: result.response[0][0].firstName + ' ' + result.response[0][0].lastName,
                            data: result.response[0][0]
                        });
                        this.travellerList[0].data.lead = true;
                        this.travellerList[0].selected = true;

                        this.userSessionInfo.buyScreen.traveller[0].registrationInfo
                            = SessionTemplate.getSessionTemplate(this.travellerList[0].data).registrationInfo;

                        result.response[1].forEach(element => {
                            this.travellerList.push({ name: element.firstName + ' ' + element.lastName, data: element });
                            this.newTravellerCount = 0;
                        });
                    }, err => {
                        // swal('Oops', 'Error fetching traveler data!', 'error');
                        Snackbar.show({
                            text: 'Error fetching traveler data!',
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                    });
            }
        } else {
            this.isLoggedIn = false;
        }

        // region Logic to restore values from session if present...
        if (SessionHelper.getSession('userSessionInfo')) {
            this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfo'));
            this.masterService.getCurrencyList(this.userSessionInfo.buyScreen.destination)
                .subscribe(data => {
                    this.currencyList = data;
                    this.currencyListCash = data;
                    this.currencyListTravellerCheque = data;
                    this.currencyListDemandDraft = data;
                }, err => {
                    // swal('Oops...', 'Unable to fetch currency list!', 'error');
                    // Snackbar.show({
                    //     text: 'Unable to fetch currency list!',
                    //     pos: 'bottom-right',
                    //     actionTextColor: '#ff4444',
                    // });
                });
            if (!this.Promoter) {
                this.userSessionInfo.buyScreen.traveller.forEach(traveller => {
                    if (traveller.prepaidCard) {
                        traveller.prepaidCardDetails.forEach((detail, index) => {
                            this.masterService.getBankList(detail.currencyCode)
                                .subscribe(data => {
                                    if (this.Promoter && this.PromotionalData) {
                                        this.bankOptions[index] = this.PromotionalData.buyScreen.IssuerLists;
                                    } else {
                                        this.bankOptions[index] = data;
                                        this.bankOptions[index].forEach(element => {
                                            element.Logo = Constants.serviceUrl + '/' + element.Logo;
                                        });
                                    }
                                }, err => {
                                    // swal('Oops...', 'Unable to fetch bank list!', 'error');
                                    Snackbar.show({
                                        text: 'Unable to fetch bank list!',
                                        pos: 'bottom-right',
                                        actionTextColor: '#ff4444',
                                    });
                                });
                        });
                    }
                });
            }

            // FOR PURPOSE LIST  @precessId values :
            // 1	Buy Forex
            // 2	Sell Forex
            // 3	Reload Card
            // 4	Send Money Abroad
            // this.masterService.getPurposeList(1)
            //     .subscribe(data => {
            //         this.purposeOptions = data;
            //     }, err => {
            //         swal('Oops...', 'Unable to fetch purpose list!', 'error');
            //     });
        } else {
            this.userSessionInfo.sessionId = UUID.UUID();
        }
        // endregion Logic to restore values from session if present...
        this.populateBranch('');
        if (sessionStorage.getItem('currentLocation') === null) {
            this.masterService.getCurrentLocation()
                .subscribe(data => {
                    this.userSessionInfo.buyScreen.currentLocation = data;
                    sessionStorage.setItem('currentLocation', JSON.stringify(this.userSessionInfo.buyScreen.currentLocation));
                    this.populateBranch(this.userSessionInfo.buyScreen.currentLocation.city);
                    if (SessionHelper.getLocal('branchIdFromOverviewBuy')) {
                        const branchIdObj = { BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewBuy')) };
                        this.selected(branchIdObj);
                    } else {
                        const branchIdObj = { BranchID: 11910 };
                        this.selected(branchIdObj);
                    }
                }, err => {
                    this.populateBranch('');
                    Snackbar.show({
                        text: 'Unable to detect current location!',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                });
        } else {
            this.userSessionInfo.buyScreen.currentLocation = JSON.parse(sessionStorage.getItem('currentLocation'));
            this.populateBranch(this.userSessionInfo.buyScreen.currentLocation.city);
            if (SessionHelper.getLocal('branchIdFromOverviewBuy')) {
                const branchIdObj = { BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewBuy')) };
                this.selected(branchIdObj);
            } else {
                const branchIdObj = { BranchID: 11910 };
                this.selected(branchIdObj);
            }
        }



        if (sessionStorage.getItem('destinationList') === null) {
            this.masterService.getDestinationList()
                .subscribe(data => {
                    this.destinationOptions = data;
                    sessionStorage.setItem('destinationList', JSON.stringify(this.destinationOptions));
                }, err => {
                    // swal('Oops...', 'Unable to fetch destination list!', 'error');
                    Snackbar.show({
                        text: 'Unable to fetch destination list!',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                });
        } else {
            this.destinationOptions = JSON.parse(sessionStorage.getItem('destinationList'));
        }
        this.CurrentBranchId = Number.parseInt(SessionHelper.getLocal('branchIdFromOverview'));
        this.currentTravellerIndex = 0;
        this.populateCurrencyRateForRule(this.CurrentBranchId);
        this.populateCashCurrency();
        this.populateDemandDraftCurrency();
        this.populatePrepaidCurrency();
        this.populateTravellersCurrency();
    }

    ngOnInit(): void {
        initDocument();
        this.textContents.convenienceTitle = 'Buying forex have never become easier!';
        // tslint:disable-next-line:max-line-length
        this.textContents.convenienceContents = 'Cox & Kings helps you choose the right forex solutions.<br> When you are on the move, just place the order and visit any of the nearest Cox & Kings location to avail our forex solutions.<br> When you are busy, just place the order and relax. We will get you the required forex solutions at your door step.';
        if (this._SharedService.AgentsTheme) {
            // tslint:disable-next-line:max-line-length
            this.AgentTheme = this._SharedService.AgentsTheme.success ? this._SharedService.AgentsTheme.Docs : this._SharedService.AgentsTheme;
            this.applyTheme();
        }
        $('body').attr('id', 'home');
        $('.custom-tabs > .resp-tabs-list > li[aria-controls="hor_1_tab_item-0"]').trigger('click');
        setTimeout(() => {
            $('.owl-item.active .TabBanners > li:first-child').trigger('click');
        }, 500);





        // FOR PURPOSE LIST  @precessId values :
        // 1	Buy Forex
        // 2	Sell Forex
        // 3	Reload Card
        // 4	Send Money Abroad
        this.masterService.getPurposeList(1)
            .subscribe(data => {
                this.purposeOptions = data;

                this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].purposeCode =
                    this.purposeOptions.filter((value, i) => i === 0)[0].purposeCode;
                if (this._router.snapshot.queryParams['screen'] === 'scrollToRate') {
                    setTimeout(() => {
                        document.getElementById('appRateHome').scrollIntoView({ block: 'start', behavior: 'smooth', inline: 'nearest' });
                    }, 700);
                }

            }, err => {
                // swal('Oops...', 'Unable to fetch purpose list!', 'error');
                Snackbar.show({
                    text: 'Unable to fetch purpose list!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });


        /// temporary number
        if (sessionStorage.getItem('userInfo') !== null) {
            const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
            this.masterService.getTemporaryOrderNumber()
                .subscribe(data => {
                    const result: any = data;
                    console.log(result);
                    this.userSessionInfo.temporaryOrderNumber = result.response.OrderNumber;
                    this.userSessionInfo.userId = userInfo.uid;
                });
        }
        this.selectTraveller(0);
        
        if (this.Promoter) {
            // tslint:disable-next-line:max-line-length
            this.defaultissuercode = this.Promoter && this.PromotionalData ? this.PromotionalData.buyScreen.IssuerLists[0].CustomerCode : environment.DEFAULT_ISSUER_CODE;
            this.runPromotionalFunctions(this.Promoter);
            this.userSessionInfo.buyScreen.traveller.forEach(traveller => {
                if (traveller.prepaidCard) {
                    traveller.prepaidCardDetails.forEach((detail, index) => {
                        this.masterService.getBankList(detail.currencyCode)
                            .subscribe(data => {
                                if (this.Promoter && this.PromotionalData) {
                                    this.bankOptions[index] = this.PromotionalData.buyScreen.IssuerLists;
                                } else {
                                    this.bankOptions[index] = data;
                                    this.bankOptions[index].forEach(element => {
                                        element.Logo = Constants.serviceUrl + '/' + element.Logo;
                                    });
                                }

                            }, err => {
                                // swal('Oops...', 'Unable to fetch bank list!', 'error');
                                Snackbar.show({
                                    text: 'Unable to fetch bank list!',
                                    pos: 'bottom-right',
                                    actionTextColor: '#ff4444',
                                });
                            });
                    });
                }
            });
        }
    }
    ngAfterViewInit(): void {
        this.Promoter = SessionHelper.getSession('promotion');
        if (this.Promoter) {
            // tslint:disable-next-line:max-line-length
            this.defaultissuercode = this.Promoter && this.PromotionalData ? this.PromotionalData.buyScreen.IssuerLists[0].CustomerCode : environment.DEFAULT_ISSUER_CODE;
            this.runPromotionalFunctions(this.Promoter);
        }
    }

    // tslint:disable-next-line:use-life-cycle-interface
    ngDoCheck() {
        this._SharedService.AgentTheme.subscribe((theme) => {
            this.AgentTheme = theme.success ? theme.Docs : theme;
            this.applyTheme();
        });
        if (SessionHelper.getSession('AgentID')) {
            this.agentId = SessionHelper.getSession('AgentID');
        }
    }

    initNotification(type: string, currencyCode, BranchId, requiredAmount: any = 0, AvailableStock: any = 0) {
        console.log(type);
        this.CommonNotificationPopupComponent.initializeNotification(type, currencyCode, BranchId, requiredAmount, AvailableStock);
    }
    applyTheme() {
        if (this.AgentTheme.overviewPage) {
            this.overviewPage = this.AgentTheme.overviewPage;
            if (this.overviewPage.mainScreenBackGround) {
                this.backGroungImage = this.overviewPage.mainScreenBackGround;
            }
            if (this.overviewPage.specialOffers) {
                this.specialOffers = this.overviewPage.specialOffers;
            }
            if (this.overviewPage.products) {
                this.products = this.overviewPage.products;
            }
            if (this.overviewPage.testimonials) {
                this.testimonials = this.overviewPage.testimonials;
            }
        } else {
            this.overviewPage = {};
            this.backGroungImage = 'assets/images/forex-bg-img.jpg';
            this.specialOffers = [];
            this.products = [];
            this.testimonials = [];
        }
    }

    populateCurrencyRateForRule(branchId) {
        this.masterService.getCurrencyRateForRule(branchId).subscribe(
            (data) => {
                const result: any = data;
                if (result.length) {
                    this.userSessionInfo.cashRateBuy = result[0].cashRateBuy;
                    this.userSessionInfo.prepaidRateBuy = result[0].prepaidRateBuy;
                    this.userSessionInfo.ddRateBuy = result[0].ddRateBuy;
                    this.userSessionInfo.cashRateSell = result[0].cashRateSell;
                    this.updateSession();
                }
            },
            (error) => {
                console.error('getCurrencyRateForRule');
                console.log(error);
            }
        );
    }


    populateBranch(cityname) {
        // tslint:disable-next-line:curly
        if (cityname)
            this.masterService.getBranchList(cityname)
                .subscribe(data => {
                    if (this.Promoter && this.PromotionalData) {
                        this.branchOptions = this.PromotionalData.BranchList;
                    } else {
                        this.branchOptions = data;
                    }
                  //  this.branchOptions = data;
                    //       console.log(this.branchOptions);
                });
    }
    addExistingTraveller(data: any, event: any, index: number) {
        if (event.target.checked) {
            if (this.userSessionInfo.buyScreen.traveller.length === 4) {
                // swal('Sorry', 'Maximum 4 travelers allowed', 'error');
                Snackbar.show({
                    text: 'Maximum 4 travelers allowed',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });

                event.target.checked = false;
            } else {
                console.log('exi traveller ADDDE>>>>>>>>>>>>>>');
                this.userSessionInfo.buyScreen.traveller.push(
                    {
                        registrationInfo: SessionTemplate.getSessionTemplate(data).registrationInfo,
                        travellingDetails: SessionTemplate.getSessionTemplate(data).travellingDetails,
                        transactionDetails: SessionTemplate.getSessionTemplate(data).transactionDetails,
                        selfTransaction: SessionTemplate.getSessionTemplate(data).selfTransaction,
                        'serviceCharge': 0,
                        'loadFees': 0,
                        'activationFees': 0,
                        'discount': 0,
                        'charges': 0,
                        'gst': 0,
                        'prepaidCardDetails': [{
                            'currencyCode': '',
                            'forexAmount': '',
                            'bankname': '',
                            'startTime': ''
                        }],
                        'cash': false,
                        'cashDetails': [{
                            'currencyCode': '',
                            'forexAmount': '',
                            'startTime': ''
                        }],
                        'travellerCheque': false,
                        'travellerChequeDetails': [{
                            'currencyCode': '',
                            'forexAmount': '',
                            'startTime': ''
                        }],
                        'demandDraft': false,
                        'demandDraftDetails': [{
                            'currencyCode': '',
                            'forexAmount': '',
                            'startTime': ''
                        }],
                        'selected': false,
                        'lead': false,
                        'prepaidCard': false,
                        'purpose': '',
                    }
                );
                this.selectTraveller(this.userSessionInfo.buyScreen.traveller.length - 1);
            }
        } else {
            if (!this.travellerList[index].data.lead) {
                if (this.userSessionInfo.buyScreen.traveller.length > 1) {
                    const obj = this.userSessionInfo.buyScreen.traveller
                        .find(item => item.registrationInfo.contactDetails.emailId === data.emailId);

                    this.removeTraveller(this.userSessionInfo.buyScreen.traveller.indexOf(obj));
                } else {
                    // swal('Sorry', 'Minimum 1 traveler needed', 'error');
                    Snackbar.show({
                        text: 'Minimum 1 traveler needed',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    event.target.checked = true;
                }
            } else {
                // swal('Sorry', 'You cannot remove lead pax. Change any other traveler to lead before this operation', 'error');
                Snackbar.show({
                    text: 'You cannot remove lead pax. Change any other traveler to lead before this operation',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });

                event.target.checked = true;
            }
        }

        this.travellerList[index].selected = event.target.checked;
        this.updateSession();
    }

    addNewTraveller(event: any) {
        if (event.target.checked) {
            if (this.userSessionInfo.buyScreen.traveller.length === 4) {
                // swal('Sorry', 'Maximum 4 travelers allowed', 'error');
                Snackbar.show({
                    text: 'Maximum 4 travelers allowed',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                event.target.checked = false;
            } else {
                this.newTravellerCount++;
                console.log('new traveller ADDDE>>>>>>>>>>>>');
                this.addTraveller();
                this.selectTraveller(this.userSessionInfo.buyScreen.traveller.length - 1);
            }
        } else {
            if (this.userSessionInfo.buyScreen.traveller.length > 1) {
                const obj = this.userSessionInfo.buyScreen.traveller
                    .find(item => item.registrationInfo.contactDetails.emailId === '');
                this.removeTraveller(this.userSessionInfo.buyScreen.traveller.indexOf(obj));
                this.newTravellerCount--;
            } else {
                // swal('Sorry', 'Minimum 1 traveler needed', 'error');
                Snackbar.show({
                    text: 'Minimum 1 traveler needed',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                event.target.checked = true;
            }
        }
    }

    changeLeadPax(event: any, data: any, index: number) {
        console.log(event);
        console.log(data);
        console.log(index);

        this.travellerList.forEach(item => {
            item.data.lead = false;
        });

        this.travellerList[index].data.lead = true;

        this.userSessionInfo.buyScreen.traveller.forEach(traveller => {
            traveller.lead = false;
        });
        const obj = this.userSessionInfo.buyScreen.traveller
            .find(item => item.registrationInfo.contactDetails.emailId === data.emailId);
        const i = this.userSessionInfo.buyScreen.traveller.indexOf(obj);

        this.userSessionInfo.buyScreen.traveller[i].lead = true;
        console.log(this.userSessionInfo.buyScreen.traveller);
    }

    showTravellerChoice() {
        this._elementRef.nativeElement.querySelector('.trvl-list').style.display = 'block';
    }

    hideTravellerChoice() {
        this._elementRef.nativeElement.querySelector('.trvl-list').style.display = 'none';
    }

    saveBudgetAmount(newValue) {
        this.userSessionInfo.buyScreen.budgetAmount = newValue;
        this.updateBalanceAmount();
    }

    updateBalanceAmount() {
        if (Number.isNaN(Number.parseInt(this.userSessionInfo.buyScreen.budgetAmount))) {
            this.userSessionInfo.buyScreen.balanceAmount = '';
        } else if (this.userSessionInfo.buyScreen.budgetAmount !== '0' && this.userSessionInfo.buyScreen.budgetAmount !== 0) {
            this.userSessionInfo.buyScreen.balanceAmount = (this.userSessionInfo.buyScreen.budgetAmount
                - this.userSessionInfo.buyScreen.usedAmount);
            this.userSessionInfo.buyScreen.balanceAmount
                = this.userSessionInfo.buyScreen.balanceAmount < 0 ? 0 : this.userSessionInfo.buyScreen.balanceAmount;
            if (this.userSessionInfo.buyScreen.budgetAmount - this.userSessionInfo.buyScreen.usedAmount <= 0) {
                // swal('Oops', 'You have exceeded your budget!!', 'warning');
                Snackbar.show({
                    text: 'You have exceeded your budget!!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            }
        }
        this.updateSession();
    }

    updateBranch(newValue: number) {
        console.log(newValue);
        this.userSessionInfo.buyScreen.branch = newValue;
        this.userSessionInfo.buyScreen.traveller.map((traveller, index) => {
            if (traveller.cash) {
                traveller.cashDetails = [];
                traveller.cash = false;
                traveller.cashDetails.push(
                    {
                        'currencyCode': '',
                        'forexAmount': '',
                        'startTime': ''
                    }
                );
            }
            this.updateSession();
        });
        this.updateUsedAmount();
        this.updateBalanceAmount();
    }

    selected($event) {
        console.log($event);
        this.CurrentBranchId = $event.BranchID;
        SessionHelper.setLocal('branchIdFromOverview', $event.BranchID);
        SessionHelper.setLocal('branchIdFromOverviewBuy', $event.BranchID);
        if ($event.BranchCode) {
            this.userSessionInfo.buyScreen.BranchCode = $event.BranchCode;
            this.updateSession();
        }
        this.populateCurrencyRateForRule(this.CurrentBranchId);
    }

    updateDestination(newValue: number) {
        this.userSessionInfo.buyScreen.destination = newValue;
        // this.masterService.getCurrencyList(this.userSessionInfo.buyScreen.destination)
        //     .subscribe(data => {
        //         this.currencyList = data;
        //         this.currencyListCash = data;
        //         this.currencyListTravellerCheque = data;
        //         this.currencyListDemandDraft = data;
        //     }, err => {
        //         swal('Oops...', 'Unable to fetch currency list!', 'error');
        //     });
        this.updateSession();
    }

    canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
        if (this.navigate === true) {
            return true;
        } else {
            Snackbar.show({
                text: 'You can not go back from this page. Please go through application flow.',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
            window.scrollTo(0, 0);
            this.navigate = true;
            return false;
        }
    }

    // region Update currency code event listeners
    updatePrepaidCurrencyCode(prepaidDetailIndex: number, newValue: string, BankCode: any = this.defaultissuercode) {
        console.log('updatePrepaidCurrencyCode');
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', 'buy', BankCode)
            .subscribe(data => {
                const result: any = data;
                console.log(data);
                this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
                    .exchangeRate = data;
                    // tslint:disable-next-line:max-line-length
                    this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex].bankname = result.CustomerCode;
                if (result.rate !== 0) {
                    this.updateUsedAmount();
                    this.updateSession();
                    this.populateCurrencyRateForRule(this.CurrentBranchId);
                } else {
                    Snackbar.show({
                        text: 'No Rates Found for <b>' + newValue + '</b>',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                }
            }, err => {
                // swal('Oops...', 'Unable to fetch exchange rate!', 'error');
                Snackbar.show({
                    text: 'Unable to fetch exchange rate!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });

        this.masterService.getBankList(newValue)
            .subscribe(data => {
                if (this.Promoter) {
                    this.bankOptions[prepaidDetailIndex] = this.PromotionalData.buyScreen.IssuerLists;
                } else {
                    this.bankOptions[prepaidDetailIndex] = data;
                    this.bankOptions[prepaidDetailIndex].forEach(element => {
                        element.Logo = Constants.serviceUrl + '/' + element.Logo;
                    });
                }
            }, err => {
                // swal('Oops...', 'Unable to fetch bank list!', 'error');
                Snackbar.show({
                    text: 'Unable to fetch bank list!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });
        this.updateSession();
    }

    updateCashCurrencyCode(cashDetailIndex: number, newValue: string) {
        console.log(this.CurrentBranchId);
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails[cashDetailIndex].currencyCode = newValue;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'cash', 'buy')
            .subscribe(data => {
                const result: any = data;
                this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails[cashDetailIndex].exchangeRate = result;
                if (result.rate !== 0) {
                    this.updateUsedAmount();
                    this.updateSession();
                    this.populateCurrencyRateForRule(this.CurrentBranchId);
                } else {
                    Snackbar.show({
                        text: 'No Rates Found for <b>' + newValue + '</b>',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    this.initNotification('NO_CASH_FOUND', newValue, this.CurrentBranchId);
                }
            }, err => {
                // swal('Oops...', 'Unable to fetch exchange rate!', 'error');
                Snackbar.show({
                    text: 'Unable to fetch exchange rate!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });
        this.updateSession();
    }

    updateTravellerChequeCurrencyCode(travellerChequeDetailIndex: number, newValue: string) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails[travellerChequeDetailIndex]
            .currencyCode = newValue;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', 'sell')
            .subscribe(data => {
                this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails[travellerChequeDetailIndex]
                    .exchangeRate = data;
                this.updateUsedAmount();
                this.updateSession();
                // tslint:disable-next-line:max-line-length
                // console.log(this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails[travellerChequeDetailIndex]);
            }, err => {
                // swal('Oops...', 'Unable to fetch exchange rate!', 'error');
                Snackbar.show({
                    text: 'Unable to fetch exchange rate!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });
        this.updateSession();
    }

    updateDemandDraftCurrencyCode(demandDraftDetailIndex: number, newValue: string) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails[demandDraftDetailIndex]
            .currencyCode = newValue;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'dd', 'buy', 'HODD')
            .subscribe(data => {
                const result: any = data;
                this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails[demandDraftDetailIndex]
                    .exchangeRate = result;
                if (result.rate !== 0) {
                    this.updateUsedAmount();
                    this.updateSession();
                    this.populateCurrencyRateForRule(this.CurrentBranchId);
                } else {
                    Snackbar.show({
                        text: 'No Rates Found for <b>' + newValue + '</b>',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                }
            }, err => {
                // swal('Oops...', 'Unable to fetch exchange rate!', 'error');
                Snackbar.show({
                    text: 'Unable to fetch exchange rate!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });
        this.updateSession();
    }
    // endregion Update currency code event listeners

    // region Main product checkbox change listeners
    updatePrepaidCard(newValue: boolean) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCard = newValue;

        if (this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails === undefined) {
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails = [{
                'currencyCode': '',
                'forexAmount': '',
                'bankname': '',
                'startTime': ''
            }];
        }

        const currentDocument = this;
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        if (newValue) {
            const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
            this.masterService.getCurrencyList(1, destination)
                .subscribe(data => {
                    this.currencyList = data;
                    if (this.Promoter) {
                        // tslint:disable-next-line:max-line-length
                        this.defaultissuercode = this.Promoter && this.PromotionalData ? this.PromotionalData.buyScreen.IssuerLists[0].CustomerCode : environment.DEFAULT_ISSUER_CODE;
                        this.runPromotionalFunctions(this.Promoter);
                    }
                }, err => {
                    // swal('Oops...', 'Unable to fetch currency list!', 'error');
                    // Snackbar.show({
                    //     text: 'Unable to fetch currency list!',
                    //     pos: 'bottom-right',
                    //     actionTextColor: '#ff4444',
                    // });
                });

        }
        this.updateUsedAmount();
    }
    populatePrepaidCurrency() {
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
        this.masterService.getCurrencyList(1, destination)
            .subscribe(data => {
                if (this.Promoter && this.PromotionalData) {
                     this.currencyList = this.PromotionalData.buyScreen.PrpaidCurrencyLists;
                }else {
                    this.currencyList = data;
                }
                
            }, err => {
                // swal('Oops...', 'Unable to fetch currency list!', 'error');
                // Snackbar.show({
                //     text: 'Unable to fetch currency list!',
                //     pos: 'bottom-right',
                //     actionTextColor: '#ff4444',
                // });

            });
    }
    updateCash(newValue: boolean) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cash = newValue;

        if (this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails === undefined) {
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails = [{
                'currencyCode': '',
                'forexAmount': '',
                'startTime': ''
            }];
        }

        const currentDocument = this;
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        if (newValue) {
            const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
            this.masterService.getCurrencyList(2, destination)
                .subscribe(data => {
                    this.currencyListCash = data;
                }, err => {
                    // swal('Oops...', 'Unable to fetch currency list!', 'error');
                    // Snackbar.show({
                    //     text: 'Unable to fetch currency list!',
                    //     pos: 'bottom-right',
                    //     actionTextColor: '#ff4444',
                    // });
                });
        }
        this.updateUsedAmount();
    }

    populateCashCurrency() {
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
        this.masterService.getCurrencyList(2, destination)
            .subscribe(data => {
                this.currencyListCash = data;
            }, err => {
                // swal('Oops...', 'Unable to fetch currency list!', 'error');
                // Snackbar.show({
                //     text: 'Unable to fetch currency list!',
                //     pos: 'bottom-right',
                //     actionTextColor: '#ff4444',
                // });
            });
    }

    updateTravellerCheque(newValue: boolean) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerCheque = newValue;

        if (this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails === undefined) {
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails = [{
                'currencyCode': '',
                'forexAmount': '',
                'startTime': ''
            }];
        }

        const currentDocument = this;
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        if (newValue) {
            const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
            this.masterService.getCurrencyList(3, destination)
                .subscribe(data => {
                    this.currencyListTravellerCheque = data;
                }, err => {
                    // swal('Oops...', 'Unable to fetch currency list!', 'error');
                    // Snackbar.show({
                    //     text: 'Unable to fetch currency list!',
                    //     pos: 'bottom-right',
                    //     actionTextColor: '#ff4444',
                    // });
                });
        }
        this.updateUsedAmount();
    }

    populateTravellersCurrency() {
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
        this.masterService.getCurrencyList(3, destination)
            .subscribe(data => {
                this.currencyListTravellerCheque = data;
            }, err => {
                // swal('Oops...', 'Unable to fetch currency list!', 'error');
                // Snackbar.show({
                //     text: 'Unable to fetch currency list!',
                //     pos: 'bottom-right',
                //     actionTextColor: '#ff4444',
                // });
            });
    }
    updateDemandDraft(newValue: boolean) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraft = newValue;

        if (this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails === undefined) {
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails = [{
                'currencyCode': '',
                'forexAmount': '',
                'startTime': ''
            }];
        }

        const currentDocument = this;
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        if (newValue) {
            const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
            this.masterService.getCurrencyList(4, destination)
                .subscribe(data => {
                    this.currencyListDemandDraft = data;
                }, err => {
                    // swal('Oops...', 'Unable to fetch currency list!', 'error');
                    // Snackbar.show({
                    //     text: 'Unable to fetch currency list!',
                    //     pos: 'bottom-right',
                    //     actionTextColor: '#ff4444',
                    // });
                });
        }
        this.updateUsedAmount();
    }

    populateDemandDraftCurrency() {
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
        this.masterService.getCurrencyList(4, destination)
            .subscribe(data => {
                this.currencyListDemandDraft = data;
            }, err => {
                // swal('Oops...', 'Unable to fetch currency list!', 'error');
                // Snackbar.show({
                //     text: 'Unable to fetch currency list!',
                //     pos: 'bottom-right',
                //     actionTextColor: '#ff4444',
                // });
            });
    }
    // endregion Main product checkbox change listeners

    // region Update purpose for prepaid card
    updatePurpose(newPurpose) {
        // console.log(this.purposeOptions.filter((value, i) => value.value === newPurpose)[0].purposeCode);
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].purpose = newPurpose;
        this.userSessionInfo.buyScreen.purposeCode = this.purposeOptions.filter((value, i) => value.value === newPurpose)[0].purposeCode;
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].purposeCode =
            this.purposeOptions.filter((value, i) => value.value === newPurpose)[0].purposeCode;

        this.updateSession();
    }
    // endregion Update purpose for prepaid card

    // region Update product forex amount value
    updatePrepaidValue(newValue, index) {
        if (newValue === '' || isNaN(newValue)) {
            newValue = '0';
        }
        // tslint:disable-next-line:max-line-length
        const checkRateCondition = this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index].exchangeRate.rate !== 0;
        if (checkRateCondition) {
            // tslint:disable-next-line:max-line-length
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index].forexAmount = parseFloat(newValue);
            this.updateUsedAmount();
        } else {
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index].forexAmount = '';
        }
    }

    updateCashValue(newValue, index, cashDetail: any = null) {
        console.log(cashDetail);
        console.log(newValue);
        console.log('CASH VALUE UDATE CALLED');
        if (newValue === '' || isNaN(newValue)) {
            console.log('dgsdg');
            newValue = '0';
        }
        // tslint:disable-next-line:max-line-length
        const checkCashRateCondition = this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails[index].exchangeRate.rate;
        if (checkCashRateCondition) {
            const requiredAmount: any = newValue;
            const AvailableStock = cashDetail.exchangeRate.CLStock ? cashDetail.exchangeRate.CLStock : 0;
            if (requiredAmount > AvailableStock) {
                this.initNotification('CASH_OUTOF_STOCK', cashDetail.currencyCode, this.CurrentBranchId, requiredAmount, AvailableStock);
            }

            console.log('CALL USED AMOUNT');
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails[index].forexAmount = parseFloat(newValue);
            this.updateUsedAmount();
        } else {
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails[index].forexAmount = '';
        }
    }

    updateTravellerChequeValue(newValue, index) {
        if (newValue === '' || isNaN(newValue)) {
            newValue = '0';
        }
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails[index]
            .forexAmount = parseFloat(newValue);
        this.updateUsedAmount();
    }

    updateDemandDraftValue(newValue, index) {
        if (newValue === '' || isNaN(newValue)) {
            newValue = '0';
        }
        // tslint:disable-next-line:max-line-length
        const checkDemandRateCondition = this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails[index].exchangeRate.rate !== 0;
        if (checkDemandRateCondition) {
            // tslint:disable-next-line:max-line-length
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails[index].forexAmount = parseFloat(newValue);
            this.updateUsedAmount();
        } else {
            this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails[index].forexAmount = '';
        }
    }
    // endregion Update product forex amount value

    updateUsedAmount() {
        let travellerTotal = 0;
        console.log('USED AMOUNT CALLED');
        this.userSessionInfo.buyScreen.traveller.forEach(currentTraveller => {
            let currentTravellerTotal = 0;
            if (currentTraveller.prepaidCard) {
                currentTraveller.prepaidCardDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }
            if (currentTraveller.cash) {
                currentTraveller.cashDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }
            if (currentTraveller.travellerCheque) {
                currentTraveller.travellerChequeDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }
            if (currentTraveller.demandDraft) {
                currentTraveller.demandDraftDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }

            travellerTotal += currentTravellerTotal;
            currentTraveller.usedAmount = currentTravellerTotal;
        });


        this.userSessionInfo.buyScreen.usedAmount = travellerTotal;

        if (this.userSessionInfo.buyScreen.usedAmount !== 0) {
            this.masterService.getTaxes(this.userSessionInfo.buyScreen.usedAmount)
                .subscribe(res => {
                    const result: any = res;
                    this.userSessionInfo.buyScreen.usedAmount += result.TotalTax;
                    this.updateBalanceAmount();
                    this.updateSession();
                    console.log('AMOUNT' + this.userSessionInfo.buyScreen.usedAmount, 'TAXES' + result.TotalTax);
                }, err => {
                    // swal('Oops', 'Error fetching taxes', 'error');
                    Snackbar.show({
                        text: 'Error fetching taxes',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                });
        }

        this.updateBalanceAmount();
    }


    getDefaultExchangeRate(index) {
        this.masterService.getExchangeRate('USD', this.CurrentBranchId, 'prepaid', 'buy', this.defaultissuercode)
            .subscribe(data => {
                this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index]
                    .exchangeRate = data;
                console.log('Exchange rate called');
                this.updateUsedAmount();
                this.updateSession();
            }, err => {
                // swal('Oops...', 'Unable to fetch exchange rate!', 'error');
                Snackbar.show({
                    text: 'Unable to fetch exchange rate!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });
    }
    getDefaultIssuer(index) {
        this.masterService.getBankList('USD')
            .subscribe(data => {
                if (this.Promoter) {
                    this.bankOptions[index] = this.PromotionalData.buyScreen.IssuerLists;
                } else {
                    this.bankOptions[index] = data;
                    this.bankOptions[index].forEach(element => {
                        element.Logo = Constants.serviceUrl + '/' + element.Logo;
                    });
                }

            }, err => {
                // swal('Oops...', 'Unable to fetch bank list!', 'error');
                Snackbar.show({
                    text: 'Unable to fetch bank list!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });
    }

    // region Add more currency for each product
    addMorePrepaidCurrency() {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.push({
            'currencyCode': 'USD',
            'forexAmount': '',
            'bankname': this.defaultissuercode,
            'startTime': ''
        });

        const currentIndex = this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.length - 1;
        this.getDefaultExchangeRate(currentIndex);
        this.getDefaultIssuer(currentIndex);
        this.updateSession();
    }

    addMoreCashCurrency() {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails.push({
            'currencyCode': '',
            'forexAmount': '',
            'startTime': ''
        });

        const currentIndex = this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails.length - 1;
        this.updateSession();
    }

    addMoreTravellerChequeCurrency() {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails.push({
            'currencyCode': '',
            'forexAmount': '',
            'startTime': ''
        });

        const currentIndex = this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails.length - 1;
        this.updateSession();
    }

    addMoreDemandDraftCurrency() {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails.push({
            'currencyCode': '',
            'forexAmount': '',
            'startTime': ''
        });

        const currentIndex = this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails.length - 1;
        this.updateSession();
    }
    // endregion Add more currency for each product

    // region Update selected bank for prepaid card
    updateBankSelected(prepaidIndex, Currency, bank) {
        console.log(bank); console.log(Currency);
        const checkBankCond = bank.CustomerCode.indexOf(environment.DEFAULT_ISSUER_CODE);
        const checkCurrencyCond = Constants.PREPAID_CURRENCY_CODES.indexOf(Currency.currencyCode);
        if (checkBankCond === 0 && checkCurrencyCond !== -1) {
            this.CommonNotificationPopupComponent.initializeIssuerNotification();
        }

        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidIndex].bankname = bank.CustomerCode;
        this.updatePrepaidCurrencyCode(prepaidIndex, Currency.currencyCode, bank.CustomerCode);
        this.updateSession();
    }
    // endregion Update selected bank for prepaid card

    // region Close individual blocks within product
    removePrepaidRegion(index: number) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.splice(index, 1);
        this.updateUsedAmount();
    }

    removeCashRegion(index: number) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails.splice(index, 1);
        this.updateUsedAmount();
    }

    removeTravellerChequeRegion(index: number) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails.splice(index, 1);
        this.updateUsedAmount();
    }

    removeDemandDraftRegion(index: number) {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails.splice(index, 1);
        this.updateUsedAmount();
    }
    // endregion Close individual blocks within product

    // region Mutli-traveller logic
    addTravellerOption() {
        this.isLoggedIn ? this.showTravellerChoice() : this.addTraveller();
        this.selectTraveller(this.userSessionInfo.buyScreen.traveller.length - 1);
    }

    addTraveller() {
        if (this.userSessionInfo.buyScreen.traveller.length < 4) {
            this.userSessionInfo.buyScreen.traveller.push({
                'serviceCharge': 0,
                'loadFees': 0,
                'activationFees': 0,
                'discount': 0,
                'charges': 0,
                'gst': 0,
                'registrationInfo': {
                    'userId': '',
                    'invoiceNo': null,
                    'firstName': {
                        'value': '', 'checkCondition': {
                            'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false'
                        }
                    },
                    'middleName': '',
                    'lastName': '',
                    'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
                    'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                    'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                    'nationality': '',
                    'mothersMaidenName': {
                        'value': '', 'checkCondition':
                            'if(value.trim()==\'\'){console.log(\'Not ok\');event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}'
                            + 'else{console.log(\'Ok\');event.target.style.background=\'#f8f8f8\'}'
                    },
                    'PAN': {
                        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                            + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                            + 'event.target.style.background=\'#f8f8f8\'}'
                    },
                    'passportNumber': '',
                    'ParentId': false,
                    'dateOfIssue': '',
                    'placeOfIssue': '',
                    'expiryDate': '',
                    'address': '101 5A Galaxy apartment',
                    'isPassportAddressAsAdhar': 'false',
                    'adharAddress': {
                        'flatNumber': '',
                        'buildingName': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': '',
                    },
                    'passportAddress': {
                        'flatNumber': '',
                        'buildingName': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': '',
                    },
                    'currentAddressAs': 'asPerAdhar',
                    'otherAddress': {
                        'flatNumber': '',
                        'buildingName': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': '',
                    },
                    'contactDetails': {
                        'countryCode': '',
                        'mobileNo': '',
                        'countryCode2': '',
                        'cityCode': '',
                        'telephoneNo': '',
                        'emailId': '',
                    },
                    'alternateContactDetails': {
                        'countryCode': '',
                        'mobileNo': '',
                        'countryCode2': '',
                        'cityCode': '',
                        'telephoneNo': '',
                        'emailId': '',
                    },
                    'officeAddress': {
                        'designation': '',
                        'conpanyName': '',
                        'companyDivision': '',
                        'flatNumber': '',
                        'building': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': ''
                    },
                    'officeContactDetails': {
                        'countryCode': '',
                        'telephoneNumber': '',
                        'officeExtension': '',
                    }
                },
                'travellingDetails': {
                    'dateOfTravel': '',
                    'dateOfArrival': '',
                    'airlineName': '',
                    'ticketNumber': ''
                },
                'transactionDetails': [{
                    'beneficiaryFirstName': '',
                    'beneficiaryBlockNumber': '',
                    'beneficiaryBuilding': '',
                    'beneficiaryStreet': '',
                    'beneficiaryLandMark': '',
                    'beneficiaryArea': '',
                    'beneficiaryCity': '',
                    'beneficiaryState': '',
                    'beneficiaryPincode': '',
                    'beneficiaryCountry': '',
                    'beneficiaryAccountNo': '',
                    'beneficiaryBankName': '',
                    'beneficiarySwiftCode': '',
                    'beneficiaryRoutingNo': '',
                    'beneficiaryBankAddress': ''
                }],
                'selfTransaction': {
                    'beneficiaryTransSelf': '',
                    'beneficiaryTravellerName': '',
                    'beneficiaryTravellerRelationship': '',
                    'beneficiaryTravellerArrivalDate': '',
                    'beneficiaryTravellerEducation': '',
                    'beneficiaryTravellerCountry': ''
                }
            });

        } else {
            // swal('Oops...', 'Maximum 4 travellers allowed!', 'error');
            Snackbar.show({
                text: 'Maximum 4 travellers allowed!',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
        }
        this.updateSession();
    }

    removeTraveller(index: number) {
        if (!this.userSessionInfo.buyScreen.traveller[index].lead) {
            if (this.userSessionInfo.buyScreen.traveller[index].selected) {
                this.selectTraveller(index === 0 ? 1 : index - 1);
            }
            if (this.userSessionInfo.buyScreen.traveller[index].registrationInfo.contactDetails.emailId === '') {
                if (this._elementRef.nativeElement.querySelector('#chkbox-new-' + this.newTravellerCount) !== null) {
                    this._elementRef.nativeElement.querySelector('#chkbox-new-' + this.newTravellerCount).checked = false;
                }
                // this._elementRef.nativeElement.querySelector('#chkbox-new-' + this.newTravellerCount).checked = false;

                this.newTravellerCount--;
            }
            this.userSessionInfo.buyScreen.traveller.splice(index, 1);
            this.updateUsedAmount();
        } else {
            // swal('Sorry', 'You cannot remove lead pax. Change any other traveler to lead before this operation', 'error');
            Snackbar.show({
                text: 'You cannot remove lead pax. Change any other traveler to lead before this operation',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
        }
    }

    selectTraveller(travellerIndex) {
        console.log(travellerIndex);
        this.currentTravellerIndex = travellerIndex;
        this.userSessionInfo.buyScreen.traveller.forEach(traveller => {
            traveller.selected = false;
        });
        this.userSessionInfo.buyScreen.traveller[travellerIndex].selected = true;
        this.updateSession();
    }
    // endregion Mutli-traveller logic

    updateSession() {
        SessionHelper.setSession('userSessionInfo', JSON.stringify(this.userSessionInfo));
    }

    // submitAndRedirect() {
    //     this.userSessionInfo['nextLink'] = '/buy/checklist';
    //     this.updateSession();
    //     if (this.validateSession()) {
    //         this.masterService.dumpSessionData(this.userSessionInfo)
    //             .subscribe(data => {
    //             }, err => {
    //                 console.log(err);
    //             });

    //         //  console.log(this.userSessionInfo);
    //         this.router.navigateByUrl(this.navUrl.navUrl() + '/buy/checklist');
    //     }
    // }

    submitAndRedirect() {
        //   this.populateCurrencyRateForRule(this.CurrentBranchId);
        this.userSessionInfo['nextLink'] = '/buy/checklist';
        this.updateSession();
        if (this.validateSession()) {
            this.masterService.RuleTest(this.userSessionInfo)
                .subscribe(data => {
                    const resData: any = JSON.parse(data);
                    if (resData.status === 1) {
                        this.masterService.dumpSessionData(this.userSessionInfo)
                            .subscribe(resD => {

                            }, err => {
                                console.log(err);
                            });
                        this.router.navigateByUrl(this.navUrl.navUrl() + '/buy/checklist');
                    } else {
                        // swal('error', resData.message, 'error');
                        Snackbar.show({
                            text: resData.message,
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                    }
                }, err => {
                    console.log(err);
                });
        }
    }

    validateSession() {
        let result = true;

        if (this.userSessionInfo.buyScreen.branch === '' || this.userSessionInfo.buyScreen.branch === undefined) {
            // swal('Error', 'Please select branch', 'error');
            Snackbar.show({
                text: 'Please select branch',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
            result = false;
            this.invalidsubmitted = true;
        } else if (this.userSessionInfo.buyScreen.destination === '' || this.userSessionInfo.buyScreen.destination === undefined) {
            // swal('Error', 'Please select destination', 'error');
            Snackbar.show({
                text: 'Please select destination',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
            result = false;
            this.invalidsubmitted = true;
        } else {

            for (let travellerIndex = 0; travellerIndex < this.userSessionInfo.buyScreen.traveller.length; travellerIndex++) {
                const traveller = this.userSessionInfo.buyScreen.traveller[travellerIndex];

                if (!traveller.prepaidCard && !traveller.cash && !traveller.demandDraft && !traveller.travellerCheque) {
                    // swal('Error', 'You have not provided any data for traveler ' + (travellerIndex + 1), 'error');
                    Snackbar.show({
                        text: 'You have not provided any data for traveler ' + (travellerIndex + 1),
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    result = false;
                    this.selectTraveller(travellerIndex);
                    this.invalidsubmitted = true;
                    break;
                }

                if (traveller.purpose === '' || traveller.purpose === undefined) {
                    // swal('Error', 'Please select purpose for traveler ' + (travellerIndex + 1), 'error');
                    Snackbar.show({
                        text: 'Please select purpose for traveler ' + (travellerIndex + 1),
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    this.selectTraveller(travellerIndex);
                    result = false;
                    this.invalidsubmitted = true;
                    break;
                }

                if (traveller.prepaidCard) {
                    let index = 0;
                    for (; index < traveller.prepaidCardDetails.length; index++) {
                        const detail = traveller.prepaidCardDetails[index];
                        if (detail.currencyCode === '' || detail.currencyCode === undefined) {
                            // swal('Error', 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            result = false;
                            this.invalidsubmitted = true;
                            break;
                        }
                        if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
                            // swal('Error', 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            result = false;
                            this.invalidsubmitted = true;
                            break;
                        }
                        if (detail.bankname === '' || detail.bankname === undefined) {
                            // swal('Error', 'Please select bank for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please select bank for prepaid card of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            result = false;
                            this.invalidsubmitted = true;
                            break;
                        }
                    }

                    if (index < traveller.prepaidCardDetails.length) {
                        break;
                    }
                }
                if (traveller.cash) {
                    let index = 0;
                    for (; index < traveller.cashDetails.length; index++) {
                        const detail = traveller.cashDetails[index];
                        if (detail.currencyCode === '' || detail.currencyCode === undefined) {
                            // swal('Error', 'Please select currency for cash of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please select currency for cash of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            result = false;
                            this.invalidsubmitted = true;
                            break;
                        }
                        if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
                            // swal('Error', 'Please provide amount for cash of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please provide amount for cash of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            result = false;
                            this.invalidsubmitted = true;
                            break;
                        }
                    }
                    if (index < traveller.cashDetails.length) {
                        break;
                    }
                }
                if (traveller.travellerCheque) {
                    let index = 0;
                    for (; index < traveller.travellerChequeDetails.length; index++) {
                        const detail = traveller.travellerChequeDetails[index];
                        if (detail.currencyCode === '' || detail.currencyCode === undefined) {
                            // swal('Error', 'Please select currency for traveler cheque of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please select currency for traveler cheque of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            result = false;
                            this.invalidsubmitted = true;
                            break;
                        }
                        if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
                            // swal('Error', 'Please provide amount for traveler cheque of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please provide amount for traveler cheque of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            result = false;
                            this.invalidsubmitted = true;
                            break;
                        }
                    }
                    if (index < traveller.travellerChequeDetails.length) {
                        break;
                    }
                }
                if (traveller.demandDraft) {
                    let index = 0;
                    for (; index < traveller.demandDraftDetails.length; index++) {
                        const detail = traveller.demandDraftDetails[index];
                        if (detail.currencyCode === '' || detail.currencyCode === undefined) {
                            // swal('Error', 'Please select currency for demand draft of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please select currency for demand draft of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            this.invalidsubmitted = true;
                            result = false;
                        }
                        if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
                            // swal('Error', 'Please provide amount for demand draft of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please provide amount for demand draft of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            this.invalidsubmitted = true;
                            result = false;
                        }
                    }
                    if (index < traveller.demandDraftDetails.length) {
                        break;
                    }
                }
            }
        }
        return result;
    }


    runPromotionalFunctions(promotionName: any) {
        console.log(promotionName);
        this.masterService.getPromotionalData(promotionName).subscribe(
            (data) => {
                this.PromotionalData = data;
                SessionHelper.setSession('PromotionalData', JSON.stringify(this.PromotionalData));
                //  this.destinationOptions = this.PromotionalData.DestinationsList;
                // tslint:disable-next-line:max-line-length
                this.defaultissuercode = this.Promoter && this.PromotionalData ? this.PromotionalData.buyScreen.IssuerLists[0].CustomerCode : environment.DEFAULT_ISSUER_CODE;
                this.branchOptions = this.PromotionalData.BranchList;
                this.currencyList = this.PromotionalData.buyScreen.PrpaidCurrencyLists;
            }, (error) => {
                SessionHelper.removeSession('promotion');
                SessionHelper.removeSession('PromotionalData');
                this.Promoter = undefined;
                this.PromotionalData = undefined;
            }
        );
    }
}
