import { BulkExchangeRateService } from './../../services/bulk-exchange-rate.service';
import { Component, OnInit, Inject, DoCheck, OnDestroy } from '@angular/core';

import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

declare function initDocument(): any;
declare function initForms(): any;
declare var $: any;
declare var Snackbar: any;
@Component({
  selector: 'app-forex-review',
  templateUrl: './forex-review.component.html',
  styleUrls: ['./forex-review.component.css']
})
export class ForexReviewComponent implements OnInit, DoCheck {

  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public serviceCharge: any = 0;
  public ddCharged: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public gst: any = 72;
  public discount: any = 0;
  public mutitravellerTotalAmount: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public currentTravellerIndex: any;
  public currencyLists: any = [];
  public currencyDetail: any;
  public travellerOfficeAddress: any = [];
  iterationNum: any = 1;
  public extraStep: boolean;
  public _primaryComp: any;
  public _BulkEvent: any;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfo'));
    this._primaryComp = '/' + navUrl.navUrl();
    this.userSessionInfoRegistration = this.userSessionInfo.buyScreen.traveller[0].registrationInfo;
    this.userSessionInfoTravellingDetails = this.userSessionInfo.buyScreen.traveller[0].travellingDetails;
    this.userSessionInfoTravellers = this.userSessionInfo.buyScreen.traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.buyScreen.traveller[0];
    this.userSessionInfoTravellers[0].selected = true;
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];
    this.currentTravellerIndex = 0;
    this.masterService.getCurrencyList(1).subscribe((data) => {
      this.currencyLists = data;
    });
    this.getCharges();
    this._document.title = 'Review your current transaction details';
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Review your current transaction details' });
    // this.syncSession();
  }

  ngOnInit(): void {
    initDocument();
    initForms();
    $('body').attr('id', '');
    this.concatOfficeAddress();
    //this.syncSession();
    this.userSessionInfo.buyScreen.traveller.forEach(element => {
      if (element.demandDraft) {

        this.extraStep = true;
      }
    });

  }

  ngDoCheck(): void {
  }

  updateSession() {
    SessionHelper.setSession('userSessionInfo', JSON.stringify(this.userSessionInfo));
  }

  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.currentTravellerIndex = travellerIndex;
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
    // console.log(this.userSessionInfoTravellers[travellerIndex]);
  }

  populatePopup(currencyCode, forexAmount, exchangeRate) {
    this.currencyLists.map((currency, index) => {
      if (currency.Code === currencyCode) {
        this.currencyDetail =
          '1 ' + currency.label + ' = <i class="fa-rupee"></i>' + exchangeRate + '<br>' +
          forexAmount + ' ' + currency.Code + ' = ' + '<i class="fa-rupee"></i>' + (forexAmount * exchangeRate).toFixed(2);
      }
    });
  }

  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.serviceCharge = Charges.response.serviceCharge;
      this.loadFees = Charges.response.LoadFee;
      this.activationFees = Charges.response.ActivationCharge;
      this.ddCharged = Charges.response.DD_Charges ? Charges.response.DD_Charges : 0;
      this.syncSession();
      this.updateSession();
      console.log(Charges);
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  onSaveAndTemporaryExit() {
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession('userSessionInfo');
    this.router.navigateByUrl(this.navUrl.navUrl() + `/buy`);
  }

  submitAndRedirect() {
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.setSession('userSessionInfo', JSON.stringify(this.userSessionInfo));
    this.router.navigateByUrl(this.navUrl.navUrl() + '/buy/lrs');
  }


  syncSession() {
    let totalAmount: any = 0;
    let grantTotalAmount: any = 0;
    this.mutitravellerTotalAmount = 0;
    this.userSessionInfoTravellers.forEach(traveller => {
      let charges = 0;
      traveller.selected = false;
      traveller.serviceCharge = this.serviceCharge;
      traveller.loadFees = this.loadFees;
      traveller.activationFees = this.activationFees;
      traveller.discount = this.discount;
      traveller.ddCharged = this.ddCharged;
      // console.log(traveller);
      if (traveller.cash) {
        traveller.cashDetails.map((cash) => {
          // console.log(cash);
          totalAmount += (cash.forexAmount * cash.exchangeRate.rate) - this.discount;
        });
      }
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.map((prepaidCard) => {
          // console.log(prepaidCard);
          totalAmount += (prepaidCard.forexAmount * prepaidCard.exchangeRate.rate) - this.discount;
        });
      }

      if (traveller.travellerCheque) {
        traveller.travellerChequeDetails.map((travellerCheque) => {
          //  console.log(travellerCheque);
          totalAmount += (travellerCheque.forexAmount * travellerCheque.exchangeRate.rate) - this.discount;
        });
      }

      if (traveller.demandDraft) {
        traveller.demandDraftDetails.map((demandDraft) => {
          // console.log(demandDraft);
          totalAmount += (demandDraft.forexAmount * demandDraft.exchangeRate.rate) - this.discount;
        });
      }
      charges += this.serviceCharge;
      traveller.totalAmount = totalAmount + this.serviceCharge;
      if (traveller.prepaidCard) {
        traveller.totalAmount += this.activationFees + this.loadFees;
        charges += this.activationFees + this.loadFees;
      }
      // tslint:disable-next-line:one-line
      if (traveller.demandDraft) {
        traveller.totalAmount += this.ddCharged;
        charges += this.ddCharged;
      }
      // tslint:disable-next-line:radix
      traveller.totalAmount += parseInt(this.userSessionInfo.buyScreen.deliveryInfo.rate);
      let totalTaxAmount = traveller.totalAmount;

      const getTaxes = this.masterService.getTaxes(totalTaxAmount).subscribe((data) => {
        if (getTaxes) {
            getTaxes.unsubscribe();
        }
        const result: any = data;

        // console.log(traveller.totalAmount);
        totalTaxAmount += result.TotalTax;
        traveller.totalAmount = totalTaxAmount;
        // charges += result.TotalTax;
        traveller.Charges = charges;
        traveller.gst = result.TotalTax;
        grantTotalAmount += traveller.totalAmount;
        this.userSessionInfo.buyScreen.usedAmount = grantTotalAmount;
        this.updateSession();
      });
      // this.mutitravellerTotalAmount += traveller.totalAmount  ;
      //  console.log('Total Amount', totalAmount);
      //  console.log('Grand Total Amount', this.mutitravellerTotalAmount);
      totalAmount = 0;
      // console.log(traveller);
      this.updateSession();
    });
    // console.log(this.mutitravellerTotalAmount);
    this.updateSession();
  }

  concatOfficeAddress() {
    const nonAdressParam = ['conpanyName', 'companyName', 'designation', 'companyDivision', 'pincode'];
    this.travellerOfficeAddress = [];
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      // tslint:disable-next-line:prefer-const
      let addressText = '', officeAddress = traveller.registrationInfo.officeAddress, counter = 0, pincodeAdded = false;
      // tslint:disable-next-line:forin
      for (const travellerData in officeAddress) {
        if (nonAdressParam.indexOf(travellerData) === -1 && officeAddress[travellerData]) {
          addressText += officeAddress[travellerData] + ', ';
          counter++;
        }
        if (travellerData === 'pincode' && officeAddress[travellerData]) {
          if (counter > 0) {
            addressText = this.replaceLastCommaWith(addressText, '-') + officeAddress[travellerData];
          } else {
            addressText += officeAddress[travellerData];
          }
          pincodeAdded = true;
        }
      }
      if ((counter > 0 && pincodeAdded) || pincodeAdded) {
        addressText += '.';
      } else if (counter > 0) {
        addressText += this.replaceLastCommaWith(addressText, '.');
      }
      this.travellerOfficeAddress[index] = addressText;
    });
  }

  replaceLastCommaWith(text, element) {
    const pos = text.lastIndexOf(',');
    return text.substring(0, pos) + ' ' + element + ' ' + text.substring(pos + 1);
  }





}
