import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForexReviewComponent } from './forex-review.component';

describe('ForexReviewComponent', () => {
  let component: ForexReviewComponent;
  let fixture: ComponentFixture<ForexReviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForexReviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForexReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
