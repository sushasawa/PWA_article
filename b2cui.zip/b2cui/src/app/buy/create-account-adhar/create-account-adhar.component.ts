import { Component, OnInit } from '@angular/core';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;

@Component({
  selector: 'app-create-account-adhar',
  templateUrl: './create-account-adhar.component.html',
  styleUrls: ['./create-account-adhar.component.css']
})
export class CreateAccountAdharComponent implements OnInit {
  public _primaryComp: any;
  constructor(private navUrl: NavigatePathService) {
    this._primaryComp = '/' + navUrl.navUrl();
  }

  ngOnInit(): void {
    $('body').attr('id', '');
  }
}
