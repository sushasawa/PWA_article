import { Component, OnInit, Inject } from '@angular/core';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { Constants } from '../../../app/helpers/constants';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { DpDatePickerModule } from 'ng2-date-picker';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import * as moment from 'moment';
declare function initDocument(): any;
declare function initForms(): any;
declare var $: any;
declare var Snackbar: any;
declare function swal(headerMessage, message, type): any;
@Component({
  selector: 'app-forex-review-edit',
  templateUrl: './forex-review-edit.component.html',
  styleUrls: ['./forex-review-edit.component.css']
})
export class ForexReviewEditComponent implements OnInit {

  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public gst: any = 72;
  public discount: any = 0;
  public mutitravellerTotalAmount: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public currencyLists: any = [];
  public currencyDetail: any;
  public iterationNum: any = 1;
  public airlineNames: any;
  public currencyList: any;
  public currencyListCash: any;
  public currencyListTravellerCheque: any;
  public currencyListDemandDraft: any;
  public bankOptions: any = [];
  public HOME_STATNDARD_AMOUNT: any;
  public HOME_EXPRESS_AMOUNT: any;
  public OFFICE_STATNDARD_AMOUNT: any;
  public OFFICE_EXPRESS_AMOUNT: any;
  public config: any;
  public ddCharged: any = 0;
  public todaysDate: any;
  public timeconfig: any;
  public isPickUpMode: any;
  public travellingDate: any;
  public _primaryComp: any;
  public Promoter: any;
  public PromotionalData: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfo')); console.log(this.userSessionInfo);
    this.userSessionInfoRegistration = this.userSessionInfo.buyScreen.traveller[0].registrationInfo;
    this.userSessionInfoTravellingDetails = this.userSessionInfo.buyScreen.traveller[0].travellingDetails;
    this._primaryComp = '/' + navUrl.navUrl();
    this.userSessionInfoTravellers = this.userSessionInfo.buyScreen.traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.buyScreen.traveller[0];
    this._document.title = 'Review and edit your current transaction details';
    // tslint:disable-next-line:max-line-length
    this.Promoter = SessionHelper.getSession('promotion');
    if (this.Promoter && SessionHelper.getSession('PromotionalData')) {
      this.PromotionalData = JSON.parse(SessionHelper.getSession('PromotionalData'));
    }
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Review and edit your current transaction details' });
    this.getCharges();
    // this.syncSession();
    // this.updateUsedAmount();
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[0].selected = true;
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];

    this.masterService.getAirlineNames()
      .subscribe(data => {
        this.airlineNames = data;
      });

    this.todaysDate = this.masterService.getTodaysDate();
    this.config = {
      format: 'DD-MM-YYYY',
      showMultipleYearsNavigation: true,
      disableKeypress: true,
      min: this.todaysDate,
      max: this.masterService.addDateMoment(this.todaysDate, 10, 'days')
    };
    this.timeconfig = {
      showMultipleYearsNavigation: true,
      min: this.getMinTime(),
      max: '18:30',
      disableKeypress: true,
      format: 'HH:mm'
    };
    this.userSessionInfo.buyScreen.traveller.forEach(traveller => {
      if (traveller.travellingDetails.dateOfTravel) {
        if (!this.travellingDate) {
          this.travellingDate = traveller.travellingDetails.dateOfTravel;
        } else {
          const diff = this.masterService.getDateDifference(this.travellingDate, traveller.travellingDetails.dateOfTravel);
          if (diff > 0) {
            this.travellingDate = traveller.travellingDetails.dateOfTravel;
          }
        }
      }
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.forEach((detail, index) => {
          if (this.Promoter && this.PromotionalData) {
            this.bankOptions[index] = this.PromotionalData.buyScreen.IssuerLists;
          } else {
            this.masterService.getBankList(detail.currencyCode)
              .subscribe(data => {
                this.bankOptions[index] = data;
                this.bankOptions[index].forEach(element => {
                  element.Logo = Constants.serviceUrl + '/' + element.Logo;
                }, err => {
                  this.showAlert('Unable to fetch bank list!');
                });
              });
          }
        });
      }
    });
    console.log(this.userSessionInfo.mode);
    this.masterService.getDeliveryAmt(this.userSessionInfo.mode).subscribe((data) => {
      const deliveryData: any = data;
      deliveryData.map((delivery) => {
        if (delivery.DeliveryType === 'HomeVisit') {
          this.HOME_STATNDARD_AMOUNT = delivery.StandardDelivery;
          this.HOME_EXPRESS_AMOUNT = delivery.ExpressDelivery;
        }

        if (delivery.DeliveryType === 'OfficeVisit') {
          this.OFFICE_STATNDARD_AMOUNT = delivery.StandardDelivery;
          this.OFFICE_EXPRESS_AMOUNT = delivery.ExpressDelivery;
        }
      });
    });
    this.populateCashCurrency();
    this.populateDemandDraftCurrency();
    this.populatePrepaidCurrency();
    this.populatePrepaidCurrency();
  }



  ngOnInit() {
    initDocument();

    // initForms();
    if (this.userSessionInfo.buyScreen.deliveryInfo.Mode === 'Pick Up') {
      this.isPickUpMode = true;
    }
    $('body').attr('id', '');
  }

  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.serviceCharge = Charges.response.serviceCharge;
      this.loadFees = Charges.response.LoadFee;
      this.activationFees = Charges.response.ActivationCharge;
      this.ddCharged = Charges.response.DD_Charges ? Charges.response.DD_Charges : 0;
      this.syncSession();
      this.updateUsedAmount();
      console.log(Charges);
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
    // console.log(this.userSessionInfoTravellers[travellerIndex]);
  }



  populatePopup(currencyCode, forexAmount, exchangeRate) {
    this.currencyLists.map((currency, index) => {
      if (currency.Code === currencyCode) {
        this.currencyDetail =
          '1 ' + currency.label + ' = <i class="fa-rupee"></i>' + exchangeRate + '<br>' +
          forexAmount + ' ' + currency.Code + ' = ' + '<i class="fa-rupee"></i>' + (forexAmount * exchangeRate).toFixed(2);
      }
    });
  }




  updateReview(editReview: NgForm, e: Event) {
    e.preventDefault();
    //  console.log(this.userSessionInfo);
    if (this.validateSession()) {
      this.masterService.RuleTest(this.userSessionInfo)
        .subscribe(data => {
          const resData: any = JSON.parse(data);
          if (resData.status === 1) {
            SessionHelper.setSession('userSessionInfo', JSON.stringify(this.userSessionInfo));
            Snackbar.show({
              text: 'Updated.',
              pos: 'bottom-right',
              actionTextColor: '#05ff01',
            });
            this.router.navigateByUrl(this.navUrl.navUrl() + '/buy/forex-review');
          } else {
            // swal('error', resData.message, 'error');
            Snackbar.show({
              text: resData.message,
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
            });
          }
        }, err => {
          console.log(err);
        });
    }

  }

  deliveryDate(event: any) {
    // tslint:disable-next-line:prefer-const
    let additionHours = 3, saturdayCheck: any;
    if (event !== undefined && typeof event !== 'object') {
      if (!this.verifyDateTime(event)) {
        this.updateDateTime();
        return;
      }
      let hourMin = '', hourMax = '';
      if (event === this.todaysDate) {
        if (!this.isPickUpMode) {
          const time = moment().add(additionHours, 'hours');
          if (Number(time.format('HH')) < 10) {
            hourMin = '10:00';
          } else {
            hourMin = time.format('HH') + ':' + time.format('mm');
          }
        }
      } else {
        hourMin = '10:00';
      }
      this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.time = hourMin;
      saturdayCheck = this.checkForSaturday(event);
      if (saturdayCheck.flag) {
        hourMax = '16:00';
      } else {
        hourMax = '18:30';
      }
      this.timeconfig = {
        format: 'HH:mm',
        min: hourMin,
        max: hourMax
      };
      this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.date = event;
    }
  }

  getMinTime() {
    const deliveryDate = this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.date;
    if (deliveryDate === this.todaysDate) {
      let time;
      if (this.isPickUpMode) {
        time = moment().add(0, 'hours');
      } else {
        time = moment().add(3, 'hours');
      }
      this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.time = time.format('HH') + ':' + time.format('mm');
      return time.format('HH') + ':' + time.format('mm');
    }
    this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.time = '10:00';
    return '10:00';
  }

  verifyDateTime(dateValue) {
    let maxDayTime = 15, maxMins = 30, displayTime = '3:30';
    // tslint:disable-next-line:prefer-const
    let timeHour: any = this.masterService.getCurrentTime(), diff;
    const saturdayCheck: any = this.checkForSaturday(dateValue);
    if (this.isPickUpMode) {
      maxDayTime = 18; maxMins = 30; displayTime = '6:30';
    }
    if (saturdayCheck.flag) {
      maxDayTime = saturdayCheck.hrs;
      maxMins = saturdayCheck.mins;
      displayTime = saturdayCheck.text;
    }
    if (this.travellingDate) {
      diff = this.masterService.getDateDifference(this.travellingDate, dateValue);
      if (diff <= 0) {
        this.showAlert('Delivery date should be at least 1 day before travelling date.');
        return false;
      }
    }
    if (this.isPickUpMode && dateValue === this.todaysDate && +timeHour.hour >= maxDayTime && +timeHour.mins >= maxMins) {
      this.showAlert('Same day pickup available before ' + displayTime + ' PM. Please select next working day.');
      return false;
    } else
      if (!this.isPickUpMode && dateValue === this.todaysDate && +timeHour.hour >= maxDayTime && +timeHour.mins >= maxMins) {
        this.showAlert('Same day delivery available if you book an order before ' + displayTime + ' PM. Please select next working day.');
        return false;
      }
    // if (dateValue !== this.todaysDate) {
    if (this.isNotWrokingDay(dateValue, true) || this.isNextTwoWorkingDays(dateValue)) {
      // this.showAlert('Delivery date should be with in next 2 working days from today.')
      return false;
    }
    // }
    return true;
  }

  isNextTwoWorkingDays(dateValue) {
    let nextDay = this.todaysDate, counter = 0;
    while (nextDay !== dateValue) {
      nextDay = this.masterService.addDateMoment(nextDay, 1, 'days');
      if (!this.isNotWrokingDay(nextDay, false)) {
        counter++;
        if (counter > 2) {
          this.showAlert('Delivery date should be within next 2 working days from today.');
          return true;
        }
      }
    }
    return false;
  }

  isNotWrokingDay(dateValue, flag) {
    // tslint:disable-next-line:prefer-const
    const daySelected = moment(dateValue, 'DD-MM-YYYY').format('ddd'),
      weekEndDays = ['Sun'],
      holyDaysList = ['15-02-2018', '22-02-2018', '20-02-2018'];
    if (weekEndDays.indexOf(daySelected) !== -1 || holyDaysList.indexOf(dateValue) !== -1) {
      if (flag) {
        switch (daySelected) {
          case 'Sat':
            this.showAlert('Deliveries not possible on Saturdays.');
            break;
          case 'Sun':
            this.showAlert('Deliveries not possible on Sundays.');
            break;
          default:
            this.showAlert(dateValue + ' is non-working day, please select another working day.');
        }
      }
      return true;
    }
    return false;
  }

  showAlert(message) {
    Snackbar.show({
      text: message,
      pos: 'bottom-right',
      actionTextColor: '#ff4444',
      duration: 3000
    });
  }

  updateDateTime() {
    this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.date = '';
    this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.time = '';
  }

  checkForSaturday(dateValue) {
    const daySelected = moment(dateValue, 'DD-MM-YYYY').format('ddd');
    if (daySelected === 'Sat') {
      if (this.isPickUpMode) {
        return { flag: true, hrs: 16, mins: 0, text: '4:00' };
      }
      return { flag: true, hrs: 13, mins: 0, text: '1:00' };
    }
    return { flag: false };
  }


  populateCashCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(2, destination)
      .subscribe(data => {
        this.currencyListCash = data;
      }, err => {
        //swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Unable to fetch currency list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  populatePrepaidCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
    if (this.Promoter && this.PromotionalData) {
      this.currencyList = this.PromotionalData.buyScreen.PrpaidCurrencyLists;
    } else {
      this.masterService.getCurrencyList(1, destination)
        .subscribe(data => {
          this.currencyList = data;
        }, err => {
          //swal('Oops...', 'Unable to fetch currency list!', 'error');
          Snackbar.show({
            text: 'Unable to fetch currency list!',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        });
    }
  }


  populateTravellersCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(3, destination)
      .subscribe(data => {
        this.currencyListTravellerCheque = data;
      }, err => {
        //swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Unable to fetch currency list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  populateDemandDraftCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(4, destination)
      .subscribe(data => {
        this.currencyListDemandDraft = data;
      }, err => {
        //swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Unable to fetch currency list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  updateBank(TravellerIndex, prepaidCardIndex, CurrencyCode, BankName) {
    console.log(BankName);
    this.userSessionInfoTravellers[TravellerIndex].prepaidCardDetails[prepaidCardIndex].bankname = BankName.CustomerCode;
    this.updatePrepaidCurrencyCode(TravellerIndex, prepaidCardIndex, CurrencyCode, BankName.CustomerCode);
  }


  updatePrepaidCurrencyCode(TravellerIndex: any, prepaidDetailIndex: number, newValue: string, BankCode: any = 'ICICIMCC') {
    const bankname = this.userSessionInfoTravellers[TravellerIndex].prepaidCardDetails[prepaidDetailIndex].bankname;
    this.userSessionInfoTravellers[TravellerIndex].prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
    // tslint:disable-next-line:max-line-length
    this.masterService.getExchangeRate(newValue, Number.parseInt(SessionHelper.getLocal('branchIdFromOverviewBuy')), 'prepaid', 'sell', bankname)
      .subscribe(data => {
        this.userSessionInfoTravellers[TravellerIndex].prepaidCardDetails[prepaidDetailIndex]
          .exchangeRate = data;
        this.syncSession();
        this.updateUsedAmount();
        console.log('Exchange rate called');
      }, err => {
        //swal('Oops...', 'Unable to fetch exchange rate!', 'error');
        Snackbar.show({
          text: 'Unable to fetch exchange rate!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
    if (this.Promoter && this.PromotionalData) {
      this.bankOptions[prepaidDetailIndex] = this.PromotionalData.buyScreen.IssuerLists;
    } else {
      this.masterService.getBankList(newValue)
        .subscribe(data => {
          this.bankOptions[prepaidDetailIndex] = data;

          this.bankOptions[prepaidDetailIndex].forEach(element => {
            element.Logo = Constants.serviceUrl + '/' + element.Logo;
          });
        }, err => {
          //swal('Oops...', 'Unable to fetch bank list!', 'error');
          Snackbar.show({
            text: 'Unable to fetch bank list!',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        });
    }
  }


  updateCashCurrencyCode(TravellerIndex: any, cashDetailIndex: number, newValue: string) {
    this.userSessionInfoTravellers[TravellerIndex].cashDetails[cashDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.buyScreen.branch, 'cash', 'sell')
      .subscribe(data => {
        this.userSessionInfoTravellers[TravellerIndex].cashDetails[cashDetailIndex].exchangeRate = data;
        this.syncSession();
        this.updateUsedAmount();
      }, err => {
        //swal('Oops...', 'Unable to fetch exchange rate!', 'error');
        Snackbar.show({
          text: 'Unable to fetch exchange rate!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  updateDemandDraftCurrencyCode(TravellerIndex: any, demandDraftDetailIndex: number, newValue: string) {
    this.userSessionInfoTravellers[TravellerIndex].demandDraftDetails[demandDraftDetailIndex]
      .currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.buyScreen.branch, 'prepaid', 'sell')
      .subscribe(data => {
        this.userSessionInfoTravellers[TravellerIndex].demandDraftDetails[demandDraftDetailIndex]
          .exchangeRate = data;
        this.syncSession();
        this.updateUsedAmount();
      }, err => {
        //swal('Oops...', 'Unable to fetch exchange rate!', 'error');
        Snackbar.show({
          text: 'Unable to fetch exchange rate!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  deliveryModes(mode: String) {
    console.log(mode);
    if (this.isPickUpMode === true && mode !== 'Pick Up') {
      this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.time = '';
    }
    if (mode === 'Pick Up') {
      this.isPickUpMode = true;
      this.deliveryTypeAndRate('', 0);
    } else {
      this.isPickUpMode = false;
      this.deliveryTypeAndRate('Standard', this.HOME_STATNDARD_AMOUNT);
    }
    this.userSessionInfo.buyScreen.deliveryInfo.Mode = mode;
    console.log(this.userSessionInfo.buyScreen.deliveryInfo);
  }

  deliveryTypeAndRate(type: String, rate: any) {
    this.userSessionInfo.buyScreen.deliveryInfo.type = type;
    this.userSessionInfo.buyScreen.deliveryInfo.rate = rate;
    this.syncSession();
    this.updateUsedAmount();
  }

  // deliveryDate(event: any) {
  //   console.log('Delivery Date' + event);
  //   if (event !== undefined && typeof event !== 'object') {
  //     this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.date = event;
  //   }
  // }


  travellingStartDate(event, TravellerIndex) {
    console.log(event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfoTravellers[TravellerIndex].travellingDetails.dateOfTravel = event;
      this.travellingDate = '';
      this.userSessionInfo.buyScreen.traveller.forEach(traveller => {
        if (traveller.travellingDetails.dateOfTravel) {
          if (!this.travellingDate) {
            this.travellingDate = traveller.travellingDetails.dateOfTravel;
          } else {
            const diff = this.masterService.getDateDifference(this.travellingDate, traveller.travellingDetails.dateOfTravel);
            if (diff > 0) {
              this.travellingDate = traveller.travellingDetails.dateOfTravel;
            }
          }
        }
      });
    }

  }

  travellingArrivaltDate(event, TravellerIndex) {
    console.log(event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfoTravellers[TravellerIndex].travellingDetails.dateOfArrival = event;
    }
  }
  deliveryTime(event: any) {
    if (event !== undefined && typeof event !== 'object') {
      console.log('updated');
      this.userSessionInfo.buyScreen.deliveryInfo.DeliverySchedule.time = event;
    }
  }
  syncSession() {
    let totalAmount: any = 0;
    this.mutitravellerTotalAmount = 0;
    this.userSessionInfoTravellers.forEach(traveller => {
      // traveller.selected = false;
      // console.log(traveller);
      let charges = 0;
      if (traveller.cash) {
        traveller.cashDetails.map((cash) => {
          // console.log(cash);
          totalAmount += (cash.forexAmount * cash.exchangeRate.rate) - this.discount;
        });
      }
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.map((prepaidCard) => {
          // console.log(prepaidCard);
          totalAmount += (prepaidCard.forexAmount * prepaidCard.exchangeRate.rate) - this.discount;
        });
      }

      if (traveller.travellerCheque) {
        traveller.travellerChequeDetails.map((travellerCheque) => {
          //  console.log(travellerCheque);
          totalAmount += (travellerCheque.forexAmount * travellerCheque.exchangeRate.rate) - this.discount;
        });
      }

      if (traveller.demandDraft) {
        traveller.demandDraftDetails.map((demandDraft) => {
          // console.log(demandDraft);
          totalAmount += (demandDraft.forexAmount * demandDraft.exchangeRate.rate) - this.discount;
        });
      }

      charges += this.serviceCharge;
      traveller.totalAmount = totalAmount + this.serviceCharge;

      if (traveller.prepaidCard) {
        traveller.totalAmount += this.activationFees + this.loadFees;
        charges += this.activationFees + this.loadFees;
      }

      if (traveller.demandDraft) {
        traveller.totalAmount += this.ddCharged;
        charges += this.ddCharged;
      }
      traveller.totalAmount += Number(this.userSessionInfo.buyScreen.deliveryInfo.rate);
      const totalTaxAmount = traveller.totalAmount;

      this.masterService.getTaxes(totalTaxAmount).subscribe((data) => {
        const result: any = data;

        // console.log(traveller.totalAmount);
        traveller.totalAmount += result.TotalTax;
        // charges += result.TotalTax;
        traveller.Charges = charges;
        traveller.gst = result.TotalTax;
        this.mutitravellerTotalAmount += traveller.totalAmount;
        this.userSessionInfo.buyScreen.usedAmount = this.mutitravellerTotalAmount;
        this.updateSession();
      });
      // this.mutitravellerTotalAmount += traveller.totalAmount  ;
      //  console.log('Total Amount', totalAmount);
      //  console.log('Grand Total Amount', this.mutitravellerTotalAmount);
      totalAmount = 0;
      // console.log(traveller);
    });
    // console.log(this.mutitravellerTotalAmount);
  }

  updateUsedAmount() {
    let travellerTotal = 0;
    console.log('USED AMOUNT CALLED');
    this.userSessionInfo.buyScreen.traveller.forEach(currentTraveller => {
      let currentTravellerTotal = 0;
      if (currentTraveller.prepaidCard) {
        currentTraveller.prepaidCardDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.cash) {
        currentTraveller.cashDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.travellerCheque) {
        currentTraveller.travellerChequeDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.demandDraft) {
        currentTraveller.demandDraftDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }

      travellerTotal += currentTravellerTotal;
      currentTraveller.usedAmount = currentTravellerTotal;
    });


    this.userSessionInfo.buyScreen.usedAmount = travellerTotal;

    if (this.userSessionInfo.buyScreen.usedAmount !== 0) {
      this.masterService.getTaxes(this.userSessionInfo.buyScreen.usedAmount)
        .subscribe(res => {
          const result: any = res;
          this.userSessionInfo.buyScreen.usedAmount += result.TotalTax;
          this.updateBalanceAmount();
          console.log('AMOUNT' + this.userSessionInfo.buyScreen.usedAmount, 'TAXES' + result.TotalTax);
        }, err => {
          // swal('Oops', 'Error fetching taxes', 'error');
          Snackbar.show({
            text: 'Error fetching taxes',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        });
    }

    this.updateBalanceAmount();
  }
  updateBalanceAmount() {
    if (Number.isNaN(Number.parseInt(this.userSessionInfo.buyScreen.budgetAmount))) {
      this.userSessionInfo.buyScreen.balanceAmount = '';
    } else if (this.userSessionInfo.buyScreen.budgetAmount !== '0' && this.userSessionInfo.buyScreen.budgetAmount !== 0) {
      this.userSessionInfo.buyScreen.balanceAmount = (this.userSessionInfo.buyScreen.budgetAmount
        - this.userSessionInfo.buyScreen.usedAmount);
      this.userSessionInfo.buyScreen.balanceAmount
        = this.userSessionInfo.buyScreen.balanceAmount < 0 ? 0 : this.userSessionInfo.buyScreen.balanceAmount;
      if (this.userSessionInfo.buyScreen.budgetAmount - this.userSessionInfo.buyScreen.usedAmount <= 0) {
        // swal('Oops', 'You have exceeded your budget!!', 'warning');
        Snackbar.show({
          text: 'You have exceeded your budget!!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }
    }
    this.updateSession();
  }

  validateSession() {
    let result = true;

    if (this.userSessionInfo.buyScreen.branch === '' || this.userSessionInfo.buyScreen.branch === undefined) {
      // swal('Error', 'Please select branch', 'error');
      Snackbar.show({
        text: 'Please select branch',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      result = false;
    } else if (this.userSessionInfo.buyScreen.destination === '' || this.userSessionInfo.buyScreen.destination === undefined) {
      // swal('Error', 'Please select destination', 'error');
      Snackbar.show({
        text: 'Please select destination',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      result = false;
    } else {

      for (let travellerIndex = 0; travellerIndex < this.userSessionInfo.buyScreen.traveller.length; travellerIndex++) {
        const traveller = this.userSessionInfo.buyScreen.traveller[travellerIndex];

        if (!traveller.prepaidCard && !traveller.cash && !traveller.demandDraft && !traveller.travellerCheque) {
          // swal('Error', 'You have not provided any data for traveler ' + (travellerIndex + 1), 'error');
          Snackbar.show({
            text: 'You have not provided any data for traveler ' + (travellerIndex + 1),
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
          result = false;
          break;
        }

        if (traveller.purpose === '' || traveller.purpose === undefined) {
          // swal('Error', 'Please select purpose for traveler ' + (travellerIndex + 1), 'error');
          Snackbar.show({
            text: 'Please select purpose for traveler ' + (travellerIndex + 1),
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });

          result = false;
          break;
        }

        if (traveller.prepaidCard) {
          let index = 0;
          for (; index < traveller.prepaidCardDetails.length; index++) {
            const detail = traveller.prepaidCardDetails[index];
            if (detail.currencyCode === '' || detail.currencyCode === undefined) {
              // swal('Error', 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });

              result = false;
              break;
            }
            if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
              // swal('Error', 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });



              result = false;
              break;
            }
            if (detail.bankname === '' || detail.bankname === undefined) {
              //swal('Error', 'Please select bank for prepaid card of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Please select bank for prepaid card of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });


              result = false;
              break;
            }
          }

          if (index < traveller.prepaidCardDetails.length) {
            break;
          }
        }
        if (traveller.cash) {
          let index = 0;
          for (; index < traveller.cashDetails.length; index++) {
            const detail = traveller.cashDetails[index];
            if (detail.currencyCode === '' || detail.currencyCode === undefined) {
              // swal('Error', 'Please select currency for cash of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Please select currency for cash of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });


              result = false;
              break;
            }
            if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
              // swal('Error', 'Please provide amount for cash of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Please provide amount for cash of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });

              result = false;
              break;
            }
          }
          if (index < traveller.cashDetails.length) {
            break;
          }
        }
        if (traveller.travellerCheque) {
          let index = 0;
          for (; index < traveller.travellerChequeDetails.length; index++) {
            const detail = traveller.travellerChequeDetails[index];
            if (detail.currencyCode === '' || detail.currencyCode === undefined) {
              // swal('Error', 'Please select currency for traveler cheque of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Please select currency for traveler cheque of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });

              result = false;
              break;
            }
            if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
              // swal('Error', 'Please provide amount for traveler cheque of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Please provide amount for traveler cheque of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });
              result = false;
              break;
            }
          }
          if (index < traveller.travellerChequeDetails.length) {
            break;
          }
        }
        if (traveller.demandDraft) {
          let index = 0;
          for (; index < traveller.demandDraftDetails.length; index++) {
            const detail = traveller.demandDraftDetails[index];
            if (detail.currencyCode === '' || detail.currencyCode === undefined) {
              // swal('Error', 'Please select currency for demand draft of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Please select currency for demand draft of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });

              result = false;
            }
            if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
              // swal('Error', 'Please provide amount for demand draft of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Please provide amount for demand draft of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });
              result = false;
            }
          }
          if (index < traveller.demandDraftDetails.length) {
            break;
          }
        }
      }
    }
    return result;
  }

  updateSession() {
    SessionHelper.setSession('userSessionInfo', JSON.stringify(this.userSessionInfo));
  }

  updateFormSession(TravellerIndex) {
    this.userSessionInfo.buyScreen.traveller[TravellerIndex] = this.userSessionInfoTravellers[TravellerIndex];
    // sessionStorage.userSessionInfoSend = JSON.stringify(this.userSessionInfoSend);
    SessionHelper.setSession('userSessionInfo', JSON.stringify(this.userSessionInfo));
    //  console.log(sessionStorage.userSessionInfoSend);
  }

}
