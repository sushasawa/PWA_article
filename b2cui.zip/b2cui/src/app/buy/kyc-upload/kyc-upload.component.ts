import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MasterService } from "../../../app/services/master.services";
import { Constants } from '../../../app/helpers/constants';
@Component({
  selector: 'app-kyc-upload',
  templateUrl: './kyc-upload.component.html',
  styleUrls: ['./kyc-upload.component.css']
})
export class KycUploadComponent implements OnInit {
  public DocCheckList: any;
  public Address_Proof: any;
  public formdata: any;
  public docs: Array<any>;
  public documentScr: any;
  public close = document.getElementsByClassName("close")[0];
  public imageAttr: any;
  public fileupload: Array<any>;
  constructor(private masterService: MasterService, private sanitizer: DomSanitizer) {
    console.log("common KYC Loaded");
    this.imageAttr = {};
     var reqData = [{
      "process": "Buy",
      "purpose": "Private Visit",
      "hasPrepaid": true
    }];
    this.masterService.getDocumentCheckList(reqData)
      .subscribe(data => {
        console.log(data)
        // this.checklistDataListFromDb = data;
        // this.DocCheckList = data[0].Checklist;
        this.DocCheckList = data[0].Checklist;
      });
    console.log("loaded");
  }

  ngOnInit() {
  }

  addressDoc(newValue: number) {
    console.log(newValue);
    this.Address_Proof = newValue;

  }

  uploadDoc(ele: any, doc: any) {
    let docs = ele.target.files;
    this.formdata = new FormData();
    let doctype = { "doc": doc };
    let userid = { "id": "cnk123" };
    this.formdata.append("Doctype", JSON.stringify(doctype));
    this.formdata.append("userdata", JSON.stringify(userid));
    for (let i = 0; i < docs.length; i++) {
      this.formdata.append("sampleFile", docs[i], docs[i].name);
    }
    this.masterService.uploadTravellerDocuments(this.formdata)
      .subscribe((data) => {
        var result: any = data;
        this.formdata = {};
        this.imageAttr[result.response.doc.doc.srNo] = result.response.imgUrl;
      });
  }
  updateUploadedDocArray(obj: any) {

  }
  viewDoc(DocId: any) {
    console.log(DocId,this.imageAttr);
    if(Object.keys(this.imageAttr).length != 0){ //getting count of object 
                 if (this.imageAttr[DocId].indexOf(".jpg") != -1) {
                    this.documentScr = this.imageAttr[DocId];
                    document.getElementById('myModal').style.display = "block";
                  }
                  else if(this.imageAttr[DocId].indexOf(".pdf") != -1) {
                    document.getElementById('myModal').style.display = "none";
                    this.documentScr = this.imageAttr[DocId];
                    let newtab = window.open(this.documentScr, '_blank');
                    newtab.focus();
                  }
            }else{
              document.getElementById('myModal').style.display = "none";
            }
  }
  removeDoc(DocId: any) {

  }

  closeDocpopup() {
    document.getElementById('myModal').style.display = "none";
  }

}
