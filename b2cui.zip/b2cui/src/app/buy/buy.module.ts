import { CommonNotificationPopupComponent } from './../forex-common/common-notification-popup/common-notification-popup.component';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from 'ng-select';
import {DpDatePickerModule} from 'ng2-date-picker';
import { ForexCommonModule } from '../forex-common/forex-common.module';
import { PipesModule } from '../pipes/pipes.module';
import { MasterService } from '../services/master.services';
import { AuthService } from '../services/auth.service';
import { AuthGuardService as AuthGuard } from '../services/auth-guard.service';
import { BuyOverviewComponent } from './buy-overview/buy-overview.component';
import { CreateAccountAdharComponent } from './create-account-adhar/create-account-adhar.component';
import { ForexReviewComponent } from './forex-review/forex-review.component';
import { KycUploadComponent } from './kyc-upload/kyc-upload.component';
import { CommonChecklistComponent } from '../forex-common/common-checklist/common-checklist.component';
import { CommonFormComponent } from '../forex-common/common-form/common-form.component';
import { CommonConfirmationComponent } from '../forex-common/common-confirmation/common-confirmation.component';
import { CommonUsercreationComponent } from '../forex-common/common-usercreation/common-usercreation.component';
import { CommonRegisterLoginComponent } from '../forex-common/common-register-login/common-register-login.component';
import { CommonRegisterLoginAdharComponent } from '../forex-common/common-register-login-adhar/common-register-login-adhar.component';
import { CommonReviewUserDetailsComponent } from '../forex-common/common-review-user-details/common-review-user-details.component';
import { CommonDeliveryModeComponent } from '../forex-common/common-delivery-mode/common-delivery-mode.component';
import { CommonPaymentGatewayComponent } from '../forex-common/common-payment-gateway/common-payment-gateway.component';
import { FailComponent } from '../forex-common/fail/fail.component';
import { CanDeactivateGuard } from '../services/can-deactivate-guard.service';
import { ForexReviewEditComponent } from './forex-review-edit/forex-review-edit.component';
import { CommonCompareDetailsComponent } from '../forex-common/common-compare-details/common-compare-details.component';
import { TransactionDetailsComponent } from './transaction-details/transaction-details.component';
import { TimerService } from '../services/timer.service';

const sessDataObj: any = {
  sessionDataProcess: 'userSessionInfo',
  sessionDataProcessScreen: 'buyScreen',
  processType: 'Buy'
};

const routes: Routes = [
  {
    path: '', children: [
      { path: '', component: BuyOverviewComponent, canDeactivate: [CanDeactivateGuard] },
      {
        path: 'checklist',
        component: CommonChecklistComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '2',
          nextLink: '/buy/register-login'
        }
      },
      {
        path: 'register-login',
        component: CommonRegisterLoginComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/buy/review-userdetail-adhar'
        }
      },
      {
        path: 'compare-details',
        component: CommonCompareDetailsComponent,
        data: {
          sessData: sessDataObj
        }
      },
      {
        path: 'register-login-adhar',
        component: CommonRegisterLoginAdharComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
        }
      },
      { path: 'create-account-adhar', component: CreateAccountAdharComponent,
      data: {
        sessData: sessDataObj,
        wizardStepNumber: '3',
        nextLink: '/buy/review-userdetail-adhar'
      } },

      { path: 'transaction-details', component: TransactionDetailsComponent, canActivate: [AuthGuard] },
      {
        path: 'delivery-mode',
        component: CommonDeliveryModeComponent,
        canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '4',
          mainHeading: 'Delivery Mode',
          subHeading: 'Forex Delivery Options',
          description: 'Please choose any of the below options for delivery of your foreign exchange',
          standardHeading: 'Standard Delivery',
          standardDesc: 'Delivery within 6 - 8 Hours*',
          expressHeading: 'Express Delivery',
          expressDesc: 'Delivery within 3 Hours*',
          tabHomeHeading: 'Delivery to My Home',
          tabOfficeHeading: 'Delivery to  My Office',
          datetimetxt: 'Appointment',
          nextLink: '/buy/forex-review',

        }
      },
      {
        path: 'review-userdetail-adhar', component: CommonReviewUserDetailsComponent,
        // canActivate: [AuthGuard]
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/buy/delivery-mode'
        }
      },
      {
        path: 'lrs', component: CommonFormComponent, canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '6',
          nextLink: '/buy/payment-gateway'
        }
      },
      {
        path: 'payment-gateway', component: CommonPaymentGatewayComponent, canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '7',
        }
      },
      { path: 'forex-review', component: ForexReviewComponent, canActivate: [AuthGuard] },
      { path: 'forex-review-edit', component: ForexReviewEditComponent, canActivate: [AuthGuard] },
      {
        path: 'confirmation', component: CommonConfirmationComponent, canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '8',
          deliveryMode: true,
          deliveryTxt: 'Delivery Charges',
          purpose: true
        }
      },
      {
        path: 'create-account', component: CommonUsercreationComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/buy/review-userdetail-adhar'
        }
      },
      {
        path : 'fail',
        component : FailComponent
      }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    // BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ForexCommonModule,
    PipesModule,
    SelectModule,
    DpDatePickerModule
  ],
  declarations: [
    BuyOverviewComponent,
    CreateAccountAdharComponent,
    ForexReviewComponent,
    KycUploadComponent,
    ForexReviewEditComponent,
    TransactionDetailsComponent,
  ],
  providers: [MasterService, AuthGuard, AuthService, CanDeactivateGuard, TimerService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class BuyModule { }
