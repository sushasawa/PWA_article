import { Component, OnInit, ElementRef, Inject, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '../../../app/helpers/location';
import { Observable } from 'rxjs/Observable';
import { LocationStrategy } from '@angular/common';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { UUID } from 'angular2-uuid';
import { SessionTemplate } from '../../helpers/session-template';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { SharedService } from '../../../app/services/shared.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;

declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;


@Component({
    selector: 'app-sendmoney-overiew',
    templateUrl: './sendmoney-overiew.component.html',
    styleUrls: ['./sendmoney-overiew.component.css']
})
export class SendmoneyOveriewComponent implements OnInit , DoCheck {

    public branchOptions: any;
    public destinationOptions: any;
    public currencyList: any;
    public currencyListCash: any;
    public purposeOptions: any;
    public bankOptions = [];
    public userSessionInfoSend: any;
    public navigate: any = true;
    private currentTravellerIndex: number;
    public isLoggedIn: boolean;
    public travellerList: any;
    public newTravellerCount: number;
    public invalidsubmitted: boolean;
    public CurrentBranchId: any;
    public _primaryComp: any;
    public AgentTheme: any;
    public textContents: any = {};
    public overviewPage: any;
    public specialOffers: any = [];
    public products: any = [];
    public testimonials: any = [];
    public backGroungImage: any = 'assets/images/forex-bg-img.jpg';
    public agentId: any;
    // tslint:disable-next-line:max-line-length
    constructor(public masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _elementRef: ElementRef, private location: LocationStrategy, private meta: Meta, @Inject(DOCUMENT) private _document: any, public _SharedService: SharedService) {
        this.location.onPopState(() => {
            this.navigate = false;
            return false;
        });
        this._primaryComp = '/' + navUrl.navUrl();
        this._document.title = 'Send money to abroad From Cox and Kings';
        // tslint:disable-next-line:max-line-length
        this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
        this.meta.addTag({ name: 'keywords', content: 'Buy, Sell, Send Money Abroad, Reload Card, Cash, Prepaid Card, Demand Draft, Check Exchange Rates, Live Forex Rates. exchange rates, currency exchange, currency rates, currency services, currency traders, currency trading, currency transfers, best exchange rates, rates, convert, currencies, currency, forex, forex news, forex terms, charts, discount, efficient, foreign exchange, foreign exchange payment, save money, save time, fx, global, global economy, graphs, guaranteed, headlines, introduction to forex, live, mid-market, trade currency, xe money transfer, accurate rates, accounting, expense management, forex markets' });
        this.userSessionInfoSend = {
            'sessionId': '',
            'mode': 'b2c',
            'type': 'sendMoneyScreen',
            'isActive': true,
            'LeadID': SessionHelper.getSession('LeadID') ? SessionHelper.getSession('LeadID') : null,
            'AgentID': SessionHelper.getSession('AgentID') ? SessionHelper.getSession('AgentID') : null,
            'IExhangeAgentId': SessionHelper.getSession('IExhangeAgentId') ? SessionHelper.getSession('IExhangeAgentId') : null,
            'created_On': new Date(),
            'sendMoneyScreen': {
                'budgetAmount': 0,
                'usedAmount': '0',
                'tranId': '',
                'balanceAmount': '0',
                'currentLocation': '',
                'branch': '',
                'destination': '',
                'bankChargesAdded': false,
                'deliveryInfo': {
                    'Mode': 'Home Delivery',
                    'type': 'Standard',
                    'DeliverySchedule': {
                        'date': '',
                        'time': ''
                    },
                    'rate': 0
                },
                'traveller': [{
                    'selected': true,
                    'lead': true,
                    'prepaidCard': true,
                    'purpose': '',
                    'serviceCharge': 0,
                    'loadFees': 0,
                    'activationFees': 0,
                    'discount': 0,
                    'charges': 0,
                    'gst': 0,
                    'prepaidCardDetails': [{
                        'currencyCode': '',
                        'promisedRate': '',
                        'promisedRateTime': '',
                        'forexAmount': '',
                        'bank': '',
                        'startTime': ''
                    }],
                    'registrationInfo': {
                        'userId': '',
                        'invoiceNo': null,
                        'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                        'middleName': '',
                        'lastName': '',
                        'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
                        'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                        'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                        // "nationality": { "id": "", "name": "" } ,
                        'nationality': '',
                        'mothersMaidenName': {
                            'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                                + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                                + 'event.target.style.background=\'#f8f8f8\'}'
                        },
                        'PAN': {
                            'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                                + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                                + 'event.target.style.background=\'#f8f8f8\'}'
                        },
                        'passportNumber': '',
                        'ParentId': true,
                        'dateOfIssue': '',
                        'placeOfIssue': '',
                        'expiryDate': '',
                        'address': '101 5A Galaxy apartment',
                        'isPassportAddressAsAdhar': 'yes',
                        'adharAddress': {
                            'flatNumber': '',
                            'buildingName': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': '',
                        },
                        'passportAddress': {
                            'flatNumber': '',
                            'buildingName': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': '',
                        },
                        'currentAddressAs': 'asPerAdhar',
                        'otherAddress': {
                            'flatNumber': '',
                            'buildingName': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': '',
                        },
                        'contactDetails': {
                            'mobileNo': '',
                            'emailId': ''
                        },
                        'alternateContactDetails': {
                            'countryCode': '',
                            'mobileNo': '',
                            'countryCode2': '',
                            'cityCode': '',
                            'telephoneNo': '',
                            'emailId': '',
                        },
                        'officeAddress': {
                            'designation': '',
                            'conpanyName': '',
                            'companyDivision': '',
                            'flatNumber': '',
                            'building': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': ''
                        },
                        'officeContactDetails': {
                            'countryCode': '',
                            'telephoneNumber': '',
                            'officeExtension': '',
                        },
                        'password': '',
                        'confirmPassword': '',
                    },
                    'travellingDetails': {
                        'dateOfTravel': '',
                        'dateOfArrival': '',
                        'airlineName': '',
                        'ticketNumber': ''
                    },
                    'PaymentDetails': {
                        'PaymentStatus': 'Fully Paid',
                        'PaymentMode': 'Online Credit Card',
                        'Amount': '6945.00',
                        'PaymentDateTime': 'Jul 27, 2016 13:50 PM',
                        'TransactionId': 'ID986524586',
                        'Last4DigitCardNum': 'xxx xxx xxxx 4646',
                        'CardHolderName': 'Kaushar R',
                        'CreditCardType': 'Visa',
                        'PaymentReceiptNo': 'CKF11',
                        'PaymentReceiptDate': '9 Jun 2016 11:01 am',
                        'OrderType': 'Send Money Abroad'
                    },
                    'ForexDetails': {
                        'TravellerName': 'Kaushal Ranpura',
                        'InvoiceNum': 'CNF 12352',
                        'PurposeOfTravel': 'Business',
                        'ForexProduct': 'Forex Card',
                        'bank': 'Axis Bank',
                        'AccountNumber': '12121212121212',
                        'ForexAmount': 'USD 100',
                        'AppliedRate': '68.23',
                        'TotalTransactionValue': '6,823.00',
                        'Discount': '0',
                        'TotalAfterDisc': '6723.00',
                        'DelivaryCharges': '150.00',
                        'CorrespondentCharges': '500.00',
                        'AppointmentCharges': '150.00',
                        'taxes': {
                            'OnFxTrns': '45.00',
                            'OnServCharge': '27.00'
                        },
                        'TotalPayable': '6,945'

                    },
                    'deliveryInfo': {
                        'Mode': '',
                        'type': '',
                        'DeliverySchedule': {
                            'date': '',
                            'time': ''
                        },
                        'rate': 0
                    },
                    'transactionDetails': [{
                        'beneficiaryFirstName': '',
                        'beneficiaryBlockNumber': '',
                        'beneficiaryBuilding': '',
                        'beneficiaryStreet': '',
                        'beneficiaryLandMark': '',
                        'beneficiaryArea': '',
                        'beneficiaryCity': '',
                        'beneficiaryState': '',
                        'beneficiaryPincode': '',
                        'beneficiaryCountry': '',
                        'beneficiaryAccountNo': '',
                        'beneficiaryBankName': '',
                        'beneficiarySwiftCode': '',
                        'beneficiaryRoutingNo': '',
                        'beneficiaryBankAddress': ''
                    }],
                    'selfTransaction': {
                        'beneficiaryTransSelf': '',
                        'beneficiaryTravellerName': '',
                        'beneficiaryTravellerRelationship': '',
                        'beneficiaryTravellerArrivalDate': '',
                        'beneficiaryTravellerEducation': '',
                        'beneficiaryTravellerCountry': ''
                    }
                }]

            }
        };

        if (SessionHelper.getSession('userInfo')) {
            const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));

            // Added after Aadhaar implementation
            if (userInfo.uid) {
                this.isLoggedIn = userInfo.loggedin;
                this.masterService.getLoggedInUserInfo(userInfo.uid)
                    .subscribe(data => {
                        const result: any = data;
                        this.travellerList = [];
                        this.travellerList.push({
                            name: result.response[0][0].firstName + ' ' + result.response[0][0].lastName,
                            data: result.response[0][0]
                        });
                        this.travellerList[0].data.lead = true;
                        this.travellerList[0].selected = true;

                        this.userSessionInfoSend.sendMoneyScreen.traveller[0].registrationInfo
                            = SessionTemplate.getSessionTemplate(this.travellerList[0].data).registrationInfo;

                        result.response[1].forEach(element => {
                            this.travellerList.push({ name: element.firstName + ' ' + element.lastName, data: element });
                            this.newTravellerCount = 0;
                        });
                    }, err => {
                        // swal('Oops', 'Error fetching traveler data!', 'error');
                        Snackbar.show({
                            text: 'Oops! Error fetching traveler data',
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                    });
            }
        } else {
            this.isLoggedIn = false;
        }

        // region Logic to restore values from session if present...
        if (SessionHelper.getSession('userSessionInfoSend')) {
            this.userSessionInfoSend = JSON.parse(SessionHelper.getSession('userSessionInfoSend'));
        } else {
            this.userSessionInfoSend.sessionId = UUID.UUID();
        }
        // endregion Logic to restore values from session if present...


        this.populateBranch('');
        if (sessionStorage.getItem('currentLocation') === null) {
            this.masterService.getCurrentLocation()
                .subscribe(data => {
                    this.userSessionInfoSend.sendMoneyScreen.currentLocation = data;
                    sessionStorage.setItem('currentLocation', JSON.stringify(this.userSessionInfoSend.sendMoneyScreen.currentLocation));
                    this.populateBranch(this.userSessionInfoSend.sendMoneyScreen.currentLocation.city);
                    if (SessionHelper.getLocal('branchIdFromOverviewSend')) {
                        const branchIdObj = { BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewSend')) };
                        this.selected(branchIdObj);
                    } else {
                        const branchIdObj = { BranchID: 11910 };
                        this.selected(branchIdObj);
                    }
                }, err => {
                    // swal('Oops...', 'Unable to detect current location!', 'error');
                    this.populateBranch('');
                    Snackbar.show({
                        text: 'Unable to detect current location!',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                });
        } else {
            this.userSessionInfoSend.sendMoneyScreen.currentLocation = JSON.parse(sessionStorage.getItem('currentLocation'));
            this.populateBranch(this.userSessionInfoSend.sendMoneyScreen.currentLocation.city);
            if (SessionHelper.getLocal('branchIdFromOverviewSend')) {
                const branchIdObj = { BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewSend')) };
                this.selected(branchIdObj);
            } else {
                const branchIdObj = { BranchID: 11910 };
                this.selected(branchIdObj);
            }
        }
        // this.masterService.getCurrentLocation()
        //     .subscribe(data => {
        //         this.userSessionInfoSend.sendMoneyScreen.currentLocation = data;
        //         this.populateBranch(this.userSessionInfoSend.sendMoneyScreen.currentLocation.city);
        //         if (SessionHelper.getLocal('branchIdFromOverviewSend')) {
        //             let branchIdObj = { BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewSend')) };
        //             this.selected(branchIdObj);
        //         } else {
        //             let branchIdObj = { BranchID: 11910 };
        //             this.selected(branchIdObj);
        //         }
        //     }, err => {
        //         // swal('Oops...', 'Unable to detect current location!', 'error');
        //         this.populateBranch('');
        //         Snackbar.show({
        //             text: 'Unable to detect current location!',
        //             pos: 'bottom-right',
        //             actionTextColor: '#ff4444',
        //         });
        //     });

        if (sessionStorage.getItem('destinationList') === null) {
            this.masterService.getDestinationList()
                .subscribe(data => {
                    this.destinationOptions = data;
                    sessionStorage.setItem('destinationList', JSON.stringify(this.destinationOptions));
                }, err => {
                    // swal('Oops...', 'Unable to fetch destination list!', 'error');
                    Snackbar.show({
                        text: 'Unable to fetch destination list!',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                });
        } else {
            this.destinationOptions = JSON.parse(sessionStorage.getItem('destinationList'));
        }






        // FOR PURPOSE LIST  @precessId values :
        // 1	Buy Forex
        // 2	Sell Forex
        // 3	Reload Card
        // 4	Send Money Abroad
        this.masterService.getPurposeList(4)
            .subscribe(data => {
                this.purposeOptions = data;
            });
        const destination = this.userSessionInfoSend.sendMoneyScreen.destination.split('#')[0];
        this.masterService.getCurrencyList(1, destination)
            .subscribe(data => {
                this.currencyList = data;
            });


        this.currentTravellerIndex = 0;
        this.CurrentBranchId = Number.parseInt(SessionHelper.getLocal('branchIdFromOverview'));
        this.populateCurrencyRateForRule(this.CurrentBranchId);
    }

    ngOnInit() {
        $('body').attr('id', 'home');
        initDocument();
        this.textContents.convenienceTitle = 'Buying forex have never become easier!';
        // tslint:disable-next-line:max-line-length
        this.textContents.convenienceContents = 'Cox & Kings helps you choose the right forex solutions.<br> When you are on the move, just place the order and visit any of the nearest Cox & Kings location to avail our forex solutions.<br> When you are busy, just place the order and relax. We will get you the required forex solutions at your door step.';
        if (this._SharedService.AgentsTheme) {
            // tslint:disable-next-line:max-line-length
            this.AgentTheme = this._SharedService.AgentsTheme.success ? this._SharedService.AgentsTheme.Docs : this._SharedService.AgentsTheme;
            this.applyTheme();
        }
        $('.custom-tabs > .resp-tabs-list > li[aria-controls="hor_1_tab_item-3"]').trigger('click');
        setTimeout(() => {
            $('.owl-item.active .TabBanners > li:first-child').trigger('click');
        }, 500);
        /// temporary number
        if (sessionStorage.getItem('userInfo') !== null) {
            const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
            this.masterService.getTemporaryOrderNumber()
                .subscribe(data => {
                    const result: any = data;
                    console.log(result);
                    this.userSessionInfoSend.temporaryOrderNumber = result.response.OrderNumber;
                    this.userSessionInfoSend.userId = userInfo.uid;
                });
        }
        this.selectTraveller(0);
    }

    ngDoCheck() {
        this._SharedService.AgentTheme.subscribe((theme) => {
            this.AgentTheme = theme.success ? theme.Docs : theme;
            this.applyTheme();
        });
        if (SessionHelper.getSession('AgentID')) {
            this.agentId = SessionHelper.getSession('AgentID');
        }
    }

    applyTheme() {
        if (this.AgentTheme.overviewPage) {
            this.overviewPage = this.AgentTheme.overviewPage;
            if (this.overviewPage.mainScreenBackGround) {
                this.backGroungImage = this.overviewPage.mainScreenBackGround;
            }
            if (this.overviewPage.specialOffers) {
                this.specialOffers = this.overviewPage.specialOffers;
            }
            if (this.overviewPage.products) {
                this.products = this.overviewPage.products;
            }
            if (this.overviewPage.testimonials) {
                this.testimonials = this.overviewPage.testimonials;
            }
        } else {
            this.overviewPage = {};
            this.backGroungImage = 'assets/images/forex-bg-img.jpg';
            this.specialOffers = [];
            this.products = [];
            this.testimonials = [];
        }
    }

    populateCurrencyRateForRule(branchId) {
        this.masterService.getCurrencyRateForRule(branchId).subscribe(
            (data) => {
                const result: any = data;
                if (result.length) {
                    this.userSessionInfoSend.cashRateBuy = result[0].cashRateBuy;
                    this.userSessionInfoSend.prepaidRateBuy = result[0].prepaidRateBuy;
                    this.userSessionInfoSend.ddRateBuy = result[0].ddRateBuy;
                    this.userSessionInfoSend.cashRateSell = result[0].cashRateSell;
                    this.updateSession();
                }
            },
            (error) => {
                console.error('getCurrencyRateForRule');
                console.log(error);
            }
        );
    }

    populateBranch(cityname) {
        // tslint:disable-next-line:curly
        if (cityname)
        this.masterService.getBranchList(cityname)
            .subscribe(data => {
                this.branchOptions = data;
            });
    }
    addExistingTraveller(data: any, event: any, index: number) {
        if (event.target.checked) {
            if (this.userSessionInfoSend.sendMoneyScreen.traveller.length === 4) {
                // swal('Sorry', 'Maximum 4 travelers allowed', 'error');
                Snackbar.show({
                    text: 'Sorry! Maximum 4 travelers allowed',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                event.target.checked = false;
            } else {
                // this.userSessionInfoSend.sendMoneyScreen.traveller.push(
                //     SessionTemplate.getSessionTemplate(data),
                // );
                this.userSessionInfoSend.sendMoneyScreen.traveller.push(
                    {
                        registrationInfo: SessionTemplate.getSessionTemplate(data).registrationInfo,
                        travellingDetails: SessionTemplate.getSessionTemplate(data).travellingDetails,
                        'selected': false,
                        'lead': false,
                        'prepaidCard': false,
                        'purpose': '',
                        'serviceCharge': 0,
                        'loadFees': 0,
                        'activationFees': 0,
                        'discount': 0,
                        'charges': 0,
                        'gst': 0,
                        'prepaidCardDetails': [{
                            'currencyCode': '',
                            'promisedRate': '',
                            'promisedRateTime': '',
                            'forexAmount': '',
                            'bank': '',
                            'startTime': ''
                        }],
                        'transactionDetails': [{
                            'beneficiaryFirstName': '',
                            'beneficiaryBlockNumber': '',
                            'beneficiaryBuilding': '',
                            'beneficiaryStreet': '',
                            'beneficiaryLandMark': '',
                            'beneficiaryArea': '',
                            'beneficiaryCity': '',
                            'beneficiaryState': '',
                            'beneficiaryPincode': '',
                            'beneficiaryCountry': '',
                            'beneficiaryAccountNo': '',
                            'beneficiaryBankName': '',
                            'beneficiarySwiftCode': '',
                            'beneficiaryRoutingNo': '',
                            'beneficiaryBankAddress': ''
                        }],
                        'selfTransaction': {
                            'beneficiaryTransSelf': '',
                            'beneficiaryTravellerName': '',
                            'beneficiaryTravellerRelationship': '',
                            'beneficiaryTravellerArrivalDate': '',
                            'beneficiaryTravellerEducation': '',
                            'beneficiaryTravellerCountry': ''
                        }
                    }
                );
                this.selectTraveller(this.userSessionInfoSend.sendMoneyScreen.traveller.length - 1);

            }
        } else {
            if (!this.travellerList[index].data.lead) {
                if (this.userSessionInfoSend.sendMoneyScreen.traveller.length > 1) {
                    const obj = this.userSessionInfoSend.sendMoneyScreen.traveller
                        .find(item => item.registrationInfo.contactDetails.emailId === data.emailId);

                    this.removeTraveller(this.userSessionInfoSend.sendMoneyScreen.traveller.indexOf(obj));
                } else {
                    // swal('Sorry', 'Minimum 1 traveler needed', 'error');
                    Snackbar.show({
                        text: 'Sorry! Minimum 1 traveler needed',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    event.target.checked = true;
                }
            } else {
                // swal('Sorry', 'You cannot remove lead pax. Change any other traveler to lead before this operation', 'error');
                Snackbar.show({
                    text: 'Sorry! You cannot remove lead pax. Change any other traveler to lead before this operation',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                event.target.checked = true;
            }
        }

        this.travellerList[index].selected = event.target.checked;
        this.updateSession();
    }

    addNewTraveller(event: any) {
        if (event.target.checked) {
            if (this.userSessionInfoSend.sendMoneyScreen.traveller.length === 4) {
                // swal('Sorry', 'Maximum 4 travelers allowed', 'error');
                Snackbar.show({
                    text: 'Sorry! Maximum 4 travelers allowed',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                event.target.checked = false;
            } else {
                this.newTravellerCount++;
                this.addTraveller();
                this.selectTraveller(this.userSessionInfoSend.sendMoneyScreen.traveller.length - 1);
            }
        } else {
            if (this.userSessionInfoSend.sendMoneyScreen.traveller.length > 1) {
                const obj = this.userSessionInfoSend.sendMoneyScreen.traveller
                    .find(item => item.registrationInfo.contactDetails.emailId === '');
                this.removeTraveller(this.userSessionInfoSend.sendMoneyScreen.traveller.indexOf(obj));
                this.newTravellerCount--;
            } else {
                // swal('Sorry', 'Minimum 1 traveler needed', 'error');
                Snackbar.show({
                    text: 'Sorry! Minimum 1 traveler needed',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                event.target.checked = true;
            }
        }
    }

    changeLeadPax(event: any, data: any, index: number) {
        console.log(event);
        console.log(data);
        console.log(index);

        this.travellerList.forEach(item => {
            item.data.lead = false;
        });

        this.travellerList[index].data.lead = true;

        this.userSessionInfoSend.sendMoneyScreen.traveller.forEach(traveller => {
            traveller.lead = false;
        });
        const obj = this.userSessionInfoSend.sendMoneyScreen.traveller
            .find(item => item.registrationInfo.contactDetails.emailId === data.emailId);
        const i = this.userSessionInfoSend.sendMoneyScreen.traveller.indexOf(obj);

        this.userSessionInfoSend.sendMoneyScreen.traveller[i].lead = true;
        console.log(this.userSessionInfoSend.sendMoneyScreen.traveller);
    }

    showTravellerChoice() {
        this._elementRef.nativeElement.querySelector('.trvl-list').style.display = 'block';
    }

    hideTravellerChoice() {
        this._elementRef.nativeElement.querySelector('.trvl-list').style.display = 'none';
    }

    updateBranch(newValue: number) {
        this.userSessionInfoSend.sendMoneyScreen.branch = newValue;
        this.updateSession();
    }

    updateDestination(newValue: number) {
        this.userSessionInfoSend.sendMoneyScreen.destination = newValue;
        this.masterService.getCurrencyList(1, this.userSessionInfoSend.sendMoneyScreen.destination.split('#')[0])
            .subscribe(data => {
                this.currencyList = data;
            });


        this.updateSession();
    }

    updateCurrencyCode(prepaidDetailIndex: number, newValue: string) {

        console.log(this.currentTravellerIndex);
        this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex]
            .prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'dd', 'buy', 'HODD')
            .subscribe(data => {
                const result: any = data;
                this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex]
                    .prepaidCardDetails[prepaidDetailIndex].exchangeRate = result;
                if (result.rate !== 0) {
                    this.updateUsedAmount();
                    this.updateSession();
                    this.populateCurrencyRateForRule(this.CurrentBranchId);
                } else {
                    Snackbar.show({
                        text: 'No Rates Found for <b>' + newValue + '</b>',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                }
            });
        this.updateSession();
    }

    updateCash(newValue: boolean) {
        this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].cash = newValue;
        if (newValue) {
            this.masterService.getCurrencyList(this.userSessionInfoSend.sendMoneyScreen.destination)
                .subscribe(data => {
                });
        }
        this.updateSession();
    }

    updatePrepaidPurpose(newPurpose) {
        console.log(newPurpose);
        console.log(this.purposeOptions.filter((value, i) => value.value === newPurpose)[0].purposeCode);
        this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].purpose = newPurpose;
        // tslint:disable-next-line:max-line-length
        this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].purposeCode = this.purposeOptions.filter((value, i) => value.value === newPurpose)[0].purposeCode;
        this.userSessionInfoSend.sendMoneyScreen.purposeCode = this.purposeOptions.filter((value, i) => value.value === newPurpose)[0].purposeCode;
        console.log(this.userSessionInfoSend);
        this.updateSession();
    }

    addMoreCurrency() {
        this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.push({
        });

        this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].transactionDetails.push({
            'beneficiaryFirstName': '',
            'beneficiaryBlockNumber': '',
            'beneficiaryBuilding': '',
            'beneficiaryStreet': '',
            'beneficiaryLandMark': '',
            'beneficiaryArea': '',
            'beneficiaryCity': '',
            'beneficiaryState': '',
            'beneficiaryPincode': '',
            'beneficiaryCountry': '',
            'beneficiaryAccountNo': '',
            'beneficiaryBankName': '',
            'beneficiarySwiftCode': '',
            'beneficiaryRoutingNo': '',
            'beneficiaryBankAddress': ''
        });

        this.updateSession();
    }

    updateValue(newValue, index) {
        if (newValue === '' || isNaN(newValue)) {
            newValue = '0';
        }
        const checkCondition = this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex]
            .prepaidCardDetails[index].exchangeRate.rate !== 0;
        if (checkCondition) {
            this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex]
                .prepaidCardDetails[index].forexAmount = parseFloat(newValue);
            this.updateUsedAmount();
        } else {
            this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex]
                .prepaidCardDetails[index].forexAmount = '';
            (<HTMLInputElement>document.getElementById('prepaid' + this.currentTravellerIndex + index)).value = '';
        }

    }

    updateUsedAmount() {
        let travellerTotal = 0;
        this.userSessionInfoSend.sendMoneyScreen.traveller.forEach(traveller => {
            let currentTravellerTotal = 0;
            traveller.prepaidCardDetails.forEach(element => {
                if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                    currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                }
            });
            travellerTotal += currentTravellerTotal;
            traveller.usedAmount = currentTravellerTotal;
        });

        this.userSessionInfoSend.sendMoneyScreen.usedAmount = travellerTotal;
        if (this.userSessionInfoSend.sendMoneyScreen.usedAmount !== 0) {
            this.masterService.getTaxes(this.userSessionInfoSend.sendMoneyScreen.usedAmount)
                .subscribe(res => {
                    const result: any = res;
                    this.userSessionInfoSend.sendMoneyScreen.usedAmount += result.TotalTax;
                    this.updateBalanceAmount();
                }, err => {
                    // swal('Oops', 'Error fetching taxes', 'error');
                    Snackbar.show({
                        text: 'Oops! Error fetching taxes',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                });
        }
        this.updateBalanceAmount();
    }

    updateBalanceAmount() {
        this.userSessionInfoSend.sendMoneyScreen.balanceAmount = (this.userSessionInfoSend.sendMoneyScreen.budgetAmount
            - this.userSessionInfoSend.sendMoneyScreen.usedAmount).toString();
        this.updateSession();
    }

    // region Mutli-traveller logic
    addTravellerOption() {
        this.isLoggedIn ? this.showTravellerChoice() : this.addTraveller();
        this.selectTraveller(this.userSessionInfoSend.sendMoneyScreen.traveller.length - 1);
    }

    addTraveller() {
        if (this.userSessionInfoSend.sendMoneyScreen.traveller.length < 4) {
            this.userSessionInfoSend.sendMoneyScreen.traveller.push({
                'selected': false,
                'prepaidCard': true,
                'purpose': '',
                'serviceCharge': 0,
                'loadFees': 0,
                'activationFees': 0,
                'discount': 0,
                'charges': 0,
                'gst': 0,
                'prepaidCardDetails': [{
                    'currencyCode': '',
                    'promisedRate': '',
                    'promisedRateTime': '',
                    'forexAmount': '',
                    'bank': '',
                    'startTime': ''
                }],
                'registrationInfo': {
                    'userId': '',
                    'invoiceNo': null,
                    'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                    'middleName': '',
                    'lastName': '',
                    'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
                    'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                    'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                    // "nationality": { "id": "", "name": "" } ,
                    'nationality': '',
                    'mothersMaidenName': {
                        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                            + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                            + 'event.target.style.background=\'#f8f8f8\'}'
                    },
                    'PAN': {
                        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                            + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                            + 'event.target.style.background=\'#f8f8f8\'}'
                    },
                    'passportNumber': '',
                    'ParentId': true,
                    'dateOfIssue': '',
                    'placeOfIssue': '',
                    'expiryDate': '',
                    'address': '101 5A Galaxy apartment',
                    'isPassportAddressAsAdhar': 'yes',
                    'adharAddress': {
                        'flatNumber': '',
                        'buildingName': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': '',
                    },
                    'passportAddress': {
                        'flatNumber': '',
                        'buildingName': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': '',
                    },
                    'currentAddressAs': 'asPerAdhar',
                    'otherAddress': {
                        'flatNumber': '',
                        'buildingName': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': '',
                    },
                    'contactDetails': {
                        'mobileNo': '',
                        'emailId': ''
                    },
                    'alternateContactDetails': {
                        'countryCode': '',
                        'mobileNo': '',
                        'countryCode2': '',
                        'cityCode': '',
                        'telephoneNo': '',
                        'emailId': '',
                    },
                    'officeAddress': {
                        'designation': '',
                        'conpanyName': '',
                        'companyDivision': '',
                        'flatNumber': '',
                        'building': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': ''
                    },
                    'officeContactDetails': {
                        'countryCode': '',
                        'telephoneNumber': '',
                        'officeExtension': '',
                    },
                    'password': '',
                    'confirmPassword': '',
                },
                'travellingDetails': {
                    'dateOfTravel': '',
                    'dateOfArrival': '',
                    'airlineName': '',
                    'ticketNumber': ''
                },
                'PaymentDetails': {
                    'PaymentStatus': 'Fully Paid',
                    'PaymentMode': 'Online Credit Card',
                    'Amount': '6945.00',
                    'PaymentDateTime': 'Jul 27, 2016 13:50 PM',
                    'TransactionId': 'ID986524586',
                    'Last4DigitCardNum': 'xxx xxx xxxx 4646',
                    'CardHolderName': 'Kaushar R',
                    'CreditCardType': 'Visa',
                    'PaymentReceiptNo': 'CKF11',
                    'PaymentReceiptDate': '9 Jun 2016 11:01 am',
                    'OrderType': 'Send Money Abroad'
                },
                'ForexDetails': {
                    'TravellerName': 'Kaushal Ranpura',
                    'InvoiceNum': 'CNF 12352',
                    'PurposeOfTravel': 'Business',
                    'ForexProduct': 'Forex Card',
                    'bank': 'Axis Bank',
                    'AccountNumber': '12121212121212',
                    'ForexAmount': 'USD 100',
                    'AppliedRate': '68.23',
                    'TotalTransactionValue': '6,823.00',
                    'Discount': '0',
                    'TotalAfterDisc': '6723.00',
                    'DelivaryCharges': '150.00',
                    'CorrespondentCharges': '500.00',
                    'AppointmentCharges': '150.00',
                    'taxes': {
                        'OnFxTrns': '45.00',
                        'OnServCharge': '27.00'
                    },
                    'TotalPayable': '6,945'

                },
                'deliveryInfo': {
                    'Mode': 'At Home',
                    'type': 'Standard Delivery',
                    'DeliverySchedule': {
                        'date': '7 Mar 2017',
                        'time': '3:00 pm to 4:00 pm'
                    }
                },
                'transactionDetails': [{
                    'beneficiaryFirstName': '',
                    'beneficiaryBlockNumber': '',
                    'beneficiaryBuilding': '',
                    'beneficiaryStreet': '',
                    'beneficiaryLandMark': '',
                    'beneficiaryArea': '',
                    'beneficiaryCity': '',
                    'beneficiaryState': '',
                    'beneficiaryPincode': '',
                    'beneficiaryCountry': '',
                    'beneficiaryAccountNo': '',
                    'beneficiaryBankName': '',
                    'beneficiarySwiftCode': '',
                    'beneficiaryRoutingNo': '',
                    'beneficiaryBankAddress': ''
                }],
                'selfTransaction': {
                    'beneficiaryTransSelf': '',
                    'beneficiaryTravellerName': '',
                    'beneficiaryTravellerRelationship': '',
                    'beneficiaryTravellerArrivalDate': '',
                    'beneficiaryTravellerEducation': '',
                    'beneficiaryTravellerCountry': ''
                }
            });
        } else {
            // swal('Oops', 'Maximum 4 travellers allowed!', 'error');
            Snackbar.show({
                text: 'Oops! Maximum 4 travellers allowed',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
        }
        this.updateSession();
    }

    removeTraveller(index: number) {
        if (!this.userSessionInfoSend.sendMoneyScreen.traveller[index].lead) {
            if (this.userSessionInfoSend.sendMoneyScreen.traveller[index].selected) {
                this.selectTraveller(index === 0 ? 1 : index - 1);
            }
            if (this.userSessionInfoSend.sendMoneyScreen.traveller[index].registrationInfo.contactDetails.emailId === '') {
                if (this._elementRef.nativeElement.querySelector('#chkbox-new-' + this.newTravellerCount) !== null) {
                    this._elementRef.nativeElement.querySelector('#chkbox-new-' + this.newTravellerCount).checked = false;
                }
                this.newTravellerCount--;
            }
            this.userSessionInfoSend.sendMoneyScreen.traveller.splice(index, 1);
            this.updateUsedAmount();
        } else {
            // swal('Sorry', 'You cannot remove lead pax. Change any other traveler to lead before this operation', 'error');
            Snackbar.show({
                text: 'Sorry! You cannot remove lead pax. Change any other traveler to lead before this operation',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
        }
        this.updateSession();
    }

    removePrepaidRegion(index: number) {
        this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.splice(index, 1);
        this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].transactionDetails.splice(index, 1);
    }

    selectTraveller(travellerIndex) {
        this.currentTravellerIndex = travellerIndex;

        this.userSessionInfoSend.sendMoneyScreen.traveller.forEach(traveller => {
            traveller.selected = false;
        });

        this.userSessionInfoSend.sendMoneyScreen.traveller[travellerIndex].selected = true;
        this.userSessionInfoSend.sendMoneyScreen.traveller[travellerIndex].prepaidCard = true;
        if (this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails === undefined) {
            this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails = [{}];
        }
        if (this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].transactionDetails === undefined) {
            this.userSessionInfoSend.sendMoneyScreen.traveller[this.currentTravellerIndex].transactionDetails = [{}];
        }

        this.updateSession();
    }
    // endregion Mutli-traveller logic

    updateSession() {
        SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfoSend));
    }

    // submitAndRedirect() {
    //     this.userSessionInfoSend['nextLink'] = '/send-money/checklist';
    //     this.updateSession();
    //     if (this.validateSession()) {
    //         this.masterService.dumpSessionData(this.userSessionInfoSend)
    //             .subscribe(data => {
    //             }, err => {
    //                 console.log(err);
    //             });
    //         this.router.navigateByUrl(this._primaryComp + '/send-money/checklist');
    //     }
    // }

    submitAndRedirect() {
        //   this.populateCurrencyRateForRule(this.CurrentBranchId);
        // this.userSessionInfoSend['nextLink'] = '/send-money/checklist';
        this.updateSession();
        if (this.validateSession()) {
            this.masterService.RuleTest(this.userSessionInfoSend)
                .subscribe(data => {
                    const resData: any = JSON.parse(data);
                    if (resData.status === 1) {
                        this.masterService.dumpSessionData(this.userSessionInfoSend)
                            .subscribe(resD => {
                            }, err => {
                                console.log(err);
                            });
                        this.router.navigateByUrl(this._primaryComp + '/send-money/checklist');

                    } else {
                        // swal('error', resData.message, 'error');
                        Snackbar.show({
                            text: resData.message,
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                    }
                });
        }
    }

    selected($event) {
        this.CurrentBranchId = $event.BranchID;
        SessionHelper.setLocal('branchIdFromOverview', $event.BranchID);
        SessionHelper.setLocal('branchIdFromOverviewSend', $event.BranchID);
        if ($event.BranchCode) {
            this.userSessionInfoSend.sendMoneyScreen.BranchCode = $event.BranchCode;
            this.updateSession();
        }
        this.populateCurrencyRateForRule(this.CurrentBranchId);
    }

    validateSession() {
        let result = true;

        if (this.userSessionInfoSend.sendMoneyScreen.branch === '' || this.userSessionInfoSend.sendMoneyScreen.branch === undefined) {
            // swal('Error', 'Please select branch', 'error');
            Snackbar.show({
                text: 'Error! Please select branch ',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
            this.invalidsubmitted = true;
            result = false;
        } else if (this.userSessionInfoSend.sendMoneyScreen.destination === ''
            || this.userSessionInfoSend.sendMoneyScreen.destination === undefined) {
            // swal('Error', 'Please select destination', 'error');
            Snackbar.show({
                text: 'Error! Please select destination ',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
            this.invalidsubmitted = true;
            result = false;
        } else {

            for (let travellerIndex = 0; travellerIndex < this.userSessionInfoSend.sendMoneyScreen.traveller.length; travellerIndex++) {
                const traveller = this.userSessionInfoSend.sendMoneyScreen.traveller[travellerIndex];

                if (traveller.purpose === '' || traveller.purpose === undefined) {
                    // swal('Error', 'Please select purpose for traveler ' + (travellerIndex + 1), 'error');
                    Snackbar.show({
                        text: 'Error!Please select purpose for traveler ' + (travellerIndex + 1),
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    this.selectTraveller(travellerIndex);
                    this.invalidsubmitted = true;
                    result = false;
                    break;
                }

                let index = 0;
                for (; index < traveller.prepaidCardDetails.length; index++) {
                    const detail = traveller.prepaidCardDetails[index];
                    if (detail.currencyCode === '' || detail.currencyCode === undefined) {
                        // swal('Error', 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                        Snackbar.show({
                            text: 'Error! Please select currency for prepaid card of traveler ' + (travellerIndex + 1),
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                        this.selectTraveller(travellerIndex);
                        this.invalidsubmitted = true;
                        result = false;
                        break;
                    }
                    if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
                        // swal('Error', 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                        Snackbar.show({
                            text: 'Error! Please provide amount for prepaid card of traveler ' + (travellerIndex + 1),
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                        this.selectTraveller(travellerIndex);
                        this.invalidsubmitted = true;
                        result = false;
                        break;
                    }
                }

                if (index < traveller.prepaidCardDetails.length) {
                    break;
                }
            }
        }
        return result;
    }

    canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
        if (this.navigate === true) {
            return true;
        } else {
            Snackbar.show({
                text: 'You can not go back from this page. Please go through application flow.',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
                duration: 3000
            });
            window.scrollTo(0, 0);
            this.navigate = true;
            return false;
        }
    }

}
