import { Component, OnInit, Inject } from '@angular/core';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { TransactionService } from '../../../app/services/transaction.service';
import { SessionHelper } from '../../helpers/session-helper';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { Router } from '@angular/router';
import { BulkExchangeRateService } from '../../services/bulk-exchange-rate.service';

declare var Snackbar: any;
declare function initDocument(): any;

@Component({
  selector: 'app-forex-review',
  templateUrl: './forex-review.component.html',
  styleUrls: ['./forex-review.component.css']
})
export class ForexReviewComponent implements OnInit {
  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public ddCharged: any = 0;
  public Bank_Correspondent_Bank_Charges: any = 0;
  public TT_Charges: any = 0;
  public gst: any = 0;
  public discount: any = 0;
  public travellerOfficeAddress: any = [];
  public mutitravellerTotalAmount: any;
  public correspondenceCharges: any = 0;
  public currencyLists: any = [];
  public currencyDetail: any;
  public userName: any;
  public _primaryComp: any;
  public correspondentCharges: any;
  // tslint:disable-next-line:no-shadowed-variable
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private TransactionService: TransactionService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any , private _BulkExchangeRateService: BulkExchangeRateService) {
    // console.log(JSON.parse(SessionHelper.getSession('userSessionInfoSend')));
    this._primaryComp = '/' + navUrl.navUrl();
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSend'));
    this.userSessionInfoRegistration = this.userSessionInfo.sendMoneyScreen.traveller[0].registrationInfo;
    this.userSessionInfoTravellingDetails = this.userSessionInfo.sendMoneyScreen.traveller[0].travellingDetails;
    this.userSessionInfoTravellers = this.userSessionInfo.sendMoneyScreen.traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.sendMoneyScreen.traveller[0];
    this.getCharges();
    this.mutitravellerTotalAmount = 0;
    this.correspondentCharges = this.userSessionInfo.sendMoneyScreen.bankChargesAdded;
    this._document.title = 'Review your current transaction';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Review your current transaction' });
  }

  syncSession() {
    let totalAmount: any = 0;
    let grantTotalAmount: any = 0;
    this.userSessionInfoTravellers.forEach(traveller => {
      let charges = 0;
      traveller.selected = false;
      traveller.serviceCharge = this.serviceCharge;
      traveller.Bank_Correspondent_Bank_Charges = this.Bank_Correspondent_Bank_Charges;
      traveller.TT_Charges = this.TT_Charges;
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.map((prepaidCard) => {
          totalAmount += (prepaidCard.forexAmount * prepaidCard.exchangeRate.rate) - this.discount + this.correspondenceCharges;
        });
      }
      let TotalTaxableAmount = totalAmount + this.Bank_Correspondent_Bank_Charges + this.TT_Charges + this.serviceCharge + parseInt(this.userSessionInfo.sendMoneyScreen.deliveryInfo.rate);
      traveller.totalAmount = TotalTaxableAmount;
      charges += this.Bank_Correspondent_Bank_Charges + this.TT_Charges + this.serviceCharge +parseInt(this.userSessionInfo.sendMoneyScreen.deliveryInfo.rate);
      this.masterService.getTaxes(TotalTaxableAmount).subscribe((data) => {
        const result: any = data;
        TotalTaxableAmount += result.TotalTax;
        traveller.totalAmount = TotalTaxableAmount;
        traveller.gst = result.TotalTax;
        // charges += result.TotalTax;
        traveller.Charges = charges;
        grantTotalAmount += parseInt(traveller.totalAmount);
        this.mutitravellerTotalAmount = grantTotalAmount;
        this.userSessionInfo.sendMoneyScreen.usedAmount = this.mutitravellerTotalAmount;
        this.updateSession();
      });
      totalAmount = 0;
      this.updateSession();
    });
    this.userSessionInfoTravellers[0].selected = true;
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];
    this.masterService.getCurrencyList(1).subscribe((data) => {
      this.currencyLists = data;
    });


    this.userSessionInfo.sendMoneyScreen.traveller.forEach(element => {

      if (element.lead) {
        // tslint:disable-next-line:max-line-length
        this.userName = element.registrationInfo.firstName.value + ' ' + element.registrationInfo.middleName + ' ' + element.registrationInfo.lastName;

      }
    });
  }

  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.serviceCharge = Charges.response.serviceCharge;
      this.Bank_Correspondent_Bank_Charges = this.correspondentCharges ? this.userSessionInfo.ddRateBuy * this.masterService.getBankCorrespondentCharges() : 0;
      this.TT_Charges = Charges.response.TT_Charges;
      this.syncSession();
      this.updateSession();
      
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  ngOnInit() {
    initDocument();
    this.concatOfficeAddress();

  }

  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;


  }

  populatePopup(currencyCode, forexAmount, exchangeRate) {
    this.currencyLists.map((currency, index) => {
      if (currency.Code === currencyCode) {
        this.currencyDetail =
          '1 ' + currency.label + ' = <i class="fa-rupee"></i>' + exchangeRate + '<br>' +
          forexAmount + ' ' + currency.Code + ' = ' + '<i class="fa-rupee"></i>' + (forexAmount * exchangeRate).toFixed(2);
      }
    });
  }


  onSaveAndTemporaryExit() {
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession('userSessionInfoSend');
    this.router.navigateByUrl(this._primaryComp + `/send-money`);
  }

  updateSession() {

    SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfo));
  }

  payment() {
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    this.userSessionInfo['userName'] = this.userName;
    this.userSessionInfo['nextLink'] = '/send-money/lrs';
    this.updateSession();
    console.log(this.userSessionInfo);
    this.generateTransaction();
    // tslint:disable-next-line:max-line-length

  }
  generateTransaction() {
    // tslint:disable-next-line:max-line-length
    const checkTransactionIdExists = this.userSessionInfo.sendMoneyScreen['tranId'] === undefined || this.userSessionInfo.sendMoneyScreen['tranId'] === null || this.userSessionInfo.sendMoneyScreen['tranId'] === '';

    if (checkTransactionIdExists) {

      this.TransactionService.TransactionId().subscribe((id) => {
        console.log(id);
        this.userSessionInfo.sendMoneyScreen['tranId'] = id;
        this.updateSession();
        this.generateInvoice();
      }, (error) => {
        console.log(error);
      });
    } else {
      this.generateInvoice();
    }
  }

  generateInvoice() {

    const TravellerNo = this.userSessionInfoTravellers.length;
    console.log('no of traveller');
    console.log(TravellerNo);
    this.TransactionService.generateInvoiceNo(TravellerNo)
      .subscribe(resD => {
        console.log(resD);
        for (let travellerIndex = 0; travellerIndex < this.userSessionInfoTravellers.length; travellerIndex++) {
          this.userSessionInfo.sendMoneyScreen.traveller[travellerIndex].registrationInfo.invoiceNo = resD[travellerIndex][0].number;
          this.updateSession();
        }
        this.saveTransaction();
      }, err => {
        console.log(err);
      });
  }

  concatOfficeAddress() {
    const nonAdressParam = ['conpanyName', 'companyName', 'designation', 'companyDivision', 'pincode'];
    this.travellerOfficeAddress = [];
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      let addressText = '', officeAddress = traveller.registrationInfo.officeAddress, counter = 0, pincodeAdded = false;
      for (let travellerData in officeAddress) {
        if (nonAdressParam.indexOf(travellerData) === -1 && officeAddress[travellerData]) {
          addressText += officeAddress[travellerData] + ', ';
          counter++;
        }
        if (travellerData === 'pincode' && officeAddress[travellerData]) {
          if (counter > 0) {
            addressText = this.replaceLastCommaWith(addressText, '-') + officeAddress[travellerData];
          } else {
            addressText += officeAddress[travellerData]
          }
          pincodeAdded = true;
        }
      }
      if ((counter > 0 && pincodeAdded) || pincodeAdded) {
        addressText += '.';
      } else if (counter > 0) {
        addressText += this.replaceLastCommaWith(addressText, '.')
      }
      this.travellerOfficeAddress[index] = addressText;
    });
  }

  replaceLastCommaWith(text, element) {
    var pos = text.lastIndexOf(',');
    return text.substring(0, pos) + ' ' + element + ' ' + text.substring(pos + 1);
  }

  saveTransaction() {
    this.userSessionInfo.isActive = false;
    this.TransactionService.initTransactionSaving(this.userSessionInfo).subscribe((data) => {
      this.router.navigateByUrl(this._primaryComp + '/send-money/lrs');
    });
  }
}
