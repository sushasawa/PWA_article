import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { DpDatePickerModule } from 'ng2-date-picker';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
// import { isatty } from 'tty';
// import { access } from 'fs';

declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;
@Component({
  selector: 'app-transaction-details',
  templateUrl: './transaction-details.component.html',
  styleUrls: ['./transaction-details.component.css']
})
export class TransactionDetailsComponent implements OnInit {
  public userSessionInfoSend: any;
  public userSessionInfoSendTravellingDetails: any;
  public userSessionInfoSendTravellers: any;
  public userSessionInfoSendSelectedTraveller: any;
  public destinationOptions: any;
  public SupPurposeOptions: any;
  public purposeOptions: any;
  public sendIndex: any = 0;
  public dateConfig: any;
  public todaysDate: any;
  public correspondentFee: any;
  public invalidsubmitted: any = false;
  public termsAcceptance: any;
  public termsAcceptanceTran: any;
  public sendMoneyScreen: any;
  public relationshipOption: any;
  public exchangeRatesUSD: any = 0;
  public _primaryComp: any;
  public travellerAmount: any = 0;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this._primaryComp = '/' + navUrl.navUrl();
    if (SessionHelper.getSession('userSessionInfoSend') === undefined || SessionHelper.getSession('userSessionInfoSend') === null) {
      this.router.navigateByUrl(this._primaryComp + 'send-money/');
    }
    this.relationshipOption = [
      { value: 'Father', label: 'Father', Id: 1, purpose: 'Father' },
      { value: 'Mother', label: 'Mother', Id: 2, purpose: 'Mother' },
      { value: 'Brother', label: 'Brother', Id: 3, purpose: 'Brother' },
      { value: 'Sister', label: 'Sister', Id: 4, purpose: 'Sister' },
      { value: 'Son', label: 'Son', Id: 5, purpose: 'Son' },
      { value: 'Daughter', label: 'Daughter', Id: 6, purpose: 'Daughter' },
      { value: 'Spouse', label: 'Spouse', Id: 7, purpose: 'Spouse' }
    ];
    this.userSessionInfoSend = JSON.parse(SessionHelper.getSession('userSessionInfoSend'));
    this.userSessionInfoSendTravellingDetails = this.userSessionInfoSend.sendMoneyScreen.traveller[0].travellingDetails;
    this.userSessionInfoSendTravellers = this.userSessionInfoSend.sendMoneyScreen.traveller;
    this.sendMoneyScreen = this.userSessionInfoSend.sendMoneyScreen;
    this.userSessionInfoSendSelectedTraveller = this.userSessionInfoSend.sendMoneyScreen.traveller[0];
    this.getExchangeRatesUSD();
    this.masterService.getDestinationList()
      .subscribe(data => {
        this.destinationOptions = data;
      }, err => {
        // swal('Oops...', 'Unable to fetch destination list!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch destination list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
      });
      });

    this.masterService.getPurposeList(4)
      .subscribe(data => {
        this.purposeOptions = data;
      }, err => {
        // swal('Oops...', 'Unable to fetch purpose list!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch purpose list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
      });
      });

      
      
    this.selectTraveller(0);
    this._document.title = 'Beneficiary details for transaction';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Beneficiary details for transaction' });
    this.getSubPurpose(0);
  }

  ngOnInit() {
    this.todaysDate = this.masterService.getTodaysDate();
    this.dateConfig = {
      format: 'DD-MM-YYYY',
      min: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
      userValueType: 'string'
    }
    initDocument();
    this.correspondentFee = this.masterService.getBankCorrespondentCharges();
  }

  onDataChange(event, travellerIndex: any): void {
    console.log(event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfoSend.sendMoneyScreen.traveller[travellerIndex].selfTransaction.beneficiaryTravellerArrivalDate = event;
      SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfoSend));
    }
  }



  selectTraveller(travellerIndex) {
   
    this.sendIndex = travellerIndex;
    for (let i = 0; i <= this.userSessionInfoSendTravellers.length - 1; i++) {
      this.userSessionInfoSendTravellers[i].selected = false;
    }
    this.userSessionInfoSendTravellers[travellerIndex].selected = true;
    // console.log(this.userSessionInfoSendTravellers);
    this.travellerAmount = 0;
    this.userSessionInfoSendTravellers[travellerIndex].prepaidCardDetails.forEach((prepaidCard)=>{
      this.travellerAmount += prepaidCard.exchangeRate.rate * prepaidCard.forexAmount;
    });

    console.log(this.userSessionInfoSendTravellers[travellerIndex].purpose)

    this.getSubPurpose(travellerIndex);
    // this.masterService.getSubPurpose()
    // .subscribe(data => {
    //   this.SupPurposeOptions = data;
    // }, err => {
    //   swal('Oops...', 'Unable to fetch Sub purpose list!', 'error');
    // });

  }

  getSubPurpose(travellerIndex) {
    const info = {
      purposeName: this.userSessionInfoSendTravellers[travellerIndex].purpose
    };

    this.masterService.getSubPurpose(info)
    .subscribe(data => {
      this.SupPurposeOptions = data;
    }, err => {
      swal('Oops...', 'Unable to fetch Sub purpose list!', 'error');
    });
  }



  callPinCodeService(event, type) {
    const pinCode = event.target.value;

    this.masterService.getPinCodeDetails(pinCode)
      .subscribe(data => {
        console.log(data);
        const Retdata: any = data;
        if (Retdata.Status === 'Success') {
          this.userSessionInfoSendSelectedTraveller.transactionDetails['beneficiaryCity'] = Retdata.PostOffice[0].District;
          this.userSessionInfoSendSelectedTraveller.transactionDetails['beneficiaryState'] = Retdata.PostOffice[0].State;
          this.userSessionInfoSendSelectedTraveller.transactionDetails['beneficiaryArea'] = Retdata.PostOffice[0].Name;
        } else {
          this.userSessionInfoSendSelectedTraveller.transactionDetails['beneficiaryCity'] = '';
          this.userSessionInfoSendSelectedTraveller.transactionDetails['beneficiaryState'] = '';
          this.userSessionInfoSendSelectedTraveller.transactionDetails['beneficiaryArea'] = '';
        }
      });
  }
  updateFormSession() {
    this.userSessionInfoSend.sendMoneyScreen.traveller[this.sendIndex] = this.userSessionInfoSendTravellers[this.sendIndex];
    // sessionStorage.userSessionInfoSend = JSON.stringify(this.userSessionInfoSend);
    SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfoSend));
    //  console.log(sessionStorage.userSessionInfoSend);
  }

  updateSession() {
    SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfoSend));
  }
  // check for country
  checkCountry(index, event) { console.log(event);
    const country = this.userSessionInfoSendTravellers[index].transactionDetails.beneficiaryCountry = event.toUpperCase();
  //  console.log(this.userSessionInfoSendTravellers[index].transactionDetails.beneficiaryCountry);
    if (country === 'NEPAL' || country === 'BHUTAN') {
      // swal('', 'Nepal and Bhutal not allowed', 'error');
      Snackbar.show({
        text: 'Nepal and Bhutal not allowed',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
         this.userSessionInfoSendTravellers[index].transactionDetails.beneficiaryCountry = '';
    }
  }



  // SUBMIT FUNCTION TO REDIRECT PAGE
  submitFunction(transactionForm: NgForm) {
    console.log(transactionForm);
    this.invalidsubmitted = transactionForm.invalid;
    this.updateSession();
    if (transactionForm.valid) {
      if (!this.termsAcceptance) {
        console.log('term call');
        // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
        Snackbar.show({
          text: 'Cannot proceed! Please accept terms and conditions to proceed!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }else if(!this.termsAcceptanceTran){
        // swal('Cannot proceed', 'Please accept transaction terms and conditions to proceed', 'error'); 
        Snackbar.show({
          text: 'Cannot proceed! Please accept transaction terms and conditions to proceed!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });

      } else {
        setTimeout(() => {
          $.magnificPopup.open({
            items: {
              src: '#user-dtls-popup'
            },
            type: 'inline'
          });
        }, 100);
        
      }
    } else {
      // swal('Cannot proceed', 'Please Fill All the required fields for Each Traveller', 'error');
      Snackbar.show({
        text: 'Cannot proceed! Please Fill All the required fields for Each Traveller!',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }
  }

  submitData(flag) {
    if (flag === 'yes') {
      this.setCorrespondentCharges();
    }
    if (flag === 'no') {
      this.removeCorrespondentCharges();
    }
  }

  saveSessionData() {
    
        this.masterService.dumpSessionData(this.userSessionInfoSend)
          .subscribe(data => {
          }, err => {
            console.log(err);
          });
        this.router.navigateByUrl(this._primaryComp + '/send-money/delivery-mode');
      }

  removeCorrespondentCharges(){
    this.userSessionInfoSend.sendMoneyScreen.bankChargesAdded = false;
    this.userSessionInfoSend.sendMoneyScreen.traveller.forEach(traveller => {
      traveller.Bank_Correspondent_Bank_Charges = 0;
    });
    this.updateSession();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#user-dtls-transaction-amt-no-popup'
        },
        type: 'inline'
      });
    }, 100);
    }

  getExchangeRatesUSD() {
    this.exchangeRatesUSD = this.userSessionInfoSend.ddRateBuy;
  }

  setCorrespondentCharges() {
    this.userSessionInfoSend.sendMoneyScreen.bankChargesAdded = true;
    this.userSessionInfoSend.sendMoneyScreen.traveller.forEach(traveller => {
      traveller.Bank_Correspondent_Bank_Charges = this.exchangeRatesUSD * this.correspondentFee;
    });
    this.updateSession();
    this.saveSessionData();
    // Snackbar.show({
    //   text: 'Bank Correspondent Bank charges added to your original remittance amount',
    //   pos: 'bottom-right',
    //   actionTextColor: '#ff4444',
    // });
  }

  isSelfTraveler(isActive, TravellerBenificiaryIndex) {
    // tslint:disable-next-line:max-line-length
    // console.log(this.userSessionInfoSendTravellers[TravellerBenificiaryIndex].transactionDetails[TravellerBenificiaryIndex].beneficiaryTransSelf);
    console.log(isActive);
    console.log(TravellerBenificiaryIndex);
    if (isActive === 'yes') {
      this.userSessionInfoSendTravellers[TravellerBenificiaryIndex].selfTransaction.beneficiaryTravellerName = '';
      this.userSessionInfoSendTravellers[TravellerBenificiaryIndex].selfTransaction.beneficiaryTravellerRelationship = '';
      this.userSessionInfoSendTravellers[TravellerBenificiaryIndex].selfTransaction.beneficiaryTravellerArrivalDate = '';
      this.userSessionInfoSendTravellers[TravellerBenificiaryIndex].selfTransaction.beneficiaryTravellerEducation = '';
      this.userSessionInfoSendTravellers[TravellerBenificiaryIndex].selfTransaction.beneficiaryTravellerCountry = '';
    }
  }
}
