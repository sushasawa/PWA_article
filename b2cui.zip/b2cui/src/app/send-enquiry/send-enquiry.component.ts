import { Component, OnInit, Inject, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MasterService } from '../../app/services/master.services';
import { DatePipe } from '@angular/common';

declare var Snackbar: any;

export interface FormModel {
  captcha?: string;
}
@Component({
  selector: 'send-enquiry',
  templateUrl: './send-enquiry.component.html',
  styleUrls: ['./send-enquiry.component.css']
})
export class SendEnquiryComponent implements OnInit {
  public querySubmited = false;
  public enquiryInfo: any = {}; 
  public products:any;
  public prefixes: any;
  public invalidsubmitted: any;
  public formModel: FormModel = {};
  @Output() closePopupClicked: EventEmitter<any> = new EventEmitter<any>();
  constructor(private masterService: MasterService) {
    this.products = [
      { value: 'Prepaid Card', label: 'Prepaid Card' },
      { value: 'Cash', label: 'Cash' },
      { value: 'Demand Draft', label: 'Demand Draft' }
    ];
    this.prefixes = [
      { value: 'Mr', label: 'Mr' },
      { value: 'Mrs', label: 'Mrs' },
      { value: 'Ms', label: 'Ms' },
      { value: 'Miss', label: 'Miss' }
    ];
  }

  ngOnInit() {
  }

  closePopup() {
    this.closePopupClicked.emit();
    this.querySubmited = false;
  }

  submitEnquiry(rateAlert: NgForm, event: Event) {
    // sendEnquiry
    event.preventDefault();
    this.invalidsubmitted = rateAlert.invalid;
    const payload = rateAlert.value;
    payload.equiryDate = new DatePipe('en-US').transform(new Date(), 'yyyy-MM-dd');
    payload.EnquiryNum = Math.floor(Date.now() / 1000);
    if (rateAlert.valid) {
      this.masterService.sendEnquiry(payload)
        .subscribe(data => {
          const result: any = data;
          if (Number(result.status) === 1) {
            this.querySubmited = true;
          }
        });
    }
  }

}
