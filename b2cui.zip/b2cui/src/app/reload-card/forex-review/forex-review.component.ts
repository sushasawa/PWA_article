import { Component, OnInit, Inject } from '@angular/core';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { BulkExchangeRateService } from './../../services/bulk-exchange-rate.service';
declare var Snackbar: any;
declare var $: any;
declare function initDocument(): any;
@Component({
  selector: 'app-forex-review',
  templateUrl: './forex-review.component.html',
  styleUrls: ['./forex-review.component.css']
})
export class ForexReviewComponent implements OnInit {
  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public discount: any;
  public serviceCharge: any;
  public gst: any;
  public reloadFees: any;
  public TotalPayableMultiTraveller: any;
  public currencyLists: any = [];
  public popupData: any;
  public _primaryComp: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any, private _BulkExchangeRateService: BulkExchangeRateService) {
    // console.log(SessionHelper.getSession('userSessionInfoRealoadCard'));
    this._primaryComp = '/' + navUrl.navUrl();
    this.discount = 0;
    this.serviceCharge = 0;
    this.gst = 0;
    this.reloadFees = 0;
    this.TotalPayableMultiTraveller = 0;
    this.getCharges()
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoRealoadCard'));
    this.userSessionInfoRegistration = this.userSessionInfo.reloadCardScreen.traveller[0].registrationInfo;
    this.userSessionInfoTravellingDetails = this.userSessionInfo.reloadCardScreen.traveller[0].travellingDetails;
    this.userSessionInfoTravellers = this.userSessionInfo.reloadCardScreen.traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.reloadCardScreen.traveller[0];
    this._document.title = 'Review your current transaction';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Review your current transaction' });

  }

  syncSession() {
    let totalAmount: any = 0;
    let grantTotalAmount: any = 0;
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      let charges = 0;
      totalAmount = 0;
      traveller.selected = false;
      traveller.prepaidCardDetails.map((prepaidCardDetail) => {
        prepaidCardDetail.currencyDetails.map((currency) => {
          totalAmount += (currency.forexAmount * currency.exchangeRate.rate) - this.discount;
        });
      });
      traveller.totalAmount = totalAmount + this.serviceCharge + this.reloadFees;
      charges += this.serviceCharge + this.reloadFees;
      this.userSessionInfo.reloadCardScreen.traveller[index].totalAmount = traveller.totalAmount;
      let totalTaxableAmount = totalAmount + this.serviceCharge + this.reloadFees;
      traveller.serviceCharge = this.serviceCharge;
      traveller.reloadFees = this.reloadFees;
      this.masterService.getTaxes(totalTaxableAmount).subscribe((data) => {
        const result: any = data;
        totalTaxableAmount += result.TotalTax;
        traveller.totalAmount = totalTaxableAmount;
        traveller.gst = result.TotalTax;
        traveller.Charges = charges;
        grantTotalAmount += parseInt(traveller.totalAmount);
        this.userSessionInfo.reloadCardScreen.usedAmount = grantTotalAmount;
        SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
        this.updateSession();
        totalAmount = 0;
      });
      this.updateSession();
    });
    this.userSessionInfoTravellers[0].selected = true;
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];
    this.masterService.getCurrencyList(1).subscribe((data) => {
      this.currencyLists = data;
    });
  }

  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.serviceCharge = Charges.response.serviceCharge;
      this.reloadFees = Charges.response.LoadFee;
      this.syncSession();
      this.updateSession();

    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }
  ngOnInit() {
    $('body').attr('id', '');
    initDocument();

}
  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
    // console.log(this.userSessionInfoSelectedTraveller);
  }

  populatePopup(currencyCode, forexAmount, exchangeRate) {
    this.currencyLists.map((currency, index) => {
      if (currency.Code === currencyCode) {
        this.popupData =
          '1 ' + currency.label + ' = <i class="fa-rupee"></i>' + exchangeRate + '<br>' +
          forexAmount + ' ' + currency.Code + ' = ' + '<i class="fa-rupee"></i>' + (forexAmount * exchangeRate).toFixed(2);
      }
    });
  }

  onSaveAndTemporaryExit() {
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession('userSessionInfoReloadCard');
    this.router.navigateByUrl(this._primaryComp + `/reload-card`);
  }

  submitAndRedirect() {
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
    this.router.navigateByUrl(this._primaryComp + '/reload-card/lrs-form');
  }



  updateSession() {
    SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
  }
}
