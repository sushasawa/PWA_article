import { Component, OnInit, Input, OnChanges } from '@angular/core';

import { NavigatePathService} from './../services/navigate-path.service';
import { SessionHelper } from '../../app/helpers/session-helper';
import { SessionTemplate } from '../helpers/session-template';
import { SessionCheckerService } from '../services/session-checker.service';

declare var $: any;

declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
@Component({
    // tslint:disable-next-line:component-selector
    selector: 'forex-header',
    templateUrl: 'header.component.html'
})

export class HeaderComponent implements OnInit  , OnChanges {
    public _primaryComp: any;
    @Input() UrlParam: string;
    constructor(public sessionChecker: SessionCheckerService, public _NavigatePathService: NavigatePathService) {
   }

    ngOnInit() {
        $('body').attr('id', '');
        // setTimeout(() => {
        //     this._primaryComp = '/' + this._NavigatePathService.navUrl();
        //     console.log(this._primaryComp);
        // }, 500);
        // initDocument();
    }

    ngOnChanges() { console.log('dsa');
        this._primaryComp = '/' + this.UrlParam;
    }

    logout() {
        SessionHelper.removeSession('userInfo');
        SessionHelper.removeSession('userSessionInfo');
        SessionHelper.removeSession('userSessionInfoSale');
        SessionHelper.removeSession('userSessionInfoRealoadCard');
        SessionHelper.removeSession('userSessionInfoSend');
        SessionHelper.removeSession('currentUser');
        SessionHelper.removeSession('AgentID');
        SessionHelper.removeSession('agentURLParam');
        window.location.href = '/';
    }
}
