import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
const routes: Routes = [
  { path: '', redirectTo: 'CNK/buy', pathMatch: 'full' },
  { path: ':clientName/page-not-found', component: PageNotFoundComponent },
  { path: ':clientName/buy', loadChildren: './buy/buy.module#BuyModule' },
  { path: 'CNK/buy', loadChildren: './buy/buy.module#BuyModule' },
  { path: ':clientName/send-money', loadChildren: './sendmoney/sendmoney.module#SendmoneyModule' },
  { path: ':clientName/reload-card', loadChildren: './reload-card/reload-card.module#ReloadCardModule' },
  { path: ':clientName/sell', loadChildren: './sell/sell.module#SellModule' },
  { path: ':clientName/account', loadChildren: './my-account/my-account.module#MyAccountModule' },
  { path: ':clientName/forex-live-rates' , loadChildren : './forex-live-rates/forex-live-rates.module#ForexLiveRatesModule' },
  { path: ':clientName/currency-convertor' , loadChildren : './currency-convertor/currency-convertor.module#CurrencyConvertorModule' },
  { path: ':clientName/login' , loadChildren : './register-login/register-login.module#RegisterLoginModule' },
  { path: ':clientName/footer-components', loadChildren: './footer-components/footer-components.module#FooterComponentsModule' },
  //{ path: ':clientName/visa', loadChildren: './visa/visa.module#VisaModule'},
  // { path: ':clientName/insurance', loadChildren: './insurance/insurance.module#InsuranceModule'},
   // otherwise redirect to home
  { path: ':clientName' , redirectTo : ':clientName/buy' },
  { path: '**' , redirectTo: 'CNK/page-not-found' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
