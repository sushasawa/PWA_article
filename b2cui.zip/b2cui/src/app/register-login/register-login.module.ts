import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { SelectModule } from 'ng-select';
import { RegisterLoginComponent } from './register-login/register-login.component';
import { CommonReviewUserDetailsComponent } from './common-review-user-details/common-review-user-details.component';
import { CommonUsercreationComponent } from './common-usercreation/common-usercreation.component';
import { PipesModule } from '../pipes/pipes.module';
import { PasswordStrengthBarModule } from 'ng2-password-strength-bar';

import {DpDatePickerModule} from 'ng2-date-picker';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { NewLeadLoginComponent } from './new-lead-login/new-lead-login.component';
import { ExistingLeadLoginComponent } from './existing-lead-login/existing-lead-login.component';

const routes: Routes = [
  {
    path: '', children: [
      { path: '', component: RegisterLoginComponent },
      { path: 'create-account', component: CommonUsercreationComponent,
        data: {
          nextLink: '/login/review-userdetail-adhar'
        }
      },
      {
        path: 'review-userdetail-adhar', component: CommonReviewUserDetailsComponent,
        // canActivate: [AuthGuard]
        data: {
          nextLink: '/login'
        }
      },
      {
        path: 'forgot-password', component: ForgotPasswordComponent,
        // canActivate: [AuthGuard]
        data: {
          nextLink: ''
        }
      },
      {
        path: 'reset-password', component: ResetPasswordComponent,
        // canActivate: [AuthGuard]
        data: {
          nextLink: ''
        }
      },
      {
        path: 'newLeadLogin', component: NewLeadLoginComponent,
        // canActivate: [AuthGuard]
        data: {
          nextLink: ''
        }
      },
      {
        path: 'existingLeadLogin', component: ExistingLeadLoginComponent,
        // canActivate: [AuthGuard]
        data: {
          nextLink: ''
        }
      }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    FormsModule,
    DpDatePickerModule,
    PipesModule,
    SelectModule,
    PasswordStrengthBarModule
  ],
  // tslint:disable-next-line:max-line-length
  declarations: [RegisterLoginComponent, CommonReviewUserDetailsComponent, CommonUsercreationComponent, ForgotPasswordComponent, ResetPasswordComponent, NewLeadLoginComponent, ExistingLeadLoginComponent]
})
export class RegisterLoginModule { }
