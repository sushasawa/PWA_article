import { Component, OnInit, Input, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import * as sha from 'sha.js';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { DpDatePickerModule } from 'ng2-date-picker';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var jquery: any;
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
@Component({
  selector: 'app-common-review-user-details',
  templateUrl: './common-review-user-details.component.html',
  styleUrls: ['./common-review-user-details.component.css']
})
export class CommonReviewUserDetailsComponent implements OnInit {
  public registrationInfo: any;
  public nextLink: any;
  public userInfo: any;
  public configsMin: any = [];
  public configsMax: any = [];
  public todaysDate: any;
  public selIndex: any;
  public _primaryComp: any;
  public skipAdhaarValidationFlag: any = false;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private route: ActivatedRoute, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    if(SessionHelper.getSession('newRegistrationInfo')){
      this.registrationInfo = JSON.parse(SessionHelper.getSession('newRegistrationInfo'));
    }
    this.skipAdhaarValidationFlag = this.masterService.getSkipAdhaarValidationFlag();
    this._primaryComp = '/' + navUrl.navUrl();
    this._document.title = 'Review Your Details';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'Review Your Details'});
  }

  ngOnInit(): void {
    this.nextLink = this.route.snapshot.data.nextLink;
    if(SessionHelper.getSession('userInfo')){
      this.userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
    }    
    $('body').attr('id', '');
    initDocument();
  }

  setDateConfig(startDate, endDate, index) {
    let maxDate = '',
      minDate = '';
    this.todaysDate = this.masterService.getTodaysDate();
    if (startDate !== '') {
      minDate = startDate;
    } else {
      minDate = this.todaysDate;
    }
    if (endDate !== '') {
      maxDate = endDate;
    }
    this.configsMin[index] = {
      format: 'DD-MM-YYYY',
      min: minDate
    }
    this.configsMax[index] = {
      format: 'DD-MM-YYYY',
      max: maxDate,
      min: this.todaysDate
    }
  }



  onSubmit() {
    if (this.registrationInfo.password !== undefined) {
      const sendRegistrationInfo = [];
      
      let password: any;
      password = this.registrationInfo.password;
      password = sha('sha256').update(password, 'utf8').digest('hex');
      this.registrationInfo.password = '';
      this.registrationInfo.password = password;
      this.registrationInfo.parent = true;
      sendRegistrationInfo.push(this.registrationInfo);
      if (sendRegistrationInfo[0].userId === '') {
        this.masterService.setUserRegistration(sendRegistrationInfo)
          .subscribe(data => {
            const result: any = data;
            this.registrationInfo.userId = result.data[0].ParentId;

            localStorage.setItem('accessToken', result.token);
            Snackbar.show({text: 'Account created successfully.',
            pos: 'bottom-right' ,
           });
          });
      } else {
        // this.userInfo.userName = sendRegistrationInfo[0].firstName.value + ' ' + sendRegistrationInfo[0].middleName + ' '
        //   + sendRegistrationInfo[0].lastName;
        // SessionHelper.setSession('userInfo', JSON.stringify(this.userInfo));
        this.masterService.updateUserRegistration(sendRegistrationInfo)
          .subscribe(data => {
            console.log(data);
          });
      }
      // this.userInfo.userName = sendRegistrationInfo[0].firstName.value + ' ' + sendRegistrationInfo[0].middleName + ' '
      //   + sendRegistrationInfo[0].lastName;
      // SessionHelper.setSession('userInfo', JSON.stringify(this.userInfo));

    }
    SessionHelper.removeSession('newRegistrationInfo');
    this.router.navigateByUrl(this._primaryComp + this.nextLink);
  }


  // updateSession() {
  //   SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
  // }

  

  onEditClick() {      
    this.router.navigateByUrl(this._primaryComp + `/login/create-account`);
  }


}
