import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router, Params } from '@angular/router';
import { NgForm } from '@angular/forms';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import * as sha from 'sha.js';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  public invalidsubmitted: any;
  public authorized: Boolean;
  public invalidUrl: Boolean;
  public email: string;
  public success: boolean;
  public hideBox : boolean;
  public _primaryComp: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private route: ActivatedRoute, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this.authorized = true;
    this.invalidUrl = true;
    this.success = true;
    this.hideBox = false;
    this._document.title = 'Reset password page';
    this._primaryComp = '/' + navUrl.navUrl();
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Reset password page' });
  }

  ngOnInit() {
    this.route.queryParams.subscribe((params: Params) => {
      let urlString = params['for'];
      const passwordInfo: any = {};
      passwordInfo.urlString = urlString;
      this.masterService.validateUrl(passwordInfo).subscribe(data => {
        const result: any = data;
        console.log(data);
        console.log(result);
        if (result.response === true) {
          this.email = result.email;
          console.log('true' + result.response);
        } else {
          console.log('false');
          this.invalidUrl = false;

        }
      }, err => {
        console.log(err);
        this.invalidUrl = false;
      });
    });


  }

  resetPasswordSubmit(UserInfo: NgForm, e: Event) {
    e.preventDefault();
    if (this.email) {
      this.invalidsubmitted = UserInfo.invalid;
      var npassword = UserInfo.value.npassword;
      var cpassword = UserInfo.value.cpassword;
      const passwordInfo: any = {};
      if (!this.invalidsubmitted) {
        if (npassword != cpassword) {
          this.authorized = false;
        } else {
          passwordInfo.newPassword = sha('sha256').update(npassword, 'utf8').digest('hex');
          passwordInfo.emailId = this.email;
          this.masterService.resetPassword(passwordInfo).subscribe(data => {
            const result: any = data;
            this.authorized = true;
            this.success = false;
            this.hideBox = true;
          }, err => {
            this.authorized = false;
          });
        }
      }else{
        this.authorized = false;
      }

    }else{
      this.invalidUrl = false;
    }
  }

}
