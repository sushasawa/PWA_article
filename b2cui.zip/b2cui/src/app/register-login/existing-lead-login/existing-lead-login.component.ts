import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms';
import * as sha from 'sha.js';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { SessionValueResetService } from '../../services/session-value-reset.service';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-existing-lead-login',
  templateUrl: './existing-lead-login.component.html',
  styleUrls: ['./existing-lead-login.component.css']
})
export class ExistingLeadLoginComponent implements OnInit {
  public invalidsubmitted: any;
  public authorized: Boolean;
  public signinmsg: String;
  public newLeadLoginJSON: any = {
    'uname': '',
    'confirmPassword': '',
    'newPassword': '',
    'oldPassword': '',
    'LeadId': ''
  };
  public tempNo: any;
  public LeadId: any;
  public lead: any;
  public AgentId: any;
  public _primaryComp: any;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private location: Location, private route: ActivatedRoute, private _SessionValueResetService: SessionValueResetService, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    console.log('EXISTING COMPONENT LOADED');
    
    this._primaryComp = '/' + navUrl.navUrl();
    this.authorized = true;
    this.signinmsg = 'Sign In';
    this.lead = this.route.snapshot.queryParams.lead;
    this.checkActiveUrl();
    this._document.title = 'Sign in via registered Email ID';
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Sign in via registered Email ID' });
  }

  ngOnInit() {
    initDocument();
  }

  loginSubmit(UserInfo: NgForm, e: Event) {
    e.preventDefault();
    this.invalidsubmitted = UserInfo.invalid;
    const payload: any = {};
    let password = UserInfo.value.upassword;
    const username = UserInfo.value.uname;
    password = sha('sha256').update(password, 'utf8').digest('hex');
    payload.upassword = password;
    payload.uname = this.newLeadLoginJSON.uname;
    console.log(payload);
    if (!this.invalidsubmitted) {
      this.signinmsg = 'Checking ...';
      this.masterService.loginUser(payload).subscribe(data => {
        const result: any = data;
        this.authorized = true;
        this.signinmsg = 'Success...';
        const userinfo = {
          'loggedin': result.success,
          'uname': result.response[0][0].EmailId,
          'uid': result.response[0][0].Id,
          'userName': result.response[1][0].firstName + ' ' + result.response[1][0].lastName
        };
        this.updateExistingUsersLeadProspectsAndUrlActiveStatus();
        this.masterService.setUserIdToSession(this.tempNo, result.response[0][0].EmailId, result.response[0][0].Id)
          .subscribe((userSessionUpdated) => {
            console.log(userSessionUpdated);
          });
          this.navUrl.setNavUrl();
        SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
        this.signinmsg = 'Redirecting...';
        const CheckTempSession = SessionHelper.getSession('tempNo')
        || SessionHelper.getSession('tempNo') === 'undefined'
        || SessionHelper.getSession('tempNo') === null
        || SessionHelper.getSession('tempNo') === 'null';
        if (!CheckTempSession) {
          SessionHelper.removeSession('tempNo');
          this.router.navigateByUrl(this._primaryComp + '/buy');
        } else {
          console.log('FOUND IN TEMP REDIRECT FUCNTION');
          const tempNo = SessionHelper.getSession('tempNo');

          console.log('CHECK CHECK CHECK CHECK', tempNo);
          this.masterService.getOrderDataFromEmail(tempNo, this.newLeadLoginJSON.uname)
            .subscribe(OrderDataFromEmail => {
              const sessionData: any = OrderDataFromEmail;
              sessionData.userId = result.response[0][0].Id;
              sessionData[sessionData.type].traveller[0].registrationInfo.userId = result.response[0][0].Id;
              sessionData[sessionData.type].traveller[0].registrationInfo.parentId = result.response[0][0].Id;
              console.log(sessionData.buyScreen);
              console.log(sessionData.sellScreen);
              console.log(sessionData.reloadCardScreen);
              console.log(sessionData.sendMoneyScreen);
              console.log(sessionData.nextLink);
              sessionData.redirectToNextLink = true;
              if (sessionData.buyScreen) {
                this.modifyNextLink(sessionData.nextLink, sessionData, 'nextLink', 'buy');
                console.log(sessionData);
                this._SessionValueResetService.getUserSessionInfo('userSessionInfo', sessionData);
                // this.router.navigateByUrl(this._primaryComp + '/buy/compare-details');
              } else if (sessionData.sellScreen) {
                this.modifyNextLink(sessionData.nextLink, sessionData, 'nextLink', 'sell');
                this._SessionValueResetService.getUserSessionInfo('userSessionInfoSale', sessionData);
                // this.router.navigateByUrl(this._primaryComp + '/sell/compare-details');
              } else if (sessionData.reloadCardScreen) {
                this.modifyNextLink(sessionData.nextLink, sessionData, 'nextLink', 'send-money');
                this._SessionValueResetService.getUserSessionInfo('userSessionInfoRealoadCard', sessionData);
                // this.router.navigateByUrl(this._primaryComp + '/reload-card/compare-details');
              } else if (sessionData.sendMoneyScreen) {
                this.modifyNextLink(sessionData.nextLink, sessionData, 'nextLink', 'reload-card');
                this._SessionValueResetService.getUserSessionInfo('userSessionInfoSend', sessionData);
                // this.router.navigateByUrl(this._primaryComp + '/send-money/compare-details');
                // this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
              }
              const routeLink = sessionData.nextLink.split('/')[1];
              this.router.navigateByUrl(this._primaryComp + `/${routeLink}/create-account`);
            }, err => {
              // Snackbar.show({
              //   text: 'Oops ! Invalid order number',
              //   pos: 'bottom-right',
              //   actionTextColor: '#ff4444',
              // });

              this.router.navigateByUrl(this._primaryComp + '/buy');
            });
        }
      }, err => {
        this.signinmsg = 'Sign in';
        this.authorized = false;
        const userinfo = { 'loggedin': false };
        // this.router.navigateByUrl(this._primaryComp + '/' + this.currentlocation[1] + '/register-login');
        SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
      });
    }
  }

  modifyNextLink(nextLink, sessionData, node, type) {
    let nextLinkArr = nextLink.split('/');
    if (nextLinkArr.indexOf(type) > 0) {
      let UrlLength = nextLinkArr.indexOf(type);
      for(let loopVar = 0; loopVar < UrlLength; loopVar++){
        nextLinkArr.shift();
      }
      nextLink = nextLinkArr.join('/');
      sessionData[node] = '/' + nextLink;
    }
  }

  checkActiveUrl() {
    console.log(this.lead);
    if(this.lead){
      this.masterService.checkActiveUrl(this.lead)
      .subscribe((UrlStatus) => {
        console.log(UrlStatus);
        const status: any = UrlStatus;
        if (status.IsUrlActive) {
          this.newLeadLoginJSON.uname = status.EmailId;
          this.tempNo = JSON.parse(status.TempNo);
          this.LeadId = status.LeadId;
          this.AgentId = status.AgentId;
          this.newLeadLoginJSON.LeadId = this.LeadId;
          SessionHelper.setSession('LeadID', this.LeadId);
          SessionHelper.setSession('AgentID', status.AgentId);
          SessionHelper.setSession('IExhangeAgentId', status.IExchangeAgentID);
        } else {
          Snackbar.show({
            text: 'Link has been Expired and This User Exists please Login...',
            pos: 'bottom-left',
            actionTextColor: '#ff4444',
          });
          this.router.navigateByUrl(this._primaryComp + '/login');
        }
        console.log(typeof this.tempNo);
        if (this.tempNo) {
          SessionHelper.setSession('tempNo', this.tempNo);
        } else {
          SessionHelper.removeSession('tempNo');
          console.log('NO TEMP');
        }
      });
    } else {
      this.router.navigateByUrl(this._primaryComp + '/login');
    }    
  }

  updateExistingUsersLeadProspectsAndUrlActiveStatus() {
    const payload: any = {
      AgentId: this.AgentId,
      LeadId: this.LeadId
    };
    this.masterService.updateExistingUsersLeadProspectsAndUrlActiveStatus(payload).subscribe((data) => {
      console.log(data);
    });
  }

}
