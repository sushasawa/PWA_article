import { Component, OnInit, Input, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '../../../app/helpers/location';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import {DpDatePickerModule} from 'ng2-date-picker';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

// import { setInterval } from 'timers';

declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
 
declare var $: any;

@Component({
  selector: 'app-common-usercreation',
  templateUrl: './common-usercreation.component.html',
  styleUrls: ['./common-usercreation.component.css']
})
export class CommonUsercreationComponent implements OnInit {
  public cityOptions: any; // : GenericEntity[];
  public nationalityOptions: any; // : GenericEntity[];
  public selIndex = 0;
  public termsAcceptance = false;
  public termsAcceptanceAdhar = false;
  public DatepickerOptions: any;
  public todaysDate: any;
  public nextLink: any;
  public configDob: any;
  public configsMin: any = [];
  public configsMax: any = [];
  public testDate: any = '01-01-2017';
  public invalidsubmitted: any;
  public isNRI: any;
  public skipAdhaarValidationFlag: any;
  public _primaryComp: any;
  public registrationInfo: any = {
    'userId': '',
    'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
    'middleName': '',
    'lastName': '',
    'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
    'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
    'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
    // "nationality": { "id": "", "name": "" } ,
    'nationality': '',
    'mothersMaidenName': {
        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
            + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
            + 'event.target.style.background=\'#f8f8f8\'}'
    },
    'PAN': {
        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
            + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
            + 'event.target.style.background=\'#f8f8f8\'}'
    },
    'passportNumber': '',
    'ParentId': true,
    'dateOfIssue': '',
    'placeOfIssue': '',
    'expiryDate': '',
    'address': '101 5A Galaxy apartment',
    'isPassportAddressAsAdhar': 'yes',
    'adharAddress': {
        'flatNumber': '',
        'buildingName': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': '',
    },
    'passportAddress': {
        'flatNumber': '',
        'buildingName': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': '',
    },
    'currentAddressAs': 'asPerAdhar',
    'otherAddress': {
        'flatNumber': '',
        'buildingName': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': '',
    },
    'contactDetails': {
        'mobileNo': '',
        'emailId': ''
    },
    'alternateContactDetails': {
        'countryCode': '',
        'mobileNo': '',
        'countryCode2': '',
        'cityCode': '',
        'telephoneNo': '',
        'emailId': '',
    },
    'officeAddress': {
        'designation': '',
        'conpanyName': '',
        'companyDivision': '',
        'flatNumber': '',
        'building': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': ''
    },
    'officeContactDetails': {
        'countryCode': '',
        'telephoneNumber': '',
        'officeExtension': '',
    },
    'password': '',
    'confirmPassword': '',
  }

  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private route: ActivatedRoute, private MasterService:MasterService, private meta: Meta, @Inject(DOCUMENT) private _document: any) {    
    this._document.title = 'Create your account here';
    this._primaryComp = '/' + navUrl.navUrl();
    this.skipAdhaarValidationFlag = this.masterService.getSkipAdhaarValidationFlag();
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'Create your account here'});
  }

  ngOnInit(): void {

    $('body').attr('id', '');
    if(SessionHelper.getSession('newRegistrationInfo')){
        this.registrationInfo = JSON.parse(SessionHelper.getSession('newRegistrationInfo'));
    }
    
    this.nextLink = this.route.snapshot.data.nextLink;
    this.todaysDate = this.masterService.getTodaysDate();
    this.configDob = {
      format: 'DD-MM-YYYY',
      max : this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.setDateConfig(this.registrationInfo.dateOfIssue, this.registrationInfo.expiryDate);
    this.masterService.getCityList()
      .subscribe(data => {
        this.cityOptions = data;
        const currentDocument = this;
      });

    this.masterService.getNationalityList()
      .subscribe(data => {
        this.nationalityOptions = data;
      });


      setTimeout(function(){
        $('ng-select > div').css('border', '0px solid black');
        $('.dp-picker-input').css('height', '44px').css('width', '275px');
      }, 5);
  }
  callPinCodeService(event, type) {
    const pinCode = event.target.value;

    // this.registrationInfo[type]['city'] = '##Service offline##';
    // this.registrationInfo[type]['state'] = '##Service offline##';
    // this.registrationInfo[type]['area'] = '##Service offline##';

    this.masterService.getPinCodeDetails(pinCode)
      .subscribe(data => {
        const Retdata: any = data;
        if (Retdata.Status === 'Success') {
          this.registrationInfo[type]['city'] = Retdata.PostOffice[0].District;
          this.registrationInfo[type]['state'] = Retdata.PostOffice[0].State;
          this.registrationInfo[type]['area'] = Retdata.PostOffice[0].Name;
        } else {
          this.registrationInfo[type]['city'] = '';
          this.registrationInfo[type]['state'] = '';
          this.registrationInfo[type]['area'] = '';
        }
      });
  }


  dataChangeBirth(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.registrationInfo.dateOfBirth.value = event;
      SessionHelper.setSession('newRegistrationInfo', JSON.stringify(this.registrationInfo));
    }
  }

  updateSession() {
    SessionHelper.setSession('newRegistrationInfo', JSON.stringify(this.registrationInfo));
  }

  updateSession1(registrationInfo, value, index){
    setTimeout(() => {      
      registrationInfo[index] = value.split(/\b/g).map(word => this.titleCaseWord(word)).join('');
    }, 10);    
  }

  titleCaseWord(word: string) {
    if (!word) return word;
    return word[0].toUpperCase() + word.substr(1).toLowerCase();
  }

  dataChangeStart(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.registrationInfo.dateOfIssue = event;
      SessionHelper.setSession('newRegistrationInfo', JSON.stringify(this.registrationInfo));
      this.configsMin = {
        format: 'DD-MM-YYYY',
        min : this.masterService.addDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      }
    }
  }

  dataChangeEnd(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.registrationInfo.expiryDate = event;
      SessionHelper.setSession('newRegistrationInfo', JSON.stringify(this.registrationInfo));
      this.configsMax = {
        format: 'DD-MM-YYYY',
        max : this.masterService.substractDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      }
    }
  }


  checkEmail(event, userForm: NgForm) {
    this.masterService.getEmailValidation(event.target.value)
    .subscribe(data => {
      const retData: any = data;
      if (retData.message.status === 'emailNotExists') {        
        $('.confirmEmailId > div > ul > li').css('background-color', 'rgb(0, 255, 0)');
      }else if (retData.message.status === 'emailExists') {
        this.registrationInfo.contactDetails.emailId = '';
        $('.confirmEmailId > div > ul > li').css('background-color', 'red');
        Snackbar.show({
          text: 'This email ID already exists, please log-in with your email ID.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }
      // console.log(retData.message.status);
    });
  }

  confirmPassword(event) {
    if (event.target.value === this.registrationInfo.password) {
       $('.confirmPassword > div > ul > li').css('background-color', 'rgb(0, 255, 0)');
    }else {
      $('.confirmPassword > div > ul > li').css('background-color', 'red');
    }
  }





  // SUBMIT FUNCTION TO REDIRECT PAGE
  submitFunction(userForm: NgForm, event: Event): void {
    event.preventDefault();
    this.invalidsubmitted = userForm.invalid;
    if (!this.isNRI) {
      Snackbar.show({
        text: "Please select option from 'Are you currently residing in India?'",
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    if (this.isNRI === 'No') {
      Snackbar.show({
        text: 'Cannot proceed!, You can not create account as you are not residing in India.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    if (userForm.valid) {
      if (!this.termsAcceptance) {
        // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
        Snackbar.show({text: 'Cannot proceed!, Please accept terms and conditions to proceed',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
       });

      }else {
        if(this.skipAdhaarValidationFlag){
          this.skipAdhaarValidation();
        } else {
          setTimeout(() => {
            $.magnificPopup.open({
              items: {
                src: '#consent-popup'
              },
              type: 'inline'
            });
          }, 100); 
        }                  
      }
    }else {
      // swal('Cannot proceed', 'Please fill required inputs', 'error');
      Snackbar.show({text: 'Please fill the mandatory fields highlighted.',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
    }
  }

  skipAdhaarValidation(){
    $.magnificPopup.close();
    this.router.navigateByUrl(this._primaryComp + this.nextLink);
  }

  ValidateAdhar(){
    if (!this.termsAcceptanceAdhar) {
      // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
      Snackbar.show({text: 'Cannot proceed!, Please accept Adhaar terms and conditions to proceed.',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
      return;
    }
    $.magnificPopup.close();
      this.masterService.validateAdhaar({"adharNo":this.registrationInfo.adharCardNo.value, "name":this.registrationInfo.firstName.value})
      .subscribe(data => {
        let returnDate:any = data;
        if(returnDate.ReturnType !== "Error"){
            this.router.navigateByUrl(this._primaryComp + this.nextLink);
          
        } else {
          // swal('Cannot proceed', 'Adhar validation failed. Please enter correct adhar details.', 'error');
          Snackbar.show({text: 'Cannot proceed! , Adhar validation failed. Please enter correct adhar details.',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
          
        }
      },err => {        
      });
  }
  // GENDER RADIO CHANGE
  Gender(newValue: any) {
    this.registrationInfo.gender.value = newValue;
  }

  isINRCheck(newValue: any) {
    this.isNRI = newValue;
  }
  // ADHARADDRESS RADIO CHANGE
  radioAdharAddress(status) {
    this.registrationInfo.isPassportAddressAsAdhar = status;
  }
  // RADIO FUNCTION FOR CURRENT ADDRESS SELECTION
  radioCurrentAddress(statusName) {
    this.registrationInfo.currentAddressAs = statusName;
  }


  setDateConfig(startDate, endDate){
    let maxDate = '', 
        minDate = '';
    this.todaysDate = this.masterService.getTodaysDate();
    if(startDate !== '') {
      minDate = startDate;
    }
    if(endDate !== '') {
      maxDate = endDate;
    }
    this.configsMin = {
      format: 'DD-MM-YYYY',
      min : minDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    }
    this.configsMax = {
      format: 'DD-MM-YYYY',
      max : maxDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    }
  }

  termsConditions(){
    $.magnificPopup.close();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#terms-conditions'
        },
        type: 'inline'
      });
    }, 100);    
  }

  privacyPolicy(){
    $.magnificPopup.close();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#privacy-policy'
        },
        type: 'inline'
      });
    }, 100);
  }
}
