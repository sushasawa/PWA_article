import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms';
import * as sha from 'sha.js';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { SessionValueResetService } from '../../services/session-value-reset.service';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-register-login',
  templateUrl: './register-login.component.html',
  styleUrls: ['./register-login.component.css']
})
export class RegisterLoginComponent implements OnInit {

  public invalidsubmitted: any;
  public authorized: Boolean;
  public signinmsg: String;
  public newLeadLoginJSON: any = {
    'uname': '',
    'confirmPassword': '',
    'newPassword': '',
    'oldPassword': '',
    'LeadId': ''
  };
  public tempNo: any;
  public LeadId: any;
  public lead: any;
  public _primaryComp: any;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private location: Location, private route: ActivatedRoute, private _SessionValueResetService: SessionValueResetService, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this.authorized = true;

    this.signinmsg = 'Sign In';
    this.lead = this.route.snapshot.queryParams.lead;
    this._primaryComp = '/' + navUrl.navUrl();
    this.checkActiveUrl();
    this._document.title = 'Sign in via registered Email ID';
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Sign in via registered Email ID' });
  }

  ngOnInit() {
    initDocument();
  }

  loginSubmit(UserInfo: NgForm, e: Event) {
    e.preventDefault();
    this.invalidsubmitted = UserInfo.invalid;
    const payload: any = {};
    let password = UserInfo.value.upassword;
    const username = UserInfo.value.uname;
    password = sha('sha256').update(password, 'utf8').digest('hex');
    payload.upassword = password;
    payload.uname = username;
    console.log(payload);
    if (!this.invalidsubmitted) {
      this.signinmsg = 'Checking ...';
      this.masterService.loginUser(payload).subscribe(data => {
        const result: any = data;
        this.authorized = true;
        this.signinmsg = 'Success...';
        const userinfo = {
          'loggedin': result.success,
          'uname': result.response[0][0].EmailId,
          'uid': result.response[0][0].Id,
          'userName': result.response[1][0].firstName + ' ' + result.response[1][0].lastName
        };
        SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
        if (this.navUrl.navUrl() !== 'CNK') {
          this.masterService.getIExchangeAgentId(SessionHelper.getSession('AgentWebsiteID')).
          subscribe(data => {
            const responseData: any = { Agent: data[0].AgentId, AgentId: data[0].IExhchangeAgentID };
            this.setAgentId(responseData, result, userinfo);
          });
        } else {
          this.masterService.getAgentIdData({ "userId": userinfo.uid }).subscribe(data => {
            const responseData: any = data;
            if (JSON.parse(responseData.status)) {
              this.setAgentId(responseData, result, userinfo);
              
            } else {
              this.afterLogin(result, userinfo);
            }
          }, err => {
            console.log(err);
          });
        }
      }, err => {
        this.signinmsg = 'Sign in';
        this.authorized = false;
        const userinfo = { 'loggedin': false };
        // this.router.navigateByUrl(this._primaryComp + '/' + this.currentlocation[1] + '/register-login');
        SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
      });
    }
  }

  setAgentId(responseData, result, userinfo) {
    SessionHelper.setSession('AgentID', responseData.Agent);
    SessionHelper.setSession('IExhangeAgentId', responseData.AgentId.trim());
    if (SessionHelper.getSession('userSessionInfoSale')) {
      let userSessionInfoSale = JSON.parse(SessionHelper.getSession('userSessionInfoSale'));
      userSessionInfoSale.AgentID = responseData.Agent;
      userSessionInfoSale.IExhangeAgentId = responseData.AgentId.trim();
      SessionHelper.setSession('userSessionInfoSale', userSessionInfoSale);
      this._SessionValueResetService.getUserSessionInfo('userSessionInfoSale', userSessionInfoSale);
    }
    if (SessionHelper.getSession('userSessionInfoRealoadCard')) {
      let userSessionInfoRealoadCard = JSON.parse(SessionHelper.getSession('userSessionInfoRealoadCard'));
      userSessionInfoRealoadCard.AgentID = responseData.Agent;
      userSessionInfoRealoadCard.IExhangeAgentId = responseData.AgentId.trim();
      SessionHelper.setSession('userSessionInfoRealoadCard', userSessionInfoRealoadCard);
      this._SessionValueResetService.getUserSessionInfo('userSessionInfoRealoadCard', userSessionInfoRealoadCard);
    }
    if (SessionHelper.getSession('userSessionInfoSend')) {
      let userSessionInfoSend = JSON.parse(SessionHelper.getSession('userSessionInfoSend'));
      userSessionInfoSend.AgentID = responseData.Agent;
      userSessionInfoSend.IExhangeAgentId = responseData.AgentId.trim();
      SessionHelper.setSession('userSessionInfoSend', userSessionInfoSend);
      this._SessionValueResetService.getUserSessionInfo('userSessionInfoSend', userSessionInfoSend);
    }
    if (SessionHelper.getSession('userSessionInfo')) {
      let userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfo'));
      userSessionInfo.AgentID = responseData.Agent;
      userSessionInfo.IExhangeAgentId = responseData.AgentId.trim();
      SessionHelper.setSession('userSessionInfo', userSessionInfo);
      this._SessionValueResetService.getUserSessionInfo('userSessionInfo', userSessionInfo, () => {
        this.afterLogin(result, userinfo);
      });
    } else {
      this.afterLogin(result, userinfo);
    }
  }

  afterLogin(result, userinfo) {
    this.signinmsg = 'Redirecting...';
    this.navUrl.setNavUrl();
    if (!SessionHelper.getSession('tempNo')) {
      if (!SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentID') === SessionHelper.getSession('AgentWebsiteID')) {
        this.router.navigateByUrl(this._primaryComp + '/buy');
      } else {
        this.redirectPage('/buy');
      }
    } else {
      const tempNo = SessionHelper.removeSession('tempNo');
      this.masterService.getOrderData(tempNo, userinfo.uid)
        // tslint:disable-next-line:no-shadowed-variable
        .subscribe(data => {
          const sessionData: any = data;
          sessionData.userId = result.response[0][0].Id;
          console.log(sessionData.buyScreen);
          console.log(sessionData.sellScreen);
          console.log(sessionData.reloadCardScreen);
          console.log(sessionData.sendMoneyScreen);
          if (sessionData.buyScreen) {
            this._SessionValueResetService.getUserSessionInfo('userSessionInfo', sessionData);
            if (!SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentID') === SessionHelper.getSession('AgentWebsiteID')) {
              this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
            }
          } else if (sessionData.sellScreen) {
            this._SessionValueResetService.getUserSessionInfo('userSessionInfoSale', sessionData);
            if (!SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentID') === SessionHelper.getSession('AgentWebsiteID')) {
              this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
            }
          } else if (sessionData.reloadCardScreen) {
            this._SessionValueResetService.getUserSessionInfo('userSessionInfoRealoadCard', sessionData);
            if (!SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentID') === SessionHelper.getSession('AgentWebsiteID')) {
              this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
            }
          } else if (sessionData.sendMoneyScreen) {
            this._SessionValueResetService.getUserSessionInfo('userSessionInfoSend', sessionData);
            if (!SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentID') === SessionHelper.getSession('AgentWebsiteID')) {
              this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
            }
          }
          if (SessionHelper.getSession('AgentID') !== SessionHelper.getSession('AgentWebsiteID')) {
            this.redirectPage(sessionData.nextLink);
          }
        }, err => {
          // swal('Oops', 'Invalid order number !!!', 'error');
          Snackbar.show({
            text: 'Oops ! Invalid order number',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
          if (!SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentID') === SessionHelper.getSession('AgentWebsiteID')) {
            this.router.navigateByUrl(this._primaryComp + '/buy');
          } else {
            this.redirectPage('/buy');
          }
        });
    }
  }

  checkActiveUrl() {
    console.log(this.lead);
    this.masterService.checkActiveUrl(this.lead)
      .subscribe((UrlStatus) => {
        console.log(UrlStatus);
        const status: any = UrlStatus;
        if (status.IsUrlActive) {
          this.newLeadLoginJSON.uname = status.EmailId;
          this.tempNo = JSON.parse(status.TempNo);
          this.LeadId = status.LeadId;
          this.newLeadLoginJSON.LeadId = this.LeadId;
        } else {
          Snackbar.show({
            text: 'Link has been Expired and This User Exists please Login...',
            pos: 'bottom-left',
            actionTextColor: '#ff4444',
          });
          this.router.navigateByUrl(this._primaryComp + '/login');
        }
        console.log();
        if (this.tempNo) {
          console.log('TEMP FOUND');
          SessionHelper.setSession('tempNo', this.tempNo);
        } else {
          SessionHelper.removeSession('tempNo');
          console.log('NO TEMP');
        }
      });
  }

  redirectPage(urlPart) {
    if (SessionHelper.getSession('AgentID')) {
      this.masterService.getIExchangeAgentId(SessionHelper.getSession('AgentID')).
        subscribe(data => {
          const agentData: any = data;
          this.navUrl.setNavUrlParam(agentData[0].AliasName);
          this.router.navigateByUrl('/' + agentData[0].AliasName + urlPart);
        });
    }
  }

}
