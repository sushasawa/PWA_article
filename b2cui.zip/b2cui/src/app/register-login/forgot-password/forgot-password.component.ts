import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import {DpDatePickerModule} from 'ng2-date-picker';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  
  public invalidsubmitted: any;
  public authorized: Boolean;
  public successMsg: Boolean;
  public Email: String;
  public todaysDate: any;
  public configDob: any;
  public dateOfBirth: any = '' ;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private route: ActivatedRoute, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this.authorized = true;
    this.successMsg = true;
    this._document.title = 'Forgot password page';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Forgot password page' });
  }

  ngOnInit() {
    this.todaysDate = this.masterService.getTodaysDate();
    this.configDob = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }
  
  forgotPasswordSubmit(UserInfo: NgForm, e: Event) {
    e.preventDefault();    
    this.invalidsubmitted = UserInfo.invalid;
    const forgotInfo: any = {};
    const username = UserInfo.value.uname;
    forgotInfo.uname = username;
    forgotInfo.dob = this.dateOfBirth;
    console.log(forgotInfo);
    if (!this.invalidsubmitted) {
      this.masterService.forgotPassword(forgotInfo).subscribe(data => {
        const result: any = data;
        this.authorized = true;
        this.successMsg = false;
        this.Email = username;
      }, err => {
        this.authorized = false;
        this.successMsg = true;
      });
    }else{
      this.authorized = false;
    }
  }

  dataChangeBirth(event): void {
    if (event !== undefined && typeof event !== 'object') {      
      this.dateOfBirth = event;
    }
  }

}
