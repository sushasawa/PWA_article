import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewLeadLoginComponent } from './new-lead-login.component';

describe('NewLeadLoginComponent', () => {
  let component: NewLeadLoginComponent;
  let fixture: ComponentFixture<NewLeadLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewLeadLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewLeadLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
