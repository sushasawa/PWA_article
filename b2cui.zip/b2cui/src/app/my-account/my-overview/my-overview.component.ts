import { Component, OnInit, ViewChild, AfterViewInit, transition, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { SessionTemplate } from '../../../app/helpers/session-template';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';
import { MyAccountBannerComponent } from '../my-account-banner/my-account-banner.component';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-my-overview',
  templateUrl: './my-overview.component.html',
  styleUrls: ['./my-overview.component.css']
})
export class MyOverviewComponent implements OnInit, AfterViewInit {
  @ViewChild(UserBannerInfoComponent) UserBannerInfoComponent;
  @ViewChild(MyAccountBannerComponent) MyAccountBannerComponent;
  public travellersRegistrationInfo: any;
  public loggedInTraveller: any; // session template
  public registrationTemplate: any;
  public checkCurrentUserSession: any;
  public currentUserInfo: any;
  public Enquiries: Array<any>;
  public EnquiriesAvailable: Boolean;
  public currentUserEmail: any;
  public currentUserId: any;
  public orders: Array<any>;
  public NoOrder: any;
  public concertinaStatus: any = '';
  public _primaryComp: any;
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this._primaryComp = '/' + navUrl.navUrl();
    const UserInfo: any = SessionHelper.getSession('userInfo');
    console.log(UserInfo);
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserEmail = JSON.parse(UserInfo).uname;
      this.currentUserId = JSON.parse(UserInfo).uid;
      this.getAlerts();
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }

    this.checkCurrentUserSession = SessionHelper.getSession('currentUser');
    this.travellersRegistrationInfo = [];
    this.loggedInTraveller = {
      'traveller': [],
      'recentOrders': ''
    };
    // check if logged in user session exists or not
    if (this.checkCurrentUserSession === undefined || this.checkCurrentUserSession == null) {
      // call user service by logged in user id
      this._MasterService.getLoggedInUserInfo(this.currentUserId)
        .subscribe(result => {
          console.log(result);
          this.populateTravellersInfo(result);
        }, error => {
          console.log(error);
        });
    } else {
      this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    }
    this._MasterService.getOrdersList(this.currentUserId).subscribe((orders) => {
      console.log(orders);
      const Orders: any = orders;
      this.orders = Orders.data;
      this.NoOrder = !Orders.status ? true : false;
      this.loggedInTraveller.recentOrders = this.orders.length;
       this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
    });
    this._document.title = 'My profile overview';
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'My profile overview'});
  }


  ngAfterViewInit() {

  }

  ngOnInit() {
    initDocument();
  }

  populateTravellersInfo(result: any) {

    // pushing parent traveller first
    if (result.response[0].length > 0) {
      result.response[0][0].parent = true;
      result.response[0][0].selected = true;
      this.travellersRegistrationInfo.push(result.response[0][0]);
    }

    // pushing child travellers
    if (result.response[1].length > 0) {
      result.response[1].map(traveller => {
        traveller.parent = false;
        traveller.selected = false;
        this.travellersRegistrationInfo.push(traveller);
      });
    }

    this.updateLoggedinTravellerInfo();
  }

  updateLoggedinTravellerInfo() {
    console.log('updateLoggedinTravellerInfo called');
    this.travellersRegistrationInfo.map((info, index) => {
      // creating template session conso
      this.loggedInTraveller.traveller.push(SessionTemplate.getSessionTemplate(info));
      console.log(SessionTemplate.getSessionTemplate(info));
    });
    // code to update cover and profile picture of parent and child traveller
    this.loggedInTraveller.traveller.map((traveller) => {
      let travellerId: any;
      if (traveller.parent) {
        travellerId = traveller.parentId;
      } else {
        travellerId = traveller.rowId;
      }
      this._MasterService.getUserDocuments(travellerId)
        .subscribe((data) => {
          const documents: any = data;
          // in case of success setting the response profile and cover photo
          documents.response.map((doc) => {
            if (doc.type === 'profile') {
              traveller.profileInfo.picture = doc.imageUrl;
            } else if (doc.type === 'cover') {
              traveller.profileInfo.cover = doc.imageUrl;
            }
          });
          traveller['documents'] = documents.response;
          SessionHelper.setSession('currentUser', JSON.stringify(this.loggedInTraveller));
          this.currentUserInfo = this.loggedInTraveller;
          // calling child components passsing current user  session
          this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
          this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
        }, (err) => {
          // in case of error set the profile and cover photo to default
          SessionHelper.setSession('currentUser', JSON.stringify(this.loggedInTraveller));
          this.currentUserInfo = this.loggedInTraveller;
          this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
          this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
        });
    });
  }

  // ENQUIREIS CODE STARTS
  getAlerts() {
    const payload = { email: this.currentUserEmail };
    this._MasterService.getAlert(payload).subscribe((enquiries) => {
      const result: any = enquiries; console.log(result);
      if (result.response.length > 0) {
        console.log('MAIN IN');
        this.EnquiriesAvailable = true;
        this.Enquiries = result.response;
        console.log(this.Enquiries);
      } else {
        this.Enquiries = result.response;
        this.EnquiriesAvailable = false;
      }
    });
  }
  // delete alerts code
  deleteAlert(EnquiryNum: any) {
    console.log(EnquiryNum);
    const payload = { 'EnquiryNum': EnquiryNum };
    this._MasterService.deleteAlert(payload).subscribe((data) => {
      // swal('Success', 'Alert Deleted', 'success');
      Snackbar.show({
        text: 'Alert Deleted',
        pos: 'bottom-right',
        actionTextColor: '#05ff01',
      });
      this.getAlerts();
      console.log(data);
    });
  }

  // ENQUIREIS CODE ENDS

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
