


import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SelectModule } from 'ng-select';
import { NumberLocalePipe } from '../pipes/number-locale.pipe';
import { OrderFilterPipe } from '../pipes/order-filter.pipe';
import { OrderDateFilterPipe } from '../pipes/order-date-filter.pipe';
import { StatusFilterPipe } from '../pipes/status-filter.pipe';
import { AllOrderFilterPipe } from './../pipes/all-order-filter.pipe';
import { LimitToPipe } from './../pipes/limit-to.pipe';
import { PipesModule } from '../pipes/pipes.module';
import {DpDatePickerModule} from 'ng2-date-picker';
import { MasterService } from '../services/master.services';
import { CanDeactivateGuard } from '../services/can-deactivate-guard.service';
import { SessionValueResetService } from '../services/session-value-reset.service';
import { MyAccountBannerComponent } from './my-account-banner/my-account-banner.component';
import { MyOverviewComponent } from './my-overview/my-overview.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { MyOffersComponent } from './my-offers/my-offers.component';
import { MyOrdersComponent } from './my-orders/my-orders.component';
import { MyEnquiriesComponent } from './my-enquiries/my-enquiries.component';
import { MyWishlistComponent } from './my-wishlist/my-wishlist.component';
import { MyDocumentsComponent } from './my-documents/my-documents.component';
import { MyGrievancesComponent } from './my-grievances/my-grievances.component';
import { SupportComponent } from './support/support.component';
import { MySettingsComponent } from './my-settings/my-settings.component';
import { UserBannerInfoComponent } from './user-banner-info/user-banner-info.component';
import { MyProfileEditComponent } from './my-profile-edit/my-profile-edit.component';
import { MyEnquiriesEditComponent } from './my-enquiries-edit/my-enquiries-edit.component';
import { MyOrderConfirmationComponent } from './my-order-confirmation/my-order-confirmation.component';
import { AgmCoreModule } from '@agm/core';
import { CommonKycComponent } from '../forex-common/common-kyc/common-kyc.component';
import { ForexCommonModule } from '../forex-common/forex-common.module';
const routes: Routes = [{
  path: '',
  children: [
    { path: '', component: MyOverviewComponent },
    { path: 'my-profile', component: MyProfileComponent },
    { path: 'my-offers', component: MyOffersComponent },
    { path: 'my-orders', component: MyOrdersComponent },
    { path: 'my-enquiries', component: MyEnquiriesComponent },
    { path: 'my-wishlist', component: MyWishlistComponent },
    { path: 'my-documents', component: MyDocumentsComponent },
    { path: 'my-grievances', component: MyGrievancesComponent },
    { path: 'support', component: SupportComponent },
    { path: 'my-settings', component: MySettingsComponent },
    { path: 'my-profile-edit', component: MyProfileEditComponent, canDeactivate: [CanDeactivateGuard] },
    { path: 'my-enquiries-edit', component: MyEnquiriesEditComponent }
  ]
}];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    FormsModule,
    SelectModule,
    PipesModule,
    DpDatePickerModule,
    ForexCommonModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAQaeIKoWfFMxZJxN3m4Bs1SJe4w-FX4Mk'
    })
  ],
  // tslint:disable-next-line:max-line-length
  declarations: [MyAccountBannerComponent, MyOverviewComponent, MyProfileComponent, MyOffersComponent, MyOrdersComponent, MyEnquiriesComponent, MyWishlistComponent, MyDocumentsComponent, MyGrievancesComponent, SupportComponent, MySettingsComponent, UserBannerInfoComponent, MyProfileEditComponent, MyEnquiriesEditComponent, MyOrderConfirmationComponent],
  providers: [MasterService, SessionValueResetService, CanDeactivateGuard]
})
export class MyAccountModule { }
