import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-my-enquiries',
  templateUrl: './my-enquiries.component.html',
  styleUrls: ['./my-enquiries.component.css']
})
export class MyEnquiriesComponent implements OnInit {
  public Enquiries: Array<any>;
  public EnquiriesAvailable: Boolean;
  public currentUserEmail: any;
  public concertinaStatus: any = '';
  public _primaryComp: any;
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserEmail = JSON.parse(UserInfo).uname;
      this.getAlerts();
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    this._document.title = 'My enquiries';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'My enquiries'});
  }

  getAlerts() {
    const payload = { email: this.currentUserEmail };
    this._MasterService.getAlert(payload).subscribe((enquiries) => {
      const result: any = enquiries;
      if (result.response.length > 0) {
        this.EnquiriesAvailable = true;
        this.Enquiries = result.response;
      } else {
        this.Enquiries = result.response;
        this.EnquiriesAvailable = false;
      }
    });
  }

  deleteAlert(EnquiryNum: any) {
    console.log(EnquiryNum);
    const payload = { 'EnquiryNum': EnquiryNum };
    this._MasterService.deleteAlert(payload).subscribe((data) => {
      //swal('Success', 'Alert Deleted', 'success');
      Snackbar.show({
        text: 'Alert Deleted',
        pos: 'bottom-right',
        actionTextColor: '#05ff01',
      });
      this.getAlerts();
      console.log(data);
    });
  }
  ngOnInit() {
    initDocument();
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
