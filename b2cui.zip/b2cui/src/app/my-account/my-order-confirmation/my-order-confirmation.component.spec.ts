import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonConfirmationComponent } from '../../forex-common/common-confirmation/common-confirmation.component';



describe('CommonConfirmationComponent', () => {
  let component: CommonConfirmationComponent;
  let fixture: ComponentFixture<CommonConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
