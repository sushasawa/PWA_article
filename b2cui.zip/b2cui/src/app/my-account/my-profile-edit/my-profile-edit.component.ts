import { Component, OnInit, ViewChild, AfterViewInit, EventEmitter, HostListener, Inject } from '@angular/core';
import { MasterService } from '../../../app/services/master.services';
import { CanComponentDeactivate } from '../../../app/services/can-deactivate-guard.service';
import { SessionHelper } from '../../../app/helpers/session-helper';
import {DpDatePickerModule} from 'ng2-date-picker';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';
import { MyAccountBannerComponent } from '../my-account-banner/my-account-banner.component';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function swal(headerMessage, message, type): any;
declare function initDocument(): any;
declare var Snackbar: any;
declare var $: any;
@Component({
  selector: 'app-my-profile-edit',
  templateUrl: './my-profile-edit.component.html',
  styleUrls: ['./my-profile-edit.component.css'],

})


export class MyProfileEditComponent implements OnInit, AfterViewInit, CanComponentDeactivate {
  @ViewChild(UserBannerInfoComponent) UserBannerInfoComponent;
  @ViewChild(MyAccountBannerComponent) MyAccountBannerComponent;
  public checkCurrentUserSession: any;
  public currentUserInfo: any;
  public currentTraveller: any;
  public formdata: any;
  public userInfo: any;
  public nationalityOptions: any;
  public cityOptions: any;
  public sessionUpdater: EventEmitter<any> = new EventEmitter<any>();
  public config: any;
  public todaysDate: any;
  public configDob: any;
  public configsMin: any = [];
  public configsMax: any = [];
  public userSessionInfoTravellers: any;
  public termsAcceptance: any = false;
  public leadTraveller: any;
  public coTraveller: any;
  public travellerSelected: any = 'main';
  public hasCoTraveller: any = true;
  public leadIndex: any;
  public coTravellerIndex: any;
  public travellerInfo: any;
  public navigate: any = false;
  public invalidsubmitted: any;
  public termsAcceptanceAdhar: any;
  public concertinaStatus: any = '';
  public skipAdhaarValidationFlag: any = false;
  public _primaryComp: any;
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private routerA: ActivatedRoute, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    console.log(UserInfo);
    if (UserInfo == null || UserInfo === undefined) {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    this.skipAdhaarValidationFlag = this._MasterService.getSkipAdhaarValidationFlag();
    this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    this.currentUserInfo.traveller[0].selected = true;
    this.userInfo = {};
    this.currentTraveller = this.currentUserInfo.traveller[0];
    this.leadTraveller = this.currentUserInfo.traveller[0];
    this.leadIndex = 0;
    if (this.routerA.snapshot.queryParams && this.routerA.snapshot.queryParams.traveller === 'add traveller') {
      this.coTraveller = this.getTravellerInfo();
      this.coTravellerIndex = this.currentUserInfo.traveller.length;
      this.currentUserInfo.traveller.push(this.coTraveller);
      this.travellerSelected = 'co';
      this.travellerInfo = 'new';
    } else if (this.routerA.snapshot.queryParams && this.routerA.snapshot.queryParams.traveller) {
      this.coTraveller = this.currentUserInfo.traveller[+this.routerA.snapshot.queryParams.traveller];
      this.coTravellerIndex = +this.routerA.snapshot.queryParams.traveller;
      this.travellerSelected = 'co';
      this.travellerInfo = 'existing';
    }
    // else if (this.currentUserInfo.traveller[1]) {
    //   this.coTraveller = this.currentUserInfo.traveller[1];
    //   this.coTravellerIndex = 1;
    //   this.travellerInfo = 'existing';
    // }
    // tslint:disable-next-line:one-line
    else if (this.currentUserInfo.traveller.length === 1) {
      this.hasCoTraveller = true;
    }
    // this.selectedTraveller(0);
    console.log(JSON.stringify(this.coTraveller));

    this._MasterService.getNationalityList()
      .subscribe(data => {
        this.nationalityOptions = data;
      });

    this._MasterService.getCityList()
      .subscribe(data => {
        // console.log(data)
        this.cityOptions = data;

      });

    this.config = {
      format: 'DD-MM-YYYY'
    };

    this._document.title = 'View and update your profile details';
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'View and update your profile details' });
  }

  ngOnInit() {
    this.todaysDate = this._MasterService.getTodaysDate();
    this.configDob = {
      format: 'DD-MM-YYYY',
      max : this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.userSessionInfoTravellers = this.currentUserInfo.traveller;
    this.currentUserInfo.traveller.forEach((traveller, index) => {
      this.setDateConfig(traveller.registrationInfo.dateOfIssue, traveller.registrationInfo.expiryDate, index);
    });
    initDocument();
  }

  selectedTab(index: any) {
    // this.travellerSelected = index;
    console.log(index);
    // tslint:disable-next-line:one-line
    if (this.travellerSelected !== index){
      this.canDeactivate();
    }
  }

  ngAfterViewInit() {
    // console.log(this.UserBannerInfoComponent);
  }

  selectedTraveller(index: any) {
    this.currentUserInfo.traveller.map((traveller) => {
      traveller.selected = false;
    });
    this.currentUserInfo.traveller[index].selected = true;
  }
  callPinCodeService(event, type, index) {
    const pinCode = event.target.value;

    // this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['city'] = '##Service offline##';
    // this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['state'] = '##Service offline##';
    // this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['area'] = '##Service offline##';

    this._MasterService.getPinCodeDetails(pinCode)
      .subscribe(data => {
        const Retdata: any = data;
        if (Retdata.Status === 'Success') {
          this.currentUserInfo.traveller[index].registrationInfo[type]['city'] = Retdata.PostOffice[0].District;
          this.currentUserInfo.traveller[index].registrationInfo[type]['state'] = Retdata.PostOffice[0].State;
          this.currentUserInfo.traveller[index].registrationInfo[type]['area'] = Retdata.PostOffice[0].Name;
        } else {
          this.currentUserInfo.traveller[index].registrationInfo[type]['city'] = '';
          this.currentUserInfo.traveller[index].registrationInfo[type]['state'] = '';
          this.currentUserInfo.traveller[index].registrationInfo[type]['area'] = '';
        }
      });
  }
  uploadPic(type: any, traveller: any, travellerIndex: any, photo: any) {
    const photos = photo.target.files;
    this.userInfo.parent = traveller.parent;
    this.userInfo.type = type;
    this.userInfo.index = travellerIndex;
    // console.log(traveller);
    if (traveller.parent) {
      this.userInfo.parent_id = traveller.parentId;
      // console.log("parent");
    } else {
      // console.log("child");
      this.userInfo.parent_id = traveller.registrationInfo.ParentId;
      this.userInfo.child_id = traveller.rowId;
    }

    this.formdata = new FormData();
    this.formdata.append('userInfo', JSON.stringify(this.userInfo));

    for (let i = 0; i < photos.length; i++) {
      const fileValidation = (photos[i].type.indexOf('jpeg') !== -1
        || photos[i].type.indexOf('png') !== -1
        || photos[i].type.indexOf('gif') !== -1) && photos[i].size <= 500000;

      if (fileValidation) {
        this.formdata.append('profile', photos[i], photos[i].name);

        this._MasterService.getUserProfilePic(this.formdata)
          .subscribe((data) => {

            const result: any = data;
            if (result.response.userinfo.type === 'profile') {
              this.currentUserInfo.traveller[result.response.userinfo.index].profileInfo.picture = result.response.imgUrl;
            } else {
              this.currentUserInfo.traveller[result.response.userinfo.index].profileInfo.cover = result.response.imgUrl;
            }
            this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
            this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
            SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
            // this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
            this.formdata = {};

          });
      } else {
        // swal('Invalid File ', 'Supports JPEG, PNG and GIF. The file size should not exceed 500 KB.', 'error');
        Snackbar.show({
          text: 'Invalid File, Supports JPEG, PNG and GIF. The file size should not exceed 500 KB.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        console.log('Invalid file');
      }

    }
  }

  // tslint:disable-next-line:one-line
  updateSession1(registrationInfo, value, index){
    setTimeout(() => {
      registrationInfo[index] = value.split(/\b/g).map(word => this.titleCaseWord(word)).join('');
    }, 10);
  }

  titleCaseWord(word: string) {
    // tslint:disable-next-line:curly
    if (!word) return word;
    return word[0].toUpperCase() + word.substr(1).toLowerCase();
  }

  Gender(index, newValue: any) {
    this.currentUserInfo.traveller[index].registrationInfo.gender.value = newValue;
    console.log(this.currentUserInfo.traveller[index].registrationInfo.gender.value);
  }

  // tslint:disable-next-line:one-line
  skipAdhaarValidation(){

    const travellerRegistrationInfo = [];
    let indexOfArray = 0;
    travellerRegistrationInfo.push(this.leadTraveller.registrationInfo);
    if (this.coTraveller) {
      indexOfArray = 1;
      travellerRegistrationInfo.push(this.coTraveller.registrationInfo);
    }
    if (this.travellerInfo === 'new') {
      this._MasterService.updateUserRegistration(travellerRegistrationInfo)
        .subscribe((response) => {
          const result: any = response;
          if (JSON.parse(result.newUserRecords.status)) {
            // swal('Success', 'Profile Updated...', 'success');
            Snackbar.show({
              text: 'Success, New traveller added...',
              pos: 'bottom-right',
              actionTextColor: '#05ff01',
            });
          }
          this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
          this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
          SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
          this.navigate = true;
          // this.router.navigateByUrl(this._primaryComp + `/account/my-profile`);
          $.magnificPopup.close();
          this.router.navigate([this._primaryComp + '/account/my-profile'], { queryParams: { traveller: this.coTravellerIndex } });
        });
    } else {
      this._MasterService.updateUserRegistration(travellerRegistrationInfo)
        .subscribe((response) => {
          const result: any = response;
          if (JSON.parse(result.response[0].success)) {
            // swal('Success', 'Profile Updated...', 'success');
            Snackbar.show({
              text: 'Success, Profile Updated...',
              pos: 'bottom-right',
              actionTextColor: '#05ff01',
            });
          }
          this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
          this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
          SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
          this.navigate = true;
          $.magnificPopup.close();
          if (this.travellerSelected === 'co') {
            this.router.navigate([this._primaryComp + '/account/my-profile'], { queryParams: { traveller: this.coTravellerIndex } });
          } else {
            this.router.navigate([this._primaryComp + '/account/my-profile'], { queryParams: { traveller: this.leadIndex } });
          }
        });
    }
  }

  ValidateAdhar() {
    if (!this.termsAcceptanceAdhar) {
      // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
      Snackbar.show({text: 'Cannot proceed!, Please accept Adhaar terms and conditions to proceed',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
      });
      return;
    }
    const travellerRegistrationInfo = [];
    let indexOfArray = 0;
    travellerRegistrationInfo.push(this.leadTraveller.registrationInfo);
    if (this.coTraveller) {
      indexOfArray = 1;
      travellerRegistrationInfo.push(this.coTraveller.registrationInfo);
    }

    // tslint:disable-next-line:max-line-length
    this._MasterService.validateAdhaar({ 'adharNo': travellerRegistrationInfo[indexOfArray].adharCardNo.value, 'name': travellerRegistrationInfo[indexOfArray].firstName.value })
      .subscribe(data => {
        const returnDate: any = data;
        console.log(returnDate);
        // tslint:disable-next-line:one-line
        if (returnDate.ReturnType !== 'Error') {
          if (this.travellerInfo === 'new') {
            this._MasterService.updateUserRegistration(travellerRegistrationInfo)
              .subscribe((response) => {
                const result: any = response;
                if (JSON.parse(result.newUserRecords.status)) {
                  // swal('Success', 'Profile Updated...', 'success');
                  Snackbar.show({
                    text: 'Success, New traveller added...',
                    pos: 'bottom-right',
                    actionTextColor: '#05ff01',
                  });
                }
                this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
                this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
                SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
                this.navigate = true;
                // this.router.navigateByUrl(this._primaryComp + `/account/my-profile`);
                $.magnificPopup.close();
                this.router.navigate([this._primaryComp + '/account/my-profile'], { queryParams: { traveller: this.coTravellerIndex } });
              });
          } else {
            this._MasterService.updateUserRegistration(travellerRegistrationInfo)
              .subscribe((response) => {
                const result: any = response;
                if (JSON.parse(result.response[0].success)) {
                  // swal('Success', 'Profile Updated...', 'success');
                  Snackbar.show({
                    text: 'Success, Profile Updated...',
                    pos: 'bottom-right',
                    actionTextColor: '#05ff01',
                  });
                }
                this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
                this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
                SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
                this.navigate = true;
                $.magnificPopup.close();
                if (this.travellerSelected === 'co') {
                  this.router.navigate([this._primaryComp + '/account/my-profile'], { queryParams: { traveller: this.coTravellerIndex } });
                } else {
                  this.router.navigate([this._primaryComp + '/account/my-profile'], { queryParams: { traveller: this.leadIndex } });
                }
              });
          }
        } else {
          // swal('Cannot proceed', 'Adhar validation failed. Please enter correct adhar details.', 'error');
          Snackbar.show({text: 'Cannot proceed , Adhar validation failed. Please enter correct adhar details.',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
        }
      });
  }

  updateRegister(userForm: NgForm, currentUserInfo) {
    console.log(userForm);
    console.log(currentUserInfo);
    const travellerRegistrationInfo = [];
    this.invalidsubmitted = userForm.invalid;
    if (userForm.valid) {
      if (!this.termsAcceptance) {
        // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
        Snackbar.show({
          text: 'Cannot proceed!, Please accept terms and conditions to proceed',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      } else {
        if(this.skipAdhaarValidationFlag){
          this.skipAdhaarValidation();
        } else {
          setTimeout(() => {
            $.magnificPopup.open({
              items: {
                src: '#consent-popup'
              },
              type: 'inline'
            });
          }, 100);
        }
      }
    }else {
      // swal('Cannot proceed', 'Please fill required inputs', 'error');
      Snackbar.show({
        text: 'Cannot proceed, Please fill the mandatory fields highlighted.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }
    console.log(travellerRegistrationInfo);
  }

   //  date picker code starts
  dataChangeBirth(travellerIndex: any , event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.currentUserInfo.traveller[travellerIndex].registrationInfo.dateOfBirth.value = event;
      SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
    }
  }

  dataChangeStart(travellerIndex: any, event): void {
   if (event !== undefined && typeof event !== 'object') {
      this.currentUserInfo.traveller[travellerIndex].registrationInfo.dateOfIssue = event;
      SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
      this.configsMin[travellerIndex] = {
        format: 'DD-MM-YYYY',
        min : this._MasterService.addDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    }
  }

  dataChangeEnd(travellerIndex: any, event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.currentUserInfo.traveller[travellerIndex].registrationInfo.expiryDate = event;
      SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
      this.configsMax[travellerIndex] = {
        format: 'DD-MM-YYYY',
        max: this._MasterService.substractDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    }
  }

  cancelEdit() {
    let currentIndex;
    this.navigate = true;
    // tslint:disable-next-line:one-line
    if (this.travellerSelected === 'co'){
      currentIndex = this.coTravellerIndex;
      // tslint:disable-next-line:one-line
      if (this.currentUserInfo.traveller[currentIndex].registrationInfo.userId === ''){
        this.currentUserInfo.traveller.splice(currentIndex, 1);
        SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
        currentIndex = currentIndex - 1;
      }
      this.router.navigate([this._primaryComp + '/account/my-profile'], {queryParams: {traveller: currentIndex}});
    }else {
      currentIndex = this.leadIndex;
      this.router.navigate([this._primaryComp + '/account/my-profile'], {queryParams: {traveller: this.leadIndex}});
    }
  }

  // tslint:disable-next-line:one-line
  setDateConfig(startDate, endDate, index){
    let maxDate = '',
        minDate = '';
    this.todaysDate = this._MasterService.getTodaysDate();
    if (startDate !== '') {
      minDate = startDate;
    }
    if (endDate !== '') {
      maxDate = endDate;
    }
    this.configsMin[index] = {
      format: 'DD-MM-YYYY',
      min : minDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.configsMax[index] = {
      format: 'DD-MM-YYYY',
      max : maxDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }
   //  date picker code ends

   // RADIO FUNCTION FOR CURRENT ADDRESS SELECTION
  radioCurrentAddress(statusName, index) {
    // this.userSessionInfoTravellers[index].registrationInfo.currentAddressAs = statusName;
    this.currentUserInfo.traveller[index].registrationInfo.currentAddressAs = statusName;
    SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
  }

  canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
    // tslint:disable-next-line:one-line
    if (this.navigate === true){
      return true;
    // tslint:disable-next-line:one-line
    } else{
      Snackbar.show({
        text: 'Please save or cancel currently edited form.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return false;
    }
  }

  // tslint:disable-next-line:one-line
  termsConditions(){
    $.magnificPopup.close();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#terms-conditions'
        },
        type: 'inline'
      });
    }, 100);
  }

  checkEmail(event, userForm: NgForm, travellerIndex) {
    // tslint:disable-next-line:one-line
    if (event.target.value){
      this._MasterService.getEmailValidation(event.target.value)
      .subscribe(data => {
        const retData: any = data;
        if (retData.message.status === 'emailNotExists') {
          this.currentUserInfo.traveller[travellerIndex] = this.userSessionInfoTravellers[travellerIndex];
          SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
          $('.confirmEmailId0 > div > ul > li').css('background-color', 'rgb(0, 255, 0)');
        } else if (retData.message.status === 'emailExists') {
          this.currentUserInfo.traveller[travellerIndex].registrationInfo.contactDetails.emailId = '';
          $('.confirmEmailId0 > div > ul > li').css('background-color', 'red');
          Snackbar.show({
            text: 'This email ID already exists, please log-in with your email ID.',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        }
      });
    }
  }

  // tslint:disable-next-line:one-line
  privacyPolicy(){
    $.magnificPopup.close();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#privacy-policy'
        },
        type: 'inline'
      });
    }, 100);
  }

  getTravellerInfo() {
    const travellerInfo = {
      'selected': false,
      'lead': false,
      'prepaidCard': false,
      'purpose': '',
      'prepaidCardDetails': [{
        'currencyCode': '',
        'forexAmount': '',
        'bankname': '',
      }],
      'cash': false,
      'cashDetails': [{
        'currencyCode': '',
        'forexAmount': '',
      }],
      'travellerCheque': false,
      'travellerChequeDetails': [{
        'currencyCode': '',
        'forexAmount': '',
      }],
      'demandDraft': false,
      'demandDraftDetails': [{
        'currencyCode': '',
        'forexAmount': '',
      }],
      'registrationInfo': {
        'userId': '',
        'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
        'middleName': '',
        'lastName': '',
        'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
        'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
        'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
        // "nationality": { "id": "", "name": "" } ,
        'nationality': '',
        'mothersMaidenName': {
          'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
            + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
            + 'event.target.style.background=\'#f8f8f8\'}'
        },
        'PAN': {
          'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
            + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
            + 'event.target.style.background=\'#f8f8f8\'}'
        },
        'passportNumber': '',
        'ParentId': false,
        'dateOfIssue': '',
        'placeOfIssue': '',
        'expiryDate': '',
        'address': '101 5A Galaxy apartment',
        'isPassportAddressAsAdhar': 'yes',
        'adharAddress': {
          'flatNumber': '',
          'buildingName': '',
          'streetName': '',
          'landmark': '',
          'area': '',
          'city': '',
          'state': '',
          'pincode': '',
        },
        'passportAddress': {
          'flatNumber': '',
          'buildingName': '',
          'streetName': '',
          'landmark': '',
          'area': '',
          'city': '',
          'state': '',
          'pincode': '',
        },
        'currentAddressAs': 'asPerAdhar',
        'otherAddress': {
          'flatNumber': '',
          'buildingName': '',
          'streetName': '',
          'landmark': '',
          'area': '',
          'city': '',
          'state': '',
          'pincode': '',
        },
        'contactDetails': {
          'mobileNo': '',
          'emailId': ''
        },
        'alternateContactDetails': {
          'countryCode': '',
          'mobileNo': '',
          'countryCode2': '',
          'cityCode': '',
          'telephoneNo': '',
          'emailId': '',
        },
        'officeAddress': {
          'designation': '',
          'conpanyName': '',
          'companyDivision': '',
          'flatNumber': '',
          'building': '',
          'streetName': '',
          'landmark': '',
          'area': '',
          'city': '',
          'state': '',
          'pincode': ''
        },
        'officeContactDetails': {
          'countryCode': '',
          'telephoneNumber': '',
          'officeExtension': '',
        },
        'password': '',
        'confirmPassword': '',
      },
      'profileInfo': {
        'picture': '',
        'cover': ''
      },
      'travellingDetails': {
        'dateOfTravel': '',
        'dateOfArrival': '',
        'airlineName': '',
        'ticketNumber': ''
      },
    };
    return travellerInfo;
  }

  // ngOnDestroy() {
  //   console.log('this is working');
  // }

  @HostListener('window:beforeunload')
  doSomething() {
    this.cancelEdit();
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
