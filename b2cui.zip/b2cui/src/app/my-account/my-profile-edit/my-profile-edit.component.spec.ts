import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';



describe('UserBannerInfoComponent', () => {
  let component: UserBannerInfoComponent;
  let fixture: ComponentFixture<UserBannerInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserBannerInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserBannerInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
