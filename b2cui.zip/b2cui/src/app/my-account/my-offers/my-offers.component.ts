import { Component, OnInit, Inject } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
@Component({
  selector: 'app-my-offers',
  templateUrl: './my-offers.component.html',
  styleUrls: ['./my-offers.component.css']
})
export class MyOffersComponent implements OnInit {
  public concertinaStatus: any = '';
  public _primaryComp: any;
  constructor(private meta: Meta, @Inject(DOCUMENT) private _document: any, private navUrl: NavigatePathService) { 
    this._primaryComp = '/' + navUrl.navUrl();
    this._document.title = 'My offers';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'My offers'});
  }

  ngOnInit() {
    initDocument();
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
