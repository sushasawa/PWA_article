import { Component, OnInit, ViewChildren, AfterViewInit, QueryList, ViewChild, Inject } from '@angular/core';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';
import { MyAccountBannerComponent } from '../my-account-banner/my-account-banner.component';

import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { CommonKycComponent } from '../../forex-common/common-kyc/common-kyc.component';
declare var $: any;
declare function initDocument(): any;
declare function initMyAccountJS(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})
export class MyOrdersComponent implements OnInit, AfterViewInit, AfterViewInit {
  public uid: any;
  public UserInfo: any;
  public currentUserInfo: any;
  public Transactions: any;
  public IsOrdersNotAvailable: Boolean = false;
  public Orders: Array<any>;
  public OrderFilter: Array<any>;
  public StatusFilter: Array<any>;
  public OrderSelected: any;
  public OrderType = '';
  public taskDetails: any;
  public StatusType = '';
  public loadKyc: Boolean = false;
  public KycSessionName: any;
  public concertinaStatus: any = '';
  public CurrentOrder: any;
  public _primaryComp: any;
  public OrderSort = {
    OrderType: 'buy',
    StatusType: false
  };
  @ViewChildren('OrderLoaded') OrderLoaded: QueryList<any>;
  @ViewChild(UserBannerInfoComponent) UserBannerInfoComponent;
  @ViewChild(CommonKycComponent) CommonKycComponent;
  constructor(private _MasterSevice: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    this._primaryComp = '/' + navUrl.navUrl();
    console.log(this.currentUserInfo);
    this.OrderFilter = [
      { 'label': 'Buy Forex', 'value': 'buy' },
      { 'label': 'Reload Card', 'value': 'reload' },
      { 'label': 'SendMoney Abroad', 'value': 'send' }
    ];
    this.StatusFilter = [
      { 'label': 'OPEN', 'value': false },
      { 'label': 'CLOSED', 'value': true }
    ];
    this.UserInfo = SessionHelper.getSession('userInfo');
    this.Orders = [];
    this.Transactions = [];
    if (this.UserInfo !== undefined || this.UserInfo != null) {
      this.uid = JSON.parse(this.UserInfo).uid;
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    this._MasterSevice.getOrdersList(this.uid).subscribe((data) => {
      const result: any = data;
      // console.log(result);
      if (result.status) {
        this.generateOrders(result.data);
      } else {
        this.IsOrdersNotAvailable = true;
      }
    });
    this._document.title = 'My orders';
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'My orders' });
  }

  ngOnInit() {
    initDocument();
  }
  ngAfterViewInit() {
    this.OrderLoaded.changes.subscribe((OrderL) => {
      this.reInitMyaccountJs();
    });
  }
  generateOrders(Transactions) {
    this.currentUserInfo.recentOrders = Transactions.length;
    this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
    SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
    this.Transactions = Transactions;
    this.Transactions = this.Transactions.map((Transaction) => {
      Transaction.BuySellDetaillistJson = JSON.parse(Transaction.BuySellDetaillistJson);
      Transaction.UserSessionJson = JSON.parse(Transaction.UserSessionJson);
      Transaction.deliveryInfo = Transaction.UserSessionJson[Transaction.UserSessionJson.type].deliveryInfo;
      // tslint:disable-next-line:max-line-length
      Transaction.destination = Transaction.UserSessionJson[Transaction.UserSessionJson.type].destination ? Transaction.UserSessionJson[Transaction.UserSessionJson.type].destination.split('#')[1] : 'N/A';
      Transaction.DeliveryAddrAndContact = Transaction.UserSessionJson[Transaction.UserSessionJson.type].traveller[0].registrationInfo;
      Transaction.UserSessionJson[Transaction.UserSessionJson.type].traveller.map((Traveller, TravellerIndex) => {
        if (Traveller.registrationInfo.parentId === Traveller.registrationInfo.userId) {
          Transaction.purpose = Traveller.purpose;
          Transaction.travellingDetails = Traveller.travellingDetails;
          Transaction.trvallerAllInfo = Traveller;
        } else if (Number.parseInt(Traveller.registrationInfo.ParentId) === this.uid) {
          Transaction.purpose = Traveller.purpose;
          Transaction.travellingDetails = Traveller.travellingDetails;
          Transaction.trvallerAllInfo = Traveller;
        }
      });
      Transaction.OrderStatus = Transaction.OrderStatus === '0' ? false : true;
      this.Orders.push(Transaction);
    });
    // console.log(this.Orders);
  }

  removeFilter() {
    this.OrderType = '';
    this.StatusType = '';
  }

  reInitMyaccountJs() {
    initMyAccountJS();
  }


  printLrs(uid) {
    console.log(uid);
    console.log(this.currentUserInfo);
    let lrsForm = '';
    const result = this.currentUserInfo.traveller.map((Traveller) => {
      if (Traveller.documents) {
        Traveller.documents.map((Docs, DocsIndex) => {
          // tslint:disable-next-line:max-line-length
          if (Docs.userId === Number.parseInt(uid) && (Docs.type === 'LRS form completely filled' || Docs.type.toUpperCase().indexOf('LRS') !== -1)) {
            console.log(Docs);
            console.log('LRS FOUND');
            lrsForm = Docs.imageUrl;
          }
        });
      }
    });

    if (lrsForm !== '') {
      let printContents = '', popupWin;

      // tslint:disable-next-line:max-line-length
      printContents += '<div style="height:100%;width:100%;" id="print-section"><img style="height:inherit;width:inherit;" src="' + lrsForm + '"/></div>';
      popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
      popupWin.document.open();
      popupWin.document.write(`
          <html>
            <head>
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <link href="/assets/css/bootstrap.css" rel="stylesheet">
              <!-- Bootstrap core CSS -->
              <link href="/assets/css/plugin.min.css" rel="stylesheet" type="text/css" media="all">
              <!-- icons -->
              <!-- Custom styles for this template -->
              <link href="/assets/css/style.min.css" rel="stylesheet">
              <link href="/assets/css/media.min.css" rel="stylesheet">
           </head>
            <body onload="window.print();window.close();">${printContents}</body>
          </html>`
      );
      popupWin.document.close();
    } else {
      Snackbar.show({
        text: 'You have not uploaded LRS Form.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }

  }

  generateReportsPrint(order) {
    console.log(order);
    this.taskDetails = 'print';
    this.OrderSelected = order;
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#consent-popup'
        },
        type: 'inline'
      });
    }, 100);
    Snackbar.show({
      text: 'Preparing your page to print.',
      pos: 'bottom-right'
    });
  }

  generateReportsDownload(order) {
    this.taskDetails = 'download';
    this.OrderSelected = order;
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#consent-popup'
        },
        type: 'inline'
      });
    }, 100);
    Snackbar.show({
      text: 'Preparing your page for download.',
      pos: 'bottom-right'
    });
  }

  // tslint:disable-next-line:one-line
  closePupup() {
    $.magnificPopup.close();
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

  uploadKyc(order) {
    this.loadKyc = true;
    //  console.log(order);
    this.CurrentOrder = order;
    this.KycSessionName = order.UserSessionJson;
    this.CommonKycComponent.initKyc(this.KycSessionName);
  }

  shouldCloseOrder(data) {
    console.log('DATA RECIEVED FORM CHILD ' + data);
    const status = data;
    this.CurrentOrder.IsDocumentPending = !status;
    this.updateDocStatus(this.CurrentOrder.TransactionId, !status);
   // console.log(this.CurrentOrder);
   //   console.log(status);
    // when document is pending and user uploads all the documents
   // if (this.CurrentOrder.IsDocumentPending && status) {
    //   this.CurrentOrder.IsDocumentPending = false; console.log('IN FIRST');
    //   this.updateDocStatus(this.CurrentOrder.TransactionId, this.CurrentOrder.IsDocumentPending);
    // }
    // //  when document is not  pending and user updates(adds or removes) documents
    // if (this.CurrentOrder.IsDocumentPending === false && status === false) {
    //   this.CurrentOrder.IsDocumentPending = true;console.log('IN LAST');
    //   this.updateDocStatus(this.CurrentOrder.TransactionId, this.CurrentOrder.IsDocumentPending);
    // }
  }

  updateDocStatus(id, status) {
    console.log('UPDATE STATUS CALL API');
    const payload = {
      'transactionID': id,
      'status': status
    };
      this._MasterSevice.updateDocStatus(payload)
      .subscribe((data) => {
        console.log(data);
      });
  }
}
