import { Component, OnInit, Inject } from '@angular/core';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { SessionHelper } from '../../helpers/session-helper';
import { MasterService } from '../../services/master.services';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import * as sha from 'sha.js';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare function initAccord(): any;

@Component({
  selector: 'app-my-settings',
  templateUrl: './my-settings.component.html',
  styleUrls: ['./my-settings.component.css']
})
export class MySettingsComponent implements OnInit {
  public invalidsubmitted: any;
  public concertinaStatus: any = '';
  public _primaryComp: any;
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this.invalidsubmitted = false;
    this._primaryComp = '/' + navUrl.navUrl();
    this._document.title = 'Change your profile settings';
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Change your profile settings' });
  }

  ngOnInit() {
    // initAccord();
    initDocument();
  }
  changePassword(changePasswordForm: NgForm, e: Event) {
    e.preventDefault();
    const payload: any = {};
    let oldPass: any = changePasswordForm.value.oldPass;
    let newPass: any = changePasswordForm.value.newPass;
    let confirmPass: any = changePasswordForm.value.confirmPass;
    this.invalidsubmitted = changePasswordForm.invalid;
    newPass = sha('sha256').update(newPass, 'utf8').digest('hex');
    oldPass = sha('sha256').update(oldPass, 'utf8').digest('hex');
    confirmPass = sha('sha256').update(confirmPass, 'utf8').digest('hex');
    payload.newPass = newPass;
    payload.oldPass  = oldPass;
    payload.confirmPass = confirmPass;
    const uid = JSON.parse(SessionHelper.getSession('userInfo')).uid;
    if (uid != null || uid !== undefined) {
      payload.uid = uid;
    }else {
      sessionStorage.removeItem('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    if (changePasswordForm.valid) {
      if (newPass === confirmPass) {
        this._MasterService.changePassword(payload)
          .subscribe((data) => {
            console.log(data);
            const result: any = data;
            if (result.code) {
              // swal(result.msg, '', 'success');
              Snackbar.show({
                text: result.msg,
                pos: 'bottom-right',
                actionTextColor: '#05ff01',
              });
            } else {
              // swal(result.msg, '', 'error');
              Snackbar.show({
                text: result.msg,
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });
            }
          }, (error) => {
            console.log(error);
          });
      } else {
        // swal('', 'Password not matched .', 'error');
        Snackbar.show({
          text: 'Password not matched',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }
    }
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
