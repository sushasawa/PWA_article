
import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { DomSanitizer } from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare function initAccord(): any;
@Component({
  selector: 'app-my-documents',
  templateUrl: './my-documents.component.html',
  styleUrls: ['./my-documents.component.css']
})
export class MyDocumentsComponent implements OnInit {
  public currentUserId;
  public Documents: any;
  public currentUserInfoTravellers: any;
  public formdata: any;
  public SelectedTravellerIndex: any;
  public close = document.getElementsByClassName('close')[0];
  public documentScr: any;
  public concertinaStatus: any = '';
  public _primaryComp: any;
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any, public sanitizer: DomSanitizer) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    this.currentUserInfoTravellers = JSON.parse(SessionHelper.getSession('currentUser'));
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserId = JSON.parse(UserInfo).uid;
      this.getDocuments();
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    this._document.title = 'View your documents';
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'View your documents' });
  }

  ngOnInit() {
    setTimeout(function () {
      // initAccord();
      initDocument();
    }, 50);
  }

  getDocuments() {
    this.currentUserInfoTravellers.traveller.map((traveller) => {
      let travellerId: any;
      if (traveller.parent) {
        travellerId = traveller.parentId;
      } else {
        travellerId = traveller.rowId;
      }
      this._MasterService.getUserDocuments(travellerId)
        .subscribe((response) => {
          const result: any = response;
          this.Documents = result.response;
          traveller['documents'] = this.Documents;
          SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfoTravellers));
        });
      console.log(this.currentUserInfoTravellers);
    });
  }

  updateKyc(file, Doc, DocIndex, travellerIndex) {
    const KycFile = file.target.files[0];
    this.formdata = new FormData();
    this.formdata.append('documentInfo', JSON.stringify(Doc));
    this.formdata.append('DocIndex', DocIndex);
    const fileValidation = (KycFile.type.indexOf('jpeg') !== -1 || KycFile.type.indexOf('png') !== -1
      || KycFile.type.indexOf('gif') !== -1) && KycFile.size <= 500000;
    if (fileValidation) {
      this.formdata.append('sampleFile', KycFile, KycFile.name);
      this._MasterService.updateKyc(this.formdata).subscribe((response) => {
        const result: any = response;
        this.currentUserInfoTravellers.traveller[travellerIndex].documents[result.response.index].imageUrl = result.response.imageUrl;
        // this.Documents[result.response.index].imageUrl = result.response.imageUrl;
        this.formdata = {};
      });
    } else {
      // swal('Invalid File ', 'Supports JPEG, PNG and GIF. The file size should not exceed 500 KB.', 'error');
      Snackbar.show({
        text: 'Invalid File, Supports JPEG, PNG and GIF. The file size should not exceed 500 KB.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      console.log('Invalid file');
    }
  }
  selectedTraveller(index: any) {
    this.currentUserInfoTravellers.traveller.map((traveller) => {
      traveller.selected = false;
    });
    this.currentUserInfoTravellers.traveller[index].selected = true;
  }


  openPopup(imgSrc: any) {
    if (imgSrc != null || imgSrc !== undefined) {

      if (imgSrc.indexOf('.pdf') !== -1) {
        const documentScr = imgSrc;
        const newtab = window.open(documentScr, '_blank');
        newtab.focus();
      } else {
        this.documentScr = imgSrc;
        document.getElementById('myModal').style.display = 'block';
      }


    }



  }
  closeDocpopup() {
    document.getElementById('myModal').style.display = 'none';
  }


  removeDoc(Doc, documents, DocIndex) {
    const payload: any = {};
    payload.type = Doc.type;
    payload.userId = Doc.userId;
    this._MasterService.deleteDocument(payload).subscribe((data) => {
      const result: any = data;
      if (result.success) {
        // swal(Doc.type, 'Removed Successfully', 'success');
        Snackbar.show({
          text: 'Removed Successfully',
          pos: 'bottom-right',
          actionTextColor: '#05ff01',
        });
        documents.splice(DocIndex, 1);
      } else {
        // swal('', 'Error removing document', 'error');
        Snackbar.show({
          text: 'Error removing document',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }
    }, (error) => {
      console.log(error);
    });
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
