import { Component, OnInit, AfterViewInit, ViewChildren, QueryList, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var Snackbar: any;
declare var $: any;
declare function initDocument(): any;
declare function initAccord(): any;
@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit, AfterViewInit {

  public checkCurrentUserSession: any;
  public currentUserInfo: any;
  public currentTraveller: any;
  public leadTraveller: any;
  public travellerOfficeAddress: any = [];
  public travellerSelected: any = 'main';
  public currentCoIndex: any;
  public concertinaStatus: any = '';
  public _primaryComp: any;
  public skipAdhaarValidationFlag: any = false;
  @ViewChildren('ProfileLists') ProfileLists: QueryList<any>;
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private routerA: ActivatedRoute, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    this.skipAdhaarValidationFlag = this._MasterService.getSkipAdhaarValidationFlag();
    console.log(UserInfo);
    if (UserInfo == null || UserInfo === undefined) {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    } else {
      this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
      this.currentUserInfo.traveller[0].selected = true;
      this.leadTraveller = this.currentUserInfo.traveller[0];
      this.currentTraveller = this.currentUserInfo.traveller[0];
      console.log(this.currentUserInfo);
    }
    this._document.title = 'View your profile details';
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'View your profile details'});
  }

  ngOnInit() {
    if (this.routerA.snapshot.queryParams && +this.routerA.snapshot.queryParams.traveller) {
      // this.coTraveller = this.currentUserInfo.traveller[+this.routerA.snapshot.queryParams.traveller];
      this.selectedTab('co');
      setTimeout(() => {
        this.currentUserInfo.traveller[+this.routerA.snapshot.queryParams.traveller].selected = false;
        this.onSelectTraveller(+this.routerA.snapshot.queryParams.traveller);
      }, 150);

      // this.coTravellerIndex = +this.routerA.snapshot.queryParams.traveller;
      // this.travellerSelected = 'co';
      // this.travellerInfo = 'existing';
    } else {
      this.selectedTab('main');
    }
    this.concatOfficeAddress();
    setTimeout(function () {
      initDocument();
    }, 100);
  }
  ngAfterViewInit() {
    this.ProfileLists.changes.subscribe((ProfileList) => {
      console.log(ProfileList);
      initAccord();
    });
  }
  selectedTraveller(index: any) {
    this.currentUserInfo.traveller.map((traveller) => {
      traveller.selected = false;
    });
    this.currentUserInfo.traveller[index].selected = true;
    this.currentTraveller = this.currentUserInfo.traveller[index];
  }

  onSelectTraveller(index: any) {
    let offsetTop = 0;
    if (this.currentUserInfo.traveller[index].selected !== true) {
      this.currentUserInfo.traveller.map((traveller) => {
        traveller.selected = false;
      });
      this.currentUserInfo.traveller[index].selected = true;
      this.currentCoIndex = index;
      offsetTop = +($('.co-traveller-list').offset().top) + 40 * index - 150;
      // console.log()
      window.scrollTo(0, offsetTop);
      // this.currentTraveller = this.currentUserInfo.traveller[index];
    } else {
      this.currentUserInfo.traveller[index].selected = false;
    }
  }

  selectedTab(index: any) {
    this.travellerSelected = index;
  }

  replaceLastCommaWith(text, element) {
    const pos = text.lastIndexOf(',');
    return text.substring(0, pos) + ' ' + element + ' ' + text.substring(pos + 1);
  }

  concatOfficeAddress() {
    const nonAdressParam = ['conpanyName', 'companyName', 'designation', 'companyDivision', 'pincode'];
    this.travellerOfficeAddress = [];
    this.currentUserInfo.traveller.forEach((traveller, index) => {
      // tslint:disable-next-line:prefer-const
      let addressText = '', officeAddress = traveller.registrationInfo.officeAddress, counter = 0, pincodeAdded = false;
      // tslint:disable-next-line:forin
      for (const travellerData in officeAddress) {
        if (nonAdressParam.indexOf(travellerData) === -1 && officeAddress[travellerData]) {
          addressText += officeAddress[travellerData] + ', ';
          counter++;
        }

        if (travellerData === 'pincode' && officeAddress[travellerData]) {
          if (counter > 0) {
            addressText = this.replaceLastCommaWith(addressText, '-') + officeAddress[travellerData];
          } else {
            addressText += officeAddress[travellerData];
          }
          pincodeAdded = true;
        }
      }
      if ((counter > 0 && pincodeAdded) || pincodeAdded) {
        addressText += '.';
      } else if (counter > 0) {
        addressText += this.replaceLastCommaWith(addressText, '.');
      }
      this.travellerOfficeAddress[index] = addressText;
    });
  }

  deleteTraveller(currentIndex, event) {
    const userId = this.currentUserInfo.traveller[currentIndex].registrationInfo.userId;
    if (userId) {
      const idObj = { 'id': userId.toString() };
      this._MasterService.removeTraveller(idObj)
        .subscribe((response) => {
          const result: any = response;
          if (result.message === 'true') {
            this.currentUserInfo.traveller.splice(currentIndex, 1);
            Snackbar.show({
              text: 'Traveller removed successfully.',
              pos: 'bottom-right',
            });
          } else {
            Snackbar.show({
              text: 'There is some issue with removing traveller.',
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
            });
          }
        });
    }
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
