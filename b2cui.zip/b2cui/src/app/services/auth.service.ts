import { Injectable } from '@angular/core';
import { SessionHelper } from '../helpers/session-helper';

@Injectable()
export class AuthService {

  constructor() { }

  public isAuthenticated(): boolean {
    if (sessionStorage.getItem('userInfo') != null) {
      const loggedin = JSON.parse(SessionHelper.getSession('userInfo')).loggedin;
      if (loggedin) {
        return true;
      }
    }
    return false;
  }

}
