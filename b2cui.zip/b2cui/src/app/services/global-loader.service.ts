import { Injectable } from '@angular/core';
import { Constants } from '../../app/helpers/constants';
import { Subject } from 'rxjs/Subject';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SessionHelper } from '../../app/helpers/session-helper';
@Injectable()
export class GlobalLoaderService {
    public isLoading = false;
    public UserInfo: any;
    public subject = new Subject();
    constructor(private http: HttpClient) { }
    setLoading() {
        this.isLoading = true;
    }

    removeLoading() {
        this.isLoading = false;
        this.subject.next(this.isLoading);
    }
}
