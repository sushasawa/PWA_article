import { MasterService } from './master.services';
import { Injectable, EventEmitter, Output } from '@angular/core';
import { SessionHelper } from '../helpers/session-helper';
import { Router } from '@angular/router';
import { NavigatePathService } from './navigate-path.service';
@Injectable()
export class BulkExchangeRateService {
  public BulkRatePayload: Array<any> = [];
  public type: any;
  public userSessionInfo: any;
  public _primaryComp: any;
  @Output() emitSession: EventEmitter<any> = new EventEmitter<any>();
  constructor(public _MasterService: MasterService, private router: Router, private navUrl: NavigatePathService) {
    this._primaryComp = '/' + navUrl.navUrl();
  }

  public getBulkExchangeRate(session, CALL_TYPE) {
    
    console.log('BULK EXHCHANGE RATE CALLED WITH TYPE'  + CALL_TYPE );
    this.userSessionInfo = session;
    this.type = this.userSessionInfo.type;
    this.BulkRatePayload = [];
    this.userSessionInfo[this.type].traveller.map((currentTraveller, TravellerIndex) => {
      if (this.type === 'reloadCardScreen') {
        if (currentTraveller.prepaidCard) {
          currentTraveller.prepaidCardDetails.map((prepaidCard, prepaidCardIndex) => {
            if (prepaidCard.currencyDetails.length > 0) {
              prepaidCard.currencyDetails.map((currency, CurrencyIndex) => {
                if (currency.currencyCode && currency.exchangeRate) {
                  this.BulkRatePayload.push(
                    {
                      'Process': this.getType(this.type),
                      'Product': 'prepaid',
                      'BranchId': this.getBranchId(this.type),
                      'CurrencyCode': currency.currencyCode,
                      'BankCode': prepaidCard.bankname,
                      'Traveller': TravellerIndex
                    }
                  );
                }
              });
            }
          });
        }
      } else {
        if (currentTraveller.prepaidCard) {
          currentTraveller.prepaidCardDetails.map((prepaidCard, prepaidCardIndex) => {
            if (!(prepaidCard.forexAmount === undefined || prepaidCard.exchangeRate === undefined)) {
              if (this.type === 'sendMoneyScreen') {
                prepaidCard.bankname = 'ICICIMCC';
              }
              this.BulkRatePayload.push(
                {
                  'Process': this.getType(this.type),
                  'Product': this.type === 'buyScreen' ? 'prepaid' : 'dd',
                  'BranchId': this.getBranchId(this.type),
                  'CurrencyCode': prepaidCard.currencyCode,
                  'BankCode': prepaidCard.bankname ? prepaidCard.bankname : 'ICICIMCC',
                  'Traveller': TravellerIndex
                }
              );
            }
          });
        }

        if (currentTraveller.cash) {
          currentTraveller.cashDetails.map((Cash, CashIndex) => {
            if (!(Cash.forexAmount === undefined || Cash.exchangeRate === undefined)) {
              this.BulkRatePayload.push(
                {
                  'Process': this.getType(this.type),
                  'Product': 'cash',
                  'BranchId': this.getBranchId(this.type),
                  'CurrencyCode': Cash.currencyCode,
                  'BankCode': Cash.bankname ? Cash.bankname : null,
                  'Traveller': TravellerIndex
                }
              );
            }
          });
        }

        if (currentTraveller.travellerCheque) {
          currentTraveller.travellerChequeDetails.map((TravellerCheque, TravellerChequeIndex) => {
            if (!(TravellerCheque.forexAmount === undefined || TravellerCheque.exchangeRate === undefined)) {
              // tslint:disable-next-line:max-line-length
              this.BulkRatePayload.push(
                {
                  'Process': this.getType(this.type),
                  'Product': 'dd',
                  'BranchId': this.getBranchId(this.type),
                  'CurrencyCode': TravellerCheque.currencyCode,
                  'BankCode': TravellerCheque.bankname ? TravellerCheque.bankname : null,
                  'Traveller': TravellerIndex
                }
              );
            }
          });
        }

        if (currentTraveller.demandDraft) {
          currentTraveller.demandDraftDetails.map((DemandDraft, DemandDraftIndex) => {
            if (!(DemandDraft.forexAmount === undefined || DemandDraft.exchangeRate === undefined)) {
              this.BulkRatePayload.push(
                {
                  'Process': this.getType(this.type),
                  'Product': 'dd',
                  'BranchId': this.getBranchId(this.type),
                  'CurrencyCode': DemandDraft.currencyCode,
                  'BankCode': DemandDraft.bankname ? DemandDraft.bankname : null,
                  'Traveller': TravellerIndex
                }
              );
            }
          });
        }
      }
    });
    // console.log(this.BulkRatePayload);
    this._MasterService.getBulkExchangeRate(this.BulkRatePayload)
      .subscribe((data) => {
        console.log(data);
        const result: any = data;
        this.mapFetchedRates(result, CALL_TYPE);
      }, (error) => {
        // console.log(error);
      });
  }



  public getType(type) {
    let ProType: any;
    switch (type) {
      case 'buyScreen':
        ProType = 'buy';
        break;
      case 'sellScreen':
        ProType = 'sell';
        break;
      case 'reloadCardScreen':
        ProType = 'buy';
        break;
      case 'sendMoneyScreen':
        ProType = 'buy';
        break;
    }

    return ProType;
  }

  getBranchId(type) {
    let BranchId: any;
    switch (type) {
      case 'buyScreen':
        // tslint:disable-next-line:max-line-length
        BranchId = SessionHelper.getLocal('branchIdFromOverviewBuy') ? SessionHelper.getLocal('branchIdFromOverviewBuy') : SessionHelper.getLocal('branchIdFromOverview');
        break;
      case 'sellScreen':
        // tslint:disable-next-line:max-line-length
        BranchId = SessionHelper.getLocal('branchIdFromOverviewSell') ? SessionHelper.getLocal('branchIdFromOverviewSell') : SessionHelper.getLocal('branchIdFromOverview');
        break;
      case 'reloadCardScreen':
        // tslint:disable-next-line:max-line-length
        BranchId = SessionHelper.getLocal('branchIdFromOverviewReload') ?  SessionHelper.getLocal('branchIdFromOverviewReload') : SessionHelper.getLocal('branchIdFromOverview');
        break;
      case 'sendMoneyScreen':
        // tslint:disable-next-line:max-line-length
        BranchId = SessionHelper.getLocal('branchIdFromOverviewSend') ? SessionHelper.getLocal('branchIdFromOverviewSend') : SessionHelper.getLocal('branchIdFromOverview');
        break;

      default:
        BranchId = SessionHelper.getLocal('branchIdFromOverview');
    }
    return BranchId;
  }

  public mapFetchedRates(rates, CALL_TYPE) {
    console.log('called mappping');
    this.userSessionInfo[this.type].traveller.map((currentTraveller, TravellerIndex) => {
      rates.map((rate, index) => {
        if (this.type === 'reloadCardScreen') {
          console.log('reload card in');
          if (currentTraveller.prepaidCard) {
            console.log('reload card in PRPAID TRUE');
            currentTraveller.prepaidCardDetails.map((prepaidCard, prepaidCardIndex) => {
              console.log('reload card in LOOPED');
              if (prepaidCard.currencyDetails.length > 0) {
                prepaidCard.currencyDetails.map((currency, CurrencyIndex) => {
                  console.log('reload card in LOOPED IN CURRENCY');
                  // tslint:disable-next-line:max-line-length
                  const prepaidValidation = (currency.currencyCode && currency.forexAmount && currency.currencyCode === rate.CurrencyCode && this.getType(this.type) === rate.Process && prepaidCard.bankname === rate.BankCode && TravellerIndex === Number.parseInt(rate.Traveller));
                  console.log('reload card in LOOPED IN CURRENCY' + prepaidValidation);
                  if (prepaidValidation) {
                    currency.exchangeRate.rate = rate.rate;
                    currency.exchangeRate.time = rate.time;
                  }
                });
              }
            });
          }
        } else {
          if (currentTraveller.prepaidCard) {
            console.log('PREPAID CONDITION TRUE');
            currentTraveller.prepaidCardDetails.map((prepaidCard, prepaidCardIndex) => {
              console.log('PREPAID LOOPED');
              // tslint:disable-next-line:max-line-length
              const prepaidValidation = (prepaidCard.currencyCode && prepaidCard.forexAmount && prepaidCard.currencyCode === rate.CurrencyCode && this.getType(this.type) === rate.Process && prepaidCard.bankname === rate.BankCode && TravellerIndex === Number.parseInt(rate.Traveller));
              console.log('prepaid ' + prepaidValidation);
              if (prepaidValidation) {
                prepaidCard.exchangeRate.rate = rate.rate;
                prepaidCard.exchangeRate.time = rate.time;
              }
            });
          }

          if (currentTraveller.cash) {
            currentTraveller.cashDetails.map((Cash, CashIndex) => {
              // tslint:disable-next-line:max-line-length
              const cashValidation = (Cash.currencyCode && Cash.forexAmount && Cash.currencyCode === rate.CurrencyCode && this.getType(this.type) === rate.Process && TravellerIndex === Number.parseInt(rate.Traveller));
              if (cashValidation) {
                Cash.exchangeRate.rate = rate.rate;
                Cash.exchangeRate.time = rate.time;
              }
            });
          }

          if (currentTraveller.travellerCheque) {
            currentTraveller.travellerChequeDetails.map((TravellerCheque, TravellerChequeIndex) => {
              // tslint:disable-next-line:max-line-length
              const travellerChequeValidation = (TravellerCheque.currencyCode && TravellerCheque.forexAmount && TravellerCheque.currencyCode === rate.CurrencyCode && this.getType(this.type) === rate.Process && TravellerIndex === Number.parseInt(rate.Traveller));
              if (travellerChequeValidation) {
                TravellerCheque.exchangeRate.rate = rate.rate;
                TravellerCheque.exchangeRate.time = rate.time;
              }
            });
          }

          if (currentTraveller.demandDraft) {
            currentTraveller.demandDraftDetails.map((DemandDraft, DemandDraftIndex) => {
              // tslint:disable-next-line:max-line-length
              const demandDraftValidation = (DemandDraft.currencyCode && DemandDraft.forexAmount && DemandDraft.currencyCode === rate.CurrencyCode && this.getType(this.type) === rate.Process && TravellerIndex === Number.parseInt(rate.Traveller));
              if (demandDraftValidation) {
                DemandDraft.exchangeRate.rate = rate.rate;
                DemandDraft.exchangeRate.time = rate.time;
              }
            });
          }
        }
      });

    });
    switch (CALL_TYPE) {
      case 'CLICK':
        this.emitSession.emit(this.userSessionInfo);
        break;

      case 'WISH_LIST':
        this.emitSession.emit(this.userSessionInfo);
        console.log('WISHLIST TYPE ' + this.type);
        console.log(JSON.stringify(this.userSessionInfo));
        switch (this.type) {
          case 'buyScreen':
            SessionHelper.setSession('userSessionInfo', JSON.stringify(this.userSessionInfo));
            this.router.navigateByUrl(this._primaryComp + this.userSessionInfo.nextLink);
            break;
          case 'sellScreen':
            SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfo));
            this.router.navigateByUrl(this._primaryComp + this.userSessionInfo.nextLink);
            break;
          case 'reloadCardScreen':
            SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
            this.router.navigateByUrl(this._primaryComp + this.userSessionInfo.nextLink);
            break;
          case 'sendMoneyScreen':
            SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfo));
            this.router.navigateByUrl(this._primaryComp + this.userSessionInfo.nextLink);
            break;
        }
        break;

      default:
        break;
    }

  }


  public updateUsedAmount(session) {
    return new Promise((resolve, reject) => {
      const userSessionInfo: any = session;
      let travellerTotal = 0;
      console.log('USED AMOUNT CALLED');
      userSessionInfo[this.type].traveller.forEach(currentTraveller => {
        let currentTravellerTotal = 0;
        if (currentTraveller.prepaidCard) {
          currentTraveller.prepaidCardDetails.forEach(element => {
            if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
              currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
            }
          });
        }
        if (currentTraveller.cash) {
          currentTraveller.cashDetails.forEach(element => {
            if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
              currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
            }
          });
        }
        if (currentTraveller.travellerCheque) {
          currentTraveller.travellerChequeDetails.forEach(element => {
            if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
              currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
            }
          });
        }
        if (currentTraveller.demandDraft) {
          currentTraveller.demandDraftDetails.forEach(element => {
            if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
              currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
            }
          });
        }

        travellerTotal += currentTravellerTotal;
        currentTraveller.usedAmount = currentTravellerTotal;
      });


      userSessionInfo[this.type].usedAmount = travellerTotal;

      if (userSessionInfo[this.type].usedAmount !== 0) {
        this._MasterService.getTaxes(userSessionInfo[this.type].usedAmount)
          .subscribe(res => {
            const result: any = res;
            userSessionInfo[this.type].usedAmount += result.TotalTax;
            resolve(this.updateBalanceAmount(userSessionInfo));
            console.log('AMOUNT' + userSessionInfo[this.type].usedAmount, 'TAXES' + result.TotalTax);
          }, err => {
            //  swal('Oops', 'Error fetching taxes', 'error');
          });
      }

    });

  }

  public updateBalanceAmount(userSessionInfo) {
    if (Number.isNaN(Number.parseInt(userSessionInfo[this.type].budgetAmount))) {
      userSessionInfo[this.type].balanceAmount = '';
    } else if (userSessionInfo[this.type].budgetAmount !== '0' && userSessionInfo[this.type].budgetAmount !== 0) {
      userSessionInfo[this.type].balanceAmount = (userSessionInfo[this.type].budgetAmount
        - userSessionInfo[this.type].usedAmount);
      userSessionInfo[this.type].balanceAmount
        = userSessionInfo[this.type].balanceAmount < 0 ? 0 : userSessionInfo[this.type].balanceAmount;
      if (userSessionInfo[this.type].budgetAmount - userSessionInfo[this.type].usedAmount <= 0) {
        // swal('Oops', 'You have exceeded your budget!!', 'warning');
      }
    }
    return userSessionInfo;
  }


}
