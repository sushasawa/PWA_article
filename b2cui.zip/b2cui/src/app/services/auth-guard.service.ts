import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { Router, CanActivate } from '@angular/router';
import { AuthService } from './auth.service';
import { NavigatePathService } from '../../app/services/navigate-path.service';
@Injectable()
export class AuthGuardService {
  public _primaryComp: any;
  constructor(public auth: AuthService, private navUrl: NavigatePathService, public router: Router, private location: Location) { 
    this._primaryComp = '/' + navUrl.navUrl();
  }

  canActivate(): boolean {
    if (!this.auth.isAuthenticated()) {
      const currentPath = this.location.path().split('/');
      this.router.navigate([this._primaryComp + '/' + currentPath[2] + '/register-login']);
      return false;
    }
    return true;
  }

}
