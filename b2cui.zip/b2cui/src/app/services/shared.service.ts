import { MasterService } from './../services/master.services';
import { Injectable, Output, EventEmitter } from '@angular/core';
import { SessionHelper } from '../helpers/session-helper';
import { NavigatePathService } from '../../app/services/navigate-path.service';
import { Subject } from 'rxjs/Subject';
@Injectable()
export class SharedService {
  public UserControledData: any;
  public subAgents: any = [];
  public AgentsTheme: any;
  public AgentWebsiteID: any;
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService) {
    this.AgentWebsiteID = new Subject();
    this.AgentsTheme = {
      'logo': 'assets/images/common/nocompanylogo.png',
      'HeaderBackgroundImage': 'assets/images/home/header-bg-inner.png'
    };
    this.navUrl.AgentIdObservable.subscribe(data => {
      const result: any = data;
      console.log(result, ';;;;;;;;;;;;;;;;;;;;;;');
      SessionHelper.setSession('AgentWebsiteID', result[0].UserId);
      this.AgentWebsiteID.next(result[0].UserId);
      SessionHelper.setSession('AgentWebsiteName', result[0].AliasName);
      this.getAgentTheme();
    });
  }
  // for agent logo
  // @Output() LogoSrc: EventEmitter<String> = new EventEmitter();

  // for Admins and Agents control access

  // @Output() ACCESS_CTRL: EventEmitter<any> = new EventEmitter();

  // @Output() subAgentsEmitter: EventEmitter<any> = new EventEmitter();

  @Output() AgentTheme: EventEmitter<any> = new EventEmitter();

  // updateLogoSrc(src) {
  //   this.LogoSrc.emit(src);
  // }

  // getUserAccessCtrl(payload) {
  //   this._MasterService.getUserControl(payload).subscribe((userCtrl) => {
  //     this.UserControledData = userCtrl;
  //     this.ACCESS_CTRL.emit(this.UserControledData);
  //   });
  // }

  // getSubAgents(payload) {
  //   this._MasterService.getSubAgents(payload).subscribe((data) => {
  //     const result: any = data;
  //     if (result.status) {
  //       result.data[0].map((agent, index) => {
  //         this.subAgents.push({
  //           'UserId': agent.value,
  //           'Email': agent.EmailId,
  //           'AdmType': agent.RoleName + '_' + agent.RoleId,
  //           'Name': agent.label
  //         });
  //       });
  //       this.subAgentsEmitter.emit(this.subAgents);
  //     } else {
  //       this.subAgentsEmitter.emit(this.subAgents);
  //     }
  //   });
  // }

  getAgentTheme() {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    let userId;
    if (SessionHelper.getSession('AgentWebsiteID')) {
      userId = SessionHelper.getSession('AgentWebsiteID');
      console.log(userId, '55555555555555555555555555');
      const payload: any = {
        id: userId
      };
      this._MasterService.getAgentTheme(payload).subscribe((AgentTheme) => {
        const theme: any = AgentTheme;
        if (theme.status === 1) {

          const TemplatePayload: any = {
            '_id': theme.templateCode
          };
          this._MasterService.getAgentThemeDetails(TemplatePayload).subscribe((data) => {
            const result: any = data;

            if (result.success) {
              this.AgentsTheme = result;
              // this.updateLogoSrc(this.AgentsTheme);
              this.AgentTheme.emit(this.AgentsTheme);
            } else {
              this.AgentTheme.emit(this.AgentsTheme);
            }
          });
        } else {
          // this.updateLogoSrc(this.AgentsTheme);
          this.AgentTheme.emit({});
        }
      });
    // }
  }
  }
}
