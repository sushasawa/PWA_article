import { Injectable } from '@angular/core';
import { Constants } from '../../app/helpers/constants';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SessionHelper } from '../helpers/session-helper';
@Injectable()
export class AgentMarginService {
    public agentMarginObj;
    constructor(private http: HttpClient) { }
    getAgentMargin(AgentId) {
        return this.http.get(Constants.getAgentMargin(AgentId));
    }

    setAgentMargin() {
        if (SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID')) {
            let AgentIDString = SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID');
            let AgentId = JSON.parse(AgentIDString);
            this.getAgentMargin(AgentId).subscribe(data => {
                const retData: any = data;
                const agentMargin: any = retData.root.element;
                this.agentMarginObj = agentMargin;
            }, err => {
                console.error(err);
            });
        }
    }

    setAgentMarginCall(callBack) {
        if (SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID')) {
            let AgentIDString = SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID');
            let AgentId = JSON.parse(AgentIDString);            
            this.getAgentMargin(AgentId).subscribe(data => {
                const retData: any = data;
                const agentMargin: any = retData.root.element;
                this.agentMarginObj = agentMargin;
                callBack();
            }, err => {
                console.error(err);
                callBack();
            });            
        }
    }
}