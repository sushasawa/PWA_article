import { TestBed, inject } from '@angular/core/testing';

import { BulkExchangeRateService } from './bulk-exchange-rate.service';

describe('BulkExchangeRateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BulkExchangeRateService]
    });
  });

  it('should be created', inject([BulkExchangeRateService], (service: BulkExchangeRateService) => {
    expect(service).toBeTruthy();
  }));
});
