import { SessionHelper } from './../helpers/session-helper';
import { Injectable, Output } from '@angular/core';
import { EventEmitter } from 'events';

@Injectable()
export class TimerService {
  @Output() isTimeExpired: EventEmitter = new EventEmitter();
  private currentTime: Date = new Date();
  constructor() {
   // console.log(this.currentTime);
    setInterval(() => {
   //   console.log(this.currentTime);
    }, 1000);
  }



 startTimer() {

 }
}
