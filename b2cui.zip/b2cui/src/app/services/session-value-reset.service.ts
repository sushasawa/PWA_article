import { Injectable } from '@angular/core';
import { MasterService } from '../services/master.services';
import { SessionHelper } from '../helpers/session-helper';
@Injectable()
export class SessionValueResetService {
    public userSessionInfo: any;
    public type: any;
    public Session: any;
    public CurrentBranchId: any;
    public callCount = 0;
    public callBackCount = 0;
    public callBackFunction: any = null;
    constructor(private masterService: MasterService) { }

    getUserSessionInfo(session, usersSession, callBackFunction?) {
        this.userSessionInfo = usersSession;
        this.type = usersSession.type;
        this.Session = session;
        console.log(this.type);
        console.log(this.Session);
        this.callCount = 0;
        this.callBackCount = 0;
        if(callBackFunction){
            this.callBackFunction = callBackFunction;
        }
        this.CurrentBranchId = Number.parseInt(SessionHelper.getLocal('branchIdFromOverview'));
        //  console.log(this.userSessionInfo);
        this.initUserInfo();
        return this.userSessionInfo;
    }

    updateSession() { console.log('SESSION UPDATED');
      //  SessionHelper.removeSession(this.Session);
        SessionHelper.setSession(this.Session, JSON.stringify(this.userSessionInfo));
        if(this.callBackFunction && this.callCount == this.callBackCount){
            this.callBackFunction();
        }
    }
    getType(type) {
        let ProType: any;
        switch (type) {
            case 'buyScreen':
                ProType = 'buy';
                break;
            case 'sellScreen':
                ProType = 'sell';
                break;
            case 'reloadCardScreen':
                ProType = 'buy';
                break;
            case 'sendMoneyScreen':
                ProType = 'buy';
                break;
        }

        return ProType;
    }
    initUserInfo() {
        console.log('INITIALIZED');
        const productType = this.getType(this.type); console.log('PRODUCT TYPE : ' + this.type + ' - ' + productType);
        this.userSessionInfo[this.type].traveller.map((currentTraveller, TravellerIndex) => {
            if (this.type === 'reloadCardScreen') {
                console.log('CALL RELOAD CURRENCY UPDATE');
                if (currentTraveller.prepaidCard) {
                    currentTraveller.prepaidCardDetails.map((prepaidCard, prepaidCardIndex) => {
                        if (prepaidCard.currencyDetails.length > 0) {
                            prepaidCard.currencyDetails.map((currency, CurrencyIndex) => {
                                if (currency.currencyCode && currency.exchangeRate) {
                                    // tslint:disable-next-line:max-line-length
                                    this.updateReloadCurrencyCode(TravellerIndex, prepaidCardIndex, CurrencyIndex, currency.currencyCode, productType);
                                }
                            });
                        }
                    });
                }
            } else {
                console.log('CALL OTHER CURRENCY UPDATE');
                if (currentTraveller.prepaidCard) {
                    currentTraveller.prepaidCardDetails.map((prepaidCard, prepaidCardIndex) => {   
                        console.log('PRO TYPE ' + productType + '>>>>>>> PREPAID');
                        if (!(prepaidCard.forexAmount === undefined || prepaidCard.exchangeRate === undefined)) {
                            this.updatePrepaidCurrencyCode(prepaidCardIndex, prepaidCard.currencyCode, TravellerIndex, productType);
                            this.updateSession();
                        }
                    });
                }
               
                if (currentTraveller.cash) { console.log('IN CASH**************************************888888')
                    currentTraveller.cashDetails.map((Cash, CashIndex) => {   console.log('PRO TYPE ' + productType + '>>>>>  CASH');
                        if (!(Cash.forexAmount === undefined || Cash.exchangeRate === undefined)) {
                            this.updateCashCurrencyCode(CashIndex, Cash.currencyCode, TravellerIndex, productType);
                            this.updateSession();
                        }
                    });
                }
                
                if (currentTraveller.travellerCheque) {
                    currentTraveller.travellerChequeDetails.map((TravellerCheque, TravellerChequeIndex) => {
                         console.log('PRO TYPE ' + productType + '>>>>>>>>>>>  TRAVLLER CHEQUE');
                        if (!(TravellerCheque.forexAmount === undefined || TravellerCheque.exchangeRate === undefined)) {
                            // tslint:disable-next-line:max-line-length
                            this.updateTravellerChequeCurrencyCode(TravellerChequeIndex, TravellerCheque.currencyCode, TravellerIndex, productType);
                            this.updateSession();
                        }
                    });
                }
                
            if (currentTraveller.demandDraft) {
                    currentTraveller.demandDraftDetails.map((DemandDraft, DemandDraftIndex) => {
                         console.log('PRO TYPE ' + productType + '>>>>>>>>>>>>> DEMAND DRFAFT');
                        if (!(DemandDraft.forexAmount === undefined || DemandDraft.exchangeRate === undefined)) {
                            this.updateDemandDraftCurrencyCode(DemandDraftIndex, DemandDraft.currencyCode, TravellerIndex, productType);
                            this.updateSession();
                        }
                    });
                }
            }
        });
        this.updateSession();
    }
    // region Update currency code event listeners
    updatePrepaidCurrencyCode(prepaidDetailIndex: number, newValue: string, currentTravellerIndex: any, productType) {
        console.log('-----------------------------------------------------------------------');
        console.log('PREVIOUS PREPAID VALUE VVVVVV');
        console.log(this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
            .exchangeRate);
        console.log('-----------------------------------------------------------------------');
        this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
        this.callCount++;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', productType)
            .subscribe(data => {
                this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
                    .exchangeRate = data;
                    this.callBackCount++;
                console.log('Exchange rate called NEW PREPAID');
                console.log('+++++++++++++++++++++++++++++++++++++++++++');
                console.log(this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
                    .exchangeRate);
                console.log('+++++++++++++++++++++++++++++++++++++++++++');
                this.updateUsedAmount();
                this.updateSession();
            }, err => {
                this.callBackCount++;
                //  swal('Oops...', 'Unable to fetch exchange rate!', 'error');
            });


    }

    updateCashCurrencyCode(cashDetailIndex: number, newValue: string, currentTravellerIndex: any, productType: any) {
        this.userSessionInfo[this.type].traveller[currentTravellerIndex].cashDetails[cashDetailIndex].currencyCode = newValue;
        console.log('++++++++++++++++++++++++++++++++++++++++++++++++++++++');
        console.log('PREVIOUS CASH VALUE VVVVVV');
        console.log(this.userSessionInfo[this.type].traveller[currentTravellerIndex].cashDetails[cashDetailIndex].exchangeRate);
        console.log('++++++++++++++++++++++++++++++++++++++++++++++++++++++');
        this.callCount++;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'cash', productType)
            .subscribe(data => {
                this.userSessionInfo[this.type].traveller[currentTravellerIndex].cashDetails[cashDetailIndex].exchangeRate = data;
                this.callBackCount++;
                console.log('++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                console.log('NEW CASH VALUE VVVVVV');
                console.log(this.userSessionInfo[this.type].traveller[currentTravellerIndex].cashDetails[cashDetailIndex].exchangeRate);
                console.log('++++++++++++++++++++++++++++++++++++++++++++++++++++++');
                this.updateUsedAmount();
                this.updateSession();
            }, err => {
                this.callBackCount++;
                // swal('Oops...', 'Unable to fetch exchange rate!', 'error');
            });
    }

    updateTravellerChequeCurrencyCode(travellerChequeDetailIndex: number, newValue: string, currentTravellerIndex: any, productType: any) {
        this.userSessionInfo[this.type].traveller[currentTravellerIndex].travellerChequeDetails[travellerChequeDetailIndex]
            .currencyCode = newValue;
            this.callCount++;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', productType)
            .subscribe(data => {
                this.userSessionInfo[this.type].traveller[currentTravellerIndex].travellerChequeDetails[travellerChequeDetailIndex]
                    .exchangeRate = data;
                this.callBackCount++;
                this.updateUsedAmount();
                this.updateSession();
            }, err => {
                this.callBackCount++;
                //   swal('Oops...', 'Unable to fetch exchange rate!', 'error');
            });
    }

    updateDemandDraftCurrencyCode(demandDraftDetailIndex: number, newValue: string, currentTravellerIndex: any, productType: any) {
        this.userSessionInfo[this.type].traveller[currentTravellerIndex].demandDraftDetails[demandDraftDetailIndex]
            .currencyCode = newValue;
            this.callCount++;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', productType)
            .subscribe(data => {
                this.userSessionInfo[this.type].traveller[currentTravellerIndex].demandDraftDetails[demandDraftDetailIndex]
                    .exchangeRate = data;
                    this.callBackCount++;
                this.updateUsedAmount();
                this.updateSession();
            }, err => {
                this.callBackCount++;
                //    swal('Oops...', 'Unable to fetch exchange rate!', 'error');
            });
    }
    updateReloadCurrencyCode(currentTravellerIndex, prepaidDetailIndex: number, currencyIndex: number, newValue: string, productType: any) {
        this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
            .currencyDetails[currencyIndex].currencyCode = newValue;
            console.log('PREVIOUS-------------------------------');
            console.log( this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
                .currencyDetails[currencyIndex].currencyCode );
                console.log(this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
                    .currencyDetails[currencyIndex]);
            console.log('PREVIOUS-------------------------------');
            this.callCount++;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', productType)
            .subscribe(data => { console.log(data);
                this.callBackCount++;
                this.userSessionInfo[this.type].traveller[currentTravellerIndex]
                    .prepaidCardDetails[prepaidDetailIndex].currencyDetails[currencyIndex].exchangeRate = data;
                    console.log('AFTER-------------------------------');
                    console.log( this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
                        .currencyDetails[currencyIndex].currencyCode );
                        console.log(this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
                            .currencyDetails[currencyIndex]);
                    console.log('AFTER-------------------------------');
                this.updateUsedAmount();
                this.updateSession();
            }, err => {
                this.callBackCount++;
            });
        this.updateSession();
    }


    updateUsedAmount() {
        let travellerTotal = 0;
        console.log('USED AMOUNT CALLED');
        this.userSessionInfo[this.type].traveller.forEach(currentTraveller => {
            let currentTravellerTotal = 0;
            if (currentTraveller.prepaidCard) {
                currentTraveller.prepaidCardDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }
            if (currentTraveller.cash) {
                currentTraveller.cashDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }
            if (currentTraveller.travellerCheque) {
                currentTraveller.travellerChequeDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }
            if (currentTraveller.demandDraft) {
                currentTraveller.demandDraftDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }

            travellerTotal += currentTravellerTotal;
            currentTraveller.usedAmount = currentTravellerTotal;
        });


        this.userSessionInfo[this.type].usedAmount = travellerTotal;

        if (this.userSessionInfo[this.type].usedAmount !== 0) {
            this.masterService.getTaxes(this.userSessionInfo[this.type].usedAmount)
                .subscribe(res => {
                    const result: any = res;
                    this.userSessionInfo[this.type].usedAmount += result.TotalTax;
                    this.updateBalanceAmount();
                    this.updateSession();
                    console.log('AMOUNT' + this.userSessionInfo[this.type].usedAmount, 'TAXES' + result.TotalTax);
                }, err => {
                    //  swal('Oops', 'Error fetching taxes', 'error');
                });
        }

        this.updateBalanceAmount();
        this.updateSession();
    }

    updateBalanceAmount() {
        if (Number.isNaN(Number.parseInt(this.userSessionInfo[this.type].budgetAmount))) {
            this.userSessionInfo[this.type].balanceAmount = '';
        } else if (this.userSessionInfo[this.type].budgetAmount !== '0' && this.userSessionInfo[this.type].budgetAmount !== 0) {
            this.userSessionInfo[this.type].balanceAmount = (this.userSessionInfo[this.type].budgetAmount
                - this.userSessionInfo[this.type].usedAmount);
            this.userSessionInfo[this.type].balanceAmount
                = this.userSessionInfo[this.type].balanceAmount < 0 ? 0 : this.userSessionInfo[this.type].balanceAmount;
            if (this.userSessionInfo[this.type].budgetAmount - this.userSessionInfo[this.type].usedAmount <= 0) {
                // swal('Oops', 'You have exceeded your budget!!', 'warning');
            }
        }
        this.updateSession();
    }



}
