/* This component added to handle large HTML content of FAQ's. 
Otherwise this is just static component can be merged in footer-static component. */
import { Component, OnInit, Inject } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { NavigatePathService } from '../../services/navigate-path.service';
declare function initAccord(): any;
declare function initDocument(): any;
declare var $: any;

@Component({
  selector: 'app-document-checklist',
  templateUrl: './documents-checklist.component.html',
  styleUrls: ['./documents-checklist.component.css']
})
export class DocumentChecklistComponent implements OnInit {
  public innerRequireSidebar: string = '0';
  public visaDetails: any = {
    currentLocation: {}
  };
  public nextLink: any = '/visa/submission-mode';
  public _primaryComp: any;
  constructor(private meta: Meta, private navUrl: NavigatePathService, private router: Router, @Inject(DOCUMENT) private _document: any) {
    this._primaryComp = '/' + navUrl.navUrl();
    if (SessionHelper.getSession('visaDetails')) {
      this.visaDetails = JSON.parse(SessionHelper.getSession('visaDetails'));
    } else {
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    if(!this.visaDetails.visaScreen.traveller[0].visaType){
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    this._document.title = "Visa documents checklist and application procedure";
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex. Buy insurance and apply for visa.' });
    this.meta.addTag({ name: 'keywords', content: 'Visa, documents, checklist, application, procedure' });
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    $('body').addClass('visa');
    // initAccord();
    setTimeout(function () {
      initDocument();
    }, 5);
  }

  ngOnDestroy() {
    $('body').removeClass('visa');
  }

  parentSaveSession(event) {
    this.visaDetails = event;
  }
}
