import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VisaOverviewComponent } from './visa-overview/visa-overview.component';
import { SelectModule } from 'ng-select';
import {DpDatePickerModule} from 'ng2-date-picker';
import { PipesModule } from '../pipes/pipes.module';
import { MasterService } from '../services/master.services';
import { AuthService } from '../services/auth.service';
import { AuthGuardService as AuthGuard } from '../services/auth-guard.service';
import { FailComponent } from '../forex-common/fail/fail.component';
import { CanDeactivateGuard } from '../services/can-deactivate-guard.service';
import { TimerService } from '../services/timer.service';
import { PasswordStrengthBarModule } from 'ng2-password-strength-bar';
import {DocumentChecklistComponent} from './documents-checklist/documents-checklist.component';
import { VisaSummaryComponent } from './visa-summary/visa-summary.component';
import {SubmissionModeComponent} from './submission-mode/submission-mode.component';
import {VisaReviewComponent} from './visa-review/visa-review.component';
import {VisaLoginComponent} from './visa-login/visa-login.component';
import {VisaCreateAccountComponent} from './visa-create-account/visa-create-account.component';
import {CheckoutTravelersComponent} from './checkout-travelers/checkout-travelers.component';
import {CheckoutPaymentComponent} from './checkout-payment/checkout-payment.component';
import {VisaOrderConfirmationComponent} from './order-confirmation/order-confirmation.component';
const routes: Routes = [
  {
    path: '', children: [
      { path: '', component: VisaOverviewComponent, canDeactivate: [CanDeactivateGuard] },
      { path: 'documents-checklist', component: DocumentChecklistComponent },
      { path: 'submission-mode', component: SubmissionModeComponent },
      { path: 'visa-review', component: VisaReviewComponent },
      { path: 'visa-login', component: VisaLoginComponent },
      { path: 'create-account', component: VisaCreateAccountComponent },
      { path: 'checkout-travelers', component: CheckoutTravelersComponent },
      { path: 'checkout-payment', component: CheckoutPaymentComponent },
      { path: 'order-confirmation', component: VisaOrderConfirmationComponent },
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    PipesModule,
    SelectModule,
    DpDatePickerModule,
    PasswordStrengthBarModule
  ],
  declarations: [
    VisaOverviewComponent,
    DocumentChecklistComponent,
    VisaSummaryComponent,
    SubmissionModeComponent,
    VisaReviewComponent,
    VisaLoginComponent,
    VisaCreateAccountComponent,
    CheckoutTravelersComponent,
    CheckoutPaymentComponent,
    VisaOrderConfirmationComponent
  ],
  providers: [MasterService, AuthGuard, AuthService, CanDeactivateGuard, TimerService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VisaModule { }
