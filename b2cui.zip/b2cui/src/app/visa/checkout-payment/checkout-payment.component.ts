/* This component added to handle large HTML content of FAQ's. 
Otherwise this is just static component can be merged in footer-static component. */
import { Component, OnInit, Inject } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { NavigatePathService } from '../../services/navigate-path.service';
declare function initAccord(): any;
declare function initDocument(): any;
declare var $: any;
declare var Snackbar: any;
declare function visaTabs(): any;
declare function initSubItinerary(): any;
@Component({
  selector: 'app-checkout-payment',
  templateUrl: './checkout-payment.component.html',
  styleUrls: ['./checkout-payment.component.css']
})
export class CheckoutPaymentComponent implements OnInit {
  public innerRequireSidebar: string = '0';
  public forgotPasswordFlag: any = false;
  public nationalityOptions: any; // : GenericEntity[];
  public havePassword: any = false;
  public configDob: any;
  public todaysDate: any;
  public visaDetails: any = {
    currentLocation: {}
  };
  public invalidsubmitted: any;
  public dateOfBirth: any;
  public configsMin: any = [];
  public configsMax: any = [];
  public registrationInfo: any;
  public nextLink: any = '/visa/order-confirmation';
  public _primaryComp: any;
  public setCouponCode:any;
  public termsAcceptance:any;
  public checkEmail:any;
  public setPaybackAccount:any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this._primaryComp = '/' + navUrl.navUrl();
    if (SessionHelper.getSession('visaDetails')) {
      this.visaDetails = JSON.parse(SessionHelper.getSession('visaDetails'));
    } else {
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    if (!this.visaDetails.visaScreen.traveller[0].visaType) {
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    if (SessionHelper.getSession('newRegistrationInfo')) {
      this.registrationInfo = JSON.parse(SessionHelper.getSession('newRegistrationInfo'));
    } else {
      this.registrationInfo = this.visaDetails.visaScreen.traveller[0].registrationInfo;
    }
    this.setDateConfig(this.registrationInfo.dateOfIssue, this.registrationInfo.expiryDate);
    this._document.title = "Visa documents checklist and application procedure";
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex. Buy insurance and apply for visa.' });
    this.meta.addTag({ name: 'keywords', content: 'Visa, documents, checklist, application, procedure' });
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    $('body').addClass('visa');
    this.masterService.getNationalityList()
      .subscribe(data => {
        this.nationalityOptions = data;
      });
    // initAccord();
    setTimeout(function () {
      initDocument();
      // visaTabs();
      // initSubItinerary();
    }, 5);
  }

  ngOnDestroy() {
    $('body').removeClass('visa');
  }

  parentSaveSession(event) {
    this.visaDetails = event;
  }

  havePasswordChecked() {

  }

  callPinCodeService(event, type) {
    const pinCode = event.target.value;

    // this.registrationInfo[type]['city'] = '##Service offline##';
    // this.registrationInfo[type]['state'] = '##Service offline##';
    // this.registrationInfo[type]['area'] = '##Service offline##';

    this.masterService.getPinCodeDetails(pinCode)
      .subscribe(data => {
        const Retdata: any = data;
        if (Retdata.Status === 'Success') {
          this.registrationInfo[type]['city'] = Retdata.PostOffice[0].District;
          this.registrationInfo[type]['state'] = Retdata.PostOffice[0].State;
          this.registrationInfo[type]['area'] = Retdata.PostOffice[0].Name;
        } else {
          this.registrationInfo[type]['city'] = '';
          this.registrationInfo[type]['state'] = '';
          this.registrationInfo[type]['area'] = '';
        }
      });
  }

  dataChangeBirth(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.dateOfBirth = event;
    }
  }

  forgotPassword() {
    this.forgotPasswordFlag = true;
  }

  setDateConfig(startDate, endDate) {
    let maxDate = '',
      minDate = '';
    this.todaysDate = this.masterService.getTodaysDate();
    minDate = this.todaysDate;
    maxDate = this.todaysDate;
    this.configDob = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    if (startDate !== '') {
      minDate = startDate;
    }
    if (endDate !== '') {
      maxDate = endDate;
    }
    this.configsMin = {
      format: 'DD-MM-YYYY',
      min: minDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    }
    this.configsMax = {
      format: 'DD-MM-YYYY',
      max: maxDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    }
  }


  dataChangeStart(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.registrationInfo.dateOfIssue = event;
      SessionHelper.setSession('newRegistrationInfo', JSON.stringify(this.registrationInfo));
      this.configsMin = {
        format: 'DD-MM-YYYY',
        min: this.masterService.addDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      }
    }
  }

  dataChangeEnd(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.registrationInfo.expiryDate = event;
      SessionHelper.setSession('newRegistrationInfo', JSON.stringify(this.registrationInfo));
      this.configsMax = {
        format: 'DD-MM-YYYY',
        max: this.masterService.substractDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      }
    }
  }

  // SUBMIT FUNCTION TO REDIRECT PAGE
  submitFunction(userForm: NgForm, event: Event): void {
    event.preventDefault();
    this.invalidsubmitted = userForm.invalid;
    if (userForm.valid) {  
      this.visaDetails.visaScreen.traveller[0].registrationInfo = this.registrationInfo; 
      SessionHelper.setSession('visaDetails', JSON.stringify(this.visaDetails));
      // SessionHelper.removeSession('newRegistrationInfo');
    } else {
      Snackbar.show({
        text: 'Please fill the mandatory fields highlighted.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }
  }

  updateSession() {
    SessionHelper.setSession('newRegistrationInfo', JSON.stringify(this.registrationInfo));
  }

  updateSession1(registrationInfo, value, index){
    setTimeout(() => {      
      registrationInfo[index] = value.split(/\b/g).map(word => this.titleCaseWord(word)).join('');
    }, 10);    
  }

  titleCaseWord(word: string) {
    if (!word) return word;
    return word[0].toUpperCase() + word.substr(1).toLowerCase();
  }
}
