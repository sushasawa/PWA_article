/* This component added to handle large HTML content of FAQ's. 
Otherwise this is just static component can be merged in footer-static component. */
import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Meta } from '@angular/platform-browser';
import * as sha from 'sha.js';
import { DOCUMENT } from '@angular/platform-browser';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { NavigatePathService } from '../../services/navigate-path.service';
declare function initAccord(): any;
declare function initDocument(): any;
declare var $: any;
declare function visaTabs(): any;
declare function initSubItinerary(): any;
declare var Snackbar: any;
@Component({
  selector: 'app-visa-login',
  templateUrl: './visa-login.component.html',
  styleUrls: ['./visa-login.component.css']
})
export class VisaLoginComponent implements OnInit {
  public innerRequireSidebar: string = '0';
  public forgotPasswordFlag: any = false;
  public havePassword: any = true;
  public configDob: any;
  public todaysDate: any;
  public visaDetails: any = {
    currentLocation: {}
  };
  public dateOfBirth:any;
  public payload: any = {
    upassword: '',
    uname: ''
  };
  public nextLink: any = '/visa';
  public _primaryComp: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this._primaryComp = '/' + navUrl.navUrl();
    if (SessionHelper.getSession('visaDetails')) {
      this.visaDetails = JSON.parse(SessionHelper.getSession('visaDetails'));
    } else {
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    if(!this.visaDetails.visaScreen.traveller[0].visaType){
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    this.setDateConfig();
    this._document.title = "Visa documents checklist and application procedure";
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex. Buy insurance and apply for visa.' });
    this.meta.addTag({ name: 'keywords', content: 'Visa, documents, checklist, application, procedure' });
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    $('body').addClass('visa');
    // initAccord();
    setTimeout(function () {
      initDocument();
      // visaTabs();
      // initSubItinerary();
    }, 5);
  }

  ngOnDestroy() {
    $('body').removeClass('visa');
  }

  parentSaveSession(event) {
    this.visaDetails = event;
  }

  havePasswordChecked() {

  }

  dataChangeBirth(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.dateOfBirth = event;
    }
  }

  forgotPassword() {
    this.forgotPasswordFlag = true;
  }

  setDateConfig() {
    this.todaysDate = this.masterService.getTodaysDate();
    this.configDob = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }

  proceedClicked() {
    this.router.navigateByUrl(this._primaryComp + '/visa/create-account');
  }

  loginClicked() {
    if (!this.validateDetails()) {
      Snackbar.show({
        text: 'Please enter your credential.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    const payload: any = {};
    let password = this.payload.upassword;
    password = sha('sha256').update(password, 'utf8').digest('hex');
    payload.upassword = password;
    payload.uname = this.payload.uname;


    this.router.navigateByUrl(this._primaryComp + '/visa/checkout-travelers');
  }

  validateDetails(){
    if(!this.payload.uname || !this.payload.upassword){
      return false;
    }
    return true;
  }
}
