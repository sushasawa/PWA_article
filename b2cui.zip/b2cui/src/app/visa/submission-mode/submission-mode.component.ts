/* This component added to handle large HTML content of FAQ's. 
Otherwise this is just static component can be merged in footer-static component. */
import { Component, OnInit, Inject } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { Router, ActivatedRoute } from '@angular/router';
import { NavigatePathService } from '../../services/navigate-path.service';
declare function initAccord(): any;
declare function initDocument(): any;
declare var $: any;
declare function visaTabs(): any;
declare function initSubItinerary(): any;
@Component({
  selector: 'app-submission-mode',
  templateUrl: './submission-mode.component.html',
  styleUrls: ['./submission-mode.component.css']
})
export class SubmissionModeComponent implements OnInit {
  public branchOptions: any;
  public BranchDetails: any;
  public BranchDetailsEnable: any;
  public branchPickupDetails: any;
  public branchOptions2: any;
  public BranchDetails2: any;
  public BranchDetailsEnable2: any;
  public branchPickupDetails2: any;
  public visaDetails: any = {
    currentLocation: {}
  };
  public cityOptions: any;
  public cityOptions2: any;
  public userCity: any;
  public userBranch: any;
  public userCity2: any;
  public userBranch2: any;
  public nextLink: any = '/visa/visa-review';
  public _primaryComp: any;
  public setSMSService:any;
  public invalidsubmitted:any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this._primaryComp = '/' + navUrl.navUrl();
    if (SessionHelper.getSession('visaDetails')) {
      this.visaDetails = JSON.parse(SessionHelper.getSession('visaDetails'));
    } else {
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    if(!this.visaDetails.visaScreen.traveller[0].visaType){
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    this._document.title = "Visa documents checklist and application procedure";
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex. Buy insurance and apply for visa.' });
    this.meta.addTag({ name: 'keywords', content: 'Visa, documents, checklist, application, procedure' });
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    $('body').addClass('visa');
    // initAccord();
    
    this.masterService.getBranchList('mumbai')
      .subscribe(data => {
        this.branchOptions = data;
      });

    this.masterService.getCityList()
      .subscribe(data => {
        this.cityOptions = data;
      });
    this.masterService.getBranchList('mumbai')
      .subscribe(data => {
        this.branchOptions2 = data;
      });

    this.masterService.getCityList()
      .subscribe(data => {
        this.cityOptions2 = data;
        setTimeout(function () {
          initDocument();
          visaTabs();
          // initSubItinerary();
        }, 50);
      });
  }

  ngOnDestroy() {
    $('body').removeClass('visa');
  }

  parentSaveSession(event) {
    this.visaDetails = event;
  }

  updateCity(newValue: string) {
    this.masterService.getBranchList(newValue.split('#')[1])
    .subscribe(data => {              
      this.branchOptions = data; 
    });      
  }

  updateBranch(newValue: number) {
    this.masterService.getBranchDetails(newValue)
      .subscribe(data => {
        this.BranchDetails = data;
        this.BranchDetailsEnable = true;
        this.branchPickupDetails = this.BranchDetails[0].branchPickupDetails;
      });
  }

  updateCity2(newValue: string) {
    this.masterService.getBranchList(newValue.split('#')[1])
    .subscribe(data => {              
      this.branchOptions2 = data; 
    });      
  }

  updateBranch2(newValue: number) {
    this.masterService.getBranchDetails(newValue)
      .subscribe(data => {
        this.BranchDetails2 = data;
        this.BranchDetailsEnable2 = true;
        this.branchPickupDetails2 = this.BranchDetails2[0].branchPickupDetails;
      });
  }

}
