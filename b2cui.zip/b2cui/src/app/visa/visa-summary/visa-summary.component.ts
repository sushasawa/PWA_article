import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { Constants } from '../../helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { NavigatePathService } from '../../services/navigate-path.service';

declare function initDocument(): any;
declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-visa-summary',
  templateUrl: './visa-summary.component.html',
  styleUrls: ['./visa-summary.component.css']
})
export class VisaSummaryComponent implements OnInit {

  public userSessionInfo: any;
  public userSessionInfoSummary: any;
  public selectedTraveller: any;
  public purposeOptions: any;
  public destinationOptions: any;
  public currencyList: any;
  public currencyListCash: any;
  public charges: any;
  public currencyListTravellerCheque: any;
  public currencyListDemandDraft: any;
  public bankOptions = [];
  public currentTravellerIndex: number;
  public todaysDate: any;
  public dateOfTravelTime: any = 10;
  public configsMax: any = [];
  public visaTypes: any;
  public invalidsubmitted1: boolean;
  public smsCharges: any;
  public visaDetails: any = {
    currentLocation: {}
  };
  public _primaryComp: any;
  @Input() nextLink: string;
  @Input() newClass: boolean;
  @Input() keepContinue: boolean;
  @Input() disableEdit: boolean;
  // @Input() paymentScreen: boolean;
  @Output() saveSession: EventEmitter<any> = new EventEmitter<any>();
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router) {
    this._primaryComp = '/' + navUrl.navUrl();
    if (SessionHelper.getSession('visaDetails')) {
      this.visaDetails = JSON.parse(SessionHelper.getSession('visaDetails'));
    }
    this.smsCharges = this.masterService.getSmsServiceCharges();
    this.setDateConfig(this.visaDetails.visaScreen.traveller[0].travellingDetails.dateOfTravel);
    this.getDestinationList();
    this.setVisaType();
  }

  ngOnInit() {
    $('body').attr('id', '');
    setTimeout(function () {
      initDocument();
    }, 1);
    console.log(this.newClass);
  }

  editButtonClick() {
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#book-summary-popup'
        },
        type: 'inline'
      });
    }, 100);
  }

  updateCity($event) {
    if (this.visaDetails.visaScreen.currentLocation) {
      this.visaDetails.visaScreen.currentLocation.city = $event;
    }
  }

  getCurrentLocation() {
    if (!this.visaDetails.visaScreen.currentLocation.city) {
      this.masterService.getCurrentLocation()
        .subscribe(data => {
          this.visaDetails.visaScreen.currentLocation = data;
        }, err => {
          Snackbar.show({
            text: 'Unable to detect current location!',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        });
    }
  }

  dataChangeStart(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.visaDetails.visaScreen.traveller[0].travellingDetails.dateOfTravel = event;
      SessionHelper.setSession('visaDetails', JSON.stringify(this.visaDetails));
    }
  }

  setVisaType() {
    this.visaTypes = [
      { "value": "Visa Tourism - 6 Months Multiple Entries", "label": "Visa Tourism - 6 Months Multiple Entries", "Id": 5, "Name": "Visa Tourism - 6 Months Multiple Entries" },
      { "value": "Visa Tourism - Long Term, valid upto 2 years", "label": "Visa Tourism - Long Term, valid upto 2 years", "Id": 6, "Name": "Visa Tourism - Long Term, valid upto 2 years" },
      { "value": "Visa Tourism - Long Term, valid upto 5 years", "label": "Visa Tourism - Long Term, valid upto 5 years", "Id": 7, "Name": "Visa Tourism - Long Term, valid upto 5 years" },
      { "value": "Visa Tourism - Long Term, valid upto 10 years", "label": "Visa Tourism - Long Term, valid upto 10 years", "Id": 9, "Name": "Visa Tourism - Long Term, valid upto 10 years" }
    ];
  }

  updateVisaType($event) {
    console.log($event);
  }

  getDestinationList() {
    if (!sessionStorage.getItem('destinationList')) {
      this.masterService.getDestinationList()
        .subscribe(data => {
          this.destinationOptions = data;
          sessionStorage.setItem('destinationList', JSON.stringify(this.destinationOptions));
        }, err => {
          // swal('Oops...', 'Unable to fetch destination list!', 'error');
          Snackbar.show({
            text: 'Unable to fetch destination list!',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        });
    } else {
      this.destinationOptions = JSON.parse(sessionStorage.getItem('destinationList'));
    }
  }

  updateDestination(newValue: number) {
    this.visaDetails.visaScreen.destination = newValue;
  }

  updateSession() {
    SessionHelper.setSession('visaDetails', JSON.stringify(this.visaDetails));
  }

  setDateConfig(startDate) {
    let maxDate = '',
      minDate = '';
    this.todaysDate = this.masterService.getTodaysDate();
    if (startDate !== '') {
      minDate = startDate;
    } else {
      minDate = this.todaysDate;
    }
    this.configsMax = {
      format: 'DD-MM-YYYY',
      // max: this.masterService.addDateMoment(this.todaysDate, 60, 'days'),
      min: this.masterService.addDateMoment(this.todaysDate, this.dateOfTravelTime, 'days'),
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }

  saveDetails() {
    if (this.validateDetails()) {
      this.updateSession();
      this.saveSession.emit(this.visaDetails);
      this.closePopup();
    }
  }

  closePopup() {
    $.magnificPopup.close();
  }

  validateDetails() {
    let result = true;
    switch (true) {
      case (!this.visaDetails.visaScreen.currentLocation.city):
        Snackbar.show({
          text: 'Please select provide city',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        this.invalidsubmitted1 = true;
        result = false;
        break;
      case (!this.visaDetails.visaScreen.destination):
        Snackbar.show({
          text: 'Please select destination',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        this.invalidsubmitted1 = true;
        result = false;
        break;
      case (!this.visaDetails.visaScreen.traveller[0].visaType):
        Snackbar.show({
          text: 'Please select visa type.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        this.invalidsubmitted1 = true;
        result = false;
        break;
      case (!this.visaDetails.visaScreen.traveller[0].travellingDetails.dateOfTravel):
        Snackbar.show({
          text: 'Please select date of travel',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        this.invalidsubmitted1 = true;
        result = false;
        break;
    }
    return result;
  }
}


