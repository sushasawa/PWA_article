/* This component added to handle large HTML content of FAQ's. 
Otherwise this is just static component can be merged in footer-static component. */
import { Component, OnInit, Inject } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { NavigatePathService } from '../../services/navigate-path.service';
declare var Snackbar: any;
declare function initAccord(): any;
declare function initDocument(): any;
declare var $: any;
declare function visaTabs(): any;
declare function initSubItinerary(): any;
@Component({
  selector: 'app-visa-create-account',
  templateUrl: './visa-create-account.component.html',
  styleUrls: ['./visa-create-account.component.css']
})
export class VisaCreateAccountComponent implements OnInit {
  public innerRequireSidebar: string = '0';
  public forgotPasswordFlag: any = false;
  public havePassword: any = false;
  public configDob: any;
  public todaysDate: any;
  public validPassword: any = false;
  public visaDetails: any = {
    currentLocation: {}
  };
  public termsAcceptance: any;
  public invalidsubmitted: any;
  public registrationInfo: any;
  public dateOfBirth:any;
  public nextLink: any = '/visa';
  public _primaryComp: any;
  public travellerIndex:any;
  public barLabel:any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this._primaryComp = '/' + navUrl.navUrl();
    if (SessionHelper.getSession('visaDetails')) {
      this.visaDetails = JSON.parse(SessionHelper.getSession('visaDetails'));
    } else {
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    if (!this.visaDetails.visaScreen.traveller[0].visaType) {
      this.router.navigateByUrl(this._primaryComp + '/visa');
    }
    if(SessionHelper.getSession('newRegistrationInfo')){
      this.registrationInfo = JSON.parse(SessionHelper.getSession('newRegistrationInfo'));
    } else {
      this.registrationInfo = this.setRegistrationsJSON();
    }
    this.registrationInfo.password = '';
    this.registrationInfo.confirmPassword = '';
    this.setDateConfig();
    this._document.title = "Visa documents checklist and application procedure";
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex. Buy insurance and apply for visa.' });
    this.meta.addTag({ name: 'keywords', content: 'Visa, documents, checklist, application, procedure' });
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    $('body').addClass('visa');
    // initAccord();
    setTimeout(function () {
      initDocument();
      // visaTabs();
      // initSubItinerary();
    }, 5);
    if (this.registrationInfo.contactDetails.emailId) {
      this.checkEmail({ target: { value: this.registrationInfo.contactDetails.emailId } });
    }
  }

  ngOnDestroy() {
    $('body').removeClass('visa');
  }

  parentSaveSession(event) {
    this.visaDetails = event;
  }

  havePasswordChecked() {

  }

  dataChangeBirth(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.registrationInfo.dateOfBirth.value = event;
      this.updateSession();
    }
  }

  forgotPassword() {
    this.forgotPasswordFlag = true;
  }

  setDateConfig() {
    this.todaysDate = this.masterService.getTodaysDate();
    this.configDob = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }

  checkEmail(event) {
    if(!event.target.value){
      $('.confirmEmailId > div > ul > li').css('background-color', 'red');
    } else {
      this.masterService.getEmailValidation(event.target.value)
      .subscribe(data => {
        const retData: any = data;
        if (retData.message.status === 'emailNotExists') {        
          $('.confirmEmailId > div > ul > li').css('background-color', 'rgb(0, 255, 0)');
        }else if (retData.message.status === 'emailExists') {
          this.registrationInfo.contactDetails.emailId = '';
          $('.confirmEmailId > div > ul > li').css('background-color', 'red');
          Snackbar.show({
            text: 'This email ID already exists, please log-in with your email ID.',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        }
        // console.log(retData.message.status);
      });
    }    
  }

  confirmPassword(event) {
    if (event.target.value === this.registrationInfo.password) {
       $('.confirmPassword > div > ul > li').css('background-color', 'rgb(0, 255, 0)');
    }else {
      $('.confirmPassword > div > ul > li').css('background-color', 'red');
    }
  }

  updateSession() {
    SessionHelper.setSession('newRegistrationInfo', JSON.stringify(this.registrationInfo));
  }

  updateSession1(registrationInfo, value, index) {
    setTimeout(() => {
      registrationInfo[index] = value.split(/\b/g).map(word => this.titleCaseWord(word)).join('');
    }, 10);
  }

  titleCaseWord(word: string) {
    if (!word) return word;
    return word[0].toUpperCase() + word.substr(1).toLowerCase();
  }

  termsConditions() {
    $.magnificPopup.close();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#terms-conditions'
        },
        type: 'inline'
      });
    }, 100);
  }

    // SUBMIT FUNCTION TO REDIRECT PAGE
  submitFunction(userForm: NgForm, event: Event): void {
    event.preventDefault();
    this.invalidsubmitted = userForm.invalid;
    if (userForm.valid) {
      this.visaDetails.visaScreen.traveller[0].registrationInfo = this.registrationInfo;
      SessionHelper.setSession('visaDetails', JSON.stringify(this.visaDetails));
      SessionHelper.removeSession('newRegistrationInfo');
      // this.router.navigateByUrl(this._primaryComp + this.nextLink);
    } else {
      Snackbar.show({
        text: 'Please fill the mandatory fields highlighted.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }
  }

  checkPassword($event) {
    let textMsg = '';
  }

  setRegistrationsJSON() {
    return {
      "userId": "",
      "invoiceNo": null,
      "firstName": {
        "value": ""
      },
      "middleName": "",
      "lastName": "",
      "dateOfBirth": {
        "value": ""
      },
      "adharCardNo": {
        "value": ""
      },
      "gender": {
        "value": ""
      },
      "nationality": "",
      "mothersMaidenName": {
        "value": ""
      },
      "PAN": {
        "value": ""
      },
      "passportNumber": "",
      "ParentId": true,
      "dateOfIssue": "",
      "placeOfIssue": "",
      "expiryDate": "",
      "address": "101 5A Galaxy apartment",
      "isPassportAddressAsAdhar": "yes",
      "adharAddress": {
        "flatNumber": "",
        "buildingName": "",
        "streetName": "",
        "landmark": "",
        "area": "",
        "city": "",
        "state": "",
        "pincode": ""
      },
      "passportAddress": {
        "flatNumber": "",
        "buildingName": "",
        "streetName": "",
        "landmark": "",
        "area": "",
        "city": "",
        "state": "",
        "pincode": ""
      },
      "currentAddressAs": "asPerAdhar",
      "otherAddress": {
        "flatNumber": "",
        "buildingName": "",
        "streetName": "",
        "landmark": "",
        "area": "",
        "city": "",
        "state": "",
        "pincode": ""
      },
      "contactDetails": {
        "mobileNo": "",
        "emailId": ""
      },
      "alternateContactDetails": {
        "countryCode": "",
        "mobileNo": "",
        "countryCode2": "",
        "cityCode": "",
        "telephoneNo": "",
        "emailId": ""
      },
      "officeAddress": {
        "designation": "",
        "conpanyName": "",
        "companyDivision": "",
        "flatNumber": "",
        "building": "",
        "streetName": "",
        "landmark": "",
        "area": "",
        "city": "",
        "state": "",
        "pincode": ""
      },
      "officeContactDetails": {
        "countryCode": "",
        "telephoneNumber": "",
        "officeExtension": ""
      },
      "password": "",
      "confirmPassword": ""
    }
  }
}
