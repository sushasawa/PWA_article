import { Component, OnInit, Inject, Input, OnChanges } from '@angular/core';
import { MasterService } from '../../app/services/master.services';
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SideBarComponent implements OnInit , OnChanges {
  public selectedSideBtn: any = '';
  public tollFreeNumber: any;
  @Input() pageChanged: any;
  constructor(private masterService: MasterService) {
this.tollFreeNumber = this.masterService.gettollFreeContact();
  }

  ngOnInit() { }

  setPopup(btnName) {
    this.selectedSideBtn = btnName;
  }

  ngOnChanges() {
    if (this.pageChanged === true) {
      this.hideAllPopup();
    }
  }

  hideAllPopup() {
    this.selectedSideBtn = '';
  }
}
