import { Component, Input, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { BulkExchangeRateService } from './../../services/bulk-exchange-rate.service';
import { MasterService } from '../../services/master.services';
import { Constants } from '../../helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;
declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-send-summary',
  templateUrl: './send-summary.component.html',
  styleUrls: ['./send-summary.component.css']
})
export class SendSummaryComponent implements OnInit , OnDestroy {

  public userSessionInfo: any;
  public userSessionInfoSummary: any;
  public selectedTraveller: any;
  public purposeOptions: any;
  public destinationOptions: any;
  public currencyList: any;
  public bankOptions = [];
  public charges: any;
  public Bank_Correspondent_Bank_Charges: any = 0;
  public Bank_Correspondent_Bank_Charge: any = 0;
  public TT_Charges: any = 0;
  public currentTravellerIndex: number;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public _primaryComp: any;
  public correspondentCharges: any;
  @Input() nextLink: string;
  @Input() disableEdit: boolean;
  @Input() paymentScreen: boolean;
  @Output() saveSession: EventEmitter<any> = new EventEmitter<any>();
  _BulkEvent: any;
  getChargesSub: any;
  getTaxes: any;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _BulkExchangeRateService: BulkExchangeRateService) {
    this._primaryComp = '/' + navUrl.navUrl();
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSend'));
    const destination = this.userSessionInfo.sendMoneyScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(1, destination)
      .subscribe(data => {
        this.currencyList = data;
      });
    this.correspondentCharges = this.userSessionInfo.sendMoneyScreen.bankChargesAdded;
    console.log(this.correspondentCharges);
  }

  ngOnInit() {
    this.userSessionInfoSummary = this.userSessionInfo;
    this.getCharges();
    // FOR PURPOSE LIST  @precessId values :
    // 1	Buy Forex
    // 2	Sell Forex
    // 3	Reload Card
    // 4	Send Money Abroad
    this.masterService.getPurposeList(4)
      .subscribe(data => {
        this.purposeOptions = data;
      });
    this.masterService.getDestinationList()
      .subscribe(data => {
        this.destinationOptions = data;
      });

    this.setCurrentTraveller(0);

    setTimeout(function () {
      initDocument();
    }, 1);

  }
  getLatestRate() {
    if (this.paymentScreen) {
      this._BulkExchangeRateService.getBulkExchangeRate(this.userSessionInfo, 'CLICK');
      this._BulkEvent =   this._BulkExchangeRateService.emitSession.subscribe((session) => {
        this.userSessionInfo = session;
        this.updateSession();
      });
     }else {
      this.updateSummaryUsedAmount();
    }
  }
  setCurrentTraveller(index: number) {
    this.selectedTraveller = this.userSessionInfo.sendMoneyScreen.traveller[index];
    this.currentTravellerIndex = index;
  }

  updateSession() {
    $.magnificPopup.close();
    SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfo));
    this.userSessionInfoSummary = this.userSessionInfo;
    this.updateSummaryUsedAmount();
    // this.saveSession.emit(this.userSessionInfoSummary);
  }
  updateMainSession() {
    SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfo));
  }
  updateSessionFromDeliveryMode(deliveryInfo) {
    this.userSessionInfo.sendMoneyScreen.deliveryInfo = deliveryInfo;
    this.updateSession();
  }

  updateCurrencyCode(prepaidDetailIndex: number, newValue: string) {
    console.log(this.currentTravellerIndex);
    this.userSessionInfo.sendMoneyScreen.traveller[this.currentTravellerIndex]
      .prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.sendMoneyScreen.branch, 'prepaid')
      .subscribe(data => {
        this.userSessionInfo.sendMoneyScreen.traveller[this.currentTravellerIndex]
          .prepaidCardDetails[prepaidDetailIndex].exchangeRate = data;
      });
  }

  updateValue(newValue, index) {
    if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    this.userSessionInfo.sendMoneyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index].forexAmount = parseFloat(newValue);
    this.updateUsedAmount();
  }

  getCharges() {
    // tslint:disable-next-line:max-line-length
    this.Bank_Correspondent_Bank_Charge = this.correspondentCharges ? this.userSessionInfoSummary.ddRateBuy * this.masterService.getBankCorrespondentCharges() : 0;
    this.getChargesSub =   this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.charges = Charges;
      this.getLatestRate();
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  updateUsedAmount() {
    let travellerTotal = 0;
    this.userSessionInfo.sendMoneyScreen.traveller.forEach(traveller => {
      let currentTravellerTotal = 0;
      traveller.prepaidCardDetails.forEach(element => {
        if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
          currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
        }
      });
      travellerTotal += currentTravellerTotal;
      traveller.usedAmount = currentTravellerTotal;
    });

    this.userSessionInfo.sendMoneyScreen.usedAmount = travellerTotal
      + this.userSessionInfo.sendMoneyScreen.deliveryInfo.rate * this.userSessionInfo.sendMoneyScreen.traveller.length;
    this.updateBalanceAmount();
    this.updateMainSession();
  }

  updateSummaryUsedAmount() {
    let travellerTotal = 0;
    this.userSessionInfoSummary.sendMoneyScreen.usedAmount = 0;
    this.userSessionInfoSummary.sendMoneyScreen.taxData = {
      'CGST': 0,
      'SGST': 0,
      'IGST': 0
    };
    this.serviceCharge = 0;
    this.Bank_Correspondent_Bank_Charges = 0;
    this.TT_Charges = 0;
    let mastercal = 0;
    let CGST = 0;
    let SGST = 0;
    let IGST = 0;
    // tslint:disable-next-line:prefer-const
    let travellerCount = this.userSessionInfoSummary.sendMoneyScreen.traveller.length, currentCount = 0;
    this.userSessionInfoSummary.sendMoneyScreen.traveller.forEach(traveller => {
      let charges = 0;
      let currentTravellerTotal = 0;
      let currentTravellerAmount = 0;
      traveller.prepaidCardDetails.forEach(element => {
        if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
          currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
        }
      });
      travellerTotal += currentTravellerTotal;
      // tslint:disable-next-line:max-line-length
      currentTravellerAmount += currentTravellerTotal + this.charges.response.serviceCharge + this.Bank_Correspondent_Bank_Charge + this.charges.response.TT_Charges + Number.parseInt(this.userSessionInfoSummary.sendMoneyScreen.deliveryInfo.rate);
      this.serviceCharge += this.charges.response.serviceCharge;
      this.Bank_Correspondent_Bank_Charges += this.Bank_Correspondent_Bank_Charge;
      this.TT_Charges += this.charges.response.TT_Charges;
      charges += this.charges.response.serviceCharge + this.Bank_Correspondent_Bank_Charge + this.charges.response.TT_Charges;
      this.getTaxes =   this.masterService.getTaxes(currentTravellerAmount).subscribe((data) => {
        const result: any = data;
        currentCount++;
        currentTravellerAmount += result.TotalTax;
        CGST += result.CGST;
        SGST += result.SGST;
        IGST += result.IGST;
        // charges += result.TotalTax;
        this.userSessionInfoSummary.sendMoneyScreen.taxData.CGST = CGST;
        this.userSessionInfoSummary.sendMoneyScreen.taxData.SGST = SGST;
        this.userSessionInfoSummary.sendMoneyScreen.taxData.IGST = IGST;
        traveller.Charges = charges;
        mastercal += currentTravellerAmount;
        this.userSessionInfoSummary.sendMoneyScreen.usedAmount = mastercal;
        if (currentCount === travellerCount && this.paymentScreen) {
          this.userSessionInfo.sendMoneyScreen.billingAmount = this.userSessionInfo.sendMoneyScreen.usedAmount;
          this.userSessionInfoSummary.sendMoneyScreen.usedAmount = Math.round(this.userSessionInfoSummary.sendMoneyScreen.usedAmount);
          this.saveSession.emit(this.userSessionInfoSummary);
        }
        currentTravellerAmount = 0;
        SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfoSummary));
      });
      traveller.usedAmount = currentTravellerTotal;

    });

    //
    // this.userSessionInfoSummary.sendMoneyScreen.usedAmount = travellerTotal
    //   + this.userSessionInfoSummary.sendMoneyScreen.deliveryInfo.rate * this.userSessionInfoSummary.sendMoneyScreen.traveller.length;

    // if (this.userSessionInfoSummary.sendMoneyScreen.usedAmount !== 0) {
    //   this.masterService.getTaxes(this.userSessionInfoSummary.sendMoneyScreen.usedAmount)
    //     .subscribe(res => {
    //       this.userSessionInfoSummary.sendMoneyScreen.taxData = res;
    //       this.userSessionInfoSummary.sendMoneyScreen.usedAmount += this.userSessionInfoSummary.sendMoneyScreen.taxData.TotalTax;
    //       SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfoSummary));
    //     }, err => {
    //       console.log(err);
    //     });
    // }
  }

  updateBalanceAmount() {
    this.userSessionInfo.sendMoneyScreen.balanceAmount =
      (this.userSessionInfo.sendMoneyScreen.budgetAmount - this.userSessionInfo.sendMoneyScreen.usedAmount).toString();
  }

  submitAndRedirect() {
    this.masterService.RuleTest(this.userSessionInfoSummary)
      .subscribe(data => {
        const resData: any = JSON.parse(data);
        console.log(resData);
        if (resData.status === 1) {
          this.router.navigateByUrl(this._primaryComp + this.nextLink);
        } else {
          // swal('error', resData.message, 'error');
          Snackbar.show({
            text: resData.message,
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        }
      }, err => {
        console.log(err);
      });
  }

 ngOnDestroy() {
    if (this._BulkEvent) {
      this._BulkEvent.unsubscribe();
}
    if (this.getChargesSub) {
      this.getChargesSub.unsubscribe();
    }
    if (this.getTaxes) {
      this.getTaxes.unsubscribe();
    }
  }

}
