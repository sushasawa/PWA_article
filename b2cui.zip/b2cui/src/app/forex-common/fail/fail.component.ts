import { Component, OnInit, Inject } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

@Component({
  selector: 'app-fail',
  templateUrl: './fail.component.html',
  styleUrls: ['./fail.component.css']
})
export class FailComponent implements OnInit {
  public _primaryComp: any;
  constructor(private meta: Meta, @Inject(DOCUMENT) private _document: any, private navUrl: NavigatePathService) { 
    this._document.title = 'Some failure occured';
    this._primaryComp = '/' + navUrl.navUrl();
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'Some failure occured'});
   }

  ngOnInit() {
  }

}
