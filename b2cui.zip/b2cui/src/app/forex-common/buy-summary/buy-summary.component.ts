import { BulkExchangeRateService } from './../../services/bulk-exchange-rate.service';
import { Component, Input, OnInit, Output, EventEmitter, OnDestroy, ChangeDetectionStrategy } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { Constants } from '../../helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { environment } from '../../../environments/environment';

declare function initDocument(): any;
declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-buy-summary',
  templateUrl: './buy-summary.component.html',
  styleUrls: ['./buy-summary.component.css']
})

export class BuySummaryComponent implements OnInit, OnDestroy {

  public userSessionInfo: any;
  public userSessionInfoSummary: any;
  public selectedTraveller: any;
  public purposeOptions: any;
  public destinationOptions: any;
  public currencyList: any;
  public currencyListCash: any;
  public charges: any;
  public currencyListTravellerCheque: any;
  public currencyListDemandDraft: any;
  public bankOptions = [];
  public currentTravellerIndex: number;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public _primaryComp: any;
  public _BulkEvent: any;
  public Promoter: any;
  public PromotionalData: any;
  @Input() nextLink: string;
  @Input() disableEdit: boolean;
  @Input() paymentScreen: boolean;
  @Output() saveSession: EventEmitter<any> = new EventEmitter<any>();
  billingAmount: any;
  getChargesSub: any;
  getTaxes: any;
  public defaultissuercode: any = environment.DEFAULT_ISSUER_CODE;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private router: Router, private navUrl: NavigatePathService, private _BulkExchangeRateService: BulkExchangeRateService) {
    console.log('SUMMARY COMPONENT LOADED');
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfo'));
    this._primaryComp = '/' + navUrl.navUrl();
    if (this.paymentScreen) {
      this.userSessionInfo.buyScreen.billingAmount = this.userSessionInfo.buyScreen.usedAmount;
      this.userSessionInfo.buyScreen.usedAmount = Math.round(this.userSessionInfo.buyScreen.usedAmount);
    }
    this.Promoter = SessionHelper.getSession('promotion');
    if(this.Promoter && SessionHelper.getSession('PromotionalData')){
      this.PromotionalData = JSON.parse(SessionHelper.getSession('PromotionalData'));
    }
    this.populateCashCurrency();
    this.populateDemandDraftCurrency();
    this.populatePrepaidCurrency();
    this.populateTravellersCurrency();
  }

  ngOnInit() {
    $('body').attr('id', '');
    
    
    // this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfo'));
    // this._BulkEvent.unsubscribe();
    this.userSessionInfoSummary = this.userSessionInfo;
    this.getCharges();
    // FOR PURPOSE LIST  @precessId values :
    // 1	Buy Forex
    // 2	Sell Forex
    // 3	Reload Card
    // 4	Send Money Abroad
    this.masterService.getPurposeList(1)
      .subscribe(data => {
        this.purposeOptions = data;
      });
    this.masterService.getDestinationList()
      .subscribe(data => {
        this.destinationOptions = data;
      });

    this.userSessionInfo.buyScreen.traveller.forEach(traveller => {
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.forEach((detail, index) => {
          if (this.Promoter && this.PromotionalData) {
            this.bankOptions[index] = this.PromotionalData.buyScreen.IssuerLists;
        } else {
          this.masterService.getBankList(detail.currencyCode)
            .subscribe(data => {
              this.bankOptions[index] = data;
              this.bankOptions[index].forEach(element => {
                element.Logo = Constants.serviceUrl + '/' + element.Logo;
              });
            });
          }
        });
      }


    });

    this.setCurrentTraveller(0);
    setTimeout(function () {
      initDocument();
    }, 1);
    // tslint:disable-next-line:max-line-length
    if (!this.userSessionInfo[this.userSessionInfo.type].billingAmount || this.numberTest(this.userSessionInfo[this.userSessionInfo.type].usedAmount, this.userSessionInfo[this.userSessionInfo.type].billingAmount)) {
      this.billingAmount = this.userSessionInfo[this.userSessionInfo.type].usedAmount;
      this.userSessionInfo[this.userSessionInfo.type].billingAmount = this.billingAmount;
    } else if (this.userSessionInfo[this.userSessionInfo.type].billingAmount) {
      this.billingAmount = this.userSessionInfo[this.userSessionInfo.type].billingAmount;
    }
  }

  getLatestRate() {
    if (this.paymentScreen) {
      this._BulkExchangeRateService.getBulkExchangeRate(this.userSessionInfo, 'CLICK');
       this._BulkEvent = this._BulkExchangeRateService.emitSession.subscribe((session) => {
        console.log('BULK RESPONSE');
        this.userSessionInfo = session;
        this.updateSession('this._BulkEvent');
      });
     }else {
       this.updateSummaryUsedAmount();
     }
  }
  numberTest(num, oldNumber) {
    const result = (num - Math.floor(num)) !== 0;
    if (result || num !== Math.round(oldNumber)) {
      return true;
    }
    return false;
  }
  setCurrentTraveller(index: number) {
    this.selectedTraveller = this.userSessionInfo.buyScreen.traveller[index];
    this.currentTravellerIndex = index;
  }

  updateSession(CALLER: any = 'NO CALLS') {
    console.log(CALLER);
    console.log('UPDATE SESSION WAS CALLED');
    $.magnificPopup.close();
    SessionHelper.setSession('userSessionInfo', JSON.stringify(this.userSessionInfo));
    this.userSessionInfoSummary = JSON.parse(SessionHelper.getSession('userSessionInfo'));
    this.updateSummaryUsedAmount(CALLER + 'THROUGH UPDATE SESSION');
    // this.saveSession.emit(this.userSessionInfoSummary);
  }

  updateSessionFromDeliveryMode(deliveryInfo) {
    this.userSessionInfo.buyScreen.deliveryInfo = deliveryInfo;
    this.updateSession('updateSessionFromDeliveryMode');
  }

  updateBalanceAmount() {
    if (Number.isNaN(Number.parseInt(this.userSessionInfo.buyScreen.budgetAmount))) {
      this.userSessionInfo.buyScreen.balanceAmount = '0';
    } else if (this.userSessionInfo.buyScreen.budgetAmount !== '0' && this.userSessionInfo.buyScreen.budgetAmount !== 0) {
      this.userSessionInfo.buyScreen.balanceAmount = (this.userSessionInfo.buyScreen.budgetAmount
        - this.userSessionInfo.buyScreen.usedAmount).toString();
    }
  }

  updateUsedAmount() {
    let travellerTotal = 0;

    this.userSessionInfo.buyScreen.traveller.forEach(currentTraveller => {
      let currentTravellerTotal = 0;
      if (currentTraveller.prepaidCard) {
        currentTraveller.prepaidCardDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.cash) {
        currentTraveller.cashDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.travellerCheque) {
        currentTraveller.travellerChequeDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.demandDraft) {
        currentTraveller.demandDraftDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }

      travellerTotal += currentTravellerTotal;
      currentTraveller.usedAmount = currentTravellerTotal;
    });


    this.userSessionInfo.buyScreen.usedAmount = travellerTotal
      + this.userSessionInfo.buyScreen.deliveryInfo.rate * this.userSessionInfo.buyScreen.traveller.length;
    this.updateBalanceAmount();
  }

  getCharges() {
    this.getChargesSub = this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.charges = Charges;
      this.getLatestRate();
      // this.updateSummaryUsedAmount('getCharges CALLER');
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  updateSummaryUsedAmount(CALLER: any = 'DEFAULT CALLER') {
    console.log(CALLER);
    let travellerTotal = 0;
    this.userSessionInfoSummary.buyScreen.usedAmount = 0;
    this.userSessionInfoSummary.buyScreen.taxData = {
      'CGST': 0,
      'SGST': 0,
      'IGST': 0
    };
    // tslint:disable-next-line:prefer-const
    let travellerCount = this.userSessionInfoSummary.buyScreen.traveller.length, currentCount = 0;
    this.serviceCharge = 0;
    this.loadFees = 0;
    this.activationFees = 0;
    let mastercal = 0;
    let CGST = 0;
    let SGST = 0;
    let IGST = 0;
    this.userSessionInfoSummary.buyScreen.traveller.forEach(currentTraveller => {
      let currentTravellerTotal = 0, charges = 0;
      let currentTravellerAmount = 0;

      if (currentTraveller.prepaidCard) {
        currentTraveller.prepaidCardDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.cash) {
        currentTraveller.cashDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.travellerCheque) {
        currentTraveller.travellerChequeDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.demandDraft) {
        currentTraveller.demandDraftDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }

      travellerTotal += currentTravellerTotal;
      // tslint:disable-next-line:max-line-length
      currentTravellerAmount += currentTravellerTotal + this.charges.response.serviceCharge + Number.parseInt(this.userSessionInfoSummary.buyScreen.deliveryInfo.rate);
      if (currentTraveller.prepaidCard) {
        currentTravellerAmount += this.charges.response.LoadFee
          + this.charges.response.ActivationCharge;
        this.loadFees += this.charges.response.LoadFee;
        this.activationFees += this.charges.response.ActivationCharge;
        charges += this.charges.response.LoadFee + this.charges.response.ActivationCharge;
      }
      this.serviceCharge += this.charges.response.serviceCharge;
      charges += this.charges.response.serviceCharge;
        if (currentTravellerAmount) {
          this.getTaxes = this.masterService.getTaxes(currentTravellerAmount).subscribe((data) => {
            const result: any = data;
            currentCount++;
            currentTravellerAmount += result.TotalTax;
            // charges += result.TotalTax;
            CGST += result.CGST;
            SGST += result.SGST;
            IGST += result.IGST;
            currentTraveller.Charges = charges;
            this.userSessionInfoSummary.buyScreen.taxData.CGST = CGST;
            this.userSessionInfoSummary.buyScreen.taxData.SGST = SGST;
            this.userSessionInfoSummary.buyScreen.taxData.IGST = IGST;
            mastercal += currentTravellerAmount;
            this.userSessionInfoSummary.buyScreen.usedAmount = mastercal;
            if (travellerCount === currentCount && this.paymentScreen) {
              this.userSessionInfo.buyScreen.billingAmount = this.userSessionInfo.buyScreen.usedAmount;
              this.userSessionInfoSummary.buyScreen.usedAmount = Math.round(this.userSessionInfoSummary.buyScreen.usedAmount);
              console.log('called');
              this.saveSession.emit(this.userSessionInfoSummary);
            }
            currentTravellerAmount = 0;
            this.userSessionInfo = this.userSessionInfoSummary;
            SessionHelper.setSession('userSessionInfo', JSON.stringify(this.userSessionInfoSummary));
           // this.updateSession();
          }, (error) => {
            Snackbar.show({
              text: 'Unable To Fetch Tax.',
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
            });
          });
        }
     currentTraveller.usedAmount = currentTravellerTotal;

    });

  }

  // region Update currency code event listeners
  updatePrepaidCurrencyCode(prepaidDetailIndex: number, newValue: string) {
    this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.buyScreen.branch, 'prepaid', 'buy')
      .subscribe(data => {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex].exchangeRate = data;
      });
    if (this.Promoter && this.PromotionalData) {
      this.bankOptions[prepaidDetailIndex] = this.PromotionalData.buyScreen.IssuerLists;
    } else {
      this.masterService.getBankList(newValue)
        .subscribe(data => {
          this.bankOptions[prepaidDetailIndex] = data;

          this.bankOptions[prepaidDetailIndex].forEach(element => {
            element.Logo = Constants.serviceUrl + '/' + element.Logo;
          });
        });
    }
  }

  updateCashCurrencyCode(cashDetailIndex: number, newValue: string) {
    this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails[cashDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.buyScreen.branch, 'cash', 'buy')
      .subscribe(data => {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails[cashDetailIndex].exchangeRate = data;
      });
  }

  updateTravellerChequeCurrencyCode(travellerChequeDetailIndex: number, newValue: string) {
    this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex]
      .travellerChequeDetails[travellerChequeDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.buyScreen.branch, 'traveller-cheque', 'buy')
      .subscribe(data => {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex]
          .travellerChequeDetails[travellerChequeDetailIndex].exchangeRate = data;
      });
  }

  updateDemandDraftCurrencyCode(demandDraftDetailIndex: number, newValue: string) {
    this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails[demandDraftDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.buyScreen.branch, 'demand-draft', 'buy')
      .subscribe(data => {
        this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails[demandDraftDetailIndex].exchangeRate = data;
      });
  }
  // endregion Update currency code event listeners

  // region Update product forex amount value
  updatePrepaidValue(newValue, index) {
    if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index].forexAmount = parseFloat(newValue);
    this.updateUsedAmount();
  }

  updateCashValue(newValue, index) {
    if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].cashDetails[index].forexAmount = parseFloat(newValue);
    this.updateUsedAmount();
  }

  updateTravellerChequeValue(newValue, index) {
    if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].travellerChequeDetails[index].forexAmount = parseFloat(newValue);
    this.updateUsedAmount();
  }

  updateDemandDraftValue(newValue, index) {
    if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    this.userSessionInfo.buyScreen.traveller[this.currentTravellerIndex].demandDraftDetails[index].forexAmount = parseFloat(newValue);
    this.updateUsedAmount();
  }
  // endregion Update product forex amount value


  populateCashCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT

    const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(2, destination)
      .subscribe(data => {
        this.currencyListCash = data;
      }, err => {
        // swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Unable to fetch currency list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  populatePrepaidCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
    if (this.Promoter && this.PromotionalData) {
      this.currencyList = this.PromotionalData.buyScreen.PrpaidCurrencyLists;
      console.log(this.PromotionalData.buyScreen.PrpaidCurrencyLists, '::::::::::::::');
    } else {
      this.masterService.getCurrencyList(1, destination)
        .subscribe(data => {
          this.currencyList = data;
        }, err => {
          // swal('Oops...', 'Unable to fetch currency list!', 'error');
          Snackbar.show({
            text: 'Unable to fetch currency list!',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        });
    }
  }

  populateTravellersCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(3, destination)
      .subscribe(data => {
        this.currencyListTravellerCheque = data;
      }, err => {
        // swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Unable to fetch currency list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }


  populateDemandDraftCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.buyScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(4, destination)
      .subscribe(data => {
        this.currencyListDemandDraft = data;
      }, err => {
        // swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Unable to fetch currency list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  submitAndRedirect() {
    this.masterService.RuleTest(this.userSessionInfoSummary)
      .subscribe(data => {
        const resData: any = JSON.parse(data);
        console.log(resData);
        if (resData.status === 1) {
          this.router.navigateByUrl(this._primaryComp + this.nextLink);
        } else {
          // swal('error', resData.message, 'error');
          Snackbar.show({
            text: resData.message,
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        }
      }, err => {
        console.log(err);
      });
  }

  // this.router.navigateByUrl(this._primaryComp + this.nextLink);
  ngOnDestroy() {
    if (this._BulkEvent) {
      this._BulkEvent.unsubscribe();
    }
    if (this.getChargesSub) {
      this.getChargesSub.unsubscribe();
    }
    if (this.getTaxes) {
      this.getTaxes.unsubscribe();
    }
  }
}


