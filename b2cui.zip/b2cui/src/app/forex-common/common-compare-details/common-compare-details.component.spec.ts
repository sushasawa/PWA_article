import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ForexRatesComponent } from '../../forex-live-rates/forex-rates/forex-rates.component';



describe('ForexRatesComponent', () => {
  let component: ForexRatesComponent;
  let fixture: ComponentFixture<ForexRatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForexRatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForexRatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
