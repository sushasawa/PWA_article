import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';
import { SessionTemplate } from '../../helpers/session-template';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { Meta } from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function swal(headerMessage, message, type): any;
declare var $: any;
declare function initDocument(): any;
declare var Snackbar: any;
@Component({
  selector: 'common-comrate-details',
  templateUrl: './common-compare-details.component.html',
  styleUrls: ['./common-compare-details.component.css']
})
export class CommonCompareDetailsComponent implements OnInit {
  public travellerInfoOld: any;
  public travellerInfoCurrent: any;
  public travellerInfoCurrentCopy: any;
  public travellerOfficeAddress: any;
  public currentSession: any;
  public pageSession: any;
  public processType: any;
  public nextLink: any;
  public userSessionInfo: any;
  public SessionInfo: any;
  public selectedIndex: any;
  public checkedTracker: any = [];
  public showhideTracker: any = [];
  public travellerInfoOldArr: any;
  public travellerInfoCurrentArr: any;
  public travellerInfoCurrentCopyArr: any;
  public _primaryComp: any;
  constructor(private route: ActivatedRoute, private navUrl: NavigatePathService, @Inject(DOCUMENT) private document: any, private router: Router, private masterService: MasterService, private meta: Meta) { 
    this._primaryComp = '/' + navUrl.navUrl();
    this.document.title = 'Review Your Mis-match Details & Select Your Current Details';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'Review Your Mis-match Details & Select Your Current Details'});
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    setTimeout(function () {
      initDocument();
    }, 5);
    this.pageSession = this.route.snapshot.data.sessData.sessionDataProcess;
    this.currentSession = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession));
    this.nextLink = this.SessionInfo.nextLink;
    this.userSessionInfo = this.SessionInfo[this.currentSession];
    if (SessionHelper.getSession('checkedTracker')) {
      this.checkedTracker = JSON.parse(SessionHelper.getSession('checkedTracker'));
    }
    this.getTravellersData();
  }

  getTravellersData() {
    this.travellerInfoOldArr = [];
    let parentEmailId = this.getLeadEmailId(this.userSessionInfo.traveller);
    this.masterService.getLoggedInUserInfo(parentEmailId).
      subscribe(data => {
        let result: any = data;
        result = result.response;
        result.forEach(travellerArr => {
          travellerArr.forEach(traveller => {
            this.travellerInfoOldArr.push(SessionTemplate.getSessionTemplate(traveller));
          });
        });
        if(this.travellerInfoOldArr.length < 1){
          this.router.navigateByUrl(this._primaryComp + this.nextLink);
        }
        this.travellerInfoCurrentArr = JSON.parse(JSON.stringify(this.userSessionInfo.traveller));   
        if (SessionHelper.getSession('travellerInfoCurrentCopyArr')) {
          this.travellerInfoCurrentCopyArr = JSON.parse(SessionHelper.getSession('travellerInfoCurrentCopyArr'));
        } else {
          this.travellerInfoCurrentCopyArr = JSON.parse(JSON.stringify(this.userSessionInfo.traveller));
        }
        this.filterTraveller();
        this.setSelectedTravellerDetails(0);
      }, error => {
        Snackbar.show({
          text: 'Unable to fetch required details',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });

  }

  getLeadEmailId(travellers){
    let leadTravellerEmail;
    travellers.forEach((traveller)=>{
      if(traveller.lead){
        leadTravellerEmail = traveller.registrationInfo.userId;
      }
    });
    return leadTravellerEmail;
  }

  filterTraveller() {
    this.travellerInfoCurrentArr.forEach((travellerInfoCurrentEle, travellerIndex) => {
      let similar = this.travellerInfoOldArr.findIndex((travellerInfoOldEle) => {
        return travellerInfoOldEle.registrationInfo.contactDetails.emailId === travellerInfoCurrentEle.registrationInfo.contactDetails.emailId;
      });
      if (similar !== -1) {
        travellerInfoCurrentEle.exist = true;
      } else {
        this.travellerInfoCurrentCopyArr[travellerIndex].exist = false; 
      }
    });
  }

  setSelectedTravellerDetails(index) {
    this.travellerInfoCurrentArr.forEach(traveller => {
      traveller.selected = false;
    });
    this.selectedIndex = index;
    this.travellerInfoCurrentArr[index].selected = true;
    if (!this.checkedTracker[index]) {
      this.checkedTracker[index] = {};
    }
    if (!this.showhideTracker[index]) {
      this.showhideTracker[index] = {};
    }
    this.travellerInfoCurrent = this.travellerInfoCurrentArr[index];
    this.travellerInfoCurrentCopy = this.travellerInfoCurrentCopyArr[index];
    this.travellerInfoOld = this.travellerInfoOldArr.find((travellerInfoOldEle) => {
      return travellerInfoOldEle.registrationInfo.contactDetails.emailId === this.travellerInfoCurrent.registrationInfo.contactDetails.emailId;
    });
    if(this.travellerInfoOld.registrationInfo && this.travellerInfoCurrent.registrationInfo){
      this.concatOfficeAddress(this.travellerInfoOld);
      this.concatOfficeAddress(this.travellerInfoCurrent);
      this.comparePhoneNumbers(this.travellerInfoOld, this.travellerInfoCurrent, this.travellerInfoCurrentCopy);
      this.compareAddresses(this.travellerInfoOld, this.travellerInfoCurrent, this.travellerInfoCurrentCopy);
      this.replaceBlankValues(this.travellerInfoOld, this.travellerInfoCurrent);
    }    
  }

  
  replaceLastCommaWith(text, element) {
    const pos = text.lastIndexOf(',');
    return text.substring(0, pos) + ' ' + element + ' ' + text.substring(pos + 1);
  }

  concatOfficeAddress(traveller) {
    const nonAdressParam = ['conpanyName', 'companyName', 'designation', 'companyDivision', 'pincode'];
    this.travellerOfficeAddress = [];
    let addressText = '', officeAddress = traveller.registrationInfo.officeAddress, counter = 0, pincodeAdded = false;
    for (const travellerData in officeAddress) {
      if (nonAdressParam.indexOf(travellerData) === -1 && officeAddress[travellerData]) {
        addressText += officeAddress[travellerData] + ', ';
        counter++;
      }
      if (travellerData === 'pincode' && officeAddress[travellerData]) {
        if (counter > 0) {
          addressText = this.replaceLastCommaWith(addressText, '-') + officeAddress[travellerData];
        } else {
          addressText += officeAddress[travellerData];
        }
        pincodeAdded = true;
      }
    }
    if ((counter > 0 && pincodeAdded) || pincodeAdded) {
      addressText += '.';
    } else if (counter > 0) {
      addressText += this.replaceLastCommaWith(addressText, '.');
    }
    traveller.registrationInfo.concatedOfficeAddress = addressText;
  }

  onTravellerSubmit() {
    this.userSessionInfo.traveller = this.travellerInfoCurrentCopyArr;  
    this.SessionInfo[this.currentSession] = this.userSessionInfo;
    SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));
    this.router.navigateByUrl(this._primaryComp + this.nextLink);
  }

  comparePhoneNumbers(travellerInfoOld, travellerInfoCurrent, travellerInfoCurrentCopy) {
    let contactDetailsOld = travellerInfoOld.registrationInfo.contactDetails,
    showhideTrackerCurr = this.showhideTracker[this.selectedIndex],
      contactDetailsCurrent = travellerInfoCurrent.registrationInfo.contactDetails,
      contactDetailsCurrentCopy = travellerInfoCurrentCopy.registrationInfo.contactDetails,
      alternateContactDetailsOld = travellerInfoOld.registrationInfo.alternateContactDetails,
      alternateContactDetailsCurrent = travellerInfoCurrent.registrationInfo.alternateContactDetails,
      alternateContactDetailsCurrentCopy = travellerInfoCurrentCopy.registrationInfo.alternateContactDetails,
      officeContactDetailsOld = travellerInfoOld.registrationInfo.officeContactDetails,
      officeContactDetailsCurrent = travellerInfoCurrent.registrationInfo.officeContactDetails,
      officeContactDetailsCurrentCopy = travellerInfoCurrentCopy.registrationInfo.officeContactDetails;
    this.removeNulls([contactDetailsOld, contactDetailsCurrent, alternateContactDetailsOld, alternateContactDetailsCurrent, officeContactDetailsOld, officeContactDetailsCurrent]);
    if (contactDetailsOld.countryCode !== contactDetailsCurrent.countryCode || contactDetailsOld.mobileNo !== contactDetailsCurrent.mobileNo) {
      travellerInfoOld.contactMobileNotSame = true;
      if(!contactDetailsCurrent.mobileNo){
        contactDetailsCurrentCopy.countryCode = contactDetailsOld.countryCode;
        contactDetailsCurrentCopy.mobileNo = contactDetailsOld.mobileNo;
        showhideTrackerCurr.showContactMobile = false;
      } else {
        showhideTrackerCurr.showContactMobile = true;
      }
    }
    if (contactDetailsOld.countryCode !== contactDetailsCurrent.countryCode || contactDetailsOld.cityCode !== contactDetailsCurrent.cityCode || contactDetailsOld.telephoneNo !== contactDetailsCurrent.telephoneNo) {
      travellerInfoOld.contactTelephoneNotSame = true;
      if(!contactDetailsCurrent.telephoneNo){
        contactDetailsCurrentCopy.countryCode = contactDetailsOld.countryCode;
        contactDetailsCurrentCopy.cityCode = contactDetailsOld.cityCode;
        contactDetailsCurrentCopy.telephoneNo = contactDetailsOld.telephoneNo;
        showhideTrackerCurr.showContactTelephone = false;
      } else {
        showhideTrackerCurr.showContactTelephone = true;
      }
    }
    if (alternateContactDetailsOld.countryCode !== alternateContactDetailsCurrent.countryCode || alternateContactDetailsOld.mobileNo !== alternateContactDetailsCurrent.mobileNo) {
      travellerInfoOld.AltContactMobileNotSame = true;
      if(!alternateContactDetailsCurrent.mobileNo){
        alternateContactDetailsCurrentCopy.countryCode = alternateContactDetailsOld.countryCode;
        alternateContactDetailsCurrentCopy.mobileNo = alternateContactDetailsOld.mobileNo;
        showhideTrackerCurr.showAltContact = false;
      } else {
        showhideTrackerCurr.showAltContact = true;
      }
    }
    if (officeContactDetailsOld.countryCode != officeContactDetailsCurrent.countryCode || officeContactDetailsOld.telephoneNumber != officeContactDetailsCurrent.telephoneNumber || officeContactDetailsOld.officeExtension != officeContactDetailsCurrent.officeExtension) {
      travellerInfoOld.officeContactNotSame = true;
      if(!officeContactDetailsCurrent.telephoneNumber){
        officeContactDetailsCurrentCopy.countryCode = officeContactDetailsOld.countryCode;
        officeContactDetailsCurrentCopy.telephoneNumber = officeContactDetailsOld.telephoneNumber;
        officeContactDetailsCurrentCopy.officeExtension = officeContactDetailsOld.officeExtension;
        showhideTrackerCurr.showOfficeContact = false;
      } else {
        showhideTrackerCurr.showOfficeContact = true;
      }
    }
  }

  removeNulls(params) {
    params.forEach(param => {
      for (let key in param) {
        if (!param[key]) {
          param[key] = "";
        }
      }
    });
  }

  compareAddresses(travellerInfoOld, travellerInfoCurrent, travellerInfoCurrentCopy) {
    if (travellerInfoOld.registrationInfo.concatedOfficeAddress !== travellerInfoCurrent.registrationInfo.concatedOfficeAddress) {
      travellerInfoOld.officeAddressDiff = true;
    }
    let passportAddressOld = travellerInfoOld.registrationInfo.passportAddress, notBlankPassportAddressCurrent = false,
      passportAddressCurrent = travellerInfoCurrent.registrationInfo.passportAddress, notBlankOtherAddressCurrent = false,
      otherAddressOld = travellerInfoOld.registrationInfo.otherAddress, showhideTrackerCurr = this.showhideTracker[this.selectedIndex],
      passportAddressCurrentCopy = travellerInfoCurrentCopy.registrationInfo.passportAddress,
      otherAddressCurrentCopy = travellerInfoCurrentCopy.registrationInfo.otherAddress,
      otherAddressCurrent = travellerInfoCurrent.registrationInfo.otherAddress;
    this.removeNulls([passportAddressOld, passportAddressCurrent, otherAddressOld, otherAddressCurrent]);
    for (let addressEle in passportAddressOld) {
      if (passportAddressOld[addressEle] !== passportAddressCurrent[addressEle]) {
        if(passportAddressCurrent[addressEle]){
          notBlankPassportAddressCurrent = true;
        }
        travellerInfoOld.passportAddressDiff = true;
      }
    }
    if(travellerInfoOld.passportAddressDiff === true && notBlankPassportAddressCurrent === false){
      for (let addressEle in passportAddressOld) {
        passportAddressCurrentCopy[addressEle] = passportAddressOld[addressEle];        
      }
      showhideTrackerCurr.showPassportAddress = false;
    } else {
      showhideTrackerCurr.showPassportAddress = true;
    }
    for (let addressEle in otherAddressOld) {
      if (otherAddressOld[addressEle] !== otherAddressCurrent[addressEle]) {
        if(otherAddressCurrent[addressEle]){
          notBlankOtherAddressCurrent = true;
        }
        travellerInfoOld.otherAddressDiff = true;
      }
    }
    if(travellerInfoOld.otherAddressDiff === true && notBlankOtherAddressCurrent === false){
      for (let addressEle in otherAddressOld) {
        otherAddressCurrentCopy[addressEle] = otherAddressOld[addressEle];
      }
      showhideTrackerCurr.showOtherAddress = false;
    } else {
      showhideTrackerCurr.showOtherAddress = true;
    }
  }

  setSelectedElement(objectRef, data, key, elementName) {
    if (typeof data[key] === "object") {
      objectRef[key] = JSON.parse(JSON.stringify(data[key]));
    } else {
      objectRef[key] = data[key];
    }
    this.updateCheckTracker(elementName);
    SessionHelper.setSession('travellerInfoCurrentCopyArr', JSON.stringify(this.travellerInfoCurrentCopyArr));
  }

  setSelectedPhoneDetails(objectRef, data, keys, elementName) {
    for (let key in keys) {
      if (typeof data[keys[key]] === "object") {
        objectRef[keys[key]] = JSON.parse(JSON.stringify(data[keys[key]]));
      } else {
        objectRef[keys[key]] = data[keys[key]];
      }
    }
    this.updateCheckTracker(elementName);
    SessionHelper.setSession('travellerInfoCurrentCopyArr', JSON.stringify(this.travellerInfoCurrentCopyArr));
  }

  updateCheckTracker(elementName) {
    let elementParam = elementName.split(':');
    this.checkedTracker[this.selectedIndex][elementParam[0]] = elementParam[1];
    SessionHelper.setSession('checkedTracker', JSON.stringify(this.checkedTracker));
  }

  replaceBlankValues(travellerInfoOld, travellerInfoCurrent) {
    let travellerInfoCurrentCopy = this.travellerInfoCurrentCopyArr[this.selectedIndex], showhideTrackerCurr = this.showhideTracker[this.selectedIndex];
    // travellerInfoCurrentCopy.registrationInfo.firstName.value = (!travellerInfoCurrent.registrationInfo.firstName.value.trim()) ? travellerInfoOld.registrationInfo.firstName.value : travellerInfoCurrentCopy.registrationInfo.firstName.value;
    // showhideTrackerCurr.showFirstName = (!travellerInfoCurrent.registrationInfo.firstName.value.trim() || !travellerInfoOld.registrationInfo.firstName.value.trim()) ? false : true;
    // travellerInfoCurrentCopy.registrationInfo.middleName = (!travellerInfoCurrent.registrationInfo.middleName.trim()) ? travellerInfoOld.registrationInfo.middleName : travellerInfoCurrentCopy.registrationInfo.middleName;
    // showhideTrackerCurr.showMiddleName = (!travellerInfoCurrent.registrationInfo.middleName.trim() || !travellerInfoOld.registrationInfo.middleName.trim()) ? false : true;
    // travellerInfoCurrentCopy.registrationInfo.lastName = (!travellerInfoCurrent.registrationInfo.lastName.trim()) ? travellerInfoOld.registrationInfo.lastName : travellerInfoCurrentCopy.registrationInfo.lastName;
    // showhideTrackerCurr.showLastName = (!travellerInfoCurrent.registrationInfo.lastName.trim() || !travellerInfoOld.registrationInfo.lastName.trim()) ? false : true;
    // travellerInfoCurrentCopy.registrationInfo.mothersMaidenName.value = (!travellerInfoCurrent.registrationInfo.mothersMaidenName.value.trim()) ? travellerInfoOld.registrationInfo.mothersMaidenName.value : travellerInfoCurrentCopy.registrationInfo.mothersMaidenName.value;
    // showhideTrackerCurr.showMotherName = (!travellerInfoCurrent.registrationInfo.mothersMaidenName.value.trim() || !travellerInfoOld.registrationInfo.mothersMaidenName.value.trim()) ? false : true;
    // travellerInfoCurrentCopy.registrationInfo.dateOfBirth.value = (!travellerInfoCurrent.registrationInfo.dateOfBirth.value.trim()) ? travellerInfoOld.registrationInfo.dateOfBirth.value : travellerInfoCurrentCopy.registrationInfo.dateOfBirth.value;
    // showhideTrackerCurr.showBirthDate = (!travellerInfoCurrent.registrationInfo.dateOfBirth.value.trim() || !travellerInfoOld.registrationInfo.dateOfBirth.value.trim()) ? false : true;
    // travellerInfoCurrentCopy.registrationInfo.nationality = (!travellerInfoCurrent.registrationInfo.nationality.trim()) ? travellerInfoOld.registrationInfo.nationality : travellerInfoCurrentCopy.registrationInfo.nationality;
    // showhideTrackerCurr.showNationality = (!travellerInfoCurrent.registrationInfo.nationality.trim() || !travellerInfoOld.registrationInfo.nationality.trim()) ? false : true;
    // travellerInfoCurrentCopy.registrationInfo.PAN.value = (!travellerInfoCurrent.registrationInfo.PAN.value.trim()) ? travellerInfoOld.registrationInfo.PAN.value : travellerInfoCurrentCopy.registrationInfo.PAN.value;
    // showhideTrackerCurr.showPanNumber = (!travellerInfoCurrent.registrationInfo.PAN.value.trim() || !travellerInfoOld.registrationInfo.PAN.value.trim()) ? false : true;
    travellerInfoCurrentCopy.registrationInfo.passportNumber = (!travellerInfoCurrent.registrationInfo.passportNumber) ? travellerInfoOld.registrationInfo.passportNumber : travellerInfoCurrentCopy.registrationInfo.passportNumber;
    showhideTrackerCurr.showPassportNumber = (!travellerInfoCurrent.registrationInfo.passportNumber || !travellerInfoOld.registrationInfo.passportNumber) ? false : true;
    travellerInfoCurrentCopy.registrationInfo.dateOfIssue = (!travellerInfoCurrent.registrationInfo.dateOfIssue) ? travellerInfoOld.registrationInfo.dateOfIssue : travellerInfoCurrentCopy.registrationInfo.dateOfIssue;
    showhideTrackerCurr.showDateOfIssue = (!travellerInfoCurrent.registrationInfo.dateOfIssue || !travellerInfoOld.registrationInfo.dateOfIssue) ? false : true;
    travellerInfoCurrentCopy.registrationInfo.placeOfIssue = (!travellerInfoCurrent.registrationInfo.placeOfIssue) ? travellerInfoOld.registrationInfo.placeOfIssue : travellerInfoCurrentCopy.registrationInfo.placeOfIssue;
    showhideTrackerCurr.showPlaceOfIssue = (!travellerInfoCurrent.registrationInfo.placeOfIssue || !travellerInfoOld.registrationInfo.placeOfIssue) ? false : true;
    travellerInfoCurrentCopy.registrationInfo.expiryDate = (!travellerInfoCurrent.registrationInfo.expiryDate) ? travellerInfoOld.registrationInfo.expiryDate : travellerInfoCurrentCopy.registrationInfo.expiryDate;
    showhideTrackerCurr.showExpiryDate = (!travellerInfoCurrent.registrationInfo.expiryDate || !travellerInfoOld.registrationInfo.expiryDate) ? false : true;
    travellerInfoCurrentCopy.registrationInfo.alternateContactDetails.emailId = (!travellerInfoCurrent.registrationInfo.alternateContactDetails.emailId) ? travellerInfoOld.registrationInfo.alternateContactDetails.emailId : travellerInfoCurrentCopy.registrationInfo.alternateContactDetails.emailId;
    showhideTrackerCurr.showEmailId = (!travellerInfoCurrent.registrationInfo.alternateContactDetails.emailId || !travellerInfoOld.registrationInfo.alternateContactDetails.emailId) ? false : true;
    (!travellerInfoCurrent.registrationInfo.concatedOfficeAddress) ? this.setSelectedElement(travellerInfoCurrentCopy.registrationInfo, travellerInfoOld.registrationInfo, 'officeAddress', 'officeAddress:0') : this.setSelectedElement(travellerInfoCurrentCopy.registrationInfo, travellerInfoCurrent.registrationInfo, 'officeAddress', 'officeAddress:1');
    showhideTrackerCurr.showOfficeAddress = (!travellerInfoCurrent.registrationInfo.concatedOfficeAddress || !travellerInfoOld.registrationInfo.concatedOfficeAddress) ? false : true;
    // console.log(travellerInfoOld.registrationInfo, '??????????????,,,,,,');
    // console.log(travellerInfoCurrentCopy.registrationInfo, '??????????????,,,,,,');
    // console.log(this.showhideTracker, '??????????????,,,,,,');
  }
  
}
