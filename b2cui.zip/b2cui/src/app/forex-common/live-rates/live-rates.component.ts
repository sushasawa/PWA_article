import { Component, OnInit, Input } from '@angular/core';
import { MasterService } from '../../services/master.services';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import * as momentTimezone from 'moment-timezone';
import { forEach } from '@angular/router/src/utils/collection';

import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { SessionHelper } from '../../helpers/session-helper';

import { DatePipe } from '@angular/common';
import { Console } from '@angular/core/src/console';
import { Meta } from '@angular/platform-browser';
import { AgentMarginService } from '../../services/agent-margin.service';
import { SharedService } from '../../services/shared.service';
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;
const newLocal = 'liveRate';

@Component({
  selector: 'app-live-rates',
  templateUrl: './live-rates.component.html',
  styleUrls: ['./live-rates.component.css']
})
export class LiveRatesComponent implements OnInit, OnDestroy {
  public timeInterval: any;
  public today: any;
  public reportDuration: any;
  public currencyLists: any = [];

  public lineChartLabels: any = [];
  public currentCurrencyList: any;
  public currentCurrencyIndex: any;
  public nextDisable: Boolean;
  public prevDisable: Boolean;
  public lineChartType: any = 'bar';
  public lineChartData: any = [];
  public lineChartColors: any = [
    {
      backgroundColor: 'rgba(211, 69, 69,0.8)',
      borderColor: 'red',
      pointBackgroundColor: 'red',
      pointBorderColor: '#fff',
    },
    {
      backgroundColor: 'rgba(151, 237, 94,0.8)',
      borderColor: 'green',
      pointBackgroundColor: 'green',
      pointBorderColor: '#fff',
    },
    { // grey
      backgroundColor: 'rgba(71, 129, 237,0.8)',
      borderColor: 'blue',
      pointBackgroundColor: 'blue',
      pointBorderColor: '#fff',
    },
    { // grey
      backgroundColor: 'rgba(204, 69, 168,0.8)',
      borderColor: 'orange',
      pointBackgroundColor: 'orange',
      pointBorderColor: '#fff',
    }
  ];
  public selectedCurrencyName: any;
  public selectedCurrencyCode: any;
  public selectedChartType: any;
  public selectedType: any;
  public selectedDuration: any;
  public selectedTypeLabel: any;
  public currencyName: any;
  public lineChartLegend: any = true;
  public loaded: any = false;
public AgentId: any;
public AgentWebsiteIDCall: any;
  public branchId: any = SessionHelper.getLocal('branchIdFromOverview');
  @Input() CurrentBranchId: any;
  @Input() CurrentAgentId: any;
  public lineChartOptions: any = {
    responsive: true,
    // bezierCurve: false
    scaleShowVerticalLines: false,
    // tooltips: {
    //   backgroundColor:'red',
    //   label:'test name'
    // }
    tooltips: {
      callbacks: {
        label: (tooltipItem, data) => {
          return ' Average : ' + tooltipItem.yLabel
            + '  Min : ' + this.lineChartData[tooltipItem.datasetIndex].minV[tooltipItem.index]
            + '  Max : ' + this.lineChartData[tooltipItem.datasetIndex].maxV[tooltipItem.index];
        }
        // label: function (tooltipItem, data) {
        //   const datasetLabel = data.datasets[tooltipItem.datasetIndex].label || 'TEST';
        //   return  datasetLabel + ': ' + tooltipItem.yLabel + '%';
        // }
      }
    }
  };
  public dropdownValues: any = 'Daily';
  public _primaryComp: any;
  constructor(private _MasterService: MasterService, private _SharedService: SharedService, private meta: Meta, private navUrl: NavigatePathService, public agentMargin: AgentMarginService) {
    this._primaryComp = '/' + navUrl.navUrl();
    
    this.dropdownValues = [
      { value: 'Daily', label: 'Daily' },
      { value: 'Weekly', label: 'Weekly' },
    ];

    this.currentCurrencyIndex = 0;
    this.lineChartData = [{ data: [], label: 'Cash', lineTension: 0, maxV: [], minV: [] },
    // { data: [], label: 'Travellers Cheque', lineTension: 0, maxV: [], minV: [] },
    { data: [], label: 'Prepaid Notes', lineTension: 0, maxV: [], minV: [] },
    { data: [], label: 'TT/DD', lineTension: 0, maxV: [], minV: [] },
    ];

  }

  ngOnInit() {
    // this.getLiveData();
    // const that = this;
    // this.timeInterval = setInterval(function () {
    //   that.getLiveData();
    // }, 60000);
    if(!this.CurrentBranchId){
      this.CurrentBranchId = '11911';
    }
    // if (sessionStorage.getItem('currencyLists') === null) {
      this.getLiveData();
    // }else {
    //   this.currencyLists = JSON.parse(sessionStorage.getItem('currencyLists'));
    //   this.currentCurrencyList = this.currencyLists[this.currentCurrencyIndex];
    //   this.setMetaData(this.currentCurrencyList);
    //   this.setTime();
    // }

    const that = this;
    this.timeInterval = setInterval(function () {
      that.getLiveData();
    }, 60000);
    if(this.AgentWebsiteIDCall){
      this.AgentWebsiteIDCall.unsubscribe();
    }
    this.AgentWebsiteIDCall =  this._SharedService.AgentWebsiteID.subscribe((agentWebsiteId) => {
      this.AgentId = btoa(JSON.parse(agentWebsiteId));
      this.agentMargin.setAgentMarginCall(() => {
        this.getLiveData();
        this.AgentWebsiteIDCall.unsubscribe();
      });
    });
  }

  getLiveData(): void {
    this.currencyLists = [];
    this._MasterService.getLiveForexDataFromBranchId(this.CurrentBranchId)
      .subscribe(data => {
        // this.currencyLists = data;
        this.setTime();
        // this.today = data[0].liveForexCurrencyDateTime;

        const results: any = data;
        const tempindex: any = 0;
        let tempArray = [];
        // this.currencyLists = [];
        results.map((result, index) => {
          tempArray.push(result);
          if (index == 0) {
            this.today = result.liveForexCurrencyDateTime.replace('AM', ' am').replace('PM', ' pm') + ' (' + momentTimezone().tz(momentTimezone.tz.guess()).format('z') + ')';
          }
          if ((index + 1) % 5 === 0) {
            // tslint:disable-next-line:one-line
            if (index < 5){
              this.setMetaData(tempArray);
            }
            this.currencyLists.push(tempArray);
            // console.log(this.currencyLists);
            tempArray = [];
          }
        });
        if (tempArray.length > 0 && tempArray.length < 5) {
          this.currencyLists.push(tempArray);
          tempArray = [];
        }
        // this.currencyLists.reverse();
        sessionStorage.setItem('currencyLists', JSON.stringify(this.currencyLists));
        this.currentCurrencyList = this.currencyLists[this.currentCurrencyIndex];

      }, err => {
        // Snackbar.show({
        //   text: 'Unable to fetch currency list!',
        //   pos: 'bottom-right',
        //   actionTextColor: '#ff4444',
        // });
      });
  }

  // tslint:disable-next-line:one-line
  setMetaData(dataArray) {
    if (dataArray) {
      dataArray.forEach((currencyData) => {
        this.meta.removeTag('name="' + currencyData.currency + 'rates' + '"');
        // tslint:disable-next-line:max-line-length
        this.meta.addTag({ name: currencyData.currency + 'rates', content: 'Todays ' + currencyData.currency + ' exchange rates are ' + currencyData.buyPrepaidRates });
      });
    }
  }

  ngOnDestroy() {
    clearInterval(this.timeInterval);
  }

  ngOnChanges() {
      this.getLiveData();
  }

  nextCurrency() {
    const currencyListsLength = this.currencyLists.length;
    if (this.currentCurrencyIndex < currencyListsLength - 1) {
      this.currentCurrencyIndex++;
      this.currentCurrencyList = this.currencyLists[this.currentCurrencyIndex];
      this.nextDisable = false;
      this.prevDisable = false;

    } else {
      this.nextDisable = true;

    }
  }
  prevCurrency() {

    const currencyListsLength = this.currencyLists.length;
    if (this.currentCurrencyIndex > 0) {
      this.currentCurrencyIndex--;
      this.currentCurrencyList = this.currencyLists[this.currentCurrencyIndex];
      this.prevDisable = false;
      this.nextDisable = false;

    } else {
      this.prevDisable = true;

    }

  }

  updateRates() {
    // this.setTime();
    this.loaded = true;
    this.getLiveData();
    setTimeout(() => {
      this.loaded = false;
    }, 700);
    // console.log('update rates');
  }

  onChange() {
    // tslint:disable-next-line:max-line-length
    this.getTrend(this.selectedCurrencyName, this.selectedCurrencyCode, this.selectedChartType, this.selectedType, this.reportDuration, false);
  }

  ChartType(val) {
    this.lineChartType = val;

    if (val === 'line') {
      this.lineChartColors[0].backgroundColor = 'transparent';
      // this.lineChartColors[1].backgroundColor = 'transparent';
      this.lineChartColors[1].backgroundColor = 'transparent';
      this.lineChartColors[2].backgroundColor = 'transparent';
    } else {
      this.lineChartColors[0].backgroundColor = 'rgba(211, 69, 69,0.8)';
      // this.lineChartColors[1].backgroundColor = 'rgba(151, 237, 94,0.8)';
      this.lineChartColors[1].backgroundColor = 'rgba(71, 129, 237,0.8)';
      this.lineChartColors[2].backgroundColor = 'rgba(204, 69, 168,0.8)';
    }
  }

  getTrend(currencyName, currencyCode, ChartType, type, duration, isNotOnChange) {
    if (isNotOnChange) {
      this.reportDuration = 'Daily';
      duration = 'Daily';
    }
    this.lineChartType = ChartType;

    this.selectedCurrencyName = currencyName;
    this.selectedCurrencyCode = currencyCode;
    this.selectedChartType = ChartType;
    this.selectedType = type;

    this.selectedTypeLabel = type.toUpperCase();
    this.selectedDuration = duration;


    if (ChartType === 'line') {
      this.lineChartColors[0].backgroundColor = 'transparent';
      // this.lineChartColors[1].backgroundColor = 'transparent';
      this.lineChartColors[1].backgroundColor = 'transparent';
      this.lineChartColors[2].backgroundColor = 'transparent';
    } else {
      this.lineChartColors[0].backgroundColor = 'rgba(211, 69, 69,0.8)';
      // this.lineChartColors[1].backgroundColor = 'rgba(151, 237, 94,0.8)';
      this.lineChartColors[1].backgroundColor = 'rgba(71, 129, 237,0.8)';
      this.lineChartColors[2].backgroundColor = 'rgba(204, 69, 168,0.8)';
    }

    this.lineChartLabels.length = 0;
    this.currencyName = currencyName + ' (' + currencyCode + ')';


    if (type === 'Buy') {
      if (duration === 'Weekly') {
        // this._MasterService.getForexTrend(currencyCode)
        this._MasterService.getForexTrendFromBranchId(currencyCode, this.CurrentBranchId)
          .subscribe(data => {
            const resData: any = data;

            this.lineChartData = [{ data: [], label: 'Cash', lineTension: 0, maxV: [], minV: [] },
            // { data: [], label: 'Travellers Cheque', lineTension: 0, maxV: [], minV: [] },
            { data: [], label: 'Prepaid Notes', lineTension: 0, maxV: [], minV: [] },
            { data: [], label: 'TT/DD', lineTension: 0, maxV: [], minV: [] },
            ];

            if (resData.length !== 0) {
              resData.forEach((collection, i) => {
                this.lineChartData[0].data.push(parseFloat(collection.buyBankNotesRatesAvg).toFixed(2));
                this.lineChartData[0].maxV.push(parseFloat(collection.buyBankNotesRatesMax).toFixed(2));
                this.lineChartData[0].minV.push(parseFloat(collection.buyBankNotesRatesMin).toFixed(2));

                // this.lineChartData[1].data.push(parseFloat(collection.buyTravellerChequeRatesAvg).toFixed(2));
                // this.lineChartData[1].maxV.push(parseFloat(collection.buyTravellerChequeRatesMax).toFixed(2));
                // this.lineChartData[1].minV.push(parseFloat(collection.buyTravellerChequeRatesMin).toFixed(2));

                this.lineChartData[1].data.push(parseFloat(collection.buyPrepaidRatesAvg).toFixed(2));
                this.lineChartData[1].maxV.push(parseFloat(collection.buyPrepaidRatesMax).toFixed(2));
                this.lineChartData[1].minV.push(parseFloat(collection.buyPrepaidRatesMin).toFixed(2));

                this.lineChartData[2].data.push(parseFloat(collection.buyDDRatesAvg).toFixed(2));
                this.lineChartData[2].maxV.push(parseFloat(collection.buyDDRatesMax).toFixed(2));
                this.lineChartData[2].minV.push(parseFloat(collection.buyDDRatesMin).toFixed(2));

                this.lineChartLabels.push(new DatePipe('en-US').transform(collection.liveForexCurrencyDate, 'dd-MM-yyyy'));
              });
            } else {
              this.lineChartData[0].data.length = 0;
              // this.lineChartData[1].data.length = 0;
              this.lineChartData[1].data.length = 0;
              this.lineChartData[2].data.length = 0;
            }

          });
      } else if (duration === 'Daily') {
        // this._MasterService.getForexTrendBuyDaywise(currencyCode)
        this._MasterService.getForexTrendBuyDaywiseFromBranchId(currencyCode, this.CurrentBranchId)
          .subscribe(data => {
            const resData: any = data;

            this.lineChartData = [{ data: [], label: 'Cash', lineTension: 0, maxV: [], minV: [] },
            // { data: [], label: 'Travellers Cheque', lineTension: 0, maxV: [], minV: [] },
            { data: [], label: 'Prepaid Notes', lineTension: 0, maxV: [], minV: [] },
            { data: [], label: 'TT/DD', lineTension: 0, maxV: [], minV: [] },
            ];

            if (resData.length !== 0) {
              resData.forEach((collection, i) => {
                this.lineChartData[0].data.push(parseFloat(collection.buyBankNotesRatesAvg).toFixed(2));
                this.lineChartData[0].maxV.push(parseFloat(collection.buyBankNotesRatesMax).toFixed(2));
                this.lineChartData[0].minV.push(parseFloat(collection.buyBankNotesRatesMin).toFixed(2));

                // this.lineChartData[1].data.push(parseFloat(collection.buyTravellerChequeRatesAvg).toFixed(2));
                // this.lineChartData[1].maxV.push(parseFloat(collection.buyTravellerChequeRatesMax).toFixed(2));
                // this.lineChartData[1].minV.push(parseFloat(collection.buyTravellerChequeRatesMin).toFixed(2));

                this.lineChartData[1].data.push(parseFloat(collection.buyPrepaidRatesAvg).toFixed(2));
                this.lineChartData[1].maxV.push(parseFloat(collection.buyPrepaidRatesMax).toFixed(2));
                this.lineChartData[1].minV.push(parseFloat(collection.buyPrepaidRatesMin).toFixed(2));

                this.lineChartData[2].data.push(parseFloat(collection.buyDDRatesAvg).toFixed(2));
                this.lineChartData[2].maxV.push(parseFloat(collection.buyDDRatesMax).toFixed(2));
                this.lineChartData[2].minV.push(parseFloat(collection.buyDDRatesMin).toFixed(2));

                this.lineChartLabels.push(new DatePipe('en-US').transform(collection.liveForexCurrencyDate, 'dd-MM-yyyy HH:mm'));
              });
            } else {
              this.lineChartData[0].data.length = 0;
              // this.lineChartData[1].data.length = 0;
              this.lineChartData[1].data.length = 0;
              this.lineChartData[2].data.length = 0;
            }

          });
      }
    } else if (type === 'Sell') {
      if (duration === 'Daily') {
        // this._MasterService.getForexTrendSellDaywise(currencyCode)
        this._MasterService.getForexTrendSellDaywiseFromBranchId(currencyCode, this.CurrentBranchId)
          .subscribe(data => {
            const resData: any = data;

            this.lineChartData = [{ data: [], label: 'Cash', lineTension: 0, maxV: [], minV: [] },
            // { data: [], label: 'Travellers Cheque', lineTension: 0, maxV: [], minV: [] },
            { data: [], label: 'Prepaid Notes', lineTension: 0, maxV: [], minV: [] },
            { data: [], label: 'TT/DD', lineTension: 0, maxV: [], minV: [] },
            ];

            if (resData.length !== 0) {
              resData.forEach((collection, i) => {
                this.lineChartData[0].data.push(parseFloat(collection.sellBankNotesRatesAvg).toFixed(2));
                this.lineChartData[0].maxV.push(parseFloat(collection.sellBankNotesRatesMax).toFixed(2));
                this.lineChartData[0].minV.push(parseFloat(collection.sellBankNotesRatesMin).toFixed(2));

                // this.lineChartData[1].data.push(parseFloat(collection.sellTravellerChequeRatesAvg).toFixed(2));
                // this.lineChartData[1].maxV.push(parseFloat(collection.sellTravellerChequeRatesMax).toFixed(2));
                // this.lineChartData[1].minV.push(parseFloat(collection.sellTravellerChequeRatesMin).toFixed(2));

                this.lineChartData[1].data.push(parseFloat(collection.sellPrepaidRatesAvg).toFixed(2));
                this.lineChartData[1].maxV.push(parseFloat(collection.sellPrepaidRatesMax).toFixed(2));
                this.lineChartData[1].minV.push(parseFloat(collection.sellPrepaidRatesMin).toFixed(2));

                this.lineChartData[2].data.push(parseFloat(collection.sellDDRatesAvg).toFixed(2));
                this.lineChartData[2].maxV.push(parseFloat(collection.sellDDRatesMax).toFixed(2));
                this.lineChartData[2].minV.push(parseFloat(collection.sellDDRatesMin).toFixed(2));

                this.lineChartLabels.push(new DatePipe('en-US').transform(collection.liveForexCurrencyDate, 'dd-MM-yyyy HH:mm'));
              });
            } else {
              this.lineChartData[0].data.length = 0;
              // this.lineChartData[1].data.length = 0;
              this.lineChartData[1].data.length = 0;
              this.lineChartData[2].data.length = 0;
            }


          });

      } else if (duration === 'Weekly') {
        // this._MasterService.getForexTrendSell(currencyCode)
        this._MasterService.getForexTrendSellFromBranchId(currencyCode, this.CurrentBranchId)
          .subscribe(data => {
            const resData: any = data;

            this.lineChartData = [{ data: [], label: 'Cash', lineTension: 0, maxV: [], minV: [] },
            // { data: [], label: 'Travellers Cheque', lineTension: 0, maxV: [], minV: [] },
            { data: [], label: 'Prepaid Notes', lineTension: 0, maxV: [], minV: [] },
            { data: [], label: 'TT/DD', lineTension: 0, maxV: [], minV: [] },
            ];

            if (resData.length !== 0) {
              resData.forEach((collection, i) => {
                this.lineChartData[0].data.push(parseFloat(collection.sellBankNotesRatesAvg).toFixed(2));
                this.lineChartData[0].maxV.push(parseFloat(collection.sellBankNotesRatesMax).toFixed(2));
                this.lineChartData[0].minV.push(parseFloat(collection.sellBankNotesRatesMin).toFixed(2));

                // this.lineChartData[1].data.push(parseFloat(collection.sellTravellerChequeRatesAvg).toFixed(2));
                // this.lineChartData[1].maxV.push(parseFloat(collection.sellTravellerChequeRatesMax).toFixed(2));
                // this.lineChartData[1].minV.push(parseFloat(collection.sellTravellerChequeRatesMin).toFixed(2));

                this.lineChartData[1].data.push(parseFloat(collection.sellPrepaidRatesAvg).toFixed(2));
                this.lineChartData[1].maxV.push(parseFloat(collection.sellPrepaidRatesMax).toFixed(2));
                this.lineChartData[1].minV.push(parseFloat(collection.sellPrepaidRatesMin).toFixed(2));

                this.lineChartData[2].data.push(parseFloat(collection.sellDDRatesAvg).toFixed(2));
                this.lineChartData[2].maxV.push(parseFloat(collection.sellDDRatesMax).toFixed(2));
                this.lineChartData[2].minV.push(parseFloat(collection.sellDDRatesMin).toFixed(2));

                this.lineChartLabels.push(new DatePipe('en-US').transform(collection.liveForexCurrencyDate, 'dd-MM-yyyy'));
              });
            } else {
              this.lineChartData[0].data.length = 0;
              // this.lineChartData[1].data.length = 0;
              this.lineChartData[2].data.length = 0;
              this.lineChartData[3].data.length = 0;
            }


          });
      }
    }

    $.magnificPopup.open({
      items: {
        src: '#trend-line-popup'
      },
      type: 'inline'
    });
  }

  setTime() {
    this.today = new DatePipe('en-US').transform(new Date(), 'EEE, d MMM y - h:mm a');
    this.today = this.today + ' (' + momentTimezone().tz(momentTimezone.tz.guess()).format('z') + ')';
    this.today = this.today.replace(' AM ', ' am ').replace(' PM ', ' pm ');
  }

}
