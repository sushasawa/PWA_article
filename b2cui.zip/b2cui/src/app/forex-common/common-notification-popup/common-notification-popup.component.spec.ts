import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonNotificationPopupComponent } from './common-notification-popup.component';

describe('CommonNotificationPopupComponent', () => {
  let component: CommonNotificationPopupComponent;
  let fixture: ComponentFixture<CommonNotificationPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonNotificationPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonNotificationPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
