import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';
import {DpDatePickerModule} from 'ng2-date-picker';
import { MasterService } from '../../../app/services/master.services';
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-rate-alert',
  templateUrl: './rate-alert.component.html',
  styleUrls: ['./rate-alert.component.css']
})



export class RateAlertComponent implements OnInit {
  public invalidsubmitted: any;
  public cityOptions: any;
  public currencyOptions: any;
  public products: any;
  public currencyList: any;
  public frmdate: any = '';
  public todate: any = '';
  public frmdateConfig: any;
  public todateConfig: any;
  public todaysDate: any;
  constructor(private _MasterService: MasterService) {
    this.setDateConfig();
   this.invalidsubmitted = false;
    this.products = [
      { value: 'Prepaid Card', label: 'Prepaid Card' },
      { value: 'Cash', label: 'Cash' },
     // { value: 'Traveller\'s Chaque', label: 'Traveller\'s Chaque' },
      { value: 'Demand Draft', label: 'Demand Draft' }
    ];
    // this._MasterService.getCityList()
    //   .subscribe(data => {
    //     this.cityOptions = data;
    //   });
    if (sessionStorage.getItem('cityList') === null) {
      this._MasterService.getCityList()
          .subscribe(data => {
            this.cityOptions = data;
              sessionStorage.setItem('cityList', JSON.stringify(this.cityOptions));
          }, err => {
              // swal('Oops...', 'Unable to fetch destination list!', 'error');
              Snackbar.show({
                  text: 'Unable to fetch City list!',
                  pos: 'bottom-right',
                  actionTextColor: '#ff4444',
              });
          });
  } else {
    this.cityOptions = JSON.parse(sessionStorage.getItem('cityList'));
  }

  }

  ngOnInit() {
  }

  updateCurrency(city: any) {
      console.log(city + ' ' + city.split('#')[0]);
    this._MasterService.getCurrencyList(1 , city.split('#')[0])
      .subscribe(data => {
        this.currencyList = data;
      }, err => {
        //swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({text: 'Unable to fetch currency list!',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
        });
      });
  }

  createAlert(rateAlert: NgForm, event: Event) {
    event.preventDefault();
    this.invalidsubmitted = rateAlert.invalid;
    rateAlert.value.city = rateAlert.value.city.split('#')[1];
    const payload = rateAlert.value;
    // payload.frmdate = this.frmdate;
    // payload.todate = this.todate;
    payload.equiryDate = new DatePipe('en-US').transform(new Date(), 'yyyy-MM-dd');
    payload.EnquiryNum = Math.floor(Date.now() / 1000);
    // console.log(payload);
    if (rateAlert.valid) {
      this._MasterService.createAlert(payload)
        .subscribe(data => {
          const result: any = data;
          if (result.success) {
            //swal('Alert Created', '', 'success');
            Snackbar.show({text: 'Alert Created',
              pos: 'bottom-right' ,
              actionTextColor: '#05ff01',
            });
            rateAlert.reset();
          }
        });
    }
  }

  setDateConfig() :void{
    let maxDate = '', 
        minDate = '';
    this.todaysDate = this._MasterService.getTodaysDate();
    
    this.todateConfig = {
      format: 'DD-MM-YYYY',
      min : this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    }
    this.frmdateConfig = {
      format: 'DD-MM-YYYY',
      max : maxDate,
      min : this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    }
  }

  dataChangeStart(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.frmdate = event;
        this.todateConfig = {
          format: 'DD-MM-YYYY',
          min : event,
          showMultipleYearsNavigation: true,
          disableKeypress: true,
        }
    }
  }

  dataChangeEnd(event): void {
    if (event !== undefined && typeof event !== 'object') { 
      this.todate  = event;
        this.frmdateConfig = {
          format: 'DD-MM-YYYY',
          max : event,
          min : this.todaysDate,
          showMultipleYearsNavigation: true,
          disableKeypress: true,
        }
    }
  }
}
