import { Component, OnInit, Input, Inject } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import * as sha from 'sha.js';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { DpDatePickerModule } from 'ng2-date-picker';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

declare var jquery: any;
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-common-review-user-details',
  templateUrl: './common-review-user-details.component.html',
  styleUrls: ['./common-review-user-details.component.css']
})
export class CommonReviewUserDetailsComponent implements OnInit {
  public userSessionInfo: any;
  public userSessionInfoTravellers: any;
  public sessionDataProcess: any;
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public b2bNavLink: any;
  public wizardStepNumber: any;
  public userInfo:    any;
  public configsMin:  any = [];
  public configsMax:  any = [];
  public disabledArr: any = [];
  public todaysDate: any;
  public selIndex: any;
  public airlineNames: any;
  public commonDetails: any;
  public _primaryComp: any;
  public travellerOfficeAddress: any = [];
  public skipAdhaarValidationFlag: any = false;
  public validationFields: any = ["firstName", "value", "lastName", "dateOfBirth", "gender", "nationality", "mothersMaidenName", "PAN", "passportNumber", "dateOfIssue", "placeOfIssue", "expiryDate", "passportAddress", "flatNumber", "buildingName", "streetName", "landmark", "area", "city", "state", "pincode", "contactDetails", "mobileNo", "emailId"];
  public ignore: any = ['invoiceNo', 'userId', 'checkCondition', 'middleName', 'adharCardNo', 'ParentId', 'address', 'isPassportAddressAsAdhar', 'adharAddress', 'alternateContactDetails', 'officeAddress', 'officeContactDetails', 'password', 'confirmPassword', 'parent', 'currentAddressAs', 'otherAddress'];
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private route: ActivatedRoute, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this._document.title = 'Review Your Details';
    this.skipAdhaarValidationFlag = this.masterService.getSkipAdhaarValidationFlag();
    // tslint:disable-next-line:max-line-length
    this._primaryComp = '/' + navUrl.navUrl();
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'Review Your Details'});
  }

  ngOnInit(): void {
    this.sessionDataProcess = this.route.snapshot.data.sessData.sessionDataProcess;
    this.sessionDataProcessScreen = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.nextLink = this.route.snapshot.data.nextLink;
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;
    this.userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
    $('body').attr('id', '');
    this.masterService.getAirlineNames()
      .subscribe(data => {
        this.airlineNames = data;
      });
    initDocument();
    this.userSessionInfo = JSON.parse(SessionHelper.getSession(this.sessionDataProcess));
    console.log(this.userSessionInfo);
    this.userSessionInfoTravellers = this.userSessionInfo[this.sessionDataProcessScreen].traveller;
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      traveller.selected = false;
      this.setDateConfig(traveller.travellingDetails.dateOfTravel, traveller.travellingDetails.dateOfArrival, index);
    });
    this.userSessionInfoTravellers[0].selected = true;
    this.concatOfficeAddress();
    
  }

  setDateConfig(startDate, endDate, index) {
    let maxDate = '',
      minDate = '';
    this.todaysDate = this.masterService.getTodaysDate();
    if (startDate !== '') {
      minDate = startDate;
    } else {
      minDate = this.todaysDate;
    }
    if (endDate !== '') {
      maxDate = endDate;
    }
    this.configsMin[index] = {
      format: 'DD-MM-YYYY',
      min: minDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.configsMax[index] = {
      format: 'DD-MM-YYYY',
      max: this.masterService.addDateMoment(this.todaysDate, 60, 'days'),
      min: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }


  dataChangeStart(event, i): void {

    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].travellingDetails.dateOfTravel = event;
      this.userSessionInfoTravellers[i].travellingDetails.dateOfTravel = event;
      SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));

        this.configsMin[i] = {
          format: 'DD-MM-YYYY',
          min : event,
          showMultipleYearsNavigation: true,
          disableKeypress: true,
        };
    }
    // tslint:disable-next-line:one-line
    if (i === 0 && this.commonDetails === true){
      this.userSessionInfoTravellers.forEach((traveller, index) => {
        // tslint:disable-next-line:one-line
        if (index !== 0){
          this.userSessionInfoTravellers[index].travellingDetails.dateOfTravel = event;
        }
      });
    }
  }

  dataChangeEnd(event, i): void {
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].travellingDetails.dateOfArrival = event;
      this.userSessionInfoTravellers[i].travellingDetails.dateOfArrival = event;
      SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
      // tslint:disable-next-line:prefer-const
      let validationDate = this.masterService.addDateMoment(this.todaysDate, 60, 'days'),
        // tslint:disable-next-line:prefer-const
        diff = this.masterService.getDateDifference(validationDate, event), validDate;
      if (diff > 0) {
        validDate = event;
      } else {
        validDate = validationDate;
      }
      this.configsMax[i] = {
        format: 'DD-MM-YYYY',
        max: validDate,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
        min: this.todaysDate
      };
    }

    if (i === 0 && this.commonDetails === true) {
      this.userSessionInfoTravellers.forEach((traveller, index) => {
        if (index !== 0) {
          this.userSessionInfoTravellers[index].travellingDetails.dateOfArrival = event;
        }
      });
    }
  }

  // tslint:disable-next-line:one-line
  airlineNameChanged(event, index){
    // tslint:disable-next-line:one-line
    if (index === 0 && this.commonDetails === true){
      // tslint:disable-next-line:no-shadowed-variable
      this.userSessionInfoTravellers.forEach((traveller, index) => {
        // tslint:disable-next-line:one-line
        if (index !== 0){
          this.userSessionInfoTravellers[index].travellingDetails.airlineName = event;
          this.userSessionInfo[this.sessionDataProcessScreen].traveller[index].travellingDetails.airlineName = event;
        }
      });
      SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
    }
  }



  selectTraveller(travellerIndex) {
    this.selIndex = travellerIndex;
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }

  // tslint:disable-next-line:one-line
  checkForNewTraveller(){
    for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {
      const currentTravellerInfo = this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo;
      // tslint:disable-next-line:max-line-length
      if (!this.validateDetails(currentTravellerInfo)) {
        Snackbar.show({
          text: 'Oops!,Some of the required fields are empty',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        this.selIndex = i;
        setTimeout(() => {
          this.onEditClick();
        }, 100);
        return false;
      }
    }
    return true;
  }

  onSubmit() {
    // tslint:disable-next-line:one-line
    if (!this.checkForNewTraveller()){
      return;
    }

    // ISSUE START
    // if (this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.password === undefined) {
      if (this.userSessionInfo[this.sessionDataProcessScreen].edited === true) {

      const sendRegistrationInfo = [];
      for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {

        // tslint:disable-next-line:prefer-const
        let password: any, currentTravellerInfo = this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo;
        if (i === 0) {
          if (currentTravellerInfo.userId === '') {
            password = currentTravellerInfo.password;
            password = sha('sha256').update(password, 'utf8').digest('hex');
            currentTravellerInfo.password = '';
            currentTravellerInfo.password = password;
          }
          currentTravellerInfo.parent = true;

        } else {
          currentTravellerInfo.parent = false;
        }
        currentTravellerInfo.travellerNo = i;

        sendRegistrationInfo.push(currentTravellerInfo);
      }


      if (sendRegistrationInfo[0].userId === '') {
        this.masterService.setUserRegistration(sendRegistrationInfo)
          .subscribe(data => {
            const result: any = data;

            for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {
              if (i === 0) {
                this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.userId = result.data[i].ParentId;
               // below code is required for transaction
                this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.parentId = result.data[i].ParentId;
              } else {
                // this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.userId = result.data[i - 1].childId;
                // // below code is required for transaction
                // this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.ParentId = result.data[i - 1].ParentId;

                // tslint:disable-next-line:max-line-length
                this.userSessionInfo[this.sessionDataProcessScreen].traveller[result.data[i - 1].travellerNo].registrationInfo.userId = result.data[i - 1].childId;
                // below code is required for transaction
                // tslint:disable-next-line:max-line-length
                this.userSessionInfo[this.sessionDataProcessScreen].traveller[result.data[i - 1].travellerNo].registrationInfo.ParentId = result.data[i - 1].ParentId;
              }
            }
            SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));

            localStorage.setItem('accessToken', result.token);

            this.userInfo.loggedin = true,
            this.userInfo.uid = sendRegistrationInfo[0].userId;
            this.userInfo.userName = sendRegistrationInfo[0].firstName.value + ' ' + sendRegistrationInfo[0].middleName + ' '
              + sendRegistrationInfo[0].lastName;
            SessionHelper.setSession('userInfo', JSON.stringify(this.userInfo));
            this.masterService.getTemporaryOrderNumber()
            .subscribe(retData => {
                const retResult: any = retData;
                this.userSessionInfo.temporaryOrderNumber = retResult.response.OrderNumber;
                this.userSessionInfo.userId = this.userInfo.uid;
            });
          });
      } else {
        this.masterService.updateUserRegistration(sendRegistrationInfo)
          .subscribe(data => {

            const retData: any = data;
            this.userInfo.loggedin = true,
            this.userInfo.uid = sendRegistrationInfo[0].userId;
            this.userInfo.userName = sendRegistrationInfo[0].firstName.value + ' ' + sendRegistrationInfo[0].middleName + ' '
              + sendRegistrationInfo[0].lastName;
            SessionHelper.setSession('userInfo', JSON.stringify(this.userInfo));


            const result: any = data;
            if (result.hasOwnProperty('newUserRecords')) {

              for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {
                // console.log("####HERE",result.newUserRecords.data[i]);
                if (i === 0) {
                  // tslint:disable-next-line:max-line-length
                  this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.userId = result.newUserRecords.data[0].ParentId;
                } else {
                  // tslint:disable-next-line:max-line-length
                  // this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.userId = result.newUserRecords.data[i - 1].childId;
                  // tslint:disable-next-line:max-line-length
                  // this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.ParentId = result.newUserRecords.data[i - 1].ParentId;

                  // tslint:disable-next-line:max-line-length
                  this.userSessionInfo[this.sessionDataProcessScreen].traveller[result.newUserRecords.data[i - 1].travellerNo].registrationInfo.userId = result.newUserRecords.data[i - 1].childId;
                  // below code is required for transaction
                  // tslint:disable-next-line:max-line-length
                  this.userSessionInfo[this.sessionDataProcessScreen].traveller[result.newUserRecords.data[i - 1].travellerNo].registrationInfo.ParentId = result.newUserRecords.data[i - 1].ParentId;
                }
              }
              SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
            }


          });
      }

     /// ISSUE END
    }



    for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {
      if (this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].prepaidCard) {
        if (this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.mothersMaidenName.value === '') {
          // swal('Oops', 'Some of the required fields are empty !', 'error');
          Snackbar.show({
            text: 'Oops!,Some of the required fields are empty',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
          if (this.processType === 'Buy') {
            this.router.navigateByUrl(this._primaryComp + `/buy/create-account`);
            return;
          } else if (this.processType === 'Sell') {
            this.router.navigateByUrl(this._primaryComp + `/sell/create-account`);
            return;
          } else if (this.processType === 'Reload') {
            this.router.navigateByUrl(this._primaryComp + `/reload-card/create-account`);
            return;
          } else if (this.processType === 'Send') {
            this.router.navigateByUrl(this._primaryComp + `/send-money/create-account`);
            return;
          }
        }
      }
    }

    this.b2bNavLink = this.userSessionInfo['nextLink'];
    this.userSessionInfo['nextLink'] = this.nextLink;
    this.updateSession();
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    if (this.userSessionInfo.redirectToNextLink && this.b2bNavLink) {
      this.userSessionInfo.redirectToNextLink = false;
      this.updateSession();
      this.router.navigateByUrl(this._primaryComp + this.b2bNavLink);
    } else if (this.processType !== 'Sell' && this.processType !== 'Send') {
      setTimeout(function () {
        $.magnificPopup.open({
          items: {
            src: '#details-traveller-popup'
          },
          type: 'inline'
        });
      }, 5);
    } else {
      this.router.navigateByUrl(this._primaryComp + this.nextLink);
    }
  }



  updateSession() {
    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
  }

  onTravellerSubmit() {

    if (this.processType !== 'buy') {
    this.userSessionInfo[this.sessionDataProcessScreen].traveller.forEach(element => {
      if (element.demandDraft) {
        this.nextLink = '/buy/transaction-details';
      }
    });
  }

    console.log(this.userSessionInfoTravellers.length);
    // console.log(this.userSessionInfoTravellers[0].travellingDetails.ticketNumber);

    // if (this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].travellingDetails.ticketNumber === '') {
    // }
    // tslint:disable-next-line:one-line

    if (this.processType !== 'Send') {
      for (let i = 0; i <= this.userSessionInfoTravellers.length - 1; i++) {
        // if (this.userSessionInfoTravellers[i].travellingDetails.ticketNumber === '') {
        //   return Snackbar.show({text: 'Oops!,Ticket number is empty',
        //   pos: 'bottom-right' ,
        //   actionTextColor: '#ff4444',
        //  });
        //   // swal('Oops', 'Ticket number is empty!', 'error');   // console.log('Ticket number empty');
        // }
        // if (this.userSessionInfoTravellers[i].travellingDetails.airlineName === '') {
        //   return Snackbar.show({text: 'Oops!,Airline Name is empty',
        //   pos: 'bottom-right' ,
        //   actionTextColor: '#ff4444',
        //  });
        //   // swal('Oops', 'Airline Name is empty!', 'error');
        // }
        if (this.userSessionInfoTravellers[i].travellingDetails.dateOfTravel === '' && this.processType !== 'Reload') {
          return Snackbar.show({
            text: 'Oops!,Date of Travel is empty',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
          // return swal('Oops', 'Date of Travel is empty!', 'error');
        }
      }
    }
    $.magnificPopup.close();
    this.userSessionInfo[this.sessionDataProcessScreen].traveller = this.userSessionInfoTravellers;
    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
    this.router.navigateByUrl(this._primaryComp + this.nextLink);
  }

  onEditClick() {
    switch (this.processType) {
      case 'Buy':
        this.router.navigate([this._primaryComp + '/buy/create-account'], {queryParams: {traveller: this.selIndex}});
        break;
      case 'Sell':
        this.router.navigate([this._primaryComp + '/sell/create-account'], {queryParams: {traveller: this.selIndex}});
        break;
      case 'Reload':
        this.router.navigate([this._primaryComp + '/reload-card/create-account'], {queryParams: {traveller: this.selIndex}});
        break;
      case 'Send':
        this.router.navigate([this._primaryComp + '/send-money/create-account'], {queryParams: {traveller: this.selIndex}});
        break;
      default:
        break;
    }
  }


  onSaveAndTemporaryExit() {
    $.magnificPopup.close();
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession(this.sessionDataProcess);
    switch (this.processType) {
      case 'Buy':
        this.router.navigateByUrl(this._primaryComp + `/buy`);
        //   /register-login
        break;
      case 'Sell':
        this.router.navigateByUrl(this._primaryComp + `/sell`);
        break;
      case 'Reload':
        this.router.navigateByUrl(this._primaryComp + `/reload-card`);
        break;
      case 'Send':
        this.router.navigateByUrl(this._primaryComp + `/send-money`);
        break;
      default:
        break;
    }
  }

  // tslint:disable-next-line:one-line
  commonDetailsChnecked(event){
    const dateOfArrival = this.userSessionInfoTravellers[0].travellingDetails.dateOfArrival,
    dateOfTravel = this.userSessionInfoTravellers[0].travellingDetails.dateOfTravel,
    airlineName = this.userSessionInfoTravellers[0].travellingDetails.airlineName;
    // tslint:disable-next-line:one-line
    if (event === true){
      this.userSessionInfoTravellers.forEach((traveller, index) => {
        // tslint:disable-next-line:one-line
        if (index !== 0){
          this.disabledArr[index] = true;
          this.userSessionInfoTravellers[index].travellingDetails.dateOfArrival = dateOfArrival;
          this.userSessionInfoTravellers[index].travellingDetails.dateOfTravel = dateOfTravel;
          this.userSessionInfoTravellers[index].travellingDetails.airlineName = airlineName;
        } else {
          this.disabledArr[index] = false;
        }
      });
    } else {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller.forEach((traveller, index) => {
          this.disabledArr[index] = false;
      });
    }
    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
  }

  concatOfficeAddress() {
    const nonAdressParam = ['conpanyName', 'companyName', 'designation', 'companyDivision', 'pincode'];
    this.travellerOfficeAddress = [];
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      // tslint:disable-next-line:prefer-const
      let addressText = '', officeAddress = traveller.registrationInfo.officeAddress, counter = 0, pincodeAdded = false;
      // tslint:disable-next-line:forin
      for (const travellerData in officeAddress) {
        if (nonAdressParam.indexOf(travellerData) === -1 && officeAddress[travellerData]) {
          addressText += officeAddress[travellerData] + ', ';
          counter++;
        }

        if (travellerData === 'pincode' && officeAddress[travellerData]) {
          if (counter > 0) {
            addressText = this.replaceLastCommaWith(addressText, '-') + officeAddress[travellerData];
          } else {
            addressText += officeAddress[travellerData];
          }
          pincodeAdded = true;
        }
      }
      if ((counter > 0 && pincodeAdded) || pincodeAdded) {
        addressText += '.';
      } else if (counter > 0) {
        addressText += this.replaceLastCommaWith(addressText, '.');
      }
      this.travellerOfficeAddress[index] = addressText;
    });

  }

  replaceLastCommaWith(text, element) {
    const pos = text.lastIndexOf(',');
    return text.substring(0, pos) + ' ' + element + ' ' + text.substring(pos + 1);
  }

  validateDetails(obj) {
    var found = [], isNotEmpty;
    for (var property in obj) {
      if (this.validationFields.indexOf(property) !== -1) { // this.ignore is list of ignored/non madatory elements from registrationInfo object
        if (obj[property] !== null && typeof obj[property] == "object") {
          isNotEmpty = this.validateDetails(obj[property]); // again call validateDetails if nested object found
          if (!isNotEmpty) {
            return false;
          }
        } else {
          if (!obj[property]) {
            return false;
          }
        }
      }
    }
    return true;
  }


  //  maskAdhar(adharNum){
  //   // this.adharNum  = adharNum.toString();
  //   var mainStr = '';
  //   for(var i = 0 ; i < adharNum.length ; i++){
  //             if(i > 5){
  //                  mainStr += adharNum[i];
  //        }else{
  //                 mainStr += '*';
  //         }
  //   }
  //   return mainStr;
  //   }


}
