import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonReviewUserDetailsComponent } from './common-review-user-details.component';

describe('CommonReviewUserDetailsComponent', () => {
  let component: CommonReviewUserDetailsComponent;
  let fixture: ComponentFixture<CommonReviewUserDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonReviewUserDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonReviewUserDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
