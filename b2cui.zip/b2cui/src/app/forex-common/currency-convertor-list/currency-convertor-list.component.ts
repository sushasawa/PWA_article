import { Component, OnInit } from '@angular/core';
import { MasterService } from '../../services/master.services';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import * as momentTimezone from 'moment-timezone';
import { forEach } from '@angular/router/src/utils/collection';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { SessionHelper } from '../../helpers/session-helper';

import { DatePipe } from '@angular/common';
import { Console } from '@angular/core/src/console';
import { Meta } from '@angular/platform-browser';
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;
const newLocal = 'liveRate';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'currency-convertor-list',
  templateUrl: './currency-convertor-list.component.html',
  styleUrls: ['./currency-convertor-list.component.css']
})
export class CurrencyConvertorListComponent implements OnInit, OnDestroy {
  public branchId: any = SessionHelper.getLocal('branchIdFromOverview');
  public currencyData: any;
  public _primaryComp: any;
  constructor(private _MasterService: MasterService, private meta: Meta, private navUrl: NavigatePathService) {
    this._primaryComp = '/' + navUrl.navUrl();
  }

  ngOnInit() {
    this._MasterService.getLiveForexDataFromBranchId(this.branchId)
      .subscribe(data => {
        this.currencyData = data;
        this.currencyData = this.currencyData.slice(0, 7);
      }, err => {
        // Snackbar.show({
        //   text: 'Unable to fetch currency list!',
        //   pos: 'bottom-right',
        //   actionTextColor: '#ff4444',
        // });
      });
  }

  // tslint:disable-next-line:one-line
  currencyClicked(currencyIndex, currencyList){
    console.log(currencyIndex, currencyList);
  }

  ngOnDestroy() {

  }

}
