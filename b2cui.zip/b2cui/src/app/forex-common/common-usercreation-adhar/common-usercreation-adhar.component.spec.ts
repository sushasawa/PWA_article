import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonUsercreationAdharComponent } from './common-usercreation-adhar.component';

describe('CommonUsercreationAdharComponent', () => {
  let component: CommonUsercreationAdharComponent;
  let fixture: ComponentFixture<CommonUsercreationAdharComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonUsercreationAdharComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonUsercreationAdharComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
