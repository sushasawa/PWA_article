import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellSummaryComponent } from './sell-summary.component';

describe('SellSummaryComponent', () => {
  let component: SellSummaryComponent;
  let fixture: ComponentFixture<SellSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
