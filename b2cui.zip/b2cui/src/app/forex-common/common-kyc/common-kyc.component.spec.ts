import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonKycComponent } from './common-kyc.component';

describe('CommonKycComponent', () => {
  let component: CommonKycComponent;
  let fixture: ComponentFixture<CommonKycComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonKycComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonKycComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
