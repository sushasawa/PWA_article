import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { NavigatePathService } from '../../../app/services/navigate-path.service';


declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;
@Component({
  selector: 'app-common-kyc',
  templateUrl: './common-kyc.component.html',
  styleUrls: ['./common-kyc.component.css']
})
export class CommonKycComponent implements OnInit {
  @Input() currentSession: any;
  @Input() pageSession: any;
  @Input() nextLink: any;
  @Input() processType: any;
  @Output() setOrderDocumentStatus: EventEmitter<any> = new EventEmitter<any>();
  public userSessionInfo: any;
  public SessionInfo: any;
  public DocCheckList: any;
  public formdata: any;
  public docs: Array<any>;
  public documentScr: any;
  public close = document.getElementsByClassName('close')[0];
  public fileupload: Array<any>;
  public currentUserId: any;
  public showModal: Boolean;
  public showSnackBar: Boolean;
  public snackBarText: any;
  public invalidsubmitted: any;
  public KycMsg: any = 'Fetching Documents Checklist Please wait...';
  public isRequestedFromMyOrders: Boolean;
  public MAX_DOC_SIZE: any = 10000000;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private sanitizer: DomSanitizer, private route: Router) {
    console.log('COMMON KYC LOADED...');
    const UserInfo: any = SessionHelper.getSession('userInfo');
    if (UserInfo !== null || UserInfo !== undefined) {
      this.currentUserId = JSON.parse(UserInfo).uid;
    }
    this.showModal = false;
    this.showSnackBar = false;
    this.isRequestedFromMyOrders = false;
  }

  ngOnInit() {
    this.KycMsg = 'Fetching Documents Checklist Please wait...';
    // tslint:disable-next-line:max-line-length
    if ((typeof this.pageSession === 'string' && this.pageSession) && (typeof this.currentSession === 'string' && this.currentSession)) {
      this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession));
      this.userSessionInfo = this.SessionInfo[this.currentSession];
      this.userSessionInfo.traveller.map((traveller, index) => {
        traveller.selected = false;
        this.masterService.getDocumentCheckList(this.SessionInfo).subscribe((data) => {
          const checklistData = data[index].Checklist;
          this.masterService.getUserDocuments(traveller.registrationInfo.userId).subscribe((uploadedDocs) => {
            const uploadedDocsResult: any = uploadedDocs;
            checklistData.map((checklist) => {
              uploadedDocsResult.response.map((docs, docsIndex) => {
                if (checklist.Doc.toUpperCase() === docs.type.toUpperCase() ||
                  checklist.Doc.toUpperCase().indexOf(docs.type.toUpperCase()) !== -1) {
                  checklist.showView = true;
                  checklist.imageUrl = docs.imageUrl;
                }
              });
            });
          });
          traveller.DocCheckList = checklistData;
        }, (error) => {
          this.KycMsg = 'Checklist Not Available';
        });
      });
      this.userSessionInfo.traveller[0].selected = true;
    }

  }


  initKyc(pageSession) {
    console.log('initKyc called');
   // console.log(pageSession);
    this.isRequestedFromMyOrders = true;
    this.SessionInfo = pageSession;
    this.userSessionInfo = this.SessionInfo[this.SessionInfo.type];
    let counter: any = this.userSessionInfo.traveller.length;
    this.userSessionInfo.traveller.map((traveller, index) => {
      traveller.selected = false;
      this.masterService.getDocumentCheckList(this.SessionInfo).subscribe((data) => {
        const checklistData = data[index].Checklist;
        counter = counter + checklistData.length;
        this.masterService.getUserDocuments(traveller.registrationInfo.userId).subscribe((uploadedDocs) => {
          const uploadedDocsResult: any = uploadedDocs;
          counter = counter + uploadedDocsResult.response.length;
        //  console.log(counter);
          checklistData.map((checklist) => {
            uploadedDocsResult.response.map((docs, docsIndex) => {
              if (checklist.Doc.toUpperCase() === docs.type.toUpperCase() ||
                checklist.Doc.toUpperCase().indexOf(docs.type.toUpperCase()) !== -1) {
                checklist.showView = true;
                checklist.uploaded = true;
                checklist.imageUrl = docs.imageUrl;
                this.shouldOrderBeCLosed(this.userSessionInfo);
              }
            });
          });
        });
        traveller.DocCheckList = checklistData;
      }, (error) => {
        this.KycMsg = 'Checklist Not Available';
      });
    });
    this.userSessionInfo.traveller[0].selected = true;
    $.magnificPopup.open({
      items: {
        src: '#upload-document'
      },
      type: 'inline'
    });
  }

  uploadDoc(ele: any, doc: any, controlIndex: any, travellerIndex: any) {
    if (this.currentUserId) {

      Snackbar.show({
        text: 'Uploading...',
        pos: 'bottom-right',
        actionTextColor: '#00880d',
        duration: 100000
      });
      const docs = ele.target.files[0];
      this.formdata = new FormData();
      const doctype = { 'doc': doc };
      const userid = { 'id': this.currentUserId };
      this.formdata.append('Doctype', JSON.stringify(doctype));
      this.formdata.append('userdata', JSON.stringify(userid));
      const fileValidation = (docs.type.indexOf('pdf') !== -1 || docs.type.indexOf('jpeg') !== -1 || docs.type.indexOf('png') !== -1
        || docs.type.indexOf('gif') !== -1) && docs.size <= this.MAX_DOC_SIZE;
      if (fileValidation) {
        this.formdata.append('sampleFile', docs, docs.name);
        this.masterService.uploadTravellerDocuments(this.formdata)
          .subscribe((data) => {
            const result: any = data;
            this.formdata = {};
            doc.imageUrl = result.response.imgUrl;
            doc.showView = true;
            doc.uploaded = true;
            Snackbar.show({
              text: 'File Uploaded Successfully...',
              pos: 'bottom-right',
              actionTextColor: '#00880d',
            });
            this.shouldOrderBeCLosed(this.userSessionInfo);
          }, (error) => {
            doc.showView = false;
            Snackbar.show({
              text: 'Error Uploading File Please try Again.',
              pos: 'bottom-right',
              actionTextColor: '#00880d',
            });
            this.shouldOrderBeCLosed(this.userSessionInfo);
          });
      } else {
        // swal('', 'Supports JPEG, PNG and GIF. The file size should not exceed 500 KB.', 'error');
        Snackbar.show({
          text: 'Supports JPEG, PNG , PDF and GIF. The file size should not exceed 10 MB.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }
    } else {
      Snackbar.show({
        text: 'You are not Authorized.',
        pos: 'bottom-right',
        actionTextColor: '#00880d',
      });
    }
  }

  viewDoc(Doc: any) {
    if (Doc.hasOwnProperty('imageUrl')) {
      console.log('openPopup');
      const imageValidation = Doc.imageUrl.indexOf('.jpg') !== -1 || Doc.imageUrl.indexOf('.png') !== -1
        || Doc.imageUrl.indexOf('.gif') !== -1;
      if (imageValidation) {
        this.documentScr = Doc.imageUrl;
        this.showModal = true;
      } else if (Doc.imageUrl.indexOf('.pdf') !== -1) {
        this.showModal = false;
        this.documentScr = Doc.imageUrl;
        const newtab = window.open(this.documentScr, '_blank');
        newtab.focus();
      }
    } else {
      this.showModal = false;
    }
  }
  removeDoc(Doc: any) {
    console.log(Doc);
    Doc.showView = false;
    const payload: any = {};
    console.log(this.userSessionInfo);
    payload.type = Doc.Doc;
    payload.userId = this.currentUserId;
    Snackbar.show({
      text: 'Removing...',
      pos: 'bottom-right',
      actionTextColor: '#00880d',
    });
    console.log(payload);
    if (this.currentUserId !== undefined || this.currentUserId !== null) {
      this.masterService.deleteDocument(payload).subscribe((data) => {
       const result: any = data;
        if (result.success) {
          this.shouldOrderBeCLosed(this.userSessionInfo);
          Snackbar.show({
             text: 'Removed Successfully...',
             pos: 'bottom-right',
             actionTextColor: '#00880d',
          });
        } else {
          this.showSnackBar = true;
          this.snackBarText = result.message;
          this.closeSnackBar();
          this.shouldOrderBeCLosed(this.userSessionInfo);
        }
        //  this.closeSnackBar();
      }, (error) => {
        Snackbar.show({
          text: 'Error Removing File Please try Again.',
          pos: 'bottom-right',
          actionTextColor: '#00880d',
        });
        this.shouldOrderBeCLosed(this.userSessionInfo);
      });
    }
  }

  closeDocpopup() {
    this.showModal = false;
  }

  closePopupAuto() {
    setTimeout(() => {
      this.showSnackBar = false;
    }, 2000);
  }
  closeSnackBar() {
    this.showSnackBar = false;
    this.snackBarText = '';
  }
  selectTraveller(travellerIndex) {

    this.userSessionInfo.traveller.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfo.traveller[travellerIndex].selected = true;
    if (this.userSessionInfo.traveller[travellerIndex].lead) {
      this.currentUserId = this.userSessionInfo.traveller[travellerIndex].registrationInfo.parentId;
    } else {
      this.currentUserId = this.userSessionInfo.traveller[travellerIndex].registrationInfo.userId;
    }
  }

  submitAndRedirect(event: Event, kycForm: NgForm) {
    $.magnificPopup.close();
    event.preventDefault();
    //  this.invalidsubmitted = kycForm.invalid;
    console.log(kycForm);
    //  this.route.navigateByUrl(this._primaryComp + this.nextLink);  // Disabled navigation to avoid skiping of steps.
  }

  shouldOrderBeCLosed(UserSession) {
  // console.log('called');
   //  console.log(UserSession);
    let isAllDocumentsUpload: Boolean = false;
    for (let travellerIndex = 0 ; travellerIndex < UserSession.traveller.length ; travellerIndex++) {
          // tslint:disable-next-line:max-line-length
          for (let DocCheckListIndex = 0 ; DocCheckListIndex < UserSession.traveller[travellerIndex].DocCheckList.length ; DocCheckListIndex++) {
                  if (UserSession.traveller[travellerIndex].DocCheckList[DocCheckListIndex].uploaded) {
                    isAllDocumentsUpload = true;
                  }else {
                    isAllDocumentsUpload = false;
                     break;
                  }
          }
          if (isAllDocumentsUpload === false) {
                break;
          }
    }
    // UserSession.traveller.map((traveller) => {
    //   traveller.DocCheckList.map((Doc) => {
    //     if (Doc.uploaded) {
    //       isAllDocumentsUpload = true;
    //     }
    //   });
    // });



    console.log('IS EVERY THING UPLOADED : ' + isAllDocumentsUpload);
    if (this.isRequestedFromMyOrders) {
      this.setOrderDocumentStatus.emit(isAllDocumentsUpload);
    }
  }
}
