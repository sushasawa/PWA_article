import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var $: any;

@Component({
  selector: 'app-common-register-login-adhar',
  templateUrl: './common-register-login-adhar.component.html',
  styleUrls: ['./common-register-login-adhar.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class CommonRegisterLoginAdharComponent implements OnInit {
  currentSession: any;
  userSessionInfo: any;
  SessionInfo: any;
  pageSession: any;
  nextLink: any;
  public adharNum = '';
  public termsAcceptance = false;
  public otp;
  public currentlocation: any;
  private txnId;
  public _primaryComp: any;
  constructor(private location: Location, private navUrl: NavigatePathService, private masterService: MasterService, private router: Router, private route: ActivatedRoute) {
    this.navUrl.setNavUrl();
    this._primaryComp = '/' + navUrl.navUrl();
    this.currentlocation = this.location.path().split('/');
  }

  ngOnInit() {
    $('body').attr('id', '');
    initDocument();
    console.log('Common login adhar component loaded');
    this.nextLink = this.route.snapshot.data.nextLink;
    this.pageSession = this.route.snapshot.data.sessData.sessionDataProcess;
    this.currentSession = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession));
    this.userSessionInfo = this.SessionInfo[this.currentSession];
  }

  aadharValidation(): void {
    if (!this.termsAcceptance) {
      swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
    } else {
      const regexForAadhar = /^\d{12}$/;

      if (regexForAadhar.test(this.adharNum)) {
        this.sendOtp();
      } else {
        swal('Error', 'Enter valid Aadhaar number', 'error');
      }
    }
  }

  sendOtp() {
    this.masterService.sendOtp({ adharNo: this.adharNum })
      .subscribe(res => {
        const response: any = res;
        console.log(response);
        if (response.ReturnType === 'Error') {
          swal('Error', response.ReturnMessage, 'error');
        } else if (response.ReturnType === 'Success') {
          this.txnId = response.TxnID;

          $.magnificPopup.open({
            items: {
              src: '#otp-popup'
            },
            type: 'inline'
          });
        }
      });
  }

  validateAadhaarOtp() {
    // routerLink="/buy/create-account-adhar"
    this.masterService.validateOtp({
      adharNo: this.adharNum,
      otpCode: this.otp,
      txnId: this.txnId
    }).subscribe(res => {
      const response: any = res;
      console.log(response);
      if (response.ReturnValue === 'n') {
        swal('Error', response.ReturnMessage, 'error');
      } else if (response.ReturnValue === 'y') {
        swal('Authenticated', 'Aadhaar number was verified successfully', 'success');
        $.magnificPopup.close();
        SessionHelper.setSession('userInfo', JSON.stringify({ loggedin: true }));
        this.masterService.loginUser({ AadharNumber: this.adharNum })
          .subscribe(data => {
            const result: any = data;
            console.log(data);
            const userinfo = {
              'loggedin': result.success,
              'uname': result.response[0][0].EmailId,
              'uid': result.response[0][0].Id,
              'userName': result.response[1][0].firstName + ' ' + result.response[1][0].middleName + ' ' + result.response[1][0].lastName
            };
            // sessionStorage.setItem('userInfo', setSession JSON.stringify(userinfo));
            SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
            this.masterService.getTemporaryOrderNumber()
              .subscribe(resp => {
                const respo: any = resp;
                console.log(resp);
                this.SessionInfo.temporaryOrderNumber = respo.response.OrderNumber;
                this.SessionInfo.userId = userinfo.uid;
                SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));


                if (this.userSessionInfo.traveller.length === 1) {
                  this.router.navigateByUrl(this._primaryComp + this.nextLink);
                }
              });
          }, err => {
            console.log('error');
            console.log(err);
            console.log(err.status);

            if (err.status === 401) {
              this.router.navigateByUrl(this._primaryComp + '/' + this.currentlocation[2] + '/create-account-adhar');
            }
          });
        // this.router.navigateByUrl(this._primaryComp + '/buy/create-account-adhar');
      }
    });
  }
}
