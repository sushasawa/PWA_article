import { Component, OnInit, Input, Inject } from '@angular/core';
import { Location } from '@angular/common';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-common-checklist',
  templateUrl: './common-checklist.component.html',
  styleUrls: ['./common-checklist.component.css']
})
export class CommonChecklistComponent implements OnInit {
  public DocCheckList;
  public userSessionInfoChecklist: any;
  public userSessionInfoTravellers: any;
  public List = ['Cash', 'Travellers Cheque', 'Demand Draft'];
  public reqData: any = [];
  public checklistDataListFromDb;

  public sessionDataProcess: any;
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public wizardStepNumber: any;
  public SessionInfo: any;
  public pageSession: any;
  public _primaryComp: any;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private route: ActivatedRoute, private router: Router, private location: Location, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    console.log('CHECKLIST COMPONENT LOADED FIRST');
    this._primaryComp = '/' + navUrl.navUrl();
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    let documentTitle = '';
    this.sessionDataProcess = this.route.snapshot.data.sessData.sessionDataProcess;
    this.sessionDataProcessScreen = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.nextLink = this.route.snapshot.data.nextLink;
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;
    switch (true) {
      case (this.processType === 'Buy'): documentTitle = 'Buy Forex';
        break;
      case (this.processType === 'Sell'): documentTitle = 'Sell Forex';
        break;
      case (this.processType === 'Reload'): documentTitle = 'Reload card';
        break;
      case (this.processType === 'Send'): documentTitle = 'Send Money Abroad';
    }
    this._document.title = 'Document checklist for ' + documentTitle;
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'Document checklist for ' + documentTitle});
    this.pageSession = this.route.snapshot.data.sessData.sessionDataProcess;
    this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession));

    this.userSessionInfoTravellers = JSON.parse(SessionHelper.getSession(this.sessionDataProcess))[this.sessionDataProcessScreen].traveller;
    for (const travellerInfo of this.userSessionInfoTravellers) {
      this.reqData.push({
        'process': this.processType,
        'purpose': travellerInfo.purpose ? travellerInfo.purpose : '',
        'hasPrepaid': travellerInfo.hasOwnProperty('prepaidCard') ? travellerInfo.prepaidCard : false
      });
    }

    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[0].selected = true;

    console.log(this.reqData);

    // this.masterService.getDocumentCheckList(this.reqData)
    this.masterService.getDocumentCheckList(this.SessionInfo)
      .subscribe(data => {  console.log(data);
        if (data !== 'error') {
          this.checklistDataListFromDb = data;
          this.DocCheckList = data[0].Checklist;
        } else {
          // swal('Oops', 'Unable to fetch checklist', 'error');
          // alert('Checklist missing from Database !!');
          Snackbar.show({text: 'Checklist missing from Database !!',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
        }
      }, error => {
        // swal('Oops', error, 'warning');
        // alert('Checklist missing from Database !!');
        Snackbar.show({text: 'Checklist missing from Database !!',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
      });
  }

  selectTraveller(travellerIndex) {
    const filteredEvents = this.checklistDataListFromDb.filter(function (event) {
      return event.traveller === travellerIndex;
    });
    this.DocCheckList = filteredEvents[0].Checklist;
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }


  updateSession() {

    SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));
  }
  routePage() {
    const UserInfo = SessionHelper.getSession('userInfo');
    const UserNextLink = this.location.path().split('/')[2] + '/review-userdetail-adhar';
    if ((UserInfo != null || UserInfo !== undefined) && JSON.parse(UserInfo).loggedin === true && JSON.parse(UserInfo).uid !== undefined) {
      this.router.navigateByUrl(this._primaryComp + '/' + UserNextLink);
    } else {
      this.router.navigateByUrl(this._primaryComp + this.nextLink);
    }
  }

  submitAndRedirect() {
    if (this.processType === 'Sell') {
      this.masterService.dumpSessionData(this.SessionInfo)
      .subscribe(data => {
       // this.router.navigateByUrl(this._primaryComp + this.nextLink);
       this.routePage();
      }, err => {
        console.log(err);
      });
    }else {
     // console.log

      this.masterService.RuleTest(this.SessionInfo)
      .subscribe(data => {
          const resData: any = JSON.parse(data);
          console.log(resData);
          if (resData.status === 1) {
           // this.router.navigateByUrl(this._primaryComp + this.nextLink);
              this.masterService.dumpSessionData(this.SessionInfo)
                  .subscribe(resD => {
                    this.routePage();
                //    this.router.navigateByUrl(this._primaryComp + this.nextLink);
                  }, err => {
                      console.log(err);
                  });
          }else {
              // swal('error', data, 'error');
              Snackbar.show({text: data,
              pos: 'bottom-right' ,
              actionTextColor: '#ff4444',
             });
          }
      }, err => {
          console.log(err);
      });
    }

    // this.router.navigateByUrl(this._primaryComp + this.nextLink);
  }


  parentSaveSession(event) {
    this.SessionInfo = event; console.log(event);
    this.updateSession();
 }


}
