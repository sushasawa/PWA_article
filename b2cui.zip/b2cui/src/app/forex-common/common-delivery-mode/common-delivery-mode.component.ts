import { Component, OnInit, Input, Output, EventEmitter, ViewChild, AfterViewInit, ElementRef, Inject, OnDestroy } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';

import { Location } from '../../../app/helpers/location';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { forEach } from '@angular/router/src/utils/collection';
import { DpDatePickerModule } from 'ng2-date-picker';
import { BuySummaryComponent } from '../buy-summary/buy-summary.component';
import { SellSummaryComponent } from '../sell-summary/sell-summary.component';
import { ReloadSummaryComponent } from '../reload-summary/reload-summary.component';
import { SendSummaryComponent } from '../send-summary/send-summary.component';
import * as moment from 'moment';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare var L: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-common-delivery-mode',
  templateUrl: './common-delivery-mode.component.html',
  styleUrls: ['./common-delivery-mode.component.css']
})

export class CommonDeliveryModeComponent implements OnInit, AfterViewInit   {


  public branchOptions: any;
  public cityOptions: any;
  public userSessionInfo: any;
  public SessionInfo: any;
  public deliveryMode: any;
  public DocCheckList;
  public TravellerCP;
  public BranchDetails;
  public BranchDetailsEnable;
  public CityDetails;
  public mymap: any;
  public currentSession: any;
  public pageSession: any;
  public nextLink: any;
  public processType: any;
  public wizardStepNumber: any;
  public mainHeading: any;
  public subHeading: any;
  public description: any;
  public standardHeading: any;
  public standardDesc: any;
  public expressHeading: any;
  public expressDesc: any;
  public tabOfficeHeading: any;
  public tabHomeHeading: any;
  public datetimetxt: any;
  public reqData: any;
  public DeliveryAmt: any;
  public DeliveryHomestand: any;
  public DeliveryHomeexpress: any;
  public DeliveryOfficestand: any;
  public DeliveryOfficeexpress: any;
  public DeliveryBranchstand: any;
  public DeliveryBranchexpress: any;
  public timeconfig: any;
  public todaysDate: any;
  public saveSession: EventEmitter<any> = new EventEmitter<any>();
  public config: any;
  public lat: Number;
  public lng: Number;
  public zoom: Number = 15;
  public travellingDate: any;
  public maploaded: Boolean = false;
  public branchEnabled: Boolean = true;
  public isPickUpMode: any;
  public _primaryComp: any;
  public Promoter: any;
  public PromotionalData: any;
  @ViewChild(BuySummaryComponent) BuySummaryComponent: BuySummaryComponent;
  @ViewChild(SellSummaryComponent) SellSummaryComponent;
  @ViewChild(ReloadSummaryComponent) ReloadSummaryComponent;
  @ViewChild(SendSummaryComponent) SendSummaryComponent;
  @ViewChild('homeDelivery') homeDelivery: ElementRef;
  @ViewChild('officeDelivery') officeDelivery: ElementRef;
  @ViewChild('pickupDelivery') pickupDelivery: ElementRef;

  constructor(public masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private route: ActivatedRoute, private meta: Meta, @Inject(DOCUMENT) private _document: any) {

    this._primaryComp = '/' + navUrl.navUrl();
    // const branchId: any = SessionHelper.getLocal('branchIdFromOverview');
    this.updateBranch(this.masterService.turnerMorrisonBranchId);
    // this.updateBranch(this);
    this._document.title = 'Select delivery details';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'Select delivery details'});
  }

  ngOnInit() {

    this.pageSession = this.route.snapshot.data.sessData.sessionDataProcess;
    // console.log(this.currentSession);
    this.Promoter = SessionHelper.getSession('promotion');
    if(this.Promoter && SessionHelper.getSession('PromotionalData')){
      this.PromotionalData = JSON.parse(SessionHelper.getSession('PromotionalData'));
    }
    this.currentSession = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.nextLink = this.route.snapshot.data.nextLink;
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;
    this.mainHeading = this.route.snapshot.data.mainHeading;
    this.subHeading = this.route.snapshot.data.subHeading;
    this.description = this.route.snapshot.data.description;
    this.standardHeading = this.route.snapshot.data.standardHeading;
    this.standardDesc = this.route.snapshot.data.standardDesc;
    this.expressHeading = this.route.snapshot.data.expressHeading;
    this.expressDesc = this.route.snapshot.data.expressDesc;
    this.tabOfficeHeading = this.route.snapshot.data.tabOfficeHeading;
    this.tabHomeHeading = this.route.snapshot.data.tabHomeHeading;
    this.datetimetxt = this.route.snapshot.data.datetimetxt;
    this.saveSession = this.route.snapshot.data.saveSession;
    this.todaysDate = this.masterService.getTodaysDate();
    this.config = {
      format: 'DD-MM-YYYY',
      showMultipleYearsNavigation: true,
      disableKeypress: true,
      min: this.todaysDate,
      max: this.masterService.addDateMoment(this.todaysDate, 10, 'days')
    };


    this.BranchDetails = '';

    $.magnificPopup.close();
    this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession));
    this.userSessionInfo = this.SessionInfo[this.currentSession];
    if (this.userSessionInfo.deliveryInfo.Mode === 'Pick Up') {
      this.isPickUpMode = true;
    }
    this.timeconfig = {
      format: 'HH:mm',
      min: this.getMinTime(),
      max: '18:30'
    };
    if (!this.userSessionInfo.deliveryInfo.Mode && !this.userSessionInfo.deliveryInfo.rate && !this.userSessionInfo.deliveryInfo.type) {
      this.userSessionInfo.deliveryInfo.Mode = 'Home Delivery';
      this.userSessionInfo.deliveryInfo.rate = this.DeliveryHomestand;
      this.userSessionInfo.deliveryInfo.type = 'Standard';
    } else {
      const deliveryModeValue = this.userSessionInfo.deliveryInfo.Mode;
      setTimeout(() => {
        if (deliveryModeValue === 'Home Delivery'){
          const el: HTMLElement = this.homeDelivery.nativeElement as HTMLElement;
          el.click();
        }else if (deliveryModeValue === 'Office Delivery'){
          const el: HTMLElement = this.officeDelivery.nativeElement as HTMLElement;
          el.click();
        }else if (deliveryModeValue === 'Pick Up'){
          const el: HTMLElement = this.pickupDelivery.nativeElement as HTMLElement;
          el.click();
        }
      }, 800);
    }

    // setTimeout(() => {
    //   this.deliveryTypeAndRate(this.userSessionInfo.deliveryInfo.type, this.userSessionInfo.deliveryInfo.rate);
    // }, 450);

    this.userSessionInfo.traveller.forEach((traveller, index) => {
      if (traveller.travellingDetails.dateOfTravel) {
        if (!this.travellingDate) {
          this.travellingDate = traveller.travellingDetails.dateOfTravel;
        } else {
          const diff = this.masterService.getDateDifference(this.travellingDate, traveller.travellingDetails.dateOfTravel);
          if (diff > 0) {
            this.travellingDate = traveller.travellingDetails.dateOfTravel;
          }
        }
      }



      if (traveller.cash) {
        const branchId: any = SessionHelper.getLocal('branchIdFromOverview');
        setTimeout(() => {
          this.userSessionInfo.deliveryInfo.branch = this.userSessionInfo.branch;
          this.updateBranch(this.userSessionInfo.branch);
          this.branchEnabled = false;
        }, 350);
      }
    });



    if (this.userSessionInfo.deliveryInfo.branch && this.userSessionInfo.deliveryInfo.city) {
      this.updateBranch(Number(this.userSessionInfo.deliveryInfo.branch));
    }


    if (this.Promoter && this.PromotionalData && this.processType == 'Buy') {
      this.branchOptions = this.PromotionalData.BranchList;
    } else {
      this.masterService.getBranchList(this.userSessionInfo.currentLocation.city)
        .subscribe(data => {
          this.branchOptions = data;
        });
    }

    this.masterService.getCityList()
      .subscribe(data => {
        this.cityOptions = data;
      });

    this.reqData = this.SessionInfo.mode;

    this.masterService.getDeliveryAmt(this.reqData)
      .subscribe(data => {
        this.DeliveryAmt = data;
        for (let i = 0; i < this.DeliveryAmt.length; i++) {
          if (this.DeliveryAmt[i].DeliveryType === 'HomeVisit') {
            this.DeliveryHomestand = this.DeliveryAmt[i].StandardDelivery;
            this.DeliveryHomeexpress = this.DeliveryAmt[i].ExpressDelivery;
            this.userSessionInfo.deliveryInfo.rate = this.DeliveryAmt[i].StandardDelivery;
          }
          if (this.DeliveryAmt[i].DeliveryType === 'OfficeVisit') {
            this.DeliveryOfficestand = this.DeliveryAmt[i].StandardDelivery;
            this.DeliveryOfficeexpress = this.DeliveryAmt[i].ExpressDelivery;
          }
          if (this.DeliveryAmt[i].DeliveryType === 'BranchPickup') {
            this.DeliveryBranchstand = this.DeliveryAmt[i].StandardDelivery;
            this.DeliveryBranchexpress = this.DeliveryAmt[i].ExpressDelivery;
          }
        }
      });

    // this.mymap = L.map('mapid', { attributionControl: false });
    // console.log(this.mymap);
    // L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    //   attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors,'
    //     + ' <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>',
    //   maxZoom: 18,
    //   id: 'mapbox.streets',
    //   accessToken: 'pk.eyJ1Ijoia2FtbGVzaC1jbmsiLCJhIjoiY2phN3d5bGRsMDB1MzM3cW1iOHYzbHN3ZCJ9.sy4v_2XvDe4zm1peJeSCXQ'
    // }).addTo(this.mymap);

    this.updateSession();
  }

  ngAfterViewInit() {
    // console.log(this.UserBannerInfoComponent);
  }
  updateBranch(newValue: number) {
    console.log(newValue);

    this.masterService.getBranchDetails(newValue)
      .subscribe(data => {
        console.log('########121212', data);
        const result: any = data;
        this.userSessionInfo.deliveryInfo.pickUpAddr = result[0].BranchName + ',' + result[0].Address;

        this.BranchDetails = data;
        this.BranchDetailsEnable = true;
        this.lat = +this.BranchDetails[0].latitude;
        this.lng = +this.BranchDetails[0].longitude;
        if (this.BranchDetails[0].latitude && this.BranchDetails[0].longitude) {
          this.maploaded = true;
        } else {
          this.maploaded = false;
        }
      });

    this.updateSession();
  }

  updateCity(newValue: string) {
    this.masterService.getBranchList(newValue.split('#')[1])
      .subscribe(data => {
        this.branchOptions = data;
      });
    this.updateSession();
  }

  deliveryModes(mode: String) {
    if (this.isPickUpMode === true && mode !== 'Pick Up') {
      this.userSessionInfo.deliveryInfo.DeliverySchedule.time = '';
    }
    if (mode === 'Pick Up') {
      this.isPickUpMode = true;
      this.deliveryTypeAndRate('', 0);
    }else {
      this.isPickUpMode = false;
      this.deliveryTypeAndRate('Standard', this.DeliveryHomestand);
    }
    this.userSessionInfo.deliveryInfo.Mode = mode;
    // console.log(this.userSessionInfo.deliveryInfo);
    this.updateSession();
  }

  deliveryTypeAndRate(type: String, rate: any) {
    this.userSessionInfo.deliveryInfo.type = type;
    this.userSessionInfo.deliveryInfo.rate = rate;
    this.updateSession();
    switch (this.processType) {
      case 'Buy':
        this.BuySummaryComponent.updateSessionFromDeliveryMode(this.userSessionInfo.deliveryInfo);
        break;

      case 'Sell':
        this.SellSummaryComponent.updateSessionFromDeliveryMode(this.userSessionInfo.deliveryInfo);
        break;

      case 'Reload':
        this.ReloadSummaryComponent.updateSessionFromDeliveryMode(this.userSessionInfo.deliveryInfo);
        break;

      case 'Send':
        this.SendSummaryComponent.updateSessionFromDeliveryMode(this.userSessionInfo.deliveryInfo);
        break;
    }
  }

  deliveryDate(event: any) {
    // tslint:disable-next-line:prefer-const
    let additionHours = 3, saturdayCheck: any;
    if (event !== undefined && typeof event !== 'object') {
      if (!this.verifyDateTime(event)) {
        this.updateDateTime();
        return;
      }
      let hourMin = '', hourMax = '';
      if (event === this.todaysDate) {
        if (!this.isPickUpMode) {
          const time = moment().add(additionHours, 'hours');
          if (Number(time.format('HH')) < 10) {
            hourMin = '10:00';
          } else {
            hourMin = time.format('HH') + ':' + time.format('mm');
          }
        }
      } else {
        hourMin = '10:00';
      }
      this.userSessionInfo.deliveryInfo.DeliverySchedule.time = hourMin;
      saturdayCheck = this.checkForSaturday(event);
      if (saturdayCheck.flag) {
        hourMax = '16:00';
      } else {
        hourMax = '18:30';
      }
      this.timeconfig = {
        format: 'HH:mm',
        min: hourMin,
        max: hourMax
      };
      this.userSessionInfo.deliveryInfo.DeliverySchedule.date = event;
      this.updateSession();
    }
  }

 deliveryTime(time: any) {
    if (time !== undefined && typeof time !== 'object') {
      this.userSessionInfo.deliveryInfo.DeliverySchedule.time = time;
      this.updateSession();
    }
  }

  updateSession() {
    SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));
  }

  proceed() {
    // if(!this.userSessionInfo.deliveryInfo.DeliverySchedule.date || !this.userSessionInfo.deliveryInfo.DeliverySchedule.time){
    //   this.showAlert('Please Select delivery date and time.');
    //   return;
    // }
    // if(!this.verifyDateTime(this.userSessionInfo.deliveryInfo.DeliverySchedule.date)){
    //   return;
    // }
    this.SessionInfo['nextLink'] = this.nextLink;
    this.SessionInfo[this.currentSession] = this.userSessionInfo;
    this.updateSession();
    if (this.processType !== 'Sell') {
      this.masterService.RuleTest(this.SessionInfo)
        .subscribe(data => {
          const resData: any = JSON.parse(data);
          console.log(resData);
          if (resData.status === 1) {
            this.router.navigateByUrl(this._primaryComp + this.nextLink);
            this.masterService.dumpSessionData(this.SessionInfo)
              .subscribe(resD => {
                this.router.navigateByUrl(this._primaryComp + this.nextLink);
              }, err => {
                console.log(err);
              });
          } else {
            // swal('error', data, 'error');
            Snackbar.show({
              text: data,
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
            });
          }
        }, err => {
          console.log(err);
        });
    } else {
      this.router.navigateByUrl(this._primaryComp + this.nextLink);
      this.masterService.dumpSessionData(this.SessionInfo)
        .subscribe(resD => {
          this.router.navigateByUrl(this._primaryComp + this.nextLink);
        }, err => {
          console.log(err);
        });
    }
  }

  onSaveAndTemporaryExit() {
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession(this.pageSession);
    switch (this.processType) {
      case 'Buy':
        this.router.navigateByUrl(this._primaryComp + `/buy`);
        //   /register-login
        break;
      case 'Sell':
        this.router.navigateByUrl(this._primaryComp + `/sell`);
        break;
      case 'Reload':
        this.router.navigateByUrl(this._primaryComp + `/reload-card`);
        break;
      case 'Send':
        this.router.navigateByUrl(this._primaryComp + `/send-money`);
        break;
      default:
        break;
    }
  }

  parentSaveSession(event) { console.log('called from child');
    this.SessionInfo = event;
    this.updateSession();
  }

  getMinTime() {
    const deliveryDate = this.userSessionInfo.deliveryInfo.DeliverySchedule.date;
    if (deliveryDate === this.todaysDate) {
      let time;
      if (this.isPickUpMode) {
        time = moment().add(0, 'hours');
      } else {
        time = moment().add(3, 'hours');
      }
      this.userSessionInfo.deliveryInfo.DeliverySchedule.time = time.format('HH') + ':' + time.format('mm');
      return time.format('HH') + ':' + time.format('mm');
    }
    this.userSessionInfo.deliveryInfo.DeliverySchedule.time = '10:00';
    return '10:00';
  }

  checkForSaturday(dateValue) {
    const daySelected = moment(dateValue, 'DD-MM-YYYY').format('ddd');
    if (daySelected === 'Sat') {
      if (this.isPickUpMode) {
        return { flag: true, hrs: 16, mins: 0, text: '4:00' };
      }
      return { flag: true, hrs: 13, mins: 0, text: '1:00' };
    }
    return { flag: false };
  }

  verifyDateTime(dateValue) {
    let maxDayTime = 15, maxMins = 30, displayTime = '3:30';
    // tslint:disable-next-line:prefer-const
    let timeHour: any = this.masterService.getCurrentTime(), diff;
    const saturdayCheck: any = this.checkForSaturday(dateValue);
    if (this.isPickUpMode) {
      maxDayTime = 18; maxMins = 30; displayTime = '6:30';
    }
    if (saturdayCheck.flag) {
      maxDayTime = saturdayCheck.hrs;
      maxMins = saturdayCheck.mins;
      displayTime = saturdayCheck.text;
    }
    if (this.travellingDate) {
      diff = this.masterService.getDateDifference(this.travellingDate, dateValue);
      if (diff <= 0) {
        this.showAlert('Delivery date should be at least 1 day before travelling date.');
        return false;
      }
    }
    if (this.isPickUpMode && dateValue === this.todaysDate && +timeHour.hour >= maxDayTime && +timeHour.mins >= maxMins) {
      this.showAlert('Same day pickup available before ' + displayTime + ' PM. Please select next working day.');
      return false;
    } else
    if (!this.isPickUpMode && dateValue === this.todaysDate && +timeHour.hour >= maxDayTime && +timeHour.mins >= maxMins) {
      this.showAlert('Same day delivery available if you book an order before ' + displayTime + ' PM. Please select next working day.');
      return false;
    }
    // if (dateValue !== this.todaysDate) {
    if (this.isNotWrokingDay(dateValue, true) || this.isNextTwoWorkingDays(dateValue)) {
      // this.showAlert('Delivery date should be with in next 2 working days from today.')
      return false;
    }
    // }
    return true;
  }

  isNextTwoWorkingDays(dateValue) {
    let nextDay = this.todaysDate, counter = 0;
    while (nextDay !== dateValue) {
      nextDay = this.masterService.addDateMoment(nextDay, 1, 'days');
      if (!this.isNotWrokingDay(nextDay, false)) {
        counter++;
        if (counter > 2){
          this.showAlert('Delivery date should be within next 2 working days from today.');
          return true;
        }
      }
    }
    return false;
  }

  isNotWrokingDay(dateValue, flag){
    // tslint:disable-next-line:prefer-const
    const daySelected = moment(dateValue, 'DD-MM-YYYY').format('ddd'),
    weekEndDays = ['Sun'],
    holyDaysList = ['15-02-2018', '22-02-2018', '20-02-2018'];
    if (weekEndDays.indexOf(daySelected) !== -1 || holyDaysList.indexOf(dateValue) !== -1) {
      if (flag) {
        switch (daySelected) {
          case 'Sat':
            this.showAlert('Deliveries not possible on Saturdays.');
            break;
          case 'Sun':
            this.showAlert('Deliveries not possible on Sundays.');
            break;
          default:
            this.showAlert(dateValue + ' is non-working day, please select another working day.');
        }
      }
      return true;
    }
    return false;
  }

  showAlert(message){
    Snackbar.show({
      text: message,
      pos: 'bottom-right',
      actionTextColor: '#ff4444',
      duration: 3000
    });
  }

  updateDateTime() {
    this.userSessionInfo.deliveryInfo.DeliverySchedule.date = '';
    this.userSessionInfo.deliveryInfo.DeliverySchedule.time = '';
    this.updateSession();
  }


}
