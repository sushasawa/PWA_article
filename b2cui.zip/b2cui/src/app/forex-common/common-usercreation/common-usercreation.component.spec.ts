import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonUsercreationComponent } from './common-usercreation.component';

describe('CommonUsercreationComponent', () => {
  let component: CommonUsercreationComponent;
  let fixture: ComponentFixture<CommonUsercreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonUsercreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonUsercreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
