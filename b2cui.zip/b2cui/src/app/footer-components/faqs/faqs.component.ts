/* This component added to handle large HTML content of FAQ's. 
Otherwise this is just static component can be merged in footer-static component. */
import { Component, OnInit, Inject } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initAccord(): any;
declare function initDocument(): any;
declare var $: any;

@Component({
  selector: 'app-faqs',
  templateUrl: './faqs.component.html',
  styleUrls: ['./faqs.component.css']
})
export class FAQsComponent implements OnInit {  
  public innerRequireSidebar:string = '0';
  public _primaryComp: any;
  constructor(private meta: Meta, @Inject(DOCUMENT) private _document: any, private navUrl: NavigatePathService) {     
    this._primaryComp = '/' + this.navUrl.navUrl();
    this._document.title = "FAQs";
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'FAQs'});
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    // initAccord();
    setTimeout(function(){
      initDocument();
    }, 5);
  }

}
