import { Component, OnInit, Inject } from '@angular/core';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;
// declare function swal(headerMessage, message, type): any;
declare var $: any;
declare var Snackbar: any;

export interface FormModel {
  captcha?: string;
}


@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  public cityOptions: any;
  public name: any;
  public email: any;
  public mobileNumber: any;
  public cityName: any;
  public feedback: any;
  public invalidsubmitted: any;
  public _primaryComp: any;
  public formModel: FormModel = {};
  public catagoryOptions: any = [{
    'value': 'Complaint', 'label': 'Complaint'
  }, {
    'value': 'General Feedback', 'label': 'General Feedback'
  }];
  public catagory: any;

  constructor(private masterService: MasterService, private meta: Meta, @Inject(DOCUMENT) private _document: any, private navUrl: NavigatePathService) {
    this.invalidsubmitted = false;
    this._primaryComp = '/' + navUrl.navUrl();
    this._document.title = "Customer feedback";
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'Feedback'});
   }

  ngOnInit(): void {
    $('body').attr('id', '');

    this.masterService.getCityList()
    .subscribe(data => {
      this.cityOptions = data;
      const currentDocument = this;
    });

    setTimeout(function(){
      $('ng-select > div').css('border', '0px solid black');
      initDocument();
    }, 5);
  }


  submitFeedback(feedBackForm: NgForm, event: Event) {

    event.preventDefault();
    this.invalidsubmitted = feedBackForm.invalid;


    if (feedBackForm.valid) {
      const payload = {
        'name': this.name,
        'email': this.email,
        'mobileNumber': this.mobileNumber,
        'city': this.cityName,
        'catagory': this.catagory,
        'feedback': this.feedback,
        'deliveryCity': null,
        'deliveryBranch': null
     };
     console.log(payload);
    this.masterService.setFeedback(payload).subscribe(data => {
      const retData: any = data;
      if (retData.status = 1) {
        // swal('', 'Feedback submitted successfully!', 'success');
        Snackbar.show({text: 'Feedback submitted successfully!',
        pos: 'bottom-right' ,
        actionTextColor: '#05ff01',
       });


        this.cityOptions = '';
        this.name = '';
        this.email = '';
        this.mobileNumber = '';
        this.cityName = '';
        this.feedback = '';

      }
    }, error => {
      // swal('Oops', 'Something went wrong,Please try again ', 'error');
      console.log(error);
      Snackbar.show({text: 'Something went wrong,Please try again ',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
    });
    }else{
      // swal('Oops', 'Fill all required Inputs ', 'error');
      Snackbar.show({text: 'Fill all required Inputs ',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
    }







  }


}
