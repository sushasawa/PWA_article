import { Component, OnInit, Inject } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../app/services/navigate-path.service';
declare function initDocument(): any;
declare var $: any;
@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent implements OnInit {
  public _primaryComp: any;
  constructor(private meta: Meta, private navUrl: NavigatePathService, @Inject(DOCUMENT) private _document: any) {
    this._document.title = 'Page not found';
    this._primaryComp = '/' + navUrl.navUrl();
    // tslint:disable-next-line:max-line-length
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.'});
    this.meta.addTag({ name: 'keywords', content: 'Page not found'});
   }

  ngOnInit() {
    $('body').attr('id', '');
    initDocument();
  }

}
