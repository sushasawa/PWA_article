import { BulkExchangeRateService } from './services/bulk-exchange-rate.service';
import { TimerService } from './services/timer.service';
import { BrowserModule} from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SlimLoadingBarModule } from 'ng2-slim-loading-bar';
import { SessionValueResetService } from './services/session-value-reset.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MasterService } from './services/master.services';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LoaderInterceptor } from './interceptors/loader-interceptor.service';
import { SessionCheckerService } from './services/session-checker.service';
import { TransactionService } from './services/transaction.service';
import { SideBarComponent } from './sidebar/sidebar.component';
import { SendEnquiryComponent } from './send-enquiry/send-enquiry.component';
import { AgentMarginService } from './services/agent-margin.service';
import { SelectModule } from 'ng-select';
import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';
import { GlobalLoaderService } from './services/global-loader.service';
import { NavigatePathService } from './services/navigate-path.service';
import { SharedService } from './services/shared.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SideBarComponent,
    PageNotFoundComponent,
    SendEnquiryComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    SelectModule,
    ReactiveFormsModule,
    HttpClientModule,
    SlimLoadingBarModule,
    RecaptchaModule.forRoot(),
     RecaptchaFormsModule
  ],
  // tslint:disable-next-line:max-line-length
  providers: [NavigatePathService, SharedService, TransactionService, MasterService, AgentMarginService, GlobalLoaderService, SessionValueResetService, TimerService , BulkExchangeRateService ,{
    provide: HTTP_INTERCEPTORS,
    useClass: LoaderInterceptor,
    multi: true,
  },
    SessionCheckerService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
