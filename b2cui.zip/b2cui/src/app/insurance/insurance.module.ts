import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InsuranceOverviewComponent } from './insurance-overview/insurance-overview.component';
import { SelectModule } from 'ng-select';
import {DpDatePickerModule} from 'ng2-date-picker';
import { PipesModule } from '../pipes/pipes.module';
import { MasterService } from '../services/master.services';
import { AuthService } from '../services/auth.service';
import { AuthGuardService as AuthGuard } from '../services/auth-guard.service';
import { FailComponent } from '../forex-common/fail/fail.component';
import { CanDeactivateGuard } from '../services/can-deactivate-guard.service';
import { TimerService } from '../services/timer.service';
import { PasswordStrengthBarModule } from 'ng2-password-strength-bar';
const routes: Routes = [
  {
    path: '', children: [
      { path: '', component: InsuranceOverviewComponent, canDeactivate: [CanDeactivateGuard] }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    PipesModule,
    SelectModule,
    DpDatePickerModule,
    PasswordStrengthBarModule
  ],
  declarations: [
    InsuranceOverviewComponent
  ],
  providers: [MasterService, AuthGuard, AuthService, CanDeactivateGuard, TimerService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class InsuranceModule { }
