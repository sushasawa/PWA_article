import { Component, OnInit, ElementRef, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UUID } from 'angular2-uuid';
import { Observable } from 'rxjs/Observable';
import { Location } from '../../../app/helpers/location';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { LocationStrategy } from '@angular/common';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { TimerService } from '../../services/timer.service';
import { DpDatePickerModule } from 'ng2-date-picker';
declare function initForms(): any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;

declare var $: any;
declare var Snackbar: any;

@Component({
    selector: 'app-insurance-overview',
    templateUrl: './insurance-overview.component.html',
    styleUrls: ['./insurance-overview.component.css']
})
export class InsuranceOverviewComponent implements OnInit {
    public userSessionInfo: any;
    public navigate: any = true;
    public branchOptions: any;
    public destinationOptions: any;
    public currencyList: any;
    public currencyListCash: any;
    public currencyListTravellerCheque: any;
    public currencyListDemandDraft: any;
    public purposeOptions: any;
    public bankOptions = [];
    public CurrentBranchId: any;
    private currentTravellerIndex: number;
    public isLoggedIn: boolean;
    public visaDetails: any = {
        currentLocation: {}
    };
    public dateOfTravelTime: any = 10;
    public visaTypes: any;
    public occupations: any;
    public configDob: any;
    public todaysDate: any;
    public configsMax: any = [];
    public newTravellerCount: number;
    public invalidsubmitted1: boolean;
    public invalidsubmitted2: boolean;
    // tslint:disable-next-line:max-line-length
    constructor(private masterService: MasterService, private router: Router, private _router: ActivatedRoute, private _elementRef: ElementRef, private location: LocationStrategy, private meta: Meta, @Inject(DOCUMENT) private _document: any, public _TimerService: TimerService) {
        this.location.onPopState(() => {
            this.navigate = false;
            return false;
        });
        this.visaDetails = this.setVisaDetailsJSON();
        if (SessionHelper.getSession('visaDetails')) {
            this.visaDetails = JSON.parse(SessionHelper.getSession('visaDetails'));
        }
        this._document.title = 'Search and buy visa.';
        this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex. Buy insurance and apply for visa here.' });
        this.meta.addTag({ name: 'keywords', content: 'Buy, Sell, Send Money Abroad, Reload Card, Cash, Prepaid Card, Demand Draft, Check Exchange Rates, Live Forex Rates. exchange rates, currency exchange, currency rates, currency services, currency traders, currency trading, currency transfers, best exchange rates, rates, convert, currencies, currency, forex, forex news, forex terms, charts, discount, efficient, foreign exchange, foreign exchange payment, save money, save time, fx, global, global economy, graphs, guaranteed, headlines, introduction to forex, live, mid-market, trade currency, xe money transfer, accurate rates, accounting, expense management, forex markets, apply, visa, insurance' });
        this.getDestinationList();
        this.getPurposeOptions();
        this.getCurrentLocation();
        this.setDateConfig(this.visaDetails.visaScreen.traveller[0].travellingDetails.dateOfTravel);
        this.setVisaType();
        this.setOccupation();
    }

    ngOnInit(): void {
        initDocument();
        // initForms();
        $('body').attr('id', 'home');
        $('body').addClass('insurance');
        $('.custom-tabs > .resp-tabs-list > li[aria-controls="hor_1_tab_item-0"]').trigger('click');
    }

    canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
        if (this.navigate === true) {
            return true;
        } else {
            Snackbar.show({
                text: 'You can not go back from this page. Please go through application flow.',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
            window.scrollTo(0, 0);
            this.navigate = true;
            return false;
        }
    }

    ngOnDestroy() {
        $('body').removeClass('insurance');
    }

    getDestinationList() {
        if (!sessionStorage.getItem('destinationList')) {
            this.masterService.getDestinationList()
                .subscribe(data => {
                    this.destinationOptions = data;
                    sessionStorage.setItem('destinationList', JSON.stringify(this.destinationOptions));
                }, err => {
                    // swal('Oops...', 'Unable to fetch destination list!', 'error');
                    Snackbar.show({
                        text: 'Unable to fetch destination list!',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                });
        } else {
            this.destinationOptions = JSON.parse(sessionStorage.getItem('destinationList'));
        }
    }

    getPurposeOptions() {
        this.masterService.getPurposeList(1)
            .subscribe(data => {
                this.purposeOptions = data;
                this.visaDetails.visaScreen.traveller[0].purposeCode = this.purposeOptions.filter((value, i) => i === 0)[0].purposeCode;
            }, err => {
                Snackbar.show({
                    text: 'Unable to fetch purpose list!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });
    }

    getCurrentLocation() {
        if (!this.visaDetails.visaScreen.currentLocation.city) {
            this.masterService.getCurrentLocation()
                .subscribe(data => {
                    this.visaDetails.visaScreen.currentLocation = data;
                    this.updateSession();
                }, err => {
                    Snackbar.show({
                        text: 'Unable to detect current location!',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                });
        }
    }

    updateDestination(newValue: number) {
        this.visaDetails.visaScreen.destination = newValue;
        this.updateSession();
    }

    updatePurpose(newPurpose) {
        this.visaDetails.visaScreen.traveller[0].purpose = newPurpose;
        this.visaDetails.visaScreen.traveller[0].purposeCode = this.purposeOptions.filter((value, i) => value.value === newPurpose)[0].purposeCode;
        this.updateSession();
    }

    updateCity($event) {
        if (this.visaDetails.visaScreen.currentLocation) {
            this.visaDetails.visaScreen.currentLocation.city = $event;
            this.updateSession();
        }
    }

    updateSession() {
        SessionHelper.setSession('visaDetails', JSON.stringify(this.visaDetails));
    }

    closePopup() {
        $.magnificPopup.close();
    }

    dataChangeStart(event): void {
        if (event !== undefined && typeof event !== 'object') {
            this.visaDetails.visaScreen.traveller[0].travellingDetails.dateOfTravel = event;
            SessionHelper.setSession('visaDetails', JSON.stringify(this.visaDetails));
        }
    }

    dataChangeBirth(event): void {
        if (event !== undefined && typeof event !== 'object') {
            this.visaDetails.visaScreen.traveller[0].registrationInfo.dateOfBirth.value = event;
            SessionHelper.setSession('visaDetails', JSON.stringify(this.visaDetails));
        }
    }

    setMaritalStatus(event) {
        this.visaDetails.visaScreen.traveller[0].maritalStatus = event;
        this.updateSession();
    }

    setDateConfig(startDate) {
        let maxDate = '',
            minDate = '';
        this.todaysDate = this.masterService.getTodaysDate();
        if (startDate !== '') {
            minDate = startDate;
        } else {
            minDate = this.todaysDate;
        }
        this.configsMax = {
            format: 'DD-MM-YYYY',
            // max: this.masterService.addDateMoment(this.todaysDate, 60, 'days'),
            min: this.masterService.addDateMoment(this.todaysDate, this.dateOfTravelTime, 'days'),
            showMultipleYearsNavigation: true,
            disableKeypress: true,
        };
        this.configDob = {
            format: 'DD-MM-YYYY',
            max: this.todaysDate,
            showMultipleYearsNavigation: true,
            disableKeypress: true,
        };
    }

    setVisaType() {
        this.visaTypes = [
            { "value": "Visa Tourism - 6 Months Multiple Entries", "label": "Visa Tourism - 6 Months Multiple Entries", "Id": 5, "Name": "Visa Tourism - 6 Months Multiple Entries" },
            { "value": "Visa Tourism - Long Term, valid upto 2 years", "label": "Visa Tourism - Long Term, valid upto 2 years", "Id": 6, "Name": "Visa Tourism - Long Term, valid upto 2 years" },
            { "value": "Visa Tourism - Long Term, valid upto 5 years", "label": "Visa Tourism - Long Term, valid upto 5 years", "Id": 7, "Name": "Visa Tourism - Long Term, valid upto 5 years" },
            { "value": "Visa Tourism - Long Term, valid upto 10 years", "label": "Visa Tourism - Long Term, valid upto 10 years", "Id": 9, "Name": "Visa Tourism - Long Term, valid upto 10 years" }
        ];
    }

    setOccupation() {
        this.occupations = [
            { "value": "Employed", "label": "Employed", "Id": 5, "Name": "Employed" },
            { "value": "Partner", "label": "Partner", "Id": 6, "Name": "Partner" },
            { "value": "Proprietor", "label": "Proprietor", "Id": 7, "Name": "Proprietor" },
            { "value": "Director in Business", "label": "Director in Business", "Id": 8, "Name": "Director in Business" },
            { "value": "Seaman", "label": "Seaman", "Id": 9, "Name": "Seaman" },
            { "value": "Self Employed / Freelancer", "label": "Self Employed / Freelancer", "Id": 10, "Name": "Self Employed / Freelancer" },
            { "value": "Student", "label": "Student", "Id": 11, "Name": "Student" },
            { "value": "Un-employed", "label": "Un-employed", "Id": 12, "Name": "Un-employed" },
            { "value": "Retired", "label": "Retired", "Id": 13, "Name": "Retired" },
            { "value": "Others (if your Occupation is not listed)", "label": "Others (if your Occupation is not listed)", "Id": 14, "Name": "Others (if your Occupation is not listed)" }
        ];
    }

    updateVisaType($event) {
    }

    updateOccupation($event) {
    }

    navigateToNext() {
        if(this.validateDetails()){
            this.visaDetails.visaScreen.traveller[0].visaFee = 1200;
            this.updateSession();
            this.closePopup();
            this.router.navigateByUrl('/visa/documents-checklist');
        }        
    }

    buyVisaClick() {
        if(this.validateSearch()){
        setTimeout(() => {
            $.magnificPopup.open({
                items: {
                    src: '#travler-details-popup'
                },
                type: 'inline'
            });
        }, 100);}
    }

    validateSearch() {
        let result = true;
        switch (true) {
            case (!this.visaDetails.visaScreen.currentLocation.city):
                Snackbar.show({
                    text: 'Please select provide city',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.invalidsubmitted1 = true;
                result = false;
                break;
            case (!this.visaDetails.visaScreen.destination):
                Snackbar.show({
                    text: 'Please select destination',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.invalidsubmitted1 = true;
                result = false;
                break;
            case (!this.visaDetails.visaScreen.traveller[0].purpose):
                Snackbar.show({
                    text: 'Please select purpose of travel',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.invalidsubmitted1 = true;
                result = false;
                break;
            case (!this.visaDetails.visaScreen.traveller[0].travellingDetails.dateOfTravel):
                Snackbar.show({
                    text: 'Please select date of travel',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.invalidsubmitted1 = true;
                result = false;
                break;
        }
        return result;
    }

    validateDetails() {
        let result = true;
        switch (true) {
            case (!this.visaDetails.visaScreen.traveller[0].visaType):
                Snackbar.show({
                    text: 'Please select visa type.',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.invalidsubmitted2 = true;
                result = false;
                break;
            case (!this.visaDetails.visaScreen.traveller[0].occupation):
                Snackbar.show({
                    text: 'Please select occupation',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.invalidsubmitted2 = true;
                result = false;
                break;
            case (!this.visaDetails.visaScreen.traveller[0].registrationInfo.dateOfBirth.value):
                Snackbar.show({
                    text: 'Please select date of birth',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.invalidsubmitted2 = true;
                result = false;
                break;
            case (!this.visaDetails.visaScreen.traveller[0].maritalStatus):
                Snackbar.show({
                    text: 'Please select marital status',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.invalidsubmitted2 = true;
                result = false;
                break;
        }
        return result;
    }

    setVisaDetailsJSON() {
        return {
            "sessionId": "",
            "mode": "b2c",
            "type": "visaScreen",
            "isActive": true,
            "created_On": "",
            "visaScreen": {
                "budgetAmount": "",
                "usedAmount": "0",
                "tranId": "",
                "balanceAmount": "0",
                "currentLocation": "",
                "branch": "",
                "destination": "",
                "deliveryInfo": {
                    "collect": {
                        "Mode": "Post by courier",
                        "Address": {
                            "flatNumber": "",
                            "buildingName": "",
                            "streetName": "",
                            "landmark": "",
                            "area": "",
                            "city": "",
                            "state": "",
                            "pincode": ""
                        }
                    },
                    "submit": {
                        "Mode": "Home Delivery",
                        "Address": {
                            "flatNumber": "",
                            "buildingName": "",
                            "streetName": "",
                            "landmark": "",
                            "area": "",
                            "city": "",
                            "state": "",
                            "pincode": ""
                        }
                    },
                    "type": "Standard",
                    "DeliverySchedule": {
                        "date": "",
                        "time": ""
                    },
                    "rate": 0
                },
                "traveller": [
                    {
                        "selected": true,
                        "lead": true,
                        "purposeCode": "",
                        "purpose": "",
                        "serviceCharge": 0,
                        "loadFees": 0,
                        "activationFees": 0,
                        "discount": 0,
                        "ddCharges": 0,
                        "charges": 0,
                        "gst": 0,
                        "visaType": "",
                        "occupation": "",
                        "maritalStatus": "",
                        "visaFee": 1200,
                        "registrationInfo": {
                            "userId": "",
                            "invoiceNo": null,
                            "firstName": {
                                "value": ""
                            },
                            "middleName": "",
                            "lastName": "",
                            "dateOfBirth": {
                                "value": ""
                            },
                            "adharCardNo": {
                                "value": ""
                            },
                            "gender": {
                                "value": ""
                            },
                            "nationality": "",
                            "mothersMaidenName": {
                                "value": ""
                            },
                            "PAN": {
                                "value": ""
                            },
                            "passportNumber": "",
                            "ParentId": true,
                            "dateOfIssue": "",
                            "placeOfIssue": "",
                            "expiryDate": "",
                            "address": "101 5A Galaxy apartment",
                            "isPassportAddressAsAdhar": "yes",
                            "adharAddress": {
                                "flatNumber": "",
                                "buildingName": "",
                                "streetName": "",
                                "landmark": "",
                                "area": "",
                                "city": "",
                                "state": "",
                                "pincode": ""
                            },
                            "passportAddress": {
                                "flatNumber": "",
                                "buildingName": "",
                                "streetName": "",
                                "landmark": "",
                                "area": "",
                                "city": "",
                                "state": "",
                                "pincode": ""
                            },
                            "currentAddressAs": "asPerAdhar",
                            "otherAddress": {
                                "flatNumber": "",
                                "buildingName": "",
                                "streetName": "",
                                "landmark": "",
                                "area": "",
                                "city": "",
                                "state": "",
                                "pincode": ""
                            },
                            "contactDetails": {
                                "mobileNo": "",
                                "emailId": ""
                            },
                            "alternateContactDetails": {
                                "countryCode": "",
                                "mobileNo": "",
                                "countryCode2": "",
                                "cityCode": "",
                                "telephoneNo": "",
                                "emailId": ""
                            },
                            "officeAddress": {
                                "designation": "",
                                "conpanyName": "",
                                "companyDivision": "",
                                "flatNumber": "",
                                "building": "",
                                "streetName": "",
                                "landmark": "",
                                "area": "",
                                "city": "",
                                "state": "",
                                "pincode": ""
                            },
                            "officeContactDetails": {
                                "countryCode": "",
                                "telephoneNumber": "",
                                "officeExtension": ""
                            },
                            "password": "",
                            "confirmPassword": ""
                        },
                        "travellingDetails": {
                            "dateOfTravel": "",
                            "dateOfArrival": "",
                            "airlineName": "",
                            "ticketNumber": ""
                        }
                    }
                ]
            }
        }
    }
}
