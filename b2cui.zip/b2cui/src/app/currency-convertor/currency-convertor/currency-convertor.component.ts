import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { MasterService } from '../../services/master.services';
import * as momentTimezone from 'moment-timezone';
import { forEach } from '@angular/router/src/utils/collection';
import { DatePipe } from '@angular/common';
import { SessionHelper } from '../../helpers/session-helper';
import { Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { AgentMarginService } from '../../services/agent-margin.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function swal(headerMessage, message, type): any;

declare var jquery: any;
declare var $: any;
declare function initDocument(): any;
declare var Snackbar: any;

@Component({
  selector: 'currency-convertor',
  templateUrl: './currency-convertor.component.html',
  styleUrls: ['./currency-convertor.component.css']
})
export class CurrencyConvertorComponent implements OnInit, OnDestroy {
  public branchId: any = SessionHelper.getLocal('branchIdFromOverview');
  public currencyData: any;
  public currencyName: any;
  public currencyListLeft: any;
  public currencyListRight: any;
  public cityData: any;
  public products: Array<any>;
  public branchData: any;
  public selectedBranch: any;
  public selectedCity: any;
  public exchangeRateObj: any;
  public exchangeRateValue: any;
  public exchangeRateValueBuy: any;
  public exchangeRateValueSell: any;
  public branchValue: any;
  public selectedProduct: any = 'Cash';
  public productValue: any = 'cash';
  public buyInput: any = 0;
  public sellInput: any = 0;
  public buyAmount: any;
  public sellAmount: any;
  public userCity: any;
  public userBranch: any;
  public _primaryComp: any;
  public invalidsubmitted: any;
  
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private meta: Meta, @Inject(DOCUMENT) private _document: any, private router: ActivatedRoute, public agentMargin: AgentMarginService) {
    // this.setCurrencyName();
    this._primaryComp = '/' + navUrl.navUrl();
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    this.setCurrencyDisplayData();
    this.getCityList();
    this.getBranchList('1#mumbai');
    this.setProductList();    
  }

  divideCurrencies() {
    this.currencyListLeft = [];
    this.currencyListRight = [];
    this.currencyData.forEach((currency, index) => {
      if (!(index % 2)) {
        this.currencyListLeft.push(currency);
      } else {
        this.currencyListRight.push(currency);
      }
    });
  }

  getBranchList(cityName) {
    this.masterService.getBranchList(cityName.split('#')[1])
      .subscribe(data => {
        this.branchData = data;
      });
  }

  setProductList() {
    this.products = [
      { value: 'Prepaid Card', label: 'Prepaid Card' },
      { value: 'Cash', label: 'Cash' },
      { value: 'Demand Draft', label: 'Demand Draft' }
    ];
  }

  getCityList() {
    this.masterService.getCityList()
      .subscribe(data => {
        this.cityData = data;
      });
  }

  setCurrencyName() {    
    if (this.checkCurrencyName(this.router.snapshot.queryParams['currencyName'])) {
      this.currencyName = this.router.snapshot.queryParams['currencyName'];
    } else {
      this.currencyName = 'USD';
    }
    this.setExchangeRate('buy');
    this.setExchangeRate('sell');
  }

  checkCurrencyName(currencyName) {
    let currencyDataLength = this.currencyData.length;
    for (let loopVar = 0; loopVar < currencyDataLength; loopVar++) {
      if (this.currencyData[loopVar].currency === currencyName) {
        return true;
      }
    }
    Snackbar.show({
      text: 'The currency name mentioned in URL not found in our database. Please select currency available from list.',
      pos: 'bottom-right',
      actionTextColor: '#ff4444',
    });
    return false;
  }

  setCurrencyDisplayData() {
    this.masterService.getLiveForexDataFromBranchId(this.branchId)
      .subscribe(data => {
        this.currencyData = data;
        this.divideCurrencies();
        this.setCurrencyName();
      }, err => {
        Snackbar.show({
          text: 'Unable to fetch currency list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  ngOnDestroy() {

  }

  updateProduct($event) {
    switch ($event) {
      case 'Prepaid Card':
        this.productValue = 'prepaid';
        break;
      case 'Cash':
        this.productValue = 'cash';
        break;
      case 'Demand Draft':
        this.productValue = 'dd';
        break;
    }
    this.setExchangeRate('buy');
    this.setExchangeRate('sell');
  }

  updateBranch(newValue: number) {
    this.masterService.getBranchDetails(newValue)
      .subscribe(data => {
        let BranchDetails: any = data;
        this.branchId = BranchDetails[0].BranchID;
        this.branchValue = BranchDetails[0].value;
        this.setExchangeRate('buy');
        this.setExchangeRate('sell');
      });
  }

  OnChanges() {

  }

  setExchangeRate(type) {
    this.masterService.getExchangeRate(this.currencyName, this.branchId, this.productValue, type)
      .subscribe(data => {
        this.exchangeRateObj = data;
        if (type === 'buy') {
          this.exchangeRateValueBuy = this.exchangeRateObj.rate;
          this.calculateBuyAmount();
        }
        if (type === 'sell') {
          this.exchangeRateValueSell = this.exchangeRateObj.rate;
          this.calculateSellAmount();
        }
      }, err => {
        Snackbar.show({
          text: 'Unable to fetch exchange rate!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  currencyClicked(currencyName) {
    if (this.currencyName !== currencyName) {
      this.currencyName = currencyName;
      this.setExchangeRate('buy');
      this.setExchangeRate('sell');
    }
  }

  calculateBuyAmount() {
    if (this.buyInput && this.exchangeRateValueBuy) {
      this.buyAmount = this.masterService.precisionRound(this.buyInput / this.exchangeRateValueBuy, 2);
    } else {
      this.buyAmount = 0;
    }
  }

  calculateSellAmount() {
    if (this.sellInput && this.exchangeRateValueSell) {
      this.sellAmount = this.masterService.precisionRound(this.sellInput * this.exchangeRateValueSell, 2);
    } else {
      this.sellAmount = 0;
    }
  }
}
