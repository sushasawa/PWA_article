import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { CurrencyConvertorComponent } from './currency-convertor/currency-convertor.component';
import { MasterService } from '../services/master.services';
import { ChartsModule } from 'ng2-charts';
import { SelectModule } from 'ng-select';
import { FormsModule } from '@angular/forms';
import { NumberLocalePipe } from '../pipes/number-locale.pipe';

const routes: Routes = [
  {
    path: '', children: [
      { path: '', component: CurrencyConvertorComponent }
    ]
  }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    ChartsModule,
    SelectModule,
    FormsModule
  ],
  declarations: [CurrencyConvertorComponent],
  providers: [MasterService]
})
export class CurrencyConvertorModule { }
