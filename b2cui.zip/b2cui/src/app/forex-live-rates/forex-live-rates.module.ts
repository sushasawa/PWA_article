import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ForexRatesComponent } from './forex-rates/forex-rates.component';
import { MasterService } from '../services/master.services';
import { ChartsModule } from 'ng2-charts';
import { SelectModule } from 'ng-select';
import { FormsModule } from '@angular/forms';
import { PipesModule } from '../pipes/pipes.module';

const routes: Routes = [
  {
    path: '', children: [
      { path: '', component: ForexRatesComponent }
    ]
  }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    ChartsModule,
    SelectModule,
    PipesModule,
    FormsModule
  ],
  declarations: [ForexRatesComponent],
  providers: [MasterService]
})
export class ForexLiveRatesModule { }
