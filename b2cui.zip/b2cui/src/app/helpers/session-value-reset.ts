import { SessionHelper } from './session-helper';
import { MasterService } from '../services/master.services';


export class SessionValueReset {
    public masterService: MasterService;
    public userSessionInfo: any;
    public type: any;
    public CurrentBranchId = Number.parseInt(SessionHelper.getLocal('branchIdFromOverview'));
     public  getUserSessionInfo(usersSession) {
        this.userSessionInfo = usersSession;
        this.type = usersSession.type;
        console.log(this.userSessionInfo);
        this.initUserInfo();
        return this.userSessionInfo;
    }


    initUserInfo() {
        console.log('INITIALIZED');
        this.userSessionInfo[this.type].traveller.map((currentTraveller , TravellerIndex) => {

            if (currentTraveller.prepaidCard) {
                currentTraveller.prepaidCardDetails.map((prepaidCard , prepaidCardIndex) => {
                    if (!(prepaidCard.forexAmount === undefined || prepaidCard.exchangeRate === undefined)) {
                         this.updatePrepaidCurrencyCode(prepaidCardIndex, prepaidCard.currencyCode, TravellerIndex);
                    }
                });
            }
            if (currentTraveller.cash) {
                currentTraveller.cashDetails.map((Cash , CashIndex) => {
                    if (!(Cash.forexAmount === undefined || Cash.exchangeRate === undefined)) {
                        this.updateCashCurrencyCode(CashIndex, Cash.currencyCode, TravellerIndex);
                    }
                });
            }
            if (currentTraveller.travellerCheque) {
                currentTraveller.travellerChequeDetails.map((TravellerCheque , TravellerChequeIndex) => {
                    if (!(TravellerCheque.forexAmount === undefined || TravellerCheque.exchangeRate === undefined)) {
                       this.updateTravellerChequeCurrencyCode(TravellerChequeIndex, TravellerCheque.currencyCode, TravellerIndex);
                    }
                });
            }
            if (currentTraveller.demandDraft) {
                currentTraveller.demandDraftDetails.map((DemandDraft , DemandDraftIndex) => {
                    if (!(DemandDraft.forexAmount === undefined || DemandDraft.exchangeRate === undefined)) {
                       this.updateDemandDraftCurrencyCode(DemandDraftIndex, DemandDraft.currencyCode, TravellerIndex );
                    }
                });
            }
        });
    }
    // region Update currency code event listeners
    updatePrepaidCurrencyCode(prepaidDetailIndex: number, newValue: string, currentTravellerIndex: any) {  console.log('IN PREPAID ++++++++++++++');
        this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
        console.log('PREVIOUS' + this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
            .exchangeRate);
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', 'sell')
            .subscribe(data => {
                this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
                    .exchangeRate = data;
                console.log('Exchange rate called NEW'+ this.userSessionInfo[this.type].traveller[currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
                .exchangeRate );
                this.updateUsedAmount();
            }, err => {
                //  swal('Oops...', 'Unable to fetch exchange rate!', 'error');
            });


    }

    updateCashCurrencyCode(cashDetailIndex: number, newValue: string, currentTravellerIndex: any) {
        this.userSessionInfo[this.type].traveller[currentTravellerIndex].cashDetails[cashDetailIndex].currencyCode = newValue;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'cash', 'sell')
            .subscribe(data => {
                this.userSessionInfo[this.type].traveller[currentTravellerIndex].cashDetails[cashDetailIndex].exchangeRate = data;
                this.updateUsedAmount();
            }, err => {
                // swal('Oops...', 'Unable to fetch exchange rate!', 'error');
            });
    }

    updateTravellerChequeCurrencyCode(travellerChequeDetailIndex: number, newValue: string, currentTravellerIndex: any) {
        this.userSessionInfo[this.type].traveller[currentTravellerIndex].travellerChequeDetails[travellerChequeDetailIndex]
            .currencyCode = newValue;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', 'sell')
            .subscribe(data => {
                this.userSessionInfo[this.type].traveller[currentTravellerIndex].travellerChequeDetails[travellerChequeDetailIndex]
                    .exchangeRate = data;
                this.updateUsedAmount();
            }, err => {
                //   swal('Oops...', 'Unable to fetch exchange rate!', 'error');
            });
    }

    updateDemandDraftCurrencyCode(demandDraftDetailIndex: number, newValue: string, currentTravellerIndex: any) {
        this.userSessionInfo[this.type].traveller[currentTravellerIndex].demandDraftDetails[demandDraftDetailIndex]
            .currencyCode = newValue;
        this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', 'sell')
            .subscribe(data => {
                this.userSessionInfo[this.type].traveller[currentTravellerIndex].demandDraftDetails[demandDraftDetailIndex]
                    .exchangeRate = data;
                this.updateUsedAmount();

            }, err => {
                //    swal('Oops...', 'Unable to fetch exchange rate!', 'error');
            });
    }



    updateUsedAmount() {
        let travellerTotal = 0;
        console.log('USED AMOUNT CALLED');
        this.userSessionInfo[this.type].traveller.forEach(currentTraveller => {
            let currentTravellerTotal = 0;
            if (currentTraveller.prepaidCard) {
                currentTraveller.prepaidCardDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }
            if (currentTraveller.cash) {
                currentTraveller.cashDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }
            if (currentTraveller.travellerCheque) {
                currentTraveller.travellerChequeDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }
            if (currentTraveller.demandDraft) {
                currentTraveller.demandDraftDetails.forEach(element => {
                    if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                        currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                    }
                });
            }

            travellerTotal += currentTravellerTotal;
            currentTraveller.usedAmount = currentTravellerTotal;
        });


        this.userSessionInfo[this.type].usedAmount = travellerTotal;

        if (this.userSessionInfo[this.type].usedAmount !== 0) {
            this.masterService.getTaxes(this.userSessionInfo[this.type].usedAmount)
                .subscribe(res => {
                    const result: any = res;
                    this.userSessionInfo[this.type].usedAmount += result.TotalTax;
                    this.updateBalanceAmount();
                    console.log('AMOUNT' + this.userSessionInfo[this.type].usedAmount, 'TAXES' + result.TotalTax);
                }, err => {
                    //  swal('Oops', 'Error fetching taxes', 'error');
                });
        }

        this.updateBalanceAmount();
    }

    updateBalanceAmount() {
        if (Number.isNaN(Number.parseInt(this.userSessionInfo[this.type].budgetAmount))) {
            this.userSessionInfo[this.type].balanceAmount = '';
        } else if (this.userSessionInfo[this.type].budgetAmount !== '0' && this.userSessionInfo[this.type].budgetAmount !== 0) {
            this.userSessionInfo[this.type].balanceAmount = (this.userSessionInfo[this.type].budgetAmount
                - this.userSessionInfo[this.type].usedAmount);
            this.userSessionInfo[this.type].balanceAmount
                = this.userSessionInfo[this.type].balanceAmount < 0 ? 0 : this.userSessionInfo[this.type].balanceAmount;
            if (this.userSessionInfo[this.type].budgetAmount - this.userSessionInfo[this.type].usedAmount <= 0) {
                // swal('Oops', 'You have exceeded your budget!!', 'warning');
            }
        }
    }


}
