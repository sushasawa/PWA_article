export interface GenericEntity {
    Id: string,
    Name: string
}