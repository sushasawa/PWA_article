import { environment } from '../../environments/environment';
import { SessionHelper } from './session-helper';
export class Constants {
    static serviceUrl = environment.API_URL;
    static tollFreeContact = '1800 209 0400';
    static smsServiceCharges = 99;
    static skipAdhaarValidationFlag = true;
    static Bank_Correspondent_Bank_Charges = 25;
    static PREPAID_CURRENCY_CODES = ['SAR', 'AED', 'THB', 'NZD', 'ZAR', 'HKD'];
    static PromotionalFIlePath = environment.CLIENT_URL;
    static getSubPurpose() {
        return this.serviceUrl + '/master/getSubPurpose';
    }

    static gettollFreeContact() {
        return this.tollFreeContact;
    }

    static getSmsServiceCharges() {
        return this.smsServiceCharges;
    }

    static getSkipAdhaarValidationFlag() {
        return this.tollFreeContact;
    }

    static getBankCorrespondentCharges() {
        return this.Bank_Correspondent_Bank_Charges;
    }

    static getAgentIdData() {
        return this.serviceUrl + '/master/userBackground';
    }

    static getIExchangeAgentId(AgentId) {
        return this.serviceUrl + '/master/getIExchangeAgentId?AgentID=' + AgentId;
    }

    static getAgentIdByAliasName(AliasName) {
        return this.serviceUrl + '/master/getAgentIdByAliasName?AliasName=' + AliasName;
    }

    static getAgentMargin(AgentId) {
        return this.serviceUrl + '/master/getAgentMargin?id=' + AgentId;
    }

    static getBranchListService(cityName: any) {
        return this.serviceUrl + '/master/Branch?City=' + cityName;
    }

    static getBranchDetailsService(val) {
        return this.serviceUrl + '/master/BranchDetails?branchId=' + val;
    }

    static getDestinationListService() {
        return this.serviceUrl + '/master/Destination';
    }

    static getNationality() {
        return this.serviceUrl + '/master/nationality';
    }

    static getCurrencyListService() {
        return this.serviceUrl + '/master/Currency';
    }

    static getExchangeRateService() {
        return this.serviceUrl + '/master/getExchangeRate_version1';
    }

    static getDocumentListService() {
        return this.serviceUrl + '/document/documentList';
    }

    static getDeliveryTypeListService() {
        return this.serviceUrl + '/master/deliveryType';
    }

    static getPurposeListService(processId: any) {
        return this.serviceUrl + '/master/TravelPurpose?processId=' + processId;
    }

    static getBanksListService() {
        return this.serviceUrl + '/master/Banks';
    }

    static getBanksService() {
        return this.serviceUrl + '/master/getBanksList';
    }

    static getCityListService() {
        return this.serviceUrl + '/master/CityList';
    }

    static getDeliveryAmtService() {
        return this.serviceUrl + '/document/DeliveryAmt';
    }

    static setUserDetailWithAdharService() {
        return this.serviceUrl + '/register/registerAdhar';
    }

    static getPincodeDetailsService() {
        return this.serviceUrl + '/register/getPincodeDetails';
    }

    static getDocUploadApi() {
        return this.serviceUrl + '/upload';
    }

    static setUserInfo() {
        return this.serviceUrl + '/users/userInfo';
    }

    static updateUserInfo() {
        return this.serviceUrl + '/UpdateUser/UpdateUserInfo';
    }


    static getLoginService() {
        return this.serviceUrl + '/master/login';
    }

    static getForgotPasswordService() {
        return this.serviceUrl + '/master/forgotPassword';
    }

    static getResetPasswordService() {
        return this.serviceUrl + '/master/resetPassword';
    }

    static validateResetPasswordService() {
        return this.serviceUrl + '/master/validateResetPasswordUrl';
    }

    static validateAnnualBalanceComplience() {
        return this.serviceUrl + '/ComplienceCheck/annualComplience';
    }

    static getCardDetailsService() {
        return this.serviceUrl + '/users/cardDetails';
    }

    static sessionDumpService() {
        return this.serviceUrl + '/mongodump/sessiondump';
    }

    static transactionDumpService() {
        return this.serviceUrl + '/transaction/SaveRequestData';
    }
    static callPaymentGateway() {
        return this.serviceUrl + '/master/paymentGatewayService';
        // return "http://10.21.20.86:8001/api/values";
    }

    static callPaymentGatewayPaynimo() {
        return this.serviceUrl + '/master/paymentGatewayServicePaynimo';
        // return "http://10.21.20.86:8001/api/values";
    }

    static getLoggedInUserInfoService(val) {
        return this.serviceUrl + '/account/userInfo?uid=' + val;
    }

    static getUserProfilePicService() {
        return this.serviceUrl + '/profile';
    }

    static createAlertService() {
        return this.serviceUrl + '/createAlert';
    }

    static getTempOrderNumber() {
        return this.serviceUrl + '/master/OrderNumber';
    }

    static generateInvoiceNoService() {
        return this.serviceUrl + '/transaction/generateInvoiceNo';
    }

    static getOrderData() {
        return this.serviceUrl + '/mongoDump/getSessionFromMongo';
    }

    static getOrderDataFromEmail() {
        return this.serviceUrl + '/mongoDump/getSessionFromMongoCheckEmail';
    }

    static getLiveForex() {
        return this.serviceUrl + '/liveForex/LiveForexRates';
    }

    static getLiveForexOverview(CurrentBranchId) {
        return this.serviceUrl + '/liveForex/LiveForexRatesOverview_C?branchId=' + CurrentBranchId;
    }

    static getLiveForexFromBranchId(val, agentID) {
        return this.serviceUrl + '/liveForex/LiveForexRatesFromBranchId_Version1?branchId=' + val + '&agentId=' + agentID;
    }


    static getForexTrend(val) {
        return this.serviceUrl + '/liveForex/ForexTrend?currencyCode=' + val;
    }

    static getForexTrendFromBranchId(currencyCode, branchId, agentId) {
        return this.serviceUrl + '/liveForex/D_getTrend_Weekwise?currencyCode=' + currencyCode + '&branchId=' + branchId + '&agentId=' + agentId;
    }


    static getForexTrendSell(val) {
        return this.serviceUrl + '/liveForex/ForexTrendSell?currencyCode=' + val;
    }

    static getForexTrendSellFromBranchId(currencyCode, branchId, agentId) {
        return this.serviceUrl + '/liveForex/D_getTrend_Weekwise?currencyCode=' + currencyCode + '&branchId=' + branchId + '&agentId=' + agentId;
    }

    static getCheckEmail() {
        return this.serviceUrl + '/CheckEmail';
    }



    static getForexTrendSellDaywise(val) {
        return this.serviceUrl + '/liveForex/ForexTrendSellDaywise?currencyCode=' + val;
    }

    static getForexTrendSellDaywiseFromBranchId(currencyCode, branchId, agentId) {
        return this.serviceUrl + '/liveForex/D_getTrend_Daywise?currencyCode=' + currencyCode + '&branchId=' + branchId + '&agentId=' + agentId;
    }


    static getForexTrendBuyDaywise(val) {
        return this.serviceUrl + '/liveForex/ForexTrendBuyDaywise?currencyCode=' + val;
    }

    static getForexTrendBuyDaywiseFromBranchId(currencyCode, branchId, agentId) {
        return this.serviceUrl + '/liveForex/D_getTrend_Daywise?currencyCode=' + currencyCode + '&branchId=' + branchId + '&agentId=' + agentId;
    }

    static getAlertService() {
        return this.serviceUrl + '/createAlert/getAlert';
    }

    static deleteAlertService() {
        return this.serviceUrl + '/createAlert/delete';
    }

    static updateAlertService() {
        return this.serviceUrl + '/createAlert/update';
    }

    static wishListService(UserId) {
        return this.serviceUrl + '/WishList?userId=' + UserId;
    }

    static getUserDocumentsService(UserId) {
        return this.serviceUrl + '/Document/getUserDocuments?uid=' + UserId;
    }

    static updateKycService() {
        return this.serviceUrl + '/Document/kyc';
    }

    static sendAadhaarOtp() {
        return this.serviceUrl + '/adharAuth/sendOtp';
    }

    static validateAadhaarOtp() {
        return this.serviceUrl + '/adharAuth/validateOtp';
    }

    static getOrdersListService(uid) {
        return this.serviceUrl + '/orders/GetOrdersList?uid=' + uid;
    }

    static changePasswordService() {
        return this.serviceUrl + '/users/ChangePassword';
    }

    static setGrievancesService() {
        return this.serviceUrl + '/createAlert/Grievances';
    }

    static getTaxes(totalPayable: number) {
        return this.serviceUrl + '/master/Taxes?totalPayable=' + totalPayable;
    }

    static releaseTempNo(tempNo: number) {
        return this.serviceUrl + '/master/releaseTempNo?tempNo=' + tempNo;
    }

    static setFeedback() {
        return this.serviceUrl + '/footerAssets/feedback';
    }

    static sendEnquiry() {
        return this.serviceUrl + '/footerAssets/sendEnquiry';
    }

    static checkCardAvailable(cardNo: number) {
        return this.serviceUrl + '/master/checkCardAvailable?cardNo=' + cardNo;
    }

    static deleteDocumentService() {
        return this.serviceUrl + '/DeleteDoc';
    }

    static RuleTest() {
        return this.serviceUrl + '/master/setData';
    }

    static getAdaarValidationService() {
        return this.serviceUrl + '/adharAuth/validateAdharDemo';
    }

    static getAirlineNamesService() {
        return this.serviceUrl + '/master/AirlineName';
    }

    static getChargesService() {
        return this.serviceUrl + '/Charges/';
    }

    static newLeadLoginService() {
        return this.serviceUrl + '/account/newLeadLogin';
    }

    static addNewLeadService() {
        return this.serviceUrl + '/account/addNewLead';
    }

    static updateLeadPassService() {
        return this.serviceUrl + '/account/updateLeadPass';
    }

    static checkActiveUrlService(url) {
        return this.serviceUrl + '/account/checkUrlServie?url=' + url;
    }

    static getUserInfoService(url) {
        return this.serviceUrl + '/BTBRegister/B2CUserInfo?EmailId=' + url;
    }

    static removeTravellerService() {
        return this.serviceUrl + '/account/removeTraveller';
    }


    static generateTransactionIdService() {
        return this.serviceUrl + '/transaction/generateTransactionId';
    }

    static initTransactionSavingService() {
        return this.serviceUrl + '/transaction/saveTransactionRequest';
    }

    static getTransactionByIdService(id) {
        return this.serviceUrl + '/transaction/transactionById?transactionId=' + id;
    }

    static sendSellInvoiceDataService() {
        return this.serviceUrl + '/transaction/sellIexchnagePOST';
    }


    static getCurrencyRateForRuleService(branchId, AgentId) {
        return this.serviceUrl + '/master/getCurrencyRateForRule_version1?branchId=' + branchId + '&agentId=' + AgentId;
    }

    static setUserIdToSessionService(tempNumber, emailId, id) {
        return this.serviceUrl + '/mongodump/setIdSession?' + 'tempNumber=' + tempNumber + '&emailId=' + emailId + '&id=' + id;
    }

    static updateExistingUsersLeadProspectsAndUrlActiveStatusService() {
        return this.serviceUrl + '/agent/existingLeadUpdate';
    }

    static updateDocStatusService() {
        return this.serviceUrl + '/transaction/updateDocStatus';
    }

    static getAgentThemeService() {
        return this.serviceUrl + '/agent/AgentTemplate';
    }

    static getAgentThemeDetailsService() {
        return this.serviceUrl + '/agent/getAgentsThemeDetails';
    }

    static currencyNotificationService() {
        return this.serviceUrl + '/mails/sendCurrencyNotification';
    }

    static getBulkExchangeRateService() {
        const AgentId: any = SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID');
        return this.serviceUrl + '/master/bulkExchangeRate?AgentId=' + AgentId;
    }

    static getPromotionalDataService(promotionName: any) {
        return '/assets/promotional/' + promotionName + '.json';
    }
}
