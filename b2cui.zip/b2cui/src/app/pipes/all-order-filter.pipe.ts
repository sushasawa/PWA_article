import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'allOrderFilter'
})
export class AllOrderFilterPipe implements PipeTransform {

  transform(Orders: any, type: any): any {
    console.log(Orders);
    console.log(type);
    return Orders;
  }

}
