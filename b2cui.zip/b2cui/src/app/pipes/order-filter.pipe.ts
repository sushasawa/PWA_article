import { Pipe, PipeTransform } from '@angular/core';

declare var $: any;
declare function initDocument(): any;
declare function initMyAccountJS(): any;
@Pipe({
  name: 'orderFilter'
})
export class OrderFilterPipe implements PipeTransform {
  transform(Orders: any, type: any): any {

    if (type) {
      return Orders.filter((Order) => Order.Operation === type);
    } else {
      return Orders;
    }
  }

}
