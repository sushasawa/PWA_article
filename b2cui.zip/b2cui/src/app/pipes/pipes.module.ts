import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NumberLocalePipe } from './number-locale.pipe';
import { SplitPipe } from './split.pipe';
import { OrderFilterPipe } from './order-filter.pipe';
import { StatusFilterPipe } from './status-filter.pipe';
import { OrderDateFilterPipe } from './order-date-filter.pipe';
import { AllOrderFilterPipe } from './all-order-filter.pipe';
import { LimitToPipe } from './limit-to.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [NumberLocalePipe, SplitPipe, OrderFilterPipe, StatusFilterPipe, OrderDateFilterPipe, AllOrderFilterPipe, LimitToPipe],
  exports: [NumberLocalePipe, SplitPipe, OrderFilterPipe , StatusFilterPipe , OrderDateFilterPipe , AllOrderFilterPipe, LimitToPipe]
})
export class PipesModule { }
