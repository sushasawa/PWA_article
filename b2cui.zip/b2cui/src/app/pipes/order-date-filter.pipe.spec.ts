import { OrderDateFilterPipe } from './order-date-filter.pipe';

describe('OrderDateFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new OrderDateFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
