import { Component, OnInit, HostListener, Inject } from '@angular/core';
import { NavigationCancel, Event, NavigationEnd, NavigationError, NavigationStart, Router, RoutesRecognized, ActivatedRoute } from '@angular/router';
import { Location, PopStateEvent } from '@angular/common';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { Observable } from 'rxjs/Observable';
import { DOCUMENT } from '@angular/platform-browser';
import 'rxjs/add/observable/fromEvent';
import { AgentMarginService } from './services/agent-margin.service';
import { SharedService } from './services/shared.service';
import { GlobalLoaderService } from './services/global-loader.service';
import { NavigatePathService } from '../app/services/navigate-path.service';
import { SessionHelper } from './helpers/session-helper';

declare var $: any;
declare var Tawk_API: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  private lastPoppedUrl: string;
  private yScrollStack: number[] = [];
  public currentRoute: any;
  public firstMouseOut: any = false;
  public mouseoutEvent: any;
  public pageChanges: any = false;
  public loading: any = false;
  public UrlParam: any = '';
  public wrongURL: any = true;
  // tslint:disable-next-line:max-line-length
  constructor(private _loadingBar: SlimLoadingBarService, private navUrl: NavigatePathService, private _SharedService: SharedService, private router: Router, private location: Location, @Inject(DOCUMENT) private document: any, public agentMargin: AgentMarginService, private globalLoaderService: GlobalLoaderService , private _router: ActivatedRoute) {
  console.log(this._router);
  this._router.queryParams.subscribe(params => {
    if (params && params['promotion']) {
      SessionHelper.setSession('promotion', params['promotion']);
    }
  });
  }

  ngOnInit() {
    this._router.queryParams.subscribe(params => {
      if (params && params['promotion']) {
        SessionHelper.setSession('promotion', params['promotion']);
      }
    });


    this.location.subscribe((ev: PopStateEvent) => {
      console.log(ev);
      this.lastPoppedUrl = ev.url;
    });
    this.globalLoaderService.subject.subscribe((event: any) => {
      setTimeout(() => {
        this.loading = false;
      }, 300);
    });
    this.router.events.subscribe((event: Event) => {
      this.navigationInterceptor(event);
    });
    this.mouseLeaveEvent();
    this.agentMargin.setAgentMargin();
    // this._SharedService.getAgentTheme();
 
  }

  /**
	* This is used to intercept and show Loading bar based on the current state of our
	* Router navigation
	* @param {Event} event
	*/
  private navigationInterceptor(event: Event): void {
    if(event instanceof RoutesRecognized) {
      this.checkURL(event.urlAfterRedirects);
    }
    if (event instanceof NavigationStart) {     
      this.loading = true;
      this._loadingBar.start();
      if (event.url !== this.lastPoppedUrl) {
        this.yScrollStack.push(window.scrollY);
      }
      this.pageChanges = true;
      setTimeout(() => {
        if (this.globalLoaderService.isLoading === false)
        this.loading = false;
      }, 10000);
    }
    if (event instanceof NavigationEnd) {
      setTimeout(() => {
        if (this.globalLoaderService.isLoading === false)
        this.loading = false;
      }, 0);
      this._loadingBar.complete();
      this.UrlParam = this.navUrl.navUrl();
      this.currentRoute = this.router.url;
      if (event.url === this.lastPoppedUrl) {
        this.lastPoppedUrl = undefined;
        window.scrollTo(0, this.yScrollStack.pop());
      } else {
        window.scrollTo(0, 0);
      }
      this.pageChanges = false;
    }

    // Set loading state to false in both of the below events to hide the loader in case a request fails
    if (event instanceof NavigationCancel || event instanceof NavigationError) {
      this._loadingBar.stop();
      this.loading = false;
    }
  }

  checkURL(url) {
    let urlArr = url.split('/'), navPath = this.navUrl.navUrl();
    if (!navPath) {
      if (urlArr[1] === 'login') {
        urlArr[1] = 'CNK';
        this.router.navigateByUrl(urlArr.join('/'));
      }
      this.navUrl.getAgentId(urlArr[1], () => {
        this.wrongURL = false;
      });
      return;
    } else if (navPath !== urlArr[1]) {
      urlArr[1] = navPath;
      this.router.navigateByUrl(urlArr.join('/'));
    }
    this.navUrl.getAgentId(urlArr[1], () => {
      this.wrongURL = false;
    });
  }

  startChat() {
    $.magnificPopup.close();
  }

  mouseLeaveEvent() {
    this.mouseoutEvent = Observable.fromEvent(document.body, 'mouseleave').subscribe((e: any) => {
      if (e.clientY <= 0) {
        $.magnificPopup.open({
          items: {
            src: '#exit-popup'
          },
          type: 'inline'
        });
        this.unsubMouseEvents();
      }
    });
  }

  unsubMouseEvents() {
    this.mouseoutEvent.unsubscribe();
  }

}
