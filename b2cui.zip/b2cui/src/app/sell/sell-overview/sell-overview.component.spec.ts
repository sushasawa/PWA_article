import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellOverviewComponent } from './sell-overview.component';

describe('SellOverviewComponent', () => {
  let component: SellOverviewComponent;
  let fixture: ComponentFixture<SellOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
