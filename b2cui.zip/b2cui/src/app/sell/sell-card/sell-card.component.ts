import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { Console } from '@angular/core/src/console';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { GlobalLoaderService } from '../../services/global-loader.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

declare function initDocument(): any;
declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-sell-card',
  templateUrl: './sell-card.component.html',
  styleUrls: ['./sell-card.component.css']
})
export class SellCardComponent implements OnInit {

  public userSessionInfo: any;
  public currentTravellerIndex: number;
  public routerUrl: any;
  public validations:any = [];
  public invalidsubmited:any = false;
  public bankDetails:any;
  public loaded: any = false;
  public _primaryComp: any;
  public cashAvailable: any = false;
  public cardAvailable: any = false;
  public CurrentBranchId: any;
  constructor(private router: Router, private navUrl: NavigatePathService, private masterService: MasterService, private meta: Meta, @Inject(DOCUMENT) private _document: any, private globalLoaderService: GlobalLoaderService) {
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSale'));
    this._primaryComp = '/' + navUrl.navUrl();
    this.currentTravellerIndex = 0;
    this.CurrentBranchId = Number.parseInt(SessionHelper.getLocal('branchIdFromOverview'));
    this.masterService.getBank()
    .subscribe(data => {
      let result:any=data;
      this.bankDetails = result;
      this.iterateTraveller();
    }, err => {
      console.log(err);
    });
    this._document.title = 'Select your card for cashout';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Select your card for cashout' });
  }

  iterateTraveller(){
    this.userSessionInfo.sellScreen.traveller.forEach((traveller, index) => {
      if (traveller.cash) {
        this.cashAvailable = true;
      }

      if (traveller.prepaidCard) {
        this.loaded = true;
        this.globalLoaderService.setLoading();
      }
      this.masterService.getCardDetails('L9390122')
        .subscribe(data => {
          this.loaded = false;
          this.globalLoaderService.removeLoading();
          this.configCardData(data, traveller);
          this.cardAvailable = true;         
          // traveller.cardData = data;
        }, err => {
          Snackbar.show({
            text: 'No Prepaid Card Details found for this account.',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
          this.loaded = false;
          this.globalLoaderService.removeLoading();
        });

      // const user = this.userSessionInfo.sellScreen.traveller[index];
      
      if (traveller.bankDetails === undefined) {
        traveller.bankDetails = {
          'name': traveller.registrationInfo.firstName.value + ' ' + traveller.registrationInfo.middleName + ' ' + traveller.registrationInfo.lastName,
          'bank': '',
          'accountNumber': '',
          'branch': '',
          'ifsc': ''
        };
      } else {
        traveller.bankDetails.name = traveller.registrationInfo.firstName.value + ' ' + traveller.registrationInfo.middleName + ' ' + traveller.registrationInfo.lastName;
      }
      this.addValidation(traveller, index);
    });
    this.selectTraveller(0);
  }

  selectTraveller(index: number) {
    this.currentTravellerIndex = index;
    this.userSessionInfo.sellScreen.traveller.forEach((traveller) => {
      traveller.selected = false;
    });
    this.userSessionInfo.sellScreen.traveller[index].selected = true;
  }

  ngOnInit() {
    $('body').attr('id', '');
  }

  updateCashout(travellerIndex: number, dataIndex: number, balanceIndex: number, newValue) {
    this.userSessionInfo.sellScreen.traveller[travellerIndex].cardData[dataIndex].balance[balanceIndex].cashout = newValue.target.checked;
  }

  updateCloseCard(travellerIndex: number, dataIndex: number, newValue) {
    this.userSessionInfo.sellScreen.traveller[travellerIndex].cardData[dataIndex].balance.forEach((balance) => {
      if(balance.cashout){
        balance.cashout = !(newValue.target.checked);
        balance.cashoutAmount = '';
      }      
    });
    this.userSessionInfo.sellScreen.traveller[travellerIndex].cardData[dataIndex].closeCard = newValue.target.checked;
  }

  updateSession() {
    SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfo));
  }

  submitAndRedirect() {
    if (this.cashAvailable === false && this.cardAvailable === false) {
      Snackbar.show({
        text: 'Can\'t proceed with this transaction, as there is no prepaid card details available with your account',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    this.invalidsubmited = false;
    let next = false;
    this.checkValidation();
    if(this.invalidsubmited){
      // swal('Cannot proceed', 'Please fill required inputs', 'error');
      Snackbar.show({
        text: 'Please fill required inputs',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    this.userSessionInfo.sellScreen.traveller.forEach(element => {
      if (element.cash) {
        next = true;
      }
      this.updatePrepaidCardDetails(element);
    });

    if (next) {
      this.routerUrl = '/sell/delivery-mode';
    } else {
      this.routerUrl = '/sell/forex-review';
    }

    this.userSessionInfo['nextLink'] = this.routerUrl;

    this.updateSession();

    console.log(this.userSessionInfo);

    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });

    if (next) {
      this.router.navigateByUrl(this._primaryComp + '/sell/delivery-mode');
    } else {
      this.router.navigateByUrl(this._primaryComp + '/sell/forex-review');
    }
  }

  updatePrepaidCardDetails(element) {

  }

  bankNameChanged($event, currentTravellerIndex) {
    if ($event !== '') {
      this.validations[currentTravellerIndex][0] = true;
    }else {
      this.validations[currentTravellerIndex][0] = false;
    }
  }

  // accountNoChanged($event, currentTravellerIndex){
  //   if($event !== ''){
  //     this.validations[currentTravellerIndex][1] = true;
  //   }else{
  //     this.validations[currentTravellerIndex][1] = false;
  //   }
  // }

  accountNoChanged($event, currentTravellerIndex) {
    // console.log("IN1", $event.length)
    if ($event !== '') {
      this.validations[currentTravellerIndex][1] = true;
    }else {
      this.validations[currentTravellerIndex][1] = false;
    }
  }







  branchAddressChanged($event, currentTravellerIndex){
    if($event !== ''){
      this.validations[currentTravellerIndex][2] = true;
    }else{
      this.validations[currentTravellerIndex][2] = false;
    }
  }

  ifscCodeChanged($event, currentTravellerIndex){
    if($event !== ''){
      this.validations[currentTravellerIndex][3] = true;
    }else{
      this.validations[currentTravellerIndex][3] = false;
    }
  }

  checkValidation(){
    this.validations.forEach((validation)=>{
      validation.forEach((validationElement) =>{
        if(!validationElement){
          this.invalidsubmited = true;
        }
      }); 
      if(validation.length<4){
        this.invalidsubmited = true;
      }     
    });
  }

  addValidation(traveller, index){
    var validation = [];
    if(traveller.bankDetails.bank){
      validation[0] = true;
    }
    if(traveller.bankDetails.accountNumber){
      validation[1] = true;
    }
    if(traveller.bankDetails.branch){
      validation[2] = true;
    }
    if(traveller.bankDetails.ifsc){
      validation[3] = true;
    }
    this.validations[index] = validation;
  }

  configCardData(cardData, traveller) {
    let cardDetailsData = {}, cardDetailsArr = [];
    for (let card in cardData) {
      if (!cardDetailsData[cardData[card].CardNumber]) {
        cardDetailsData[cardData[card].CardNumber] = {
          cardNo: cardData[card].CardNumber,
          bank: this.getBankName(cardData[card].CustomerCode),
          bankCode: cardData[card].CustomerCode,
          balance: {}
        }        
      }
      cardDetailsData[cardData[card].CardNumber].balance[cardData[card].Code] = { currencyCode: cardData[card].Code };
      
    }
    for (let card in cardDetailsData) {
      let balanceArr = [];
      let balances = cardDetailsData[card].balance;
      for (let balance in balances) {        
        balanceArr.push(balances[balance]);
        this.masterService.getExchangeRate(balances[balance].currencyCode, this.CurrentBranchId, 'prepaid', 'sell', cardDetailsData[card].bankCode)
          .subscribe(data => {
            const result: any = data;
            balances[balance].exchangeRate = result;
            console.log(traveller.cardData, '>>>>>>>>>>>>>>>>');
          });
      }
      cardDetailsData[card].balance = balanceArr;
      cardDetailsArr.push(cardDetailsData[card]);
    }
    if(!traveller.cardData){
      traveller.cardData = cardDetailsArr;
    }
    
    
  }

  getBankName(bankCode){
    let bankName;
    for(let bank in this.bankDetails){
      if(this.bankDetails[bank].CustomerCode === bankCode){
        return this.bankDetails[bank].BankName;
      }
    };
  }

}
