import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SelectModule} from 'ng-select';
import { SellOverviewComponent } from './sell-overview/sell-overview.component';
import { Routes, RouterModule } from '@angular/router';
import { ForexCommonModule } from '../forex-common/forex-common.module';
import { PipesModule } from '../pipes/pipes.module';

import { MasterService } from '../services/master.services';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SellCardComponent } from './sell-card/sell-card.component';
import { CreateAccountAdharComponent } from './create-account-adhar/create-account-adhar.component';
import { ForexReviewComponent } from './forex-review/forex-review.component';
import { AuthService } from '../services/auth.service';
import { AuthGuardService as AuthGuard } from '../services/auth-guard.service';
import { CanDeactivateGuard } from '../services/can-deactivate-guard.service';
import { CommonRegisterLoginComponent } from '../forex-common/common-register-login/common-register-login.component';
import { CommonChecklistComponent } from '../forex-common/common-checklist/common-checklist.component';
import { CommonUsercreationComponent } from '../forex-common/common-usercreation/common-usercreation.component';
import { CommonRegisterLoginAdharComponent } from '../forex-common/common-register-login-adhar/common-register-login-adhar.component';
import { CommonConfirmationComponent } from '../forex-common/common-confirmation/common-confirmation.component';
import { CommonReviewUserDetailsComponent } from '../forex-common/common-review-user-details/common-review-user-details.component';
import { ForexReviewEditComponent } from './forex-review-edit/forex-review-edit.component';
import { CommonDeliveryModeComponent } from '../forex-common/common-delivery-mode/common-delivery-mode.component';
import { FailComponent } from '../forex-common/fail/fail.component';
import { CommonCompareDetailsComponent } from '../forex-common/common-compare-details/common-compare-details.component';


const sessDataObj: any = {
  sessionDataProcess: 'userSessionInfoSale',
  sessionDataProcessScreen: 'sellScreen',
  processType: 'Sell'
}

const routes: Routes = [
  {
    path: '', children: [
      {
        path: '',
        component: SellOverviewComponent, canDeactivate: [CanDeactivateGuard]
      },
      {
        path: 'checklist',
        component: CommonChecklistComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '2',
          nextLink: '/sell/register-login'
        }
      },
      {
        path: 'create-account', component: CommonUsercreationComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/sell/review-userdetail-adhar'
        }
      },
      {
        path: 'register-login',
        component: CommonRegisterLoginComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/sell/review-userdetail-adhar'
        }
      },
      {
        path: 'register-login-adhar',
        component: CommonRegisterLoginAdharComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
        }
      },
      {
        path: 'create-account', component: CommonUsercreationComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/sell/review-userdetail-adhar'
        }
      },
      { 
        path: 'delivery-mode',
         component: CommonDeliveryModeComponent,
          canActivate: [AuthGuard],
          data: {
            sessData: sessDataObj,
            wizardStepNumber: '5',
            mainHeading : 'Pick-up Mode',
            subHeading : 'Forex Pick-up Options',
            // tslint:disable-next-line:max-line-length
            description : 'Please choose any of the below options for delivery of your foreign exchange',
            standardHeading : 'Standard Pick-up',
            standardDesc : 'Pick-up within 6 - 8 Hours*',
            expressHeading : 'Express Pick-up',
            expressDesc : 'Pick-up within 3 Hours*',
            tabHomeHeading : 'Pick-up from My Home',
            tabOfficeHeading : 'Pick-up from My Office',
            datetimetxt : 'Select Pick-up',
            nextLink: '/sell/forex-review',

          }
    },
      { path: 'card', component: SellCardComponent, canActivate: [AuthGuard] },
      { path: 'create-account-adhar', component: CreateAccountAdharComponent ,
      data: {
        sessData: sessDataObj,
        wizardStepNumber: '3',
        nextLink: '/sell/review-userdetail-adhar'
      }},
      {
        path: 'compare-details',
        component: CommonCompareDetailsComponent,
        data: {
          sessData: sessDataObj
        }
      },
      {
        path: 'review-userdetail-adhar', component: CommonReviewUserDetailsComponent, 
        // canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/sell/card'
        }
      },
      { path: 'forex-review', component: ForexReviewComponent, canActivate: [AuthGuard] },
      { path: 'forex-review-edit', component: ForexReviewEditComponent, canActivate: [AuthGuard] },
      {
        path: 'confirmation', component: CommonConfirmationComponent, canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '7',
          deliveryMode: false,
          deliveryTxt: '',
          purpose: false
        }
      },
      {
        path : 'fail',
        component : FailComponent
      }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ForexCommonModule,
    PipesModule,
    SelectModule
  ],
  declarations: [
    SellOverviewComponent,
    SellCardComponent,
    CreateAccountAdharComponent,
    ForexReviewEditComponent,
    ForexReviewComponent
  ],
  providers: [MasterService, AuthGuard, AuthService, CanDeactivateGuard],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class SellModule { }
