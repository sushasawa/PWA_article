import { Component, OnInit, Inject } from '@angular/core';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { Constants } from '../../../app/helpers/constants';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { DpDatePickerModule } from 'ng2-date-picker';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;
declare function initForms(): any;
declare var $: any;
declare var Snackbar: any;
declare function swal(headerMessage, message, type): any;
@Component({
  selector: 'app-forex-review-edit',
  templateUrl: './forex-review-edit.component.html',
  styleUrls: ['./forex-review-edit.component.css']
})
export class ForexReviewEditComponent implements OnInit {

  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public gst: any = 72;
  public discount: any = 0;
  public mutitravellerTotalAmount: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public currencyLists: any = [];
  public currencyDetail: any;
  public iterationNum: any = 1;
  public airlineNames: any;
  public currencyList: any;
  public currencyListCash: any;
  public currencyListTravellerCheque: any;
  public currencyListDemandDraft: any;
  public bankOptions: any = [];
  public HOME_STATNDARD_AMOUNT: any;
  public HOME_EXPRESS_AMOUNT: any;
  public OFFICE_STATNDARD_AMOUNT: any;
  public OFFICE_EXPRESS_AMOUNT: any;
  public config: any;
  public todaysDate: any;
  public timeconfig: any;
  public exchangeRates:any = {};
  public closeCard:any = false;
  public prepaidCardTotalAmount:any = 0;
  public cashTotalAmount:any = 0;
  public _primaryComp: any;
  public CurrentBranchId: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSale')); console.log(this.userSessionInfo);
    this.userSessionInfoRegistration = this.userSessionInfo.sellScreen.traveller[0].registrationInfo;
    this.userSessionInfoTravellingDetails =
      this.userSessionInfo.sellScreen.traveller[0].travellingDetails;
      this._primaryComp = '/' + navUrl.navUrl();
    this.userSessionInfoTravellers = this.userSessionInfo.sellScreen.traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.sellScreen.traveller[0];
    this.CurrentBranchId = Number.parseInt(SessionHelper.getLocal('branchIdFromOverview'));
    this.getCharges();
    // this.syncSession();
    // this.updateUsedAmount();
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[0].selected = true;
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];

    this.airlineNames = [
      { Id: 1, Airline: 'Air India', label: 'Air India', value: '1#Air India' },
      { Id: 2, Airline: 'SpiceJet', label: 'SpiceJet', value: '2#SpiceJet' },
      { Id: 3, Airline: 'Jet Airways', label: 'Jet Airways', value: '3#Jet Airways' },
      { Id: 4, Airline: 'IndiGo', label: 'IndiGo', value: '4#IndiGo' }
    ];

    this.todaysDate = this.masterService.getTodaysDate();
    this.config = {
      format: 'DD-MM-YYYY',
      min: this.todaysDate,
    };
    this.timeconfig = {
      format: 'HH:mm'
    };
    this.userSessionInfo.sellScreen.traveller.forEach(traveller => {
      this.getExchangeRatesPrepaid(traveller)
      // this.addBalanceNumber(traveller);
      this.addCashBalanceNumber(traveller);
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.forEach((detail, index) => {
          this.masterService.getBankList(detail.currencyCode)
            .subscribe(data => {
              this.bankOptions[index] = data;

              this.bankOptions[index].forEach(element => {
                element.Logo = Constants.serviceUrl + '/' + element.Logo;
              }, err => {
                //swal('Oops...', 'Unable to fetch bank list!', 'error');
                Snackbar.show({
                  text: 'Oops! Unable to fetch bank list',
                  pos: 'bottom-right',
                  actionTextColor: '#ff4444',
                });
              });
            });
        });
      }
    });
    console.log(this.userSessionInfo.mode);
    this.masterService.getDeliveryAmt(this.userSessionInfo.mode).subscribe((data) => {
      console.log(data);
      const deliveryData: any = data;
      deliveryData.map((delivery) => {
        if (delivery.DeliveryType === 'HomeVisit') {
          this.HOME_STATNDARD_AMOUNT = delivery.StandardDelivery;
          this.HOME_EXPRESS_AMOUNT = delivery.ExpressDelivery;
        }

        if (delivery.DeliveryType === 'OfficeVisit') {
          this.OFFICE_STATNDARD_AMOUNT = delivery.StandardDelivery;
          this.OFFICE_EXPRESS_AMOUNT = delivery.ExpressDelivery;
        }
      });
    });
    this.populateCashCurrency();
    this.populateDemandDraftCurrency();
    this.populatePrepaidCurrency();
    this.populatePrepaidCurrency();
    this._document.title = 'Review and update your current transaction';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Review and update your current transaction' });
  }



  ngOnInit() {
    initDocument();
    initForms();
    $('body').attr('id', '');
  }

  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.serviceCharge = Charges.response.serviceCharge;
      this.syncSession();
    this.updateUsedAmount();
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
    // console.log(this.userSessionInfoTravellers[travellerIndex]);
  }



  populatePopup(currencyCode, forexAmount, exchangeRate) {
    this.currencyLists.map((currency, index) => {
      if (currency.Code === currencyCode) {
        this.currencyDetail =
          '1 ' + currency.label + ' = <i class="fa-rupee"></i>' + exchangeRate + '<br>' +
          forexAmount + ' ' + currency.Code + ' = ' + '<i class="fa-rupee"></i>' + (forexAmount * exchangeRate).toFixed(2);
      }
    });
  }




  updateReview(editReview: NgForm, e: Event) {
    e.preventDefault();
    //  console.log(this.userSessionInfo);

    if (this.validateSession()) {
      SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfo));
      Snackbar.show({
        text: 'Updated .',
        pos: 'bottom-right',
        actionTextColor: '#05ff01',
      });
      this.router.navigateByUrl(this._primaryComp + '/sell/forex-review');
    }
  }


  populateCashCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.sellScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(2, destination)
      .subscribe(data => {
        this.currencyListCash = data;
      }, err => {
        //swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch currency list',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  populatePrepaidCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.sellScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(1, destination)
      .subscribe(data => {
        this.currencyList = data;
      }, err => {
        //swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch currency list',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }


  populateTravellersCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.sellScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(3, destination)
      .subscribe(data => {
        this.currencyListTravellerCheque = data;
      }, err => {
        //swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch currency list',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  populateDemandDraftCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.sellScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(4, destination)
      .subscribe(data => {
        this.currencyListDemandDraft = data;
      }, err => {
        //swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch currency list',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  updateBank(TravellerIndex, prepaidCardIndex, BankName) {
    this.userSessionInfoTravellers[TravellerIndex].prepaidCardDetails[prepaidCardIndex].bankname = BankName;
  }


  updatePrepaidCurrencyCode(TravellerIndex: any, prepaidDetailIndex: number, newValue: string) {
    this.userSessionInfoTravellers[TravellerIndex].prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.sellScreen.branch, 'prepaid', 'sell')
      .subscribe(data => {
        this.userSessionInfoTravellers[TravellerIndex].prepaidCardDetails[prepaidDetailIndex]
          .exchangeRate = data;
        this.syncSession();
        this.updateUsedAmount();
        console.log('Exchange rate called');
      }, err => {
        //swal('Oops...', 'Unable to fetch exchange rate!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch exchange rate',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });

    this.masterService.getBankList(newValue)
      .subscribe(data => {
        this.bankOptions[prepaidDetailIndex] = data;

        this.bankOptions[prepaidDetailIndex].forEach(element => {
          element.Logo = Constants.serviceUrl + '/' + element.Logo;
        });
      }, err => {
        //swal('Oops...', 'Unable to fetch bank list!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch bank list',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }


  updateCashCurrencyCode(TravellerIndex: any, cashDetailIndex: number, newValue: string) {
    this.userSessionInfoTravellers[TravellerIndex].cashDetails[cashDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.sellScreen.branch, 'cash', 'sell')
      .subscribe(data => {
        this.userSessionInfoTravellers[TravellerIndex].cashDetails[cashDetailIndex].exchangeRate = data;
        this.syncSession();
        this.updateUsedAmount();
      }, err => {
        //swal('Oops...', 'Unable to fetch exchange rate!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch exchange rate',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  updateDemandDraftCurrencyCode(TravellerIndex: any, demandDraftDetailIndex: number, newValue: string) {
    this.userSessionInfoTravellers[TravellerIndex].demandDraftDetails[demandDraftDetailIndex]
      .currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.sellScreen.branch, 'prepaid', 'sell')
      .subscribe(data => {
        this.userSessionInfoTravellers[TravellerIndex].demandDraftDetails[demandDraftDetailIndex]
          .exchangeRate = data;
        this.syncSession();
        this.updateUsedAmount();
      }, err => {
        //swal('Oops...', 'Unable to fetch exchange rate!', 'error');
        Snackbar.show({
          text: 'Oops! Unable to fetch exchange rate',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  deliveryModes(mode: String) {
    console.log(mode);
    if (mode === 'Pick Up') {
      this.deliveryTypeAndRate('', 0);
    }
    this.userSessionInfo.sellScreen.deliveryInfo.Mode = mode;
    console.log(this.userSessionInfo.sellScreen.deliveryInfo);
  }

  deliveryTypeAndRate(type: String, rate: any) {
    console.log('TYPE :::' + type, 'RATE :::' + rate);
    this.userSessionInfo.sellScreen.deliveryInfo.type = type;
    this.userSessionInfo.sellScreen.deliveryInfo.rate = rate;
    console.log(this.userSessionInfo.sellScreen.deliveryInfo);
    this.syncSession();
    this.updateUsedAmount();
  }

  deliveryDate(event: any) {
    console.log('Delivery Date' + event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfo.sellScreen.deliveryInfo.DeliverySchedule.date = event;
    }
  }


  travellingStartDate(event, TravellerIndex) {
    console.log(event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfoTravellers[TravellerIndex].travellingDetails.dateOfTravel = event;
    }
  }

  travellingArrivaltDate(event, TravellerIndex) {
    console.log(event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfoTravellers[TravellerIndex].travellingDetails.dateOfArrival = event;
    }
  }
  deliveryTime(event: any) {
    if (event !== undefined && typeof event !== 'object') { console.log('updated');
       this.userSessionInfo.sellScreen.deliveryInfo.DeliverySchedule.time = event;
    }
  }

  getExchangeRatesPrepaid(traveller) {
    const prepaidCardDetails = traveller.prepaidCardDetails;
    let isCashout = false, requestCount = 0, respCount = 0;
    if (traveller.prepaidCard) {
      const cardDatas = traveller.cardData;
      // tslint:disable-next-line:forin
      for (const cardData in cardDatas) {
        const balances = cardDatas[cardData].balance;
        for (const balance in balances) {
          if (balances[balance].cashout && balances[balance].cashoutAmount) {
            requestCount++;
            isCashout = true;
            this.masterService.getExchangeRate(balances[balance].currencyCode, this.CurrentBranchId, 'prepaid', 'sell', cardDatas[cardData].bankCode)
              .subscribe(data => {
                respCount++;
                const result: any = data;
                this.exchangeRates[balances[balance].currencyCode] = result.rate;
                if(requestCount===respCount){
                  this.addBalanceNumber(traveller);
                  this.syncSession();
                  this.updateUsedAmount();
                  requestCount = 0; respCount = 0;
                }                
              });
          }
        }
      }
    }
  }


  syncSession() {
    let totalAmount: any = 0;
    this.mutitravellerTotalAmount = 0;
    let travellerCount = this.userSessionInfoTravellers.length, currentCounter = 0;
    this.userSessionInfoTravellers.forEach(traveller => {
      this.addBalanceNumber(traveller);
      let charges = 0;
      // traveller.selected = false;
      // console.log(traveller);
      if (traveller.cash) {
        traveller.cashDetails.map((cash) => {
          // console.log(cash);
          totalAmount += (cash.forexAmount * cash.exchangeRate.rate) - this.discount;
        });
      }
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.map((prepaidCard) => {
          // console.log(prepaidCard);
          totalAmount += (prepaidCard.forexAmount * prepaidCard.exchangeRate.rate) - this.discount;
        });
      }
      
      if (traveller.travellerCheque) {
        traveller.travellerChequeDetails.map((travellerCheque) => {
          //  console.log(travellerCheque);
          totalAmount += (travellerCheque.forexAmount * travellerCheque.exchangeRate.rate) - this.discount;
        });
      }

      if (traveller.demandDraft) {
        traveller.demandDraftDetails.map((demandDraft) => {
          // console.log(demandDraft);
          totalAmount += (demandDraft.forexAmount * demandDraft.exchangeRate.rate) - this.discount;
        });
      }
      const TotalTaxebleAmount = traveller.prepaidCardTotalAmount + traveller.cashTotalAmount - this.userSessionInfo.sellScreen.deliveryInfo.rate - this.serviceCharge;
      charges +=  this.serviceCharge;
      //  traveller.totalAmount = totalAmount - (this.deliveryRate + this.gst + this.serviceCharge + this.activationFees + this.loadFees );
      traveller.totalAmount = TotalTaxebleAmount;
      this.masterService.getTaxes(TotalTaxebleAmount).subscribe((data) => {
        const result: any = data;
        currentCounter++;
        traveller.totalAmount -= result.TotalTax;
        traveller.usedAmount = traveller.totalAmount;
        traveller.gst = result.TotalTax;
        // charges += result.TotalTax;
        traveller.Charges = charges;
        this.mutitravellerTotalAmount += Number(traveller.totalAmount);
        this.userSessionInfo.sellScreen.billingAmount = this.mutitravellerTotalAmount;
        this.userSessionInfo.sellScreen.usedAmount = Math.round(this.mutitravellerTotalAmount);
        this.userSessionInfo.sellScreen.totalPayout = Math.round(this.mutitravellerTotalAmount);
        this.userSessionInfo.sellScreen.differenceAmount = this.userSessionInfo.sellScreen.billingAmount - this.userSessionInfo.sellScreen.usedAmount;
        if(travellerCount === currentCounter){
          SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfo));
        }
      });
      // this.mutitravellerTotalAmount += traveller.totalAmount  ;
      //  console.log('Total Amount', totalAmount);
      //  console.log('Grand Total Amount', this.mutitravellerTotalAmount);
      totalAmount = 0;
      // console.log(traveller);
    });
    // console.log(this.mutitravellerTotalAmount);
  }

  updateUsedAmount() {
    let travellerTotal = 0;
     console.log('USED AMOUNT CALLED');
    this.userSessionInfo.sellScreen.traveller.forEach(currentTraveller => {
        let currentTravellerTotal = 0;
        if (currentTraveller.prepaidCard) {
            currentTraveller.prepaidCardDetails.forEach(element => {
                if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                    currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                }
            });
        }
        if (currentTraveller.cash) {
            currentTraveller.cashDetails.forEach(element => {
                if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                    currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                }
            });
        }
        if (currentTraveller.travellerCheque) {
            currentTraveller.travellerChequeDetails.forEach(element => {
                if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                    currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                }
            });
        }
        if (currentTraveller.demandDraft) {
            currentTraveller.demandDraftDetails.forEach(element => {
                if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                    currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
                }
            });
        }

        travellerTotal += currentTravellerTotal;
        currentTraveller.usedAmount = currentTravellerTotal;
    });


    this.userSessionInfo.sellScreen.usedAmount = travellerTotal;

    if (this.userSessionInfo.sellScreen.usedAmount !== 0) {
        this.masterService.getTaxes(this.userSessionInfo.sellScreen.usedAmount)
            .subscribe(res => {
                const result: any = res;
                this.userSessionInfo.sellScreen.usedAmount += result.TotalTax;
                this.updateBalanceAmount();
               console.log('AMOUNT' + this.userSessionInfo.sellScreen.usedAmount, 'TAXES' + result.TotalTax);
            }, err => {
                // swal('Oops', 'Error fetching taxes', 'error');
                Snackbar.show({text: 'Error fetching taxes',
                pos: 'bottom-right' ,
                actionTextColor: '#ff4444',
               });
            });
    }

    this.updateBalanceAmount();
}
updateBalanceAmount() {
  if (Number.isNaN(Number.parseInt(this.userSessionInfo.sellScreen.budgetAmount))) {
      this.userSessionInfo.sellScreen.balanceAmount = '';
  } else if (this.userSessionInfo.sellScreen.budgetAmount !== '0' && this.userSessionInfo.sellScreen.budgetAmount !== 0) {
      this.userSessionInfo.sellScreen.balanceAmount = (this.userSessionInfo.sellScreen.budgetAmount
          - this.userSessionInfo.sellScreen.usedAmount);
      this.userSessionInfo.sellScreen.balanceAmount
          = this.userSessionInfo.sellScreen.balanceAmount < 0 ? 0 : this.userSessionInfo.sellScreen.balanceAmount;
      if (this.userSessionInfo.sellScreen.budgetAmount - this.userSessionInfo.sellScreen.usedAmount <= 0) {
          // swal('Oops', 'You have exceeded your budget!!', 'warning');
          Snackbar.show({text: 'You have exceeded your budget!!',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
      }
  }
  
}

getExchangeRates(traveller){
  let prepaidCardDetails = traveller.prepaidCardDetails;
  if(traveller.prepaidCard){
    for(let prepaidCard in prepaidCardDetails){
        this.exchangeRates[prepaidCardDetails[prepaidCard].currencyCode] = prepaidCardDetails[prepaidCard].exchangeRate.rate;
    }
  }  
}

addBalanceNumber(traveller){
  let cardDatas = traveller.cardData, cardAmount = 0;
  for(let cardData in cardDatas){
    let balances = cardDatas[cardData].balance, counter = 0;
    for(let balance in balances){
      if(balances[balance].cashout && balances[balance].cashoutAmount){
        this.prepaidCardTotalAmount += (balances[balance].cashoutAmount * this.exchangeRates[balances[balance].currencyCode]);
        cardAmount += (balances[balance].cashoutAmount * this.exchangeRates[balances[balance].currencyCode]);
        counter++;
      }
    }
    if(cardDatas[cardData].closeCard){
      this.closeCard = true;
    }
    cardDatas[cardData].balanceCount = counter;
  }
  traveller.prepaidCardTotalAmount = cardAmount;
}

  addCashBalanceNumber(traveller) {
    let cardDatas = traveller.cashDetails, cashAmount = 0;
    for (let cardData in cardDatas) {
      if (cardDatas[cardData].forexAmount) {
        this.cashTotalAmount += cardDatas[cardData].forexAmount * cardDatas[cardData].exchangeRate.rate;
        cashAmount += cardDatas[cardData].forexAmount * cardDatas[cardData].exchangeRate.rate;
      }
    }
    traveller.cashTotalAmount = cashAmount;
  }

  validateSession() {
    let result = true;

    if (this.userSessionInfo.sellScreen.branch === '' || this.userSessionInfo.sellScreen.branch === undefined) {
      // swal('Error', 'Please select branch', 'error');
      Snackbar.show({
        text: 'Error , Please select branch',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      //  this.invalidsubmitted = true;
      result = false;
    } else {

      for (let travellerIndex = 0; travellerIndex < this.userSessionInfo.sellScreen.traveller.length; travellerIndex++) {
        const traveller = this.userSessionInfo.sellScreen.traveller[travellerIndex];

        if (!traveller.prepaidCard && !traveller.cash) {
          // swal('Error', 'You have not provided any data for traveler ' + (travellerIndex + 1), 'error');
          Snackbar.show({
            text: 'Error , You have not provided any data for traveler ' + (travellerIndex + 1),
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
          this.selectTraveller(travellerIndex);
          //  this.invalidsubmitted = true;
          result = false;
          break;
        }

        if (traveller.prepaidCard) {
          let index = 0;
          for (; index < traveller.prepaidCardDetails.length; index++) {
            const detail = traveller.prepaidCardDetails[index];
            if (detail.currencyCode === '' || detail.currencyCode === undefined) {
              // swal('Error', 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Error , Please select currency for prepaid card of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });
              this.selectTraveller(travellerIndex);
              //  this.invalidsubmitted = true;
              result = false;
              break;
            }
            if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
              // swal('Error', 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Error , Please provide amount for prepaid card of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });
              this.selectTraveller(travellerIndex);
              //  this.invalidsubmitted = true;
              result = false;
              break;
            }
          }

          if (index < traveller.prepaidCardDetails.length) {
            break;
          }
        }
        if (traveller.cash) {
          let index = 0;
          for (; index < traveller.cashDetails.length; index++) {
            const detail = traveller.cashDetails[index];
            if (detail.currencyCode === '' || detail.currencyCode === undefined) {
              // swal('Error', 'Please select currency for cash of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Error , Please select currency for cash of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });
              this.selectTraveller(travellerIndex);
              //  this.invalidsubmitted = true;
              result = false;
              break;
            }
            if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
              // swal('Error', 'Please provide amount for cash of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                text: 'Error , Please provide amount for cash of traveler ' + (travellerIndex + 1),
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });
              this.selectTraveller(travellerIndex);
              //  this.invalidsubmitted = true;
              result = false;
              break;
            }
          }
          if (index < traveller.cashDetails.length) {
            break;
          }
        }
      }
    }

    return result;
  }

}
