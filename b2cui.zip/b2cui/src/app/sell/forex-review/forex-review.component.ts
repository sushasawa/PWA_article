import { Component, OnInit, Inject } from '@angular/core';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { TransactionService } from '../../../app/services/transaction.service';
import { Router } from '@angular/router';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var Snackbar: any;
declare function initDocument(): any;
@Component({
  selector: 'app-forex-review',
  templateUrl: './forex-review.component.html',
  styleUrls: ['./forex-review.component.css']
})
export class ForexReviewComponent implements OnInit {
  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public premiumOffer: any = 0;
  public prepaidCardTotalAmount: any = 0;
  public cashTotalAmount: any = 0;
  public mutitravellerTotalAmount: any;
  public deliveryRate: any;
  public currencyLists: any = [];
  public currencyDetail: any;
  public exchangeRates: any = {};
  public closeCard: any = false;
  public _primaryComp: any;
  public CurrentBranchId: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _TransactionService: TransactionService, private meta: Meta, @Inject(DOCUMENT) private _document: any) {
   // console.log(JSON.parse(SessionHelper.getSession('userSessionInfoSale')));
    this._primaryComp = '/' + navUrl.navUrl();
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSale'));
    this.deliveryRate = Number.parseInt(this.userSessionInfo.sellScreen.deliveryInfo.rate);
    console.log(this.deliveryRate, '>>>>>>>');
    this.userSessionInfoRegistration = this.userSessionInfo.sellScreen.traveller[0].registrationInfo;
    this.userSessionInfoTravellingDetails = this.userSessionInfo.sellScreen.traveller[0].travellingDetails;
    this.CurrentBranchId = Number.parseInt(SessionHelper.getLocal('branchIdFromOverview'));
    this.userSessionInfoTravellers = this.userSessionInfo.sellScreen.traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.sellScreen.traveller[0];
    this._document.title = 'Review your current transaction';
    this.meta.addTag({ name: 'description', content: 'Buy, Sell, Reload yours prepaid cards, Send money to Abroad. Check live exchange/forex rates. Get exchange rate alerts. Compare rates for currencies and prepaid cards. Get special offers on buying forex.' });
    this.meta.addTag({ name: 'keywords', content: 'Review your current transaction' });
    this.getCharges();
    this.mutitravellerTotalAmount = 0;
    let travellerTraveArr = [], travellerLength = this.userSessionInfoTravellers.length, counter = 0, calledFunction = false;
    this.userSessionInfoTravellers.forEach(traveller => {
      this.getExchangeRates(traveller, travellerTraveArr);
      let myVar = setInterval(()=>{
        counter++;
        if(counter === 50){
          clearInterval(myVar);
        }
        if(travellerTraveArr.length === travellerLength && calledFunction === false){
          this.traversTraveller();
          calledFunction = true;
          clearInterval(myVar);
        }
      }, 100);      
    });
  }

  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.serviceCharge = Charges.response.serviceCharge;
      
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  traversTraveller() {
    let totalAmount: any = 0;
    let travellerCount = this.userSessionInfoTravellers.length, currentCounter = 0;
    let grantTotalAmount: any = 0;
    this.userSessionInfoTravellers.forEach(traveller => {
      let charges = 0;
      traveller.selected = false;
      traveller.serviceCharge = this.serviceCharge;
      this.addBalanceNumber(traveller);
      this.addCashBalanceNumber(traveller);
      // console.log(traveller);
      if (traveller.cash) {
        traveller.cashDetails.map((cash) => {
          // console.log(cash);
          totalAmount += (cash.forexAmount * cash.exchangeRate.rate) + this.premiumOffer;
        });
      }
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.map((prepaidCard) => {
          // console.log(prepaidCard);
          totalAmount += (prepaidCard.forexAmount * prepaidCard.exchangeRate.rate) + this.premiumOffer;
        });
      }

      if (traveller.travellerCheque) {
        traveller.travellerChequeDetails.map((travellerCheque) => {
          //  console.log(travellerCheque);
          totalAmount += (travellerCheque.forexAmount * travellerCheque.exchangeRate.rate) + this.premiumOffer;
        });
      }

      if (traveller.demandDraft) {
        traveller.demandDraftDetails.map((demandDraft) => {
          // console.log(demandDraft);
          totalAmount += (demandDraft.forexAmount * demandDraft.exchangeRate.rate) + this.premiumOffer;
        });
      }
      let TotalTaxebleAmount = traveller.prepaidCardTotalAmount + traveller.cashTotalAmount - this.deliveryRate - this.serviceCharge;
      charges +=  this.serviceCharge;
      traveller.serviceCharge = this.serviceCharge;
      //  traveller.totalAmount = totalAmount - (this.deliveryRate + this.gst + this.serviceCharge + this.activationFees + this.loadFees );
      traveller.totalAmount = TotalTaxebleAmount;
      this.masterService.getTaxes(TotalTaxebleAmount).subscribe((data) => {
        const result: any = data;
        currentCounter++;
        TotalTaxebleAmount -= result.TotalTax;
        traveller.totalAmount = TotalTaxebleAmount;
        traveller.usedAmount = traveller.totalAmount;
        traveller.gst = result.TotalTax;
        // charges += result.TotalTax;
        traveller.Charges = charges;
        grantTotalAmount += Number(traveller.totalAmount);
        this.userSessionInfo.sellScreen.billingAmount = grantTotalAmount;
        this.userSessionInfo.sellScreen.usedAmount = Math.round(grantTotalAmount);
        this.userSessionInfo.sellScreen.totalPayout = Math.round(grantTotalAmount);
        this.userSessionInfo.sellScreen.differenceAmount = this.userSessionInfo.sellScreen.billingAmount - this.userSessionInfo.sellScreen.usedAmount;
        if(travellerCount === currentCounter){
          SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfo));
        }
      });
      totalAmount = 0;
    });
    this.userSessionInfo.sellScreen.traveller = this.userSessionInfoTravellers;
    SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfo));
    this.userSessionInfoTravellers[0].selected = true;
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];
    this.userSessionInfo.sellScreen.totalPayout = this.mutitravellerTotalAmount;
    this.masterService.getCurrencyList(1).subscribe((data) => {
      this.currencyLists = data;
    });
  }

  ngOnInit() {
    initDocument();
  }
  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;


  }

  populatePopup(currencyCode, forexAmount, exchangeRate) {
    this.currencyLists.map((currency, index) => {
       if (currency.Code === currencyCode) {
                 this.currencyDetail =
                 '1 ' + currency.label + ' = <i class="fa-rupee"></i>' + exchangeRate + '<br>' +
                  forexAmount + ' ' + currency.Code + ' = ' + '<i class="fa-rupee"></i>' + (forexAmount * exchangeRate).toFixed(2);
               }
      });
  }

  onSaveAndTemporaryExit() {
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession('userSessionInfoSale');
    this.router.navigateByUrl(this._primaryComp + `/sell`);
  }

  submitAndRedirect() {
    SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfo));
    this.generateTransaction();
  }

updateSession() {
  SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfo));
}
  generateTransaction() {
    // tslint:disable-next-line:max-line-length
    const checkTransactionIdExists = this.userSessionInfo.sellScreen['tranId'] === undefined || this.userSessionInfo.sellScreen['tranId'] === null || this.userSessionInfo.sellScreen['tranId'] === '';

    if (checkTransactionIdExists) {

      this._TransactionService.TransactionId().subscribe((id) => {
        console.log(id);
        this.userSessionInfo.sellScreen['tranId'] = id;
        this.updateSession();
        this.generateInvoice();
      }, (error) => {
        console.log(error);
      });
    }else {
      this.generateInvoice();
    }
  }

  generateInvoice() {

    const TravellerNo = this.userSessionInfoTravellers.length;
    console.log('no of traveller');
    console.log(TravellerNo);
    this._TransactionService.generateInvoiceNo(TravellerNo)
      .subscribe(resD => {
        console.log(resD);
        for (let travellerIndex = 0; travellerIndex < this.userSessionInfoTravellers.length; travellerIndex++) {
          this.userSessionInfo.sellScreen.traveller[travellerIndex].registrationInfo.invoiceNo = resD[travellerIndex][0].number;
          this.updateSession();
        }
        this.saveTransaction();
      }, err => {
        console.log(err);
      });
  }

  saveTransaction() {
    this.userSessionInfo.isActive = false;
    this._TransactionService.initTransactionSaving(this.userSessionInfo).subscribe((data) => {
      console.log(data);
      this.router.navigateByUrl(this._primaryComp + '/sell/confirmation?transactionId=' + this.userSessionInfo.sellScreen['tranId']);
      const payload = { transactionId: this.userSessionInfo.sellScreen['tranId'] };
      this._TransactionService.sendSellInvoiceData(payload).subscribe((IexchangeSuccess) => {
        console.log(IexchangeSuccess);
      });
    });
  }

  getExchangeRates(traveller, travArr) {
    const prepaidCardDetails = traveller.prepaidCardDetails;
    let isCashout = false;
    if (traveller.prepaidCard) {
      const cardDatas = traveller.cardData;
      // tslint:disable-next-line:forin
      for (const cardData in cardDatas) {
        const balances = cardDatas[cardData].balance;
        for (const balance in balances) {
          if (balances[balance].cashout && balances[balance].cashoutAmount) {
            isCashout = true;
            this.masterService.getExchangeRate(balances[balance].currencyCode, this.CurrentBranchId, 'prepaid', 'sell', cardDatas[cardData].bankCode)
              .subscribe(data => {
                const result: any = data;
                this.exchangeRates[balances[balance].currencyCode] = result.rate;
                setTimeout(() => {
                  travArr.push(1);
                }, 400);
              });
          }
        }
      }
    }
    if (isCashout === false) {
      travArr.push(1);
    }
  }

  addBalanceNumber(traveller) {
    let cardDatas = traveller.cardData, cardAmount = 0;
    for (const cardData in cardDatas) {
      let balances = cardDatas[cardData].balance, counter = 0;
      for (const balance in balances) {
        if (balances[balance].cashout && balances[balance].cashoutAmount) {
          this.prepaidCardTotalAmount += (balances[balance].cashoutAmount * this.exchangeRates[balances[balance].currencyCode]);
          cardAmount += (balances[balance].cashoutAmount * this.exchangeRates[balances[balance].currencyCode]);
          counter++;
        }
      }
      if (cardDatas[cardData].closeCard){
        this.closeCard = true;
      }
      cardDatas[cardData].balanceCount = counter;
    }
    traveller.prepaidCardTotalAmount = cardAmount;
    
    if(traveller.cashTotalAmount){
      traveller.usedAmount = traveller.prepaidCardTotalAmount + traveller.cashTotalAmount;
    }
    
  }

  addCashBalanceNumber(traveller) {
    let cardDatas = traveller.cashDetails, cashAmount = 0;
    for (const cardData in cardDatas) {
      if (cardDatas[cardData].forexAmount) {
        this.cashTotalAmount += cardDatas[cardData].forexAmount * cardDatas[cardData].exchangeRate.rate;
        cashAmount += cardDatas[cardData].forexAmount * cardDatas[cardData].exchangeRate.rate;
      }
    }
    traveller.cashTotalAmount = cashAmount;
    if (traveller.prepaidCardTotalAmount) {
      traveller.usedAmount = traveller.prepaidCardTotalAmount + traveller.cashTotalAmount;
    } else {
      traveller.usedAmount = traveller.cashTotalAmount;
    }
  }
}
