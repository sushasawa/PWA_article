import { Component, OnInit, Inject, Input } from '@angular/core';
import { SessionHelper } from '../helpers/session-helper';
import { MasterService } from '../services/master.services';
import { Router, RouterModule } from '@angular/router';
import { SessionValueResetService } from '../services/session-value-reset.service';
import { Meta } from '@angular/platform-browser';
import {DOCUMENT} from '@angular/platform-browser';
import { NavigatePathService } from '../../app/services/navigate-path.service';
// declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
    selector: 'forex-footer',
    templateUrl: 'footer.component.html',
    styleUrls: []
})
export class FooterComponent {
    public tempNo: any;
    public _primaryComp: any;
    @Input() UrlParam: string;
    // tslint:disable-next-line:max-line-length
    constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router , private _SessionValueResetService: SessionValueResetService, private meta: Meta, @Inject(DOCUMENT) private _document: any) { 
        this._primaryComp = '/' + navUrl.navUrl();
        this.meta.addTag({ name: 'keywords', content: 'Currency Notes, Prepaid Cards, Demand Draft, Buy Forex, Sell Forex, Reload Card, Outward Remittance, Our Branches, Offers, Visa locators, Know More, Why Us, About Us, FAQ, Feedback, Send Enquiry, Contact Us, Products, Services, Locators'});
    }

    processTempNo() {
        console.log('tempNo: ' + this.tempNo);
        if (SessionHelper.getSession('userInfo')) {
            const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
            this.masterService.getOrderData(this.tempNo, userInfo.uid)
                .subscribe(data => {
                    const sessionData: any = data;
                    this.tempNo = '';
                    console.log(sessionData.buyScreen);
                    console.log(sessionData.sellScreen);
                    console.log(sessionData.reloadCardScreen);
                    console.log(sessionData.sendMoneyScreen);

                    if (sessionData.buyScreen) {
                       // SessionHelper.setSession('userSessionInfo', JSON.stringify(sessionData));
                        this._SessionValueResetService.getUserSessionInfo('userSessionInfo', sessionData);
                        this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
                    } else if (sessionData.sellScreen) {
                      //  SessionHelper.setSession('userSessionInfoSale', JSON.stringify(sessionData));
                        this._SessionValueResetService.getUserSessionInfo('userSessionInfoSale', sessionData);
                        this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
                    } else if (sessionData.reloadCardScreen) {
                       // SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(sessionData));
                        this._SessionValueResetService.getUserSessionInfo('userSessionInfoRealoadCard', sessionData);
                        this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
                    } else if (sessionData.sendMoneyScreen) {
                       // SessionHelper.setSession('userSessionInfoSend', JSON.stringify(sessionData));
                        this._SessionValueResetService.getUserSessionInfo('userSessionInfoSend', sessionData);
                        this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
                    }
                   // this.router.navigateByUrl(this._primaryComp + sessionData.nextLink);
                }, err => {
                    // swal('Oops', 'Invalid order number!!', 'error');
                    Snackbar.show({text: 'Invalid order number!!',
                    pos: 'bottom-right' ,
                    actionTextColor: '#ff4444',
                   });

                });
        } else {
            // TODO: redirect to login with next values set..
            SessionHelper.setSession('tempNo', this.tempNo);
            this.router.navigateByUrl(this._primaryComp + '/login');
        }
    }

    ngOnChanges() {
        this._primaryComp = '/' + this.UrlParam;
    }
}
