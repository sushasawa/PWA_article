
export const environment = {
  production: true,
  API_URL: 'http://forex.coxandkings.com:8070',
  MERCHANT_ID: 'L218263',
  CLIENT_URL : 'https://forex.coxandkings.com',
  DEFAULT_ISSUER_CODE : 'ICICIMCC'
};
