var handleResponse=function(e){void 0!==e&&void 0!==e.paymentMethod&&void 0!==e.paymentMethod.paymentTransaction&&void 0!==e.paymentMethod.paymentTransaction.statusCode&&e.paymentMethod.paymentTransaction.statusCode},counterPaynimo=0,paymentGatewayCall=function(e,t,i,o,a,n,l,c,s,r,d,h){0==counterPaynimo?$.getScript("https://www.paynimo.com/Paynimocheckout/server/lib/checkout.js",function(f,m,u){console.log("Load was performed."),counterPaynimo++,paynimoCall(e,t,i,o,a,n,l,c,s,r,d,h)}):paynimoCall(e,t,i,o,a,n,l,c,s,r,d,h)},paynimoCall=function(e,t,i,o,a,n,l,c,s,r,d,h){var f={tarCall:!1,features:{showPGResponseMsg:!0,enableNewWindowFlow:!0},consumerData:{deviceId:e,token:t,returnUrl:i,responseHandler:handleResponse,paymentMode:o,merchantId:a,consumerId:n,consumerMobileNo:l,consumerEmailId:c,txnId:s,items:[{itemId:r,amount:d,comAmt:h}],customStyle:{PRIMARY_COLOR_CODE:"#3977b7",SECONDARY_COLOR_CODE:"#FFFFFF",BUTTON_COLOR_CODE_1:"#1969bb",BUTTON_COLOR_CODE_2:"#FFFFFF"}}};console.log(JSON.stringify(f)),$.pnCheckout(f),f.features.enableNewWindowFlow&&$(document).data("pnCheckout").openNewWindow()},initImgFit=function(){$(ImgFit).find("figure").find("img").each(function(e,t){var i=$(t),o=$("<div />").css({background:"url("+i.attr("src")+") no-repeat","background-size":"cover","background-position":"center",width:"100%",height:"100%"});i.replaceWith(o)})},initHeader=function(){$(".mob-menu > li > a.parent").bind("click",function(e){var t=$(this),i=t.parent(),o=t.parent().find("ul.dropdown-menu");o.slideToggle(),$(".mob-menu > li > ul.dropdown-menu").not(o).slideUp().removeClass("hover"),$(".mob-menu > li").not(i).removeClass("hover"),$(this).parent("li").toggleClass("hover")})},adjustMenu=function(){$("#nav_overlay");Modernizr.mq(mq_green)?($(".toggleMenu").css("display","inline-block"),$(".toggleMenu").hasClass("active")?$(".mobile-nav").show():$(".mobile-nav").hide(),$(".navbar").hide()):($(".toggleMenu").css("display","none"),$(".navbar").show(),/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)?($("#nav_menu  > li > a").bind("touchstart mouseenter"),$("#nav_menu  > li > a").unbind("click").bind("touchstart mouseenter",function(){$("#nav_menu  > li").removeClass("hover"),$(this).parent().toggleClass("hover")})):($("#nav_menu > li").removeClass("hover"),$("#nav_menu > li > a").unbind("click"),$("#nav_menu > li").unbind("mouseenter mouseleave").bind("mouseenter mouseleave touchstart",function(){$(this).toggleClass("hover")})))},adjustMenuHov=function(e){var t=$("#nav_menu"),i=t.find("li.has-submenu"),o=(t.find("li.has-submenu > a"),$("#nav_overlay"));i.find("ul.dropdown-menu").hide(),Modernizr.mq(mq_green)?o.hide():(i.bind("touchstart mouseenter",function(){var e=$(this);e.addClass("slided selected"),e.find("ul.dropdown-menu").css("z-index","9999").stop(!0,!0).slideDown(200,function(){i.not(e).find("ul.dropdown-menu").hide(),o.stop(!0,!0).fadeTo(200,.3),e.addClass("hovered"),$("header").addClass("sec-hove")})}).bind("mouseleave",function(){var e=$(this);e.removeClass("selected").find("ul.dropdown-menu").css("z-index","1").stop(!0,!0).slideUp(200,function(){e.removeClass("slided selected"),e.removeClass("hovered"),o.stop(!0,!0).fadeTo(200,0,function(){$("header").removeClass("sec-hove"),o.hide()})})}),$("#nav_menu > li.has-submenu  ul.dropdown-menu").css({display:"none"}))},adjustFooter=function(){},ChangeView=function(){},initAccordionBox=function(e){$(".faqslist dt").off("click.click9").on("click.click9",function(){var e=$(this).next("dd");$(this).next(e).slideToggle(),$(this).toggleClass("active")})};function sizeOrientationChange(){checkMQs()}function checkMQs(){Modernizr.mq("only all")?(mq_red_check=Modernizr.mq(mq_red),mq_orange_check=Modernizr.mq(mq_orange),mq_yellow_check=Modernizr.mq(mq_yellow),mq_green_check=Modernizr.mq(mq_green),mq_blue_check=Modernizr.mq(mq_blue),mq_purple_check=Modernizr.mq(mq_purple)):(mq_red_check=!1,mq_orange_check=!0,mq_yellow_check=!1,mq_green_check=!1,mq_blue_check=!1,mq_purple_check=!1)}function checkFeatures(){touchEnabled=Modernizr.touch,touchEnabled&&$("html, body").removeClass("no-touch").addClass("touch-mod"),formPlaceholders=Modernizr.input.placeholder,boxShadows=Modernizr.boxshadow,isIE7=$("html").hasClass("ie7"),isIE8=$("html").hasClass("ie8"),forms.length}var waitForFinalEvent=function(){var e={};return function(t,i,o){o||(o="Don't call this twice without a uniqueId"),e[o]&&clearTimeout(e[o]),e[o]=setTimeout(t,i)}}();function setLocation(e){window.location.href=e}function setLocation(e){window.location.href=e}function isNumberKey(e){var t=e.which?e.which:event.keyCode;return!(t>31&&(t<48||t>57))}equalheight=function(e){var t,i=0,o=0,a=new Array;$(e).each(function(){if(t=$(this),$(t).height("auto"),topPostion=t.position().top,o!=topPostion){for(currentDiv=0;currentDiv<a.length;currentDiv++)a[currentDiv].height(i);a.length=0,o=topPostion,i=t.height(),a.push(t)}else a.push(t),i=i<t.height()?t.height():i;for(currentDiv=0;currentDiv<a.length;currentDiv++)a[currentDiv].height(i)})};var counterCall=0,initDocument=function(){if(mq_red="(min-width: 1300px)",mq_orange="(min-width: 992px) and (max-width: 1299px)",mq_purple="(max-width: 991px)",mq_yellow="(min-width: 768px) and (max-width: 991px)",mq_green="(max-width: 767px)",mq_blue="(max-width: 479px)",anSp=500,anSpFast=400,isMobileNav=!1,mobileNav="",forms=$("form, .form"),header=$("header"),AccordionBox=$(".accordion-style"),ImgFit=$(".img-fit"),checkMQs(),checkFeatures(),header.length&&initHeader(),AccordionBox.length&&initAccordionBox(),ImgFit.length&&initImgFit(),adjustMenu(),adjustMenuHov(),adjustFooter(),$(window).resize(function(){waitForFinalEvent(function(){sizeOrientationChange()},100,"main resize"),adjustMenu(),adjustMenuHov(),adjustFooter()}),window.addEventListener?window.addEventListener("orientationchange",sizeOrientationChange,!1):window.attachEvent("orientationchange",sizeOrientationChange),0===counterCall&&($(".mobile-nav").append("<a href='#' class='closeMenu'></a><nav><ul class='mob-menu nav' id='nav-menu'></ul></nav>"),$("#nav_menu > li").clone().appendTo(".mob-menu"),$("#nav_menu").addClass("hidden-xs")),$(".nav > li > a, .mob-menu > li > a").each(function(){$(this).next().length>0&&$(this).addClass("parent")}),0===counterCall&&$(".mob-menu > li a.parent").append('<b class="caret"></b>'),$(window).off("orientationchange.orientationchange1").on("orientationchange.orientationchange1",function(){}),$("ul#nav_menu > li:has(ul.dropdown-menu)").addClass("has-submenu"),$(window).off("load.load1").on("load.load1",function(){equalheight(".equal-heights > div")}),$(window).off("resize.resize1").on("resize.resize1",function(){equalheight(".equal-heights > div")}),$(window).off("load.load2").on("load.load2",function(){equalheight(".equal-heights-custom > div > div")}),$(window).off("resize.resize2").on("resize.resize2",function(){equalheight(".equal-heights-custom > div > div")}),$(window).off("scroll.scroll1").on("scroll.scroll1",function(){$(this).scrollTop()>0?$("header").addClass("fixedHeader"):$("header").removeClass("fixedHeader")}),$(".toggleMenu").off("click.click1").on("click.click1",function(e){e.preventDefault(),$(this).hasClass("active")?($(this).removeClass("active"),$(".mobile-nav").fadeOut()):($(this).addClass("active"),$(".mobile-nav").fadeIn())}),$(".closeMenu").off("click.click2").on("click.click2",function(e){e.preventDefault(),$(".toggleMenu").removeClass("active"),$(".mobile-nav").fadeOut()}),$(".testimonial .owl-carousel").length&&$(".testimonial .owl-carousel").owlCarousel({items:1,mouseDrag:!1,pagination:!0,navigation:!1,itemsDesktop:[1e3,1],itemsDesktopSmall:[900,1],itemsTablet:[600,1]}),$(".buy-forex .owl-carousel").length&&$(".buy-forex .owl-carousel").owlCarousel({items:1,mouseDrag:!1,pagination:!0,navigation:!1,itemsDesktop:[1e3,1],itemsDesktopSmall:[900,1],itemsTablet:[600,1]}),$(".single-item-carousel").length){$(this);$(".single-item-carousel").each(function(){var e=$(this).find(".item").length,t=$(this);$(this).owlCarousel({items:1,loop:!1,margin:0,nav:!0,mouseDrag:!1,pullDrag:!1,drag:!1,navText:[,],responsive:{0:{items:1},600:{items:1},1e3:{items:1}},onInitialize:function(){$(t).parent().find(".owlStatus").html("<span><b>"+(e-1)+"</b><span>more</span></span>")},onTranslate:function(){$(t).find(".TabBanners").length&&TweenMax.to($(".TabBanners > li"),0,{css:{width:"25%"},ease:Expo.easeInOut,onStart:function(){$(".TabBanners > li").removeClass("activeBanner")}})},onTranslated:function(){$(t).find(".TabBanners").length&&$(".owl-item.active .TabBanners > li:first-child").bind("click").trigger("click")}}),$(this).off("changed.owl.carousel").on("changed.owl.carousel",function(e){e.namespace&&"position"==e.property.name&&$(this).parent().find(".owlStatus").html("<span><b>"+(e.item.count-(e.relatedTarget.relative(e.item.index)+1))+"</b><span>more</span></span>")})})}function e(e,t){return Number(e)+Number(t)}$(".custom-tabs").easyResponsiveTabs({type:"default",width:"auto",fit:!0,closed:"accordion",tabidentify:"hor_1"}),$(".sub-hrz-tabs").easyResponsiveTabs({type:"default",width:"auto",fit:!0,closed:"accordion",tabidentify:"hor_2"}),$(".verti-tabs").easyResponsiveTabs({type:"vertical",width:"auto",fit:!0,tabidentify:"ver",activate:function(e){var t=$(this),i=$("#nested-tabInfo");$("span",i).text(t.text())}}),$(".tooltip-btn").tooltip(),$(".container").tooltip("hide"),$(".tooltip-right").tooltip({placement:"right",viewport:{selector:"body",padding:2}}),$(".tooltip-bottom").tooltip({placement:"bottom",viewport:{selector:"body",padding:2}}),$(".tooltip-viewport-right").tooltip({placement:"right",viewport:{selector:".container-viewport",padding:2}}),$(".tooltip-viewport-bottom").tooltip({placement:"bottom",viewport:{selector:".container-viewport",padding:2}}),$(".popup").magnificPopup({type:"inline",fixedContentPos:!0,fixedBgPos:!0,overflowY:"auto",closeBtnInside:!0,preloader:!1,midClick:!0,removalDelay:300,mainClass:"my-mfp-slide-bottom"}),$(".widget-rt ul > li > .wdgt-wrapper > .wdgt").off("click.click3").on("click.click3",function(){$(this).closest(".widget-rt ul > li > .wdgt-wrapper").find("span.icon-txt").toggle(),$(this).closest(".widget-rt ul > li > .wdgt-wrapper").find(".calc-sec").toggle()}),$(".profile-user > a").off("click.click4").on("click.click4",function(){$(".user-optns").slideToggle()}),$(".chat-widget-head").off("click.click5").on("click.click5",function(){$(".chat-widget-bdy").slideToggle(),$(".chat-widget").toggleClass("active"),$(".chat-widget .chat-widget-head span, .chat-widget .chat-widget-head small, .chat-widget .chat-widget-head:after").show()}),$(".itemsScaleUp-true").owlCarousel({items:7,itemsScaleUp:!0}),navigator.userAgent.match(/(iPhone|Android|BlackBerry)/)||(navigator.userAgent.match(/(iPod|iPad)/)?$("a[href^=tel]").click(function(e){}):($("a[href^=tel]").click(function(e){e.preventDefault()}),$("a[href^=tel]").addClass("disable"))),$(window).width()<767&&$("footer .footer-sec h5").off("click.click6").on("click.click6",function(e){$(this).closest(".footer-col").find(".footer-collapse").slideToggle(),$(this).toggleClass("active")}),$('[data-toggle="tooltip"]').tooltip(),$(document).off("click.click7").on("click.click7",".TabBanners > li",function(e){var t=$(this),i=$(this).find(".banner-box-cont"),o=$(this).find("img.banner-img"),a=0,n=$(this).find("a");TweenMax.to($(".TabBanners > li"),1,{css:{width:"25%"},ease:Expo.easeInOut,onStart:function(){$(".TabBanners > li").removeClass("activeBanner")}}),TweenMax.to($(".TabBanners > li > .banner-box-cont"),0,{css:{opacity:"0"},ease:Expo.easeInOut}),TweenMax.to($(".TabBanners > li a"),1,{css:{display:"none"},ease:Expo.easeInOut}),TweenMax.to($(".TabBanners > li img.banner-img"),1,{css:{left:a},ease:Expo.easeInOut}),TweenMax.to(t,1,{css:{width:"50%"},ease:Expo.easeInOut,onStart:function(){t.addClass("activeBanner")}}),TweenMax.to(n,1,{css:{display:"block"},ease:Expo.easeInOut}),TweenMax.to(i,2,{css:{opacity:"1"},ease:Expo.easeInOut}),TweenMax.to(o,1,{css:{left:"0"},ease:Expo.easeInOut})}),$(".owl-item.active .TabBanners > li:first-child").bind("click").trigger("click"),$(".req-field").length&&$(".req-field").each(function(){var e=$(this),t=e.find(".holder"),i=e.find("input, textarea").val(),o=e.find("input, textarea");i?t.fadeOut():t.fadeIn(),o.focus(function(){t.fadeOut()}).focusout(function(){e.find("input, textarea").val().length?t.fadeOut():t.fadeIn()})}),$(document).ready(function(){ww=document.body.clientWidth,ww>=768||($(".summary-box .summary-cont").slideUp(),$(".summary-box h2").removeClass("active"))}),$(".summary-box h2").off("click.click8").on("click.click8",function(){document.body.clientWidth<768&&($(this).toggleClass("active"),$(this).parent().find(".summary-cont").slideToggle())}),$("#trvl-slider").slider({tooltip:"hide",ticks:[0,1,2,3]}),$(".select-opt").off("change.change1").on("change.change1",function(){$(".select-opt").val(),$(".issuers").show()}),$("#footerFixedBand").length&&($win=$(window),$(document).ready(function(){$FooterPos=$(".wrapper").height()+$("header").height()-$("#footerFixedBand").height(),$FooterHeight=$("#footerFixedBand").height();$win.height(),$FooterHeight;function e(){var e=$win.height()-$FooterHeight;$FooterPosDef=$(".wrapper").height()+$("header").height()-$("#footerFixedBand").height(),e<$FooterPosDef?$("#footerFixedBand").addClass("fixedElem"):$("#footerFixedBand").removeClass("fixedElem")}e(),$(window).off("resize.resize2").on("resize.resize2",function(){e()})}),$(window).off("scroll.scroll2").on("scroll.scroll2",function(){$FooterPos2=$(".wrapper").height()+$("header").height()-$("#footerFixedBand").height(),$FooterHeight2=$("#footerFixedBand").height()+10;var e=$win.height()-$FooterHeight2;$(this).scrollTop()+e<$FooterPos2?$("#footerFixedBand").addClass("fixedElem"):$("#footerFixedBand").removeClass("fixedElem")})),$(".hasDatepicker").datepicker().off("input.hasDatepicker change.hasDatepicker").on("input.hasDatepicker change.hasDatepicker",function(e){$(this).siblings(".holder").css("display","none")}),$("span.tool-tip").off("mouseenter.mouseenter1").on("mouseenter.mouseenter1",function(){$(this).find(".tooltip-cont").show(),$(this).children("a").addClass("active")}).off("mouseleave.mouseleave1").on("mouseleave.mouseleave1",function(){$(this).find(".tooltip-cont").hide(),$(this).children("a").removeClass("active")}),$(".sell-forex").hide(),$.fn.digits=function(){return this.each(function(){$(this).text($(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g,"$1,"))})},$(".select-opt").off("change.change2").on("change.change2",function(){$(this).val();"us-dollar"==$(this).children(":selected").attr("id")&&$(".add-more-currency ul li .amt-input input").on("keyup.keyup1").on("keyup.keyup1",function(){var e=$(this).val(),t=(68.23*e).toFixed(0),i=(68.23*e-100+45).toFixed(0);$(this).closest(".amt-input").is("#corspt-charges")?($(".corspt-charges").hide(),$(".tool-tip").show(),$("#branch").show(),$(".fort-branch").hide(),$(".traveller-details-sec .forex-amt em").html(t).digits(),$(".corspt-charges span.tot-amt em").html(t).digits(),$(".payable-amt span.tot-amt em").html(i).digits(),$(".info-frm-btm .total > span.tot-amt").addClass("ttlamt-black")):($(".tool-tip").show(),$(".traveller-details-sec .forex-amt em").html(t).digits(),$(".info-frm-btm .total > span.tot-amt em").html(t).digits(),$(".info-frm-btm .total > span.tot-amt").addClass("ttlamt-black"))})}),$(".select-opt").off("change.change3").on("change.change3",function(){$(this).val();"us-dollar"==$(this).children(":selected").attr("id")&&$(".add-more-currency ul li.multi-product .input-text input").off("keyup.keyup2").on("keyup.keyup2",function(){var t=$(this).val();if($(this).closest(".frx-data").is("#corspt-charges")){if($(this).closest(".amt-input").is("#corspt-charges")){var i=(68.23*t).toFixed(0);(68.23*t-100+45).toFixed(0);$(".forex-amt em").html(i).digits()}if($(this).closest(".amt-input-cash").is("#corspt-charges")){var o=(68.5*t).toFixed(0);(68.5*t-100+45).toFixed(0);$(".forex-amt-cash em").html(o).digits()}if($(this).closest(".amt-input-trvl").is("#corspt-charges")){var a=(68.45*t).toFixed(0);(68.5*t-100+45).toFixed(0);$(".forex-amt-trvl em").html(a).digits()}if($(this).closest(".amt-input-dd").is("#corspt-charges")){var n=(68.3*t).toFixed(0);(68.3*t-100+45).toFixed(0);$(".forex-amt-dd em").html(n).digits()}var l=$(".forex-amt em").text().replace(",","").replace("*",""),c=$(".forex-amt-cash em").text().replace(",","").replace("*",""),s=$(".forex-amt-trvl em").text().replace(",","").replace("*",""),r=$(".forex-amt-dd em").text().replace(",","").replace("*",""),d=e(e(l,c),e(s,r));$(".payable-amt span.tot-amt em").text(d).digits().parent().addClass("pr-updated")}})}),$(".select-opt").off("change.change4").on("change.change4",function(){$(this).val();"us-dollar"==$(this).children(":selected").attr("id")&&$(".add-more-currency ul li.sell-forex-amt .amt-input input").off("keyup.keyup3").on("keyup.keyup3",function(){var e=$(this).val(),t=(67.9*e).toFixed(0),i=(67.9*e-45).toFixed(0);$(this).closest(".amt-input").is("#corspt-charges")?($(".corspt-charges").hide(),$(".tool-tip").show(),$(".traveller-details-sec .forex-amt em").html(t).digits(),$(".corspt-charges span.tot-amt em").html(t).digits(),$(".payable-amt span.tot-amt em").html(i).digits(),$(".info-frm-btm .total > span.tot-amt").addClass("ttlamt-black")):($(".tool-tip").show(),$(".traveller-details-sec .forex-amt em").html(t).digits(),$(".info-frm-btm .total > span.tot-amt em").html(t).digits(),$(".info-frm-btm .total > span.tot-amt").addClass("ttlamt-black"))})}),$(".select-opt").off("change.change5").on("change.change5",function(){$(this).val();"us-dollar"==$(this).children(":selected").attr("id")&&$(".add-more-currency.sell-forex-amt-ppc ul li .amt-input input").off("keyup.keyup4").on("keyup.keyup4",function(){var e=$(this).val(),t=(67.5*e).toFixed(0),i=(67.5*e+100-45).toFixed(0);$(this).closest(".amt-input").is("#corspt-charges")?($(".corspt-charges").hide(),$(".tool-tip").show(),$(".traveller-details-sec .forex-amt em").html(t).digits(),$(".corspt-charges span.tot-amt em").html(t).digits(),$(".payable-amt span.tot-amt em").html(i).digits(),$(".info-frm-btm .total > span.tot-amt").addClass("ttlamt-black")):($(".tool-tip").show(),$(".traveller-details-sec .forex-amt em").html(t).digits(),$(".info-frm-btm .total > span.tot-amt em").html(t).digits(),$(".info-frm-btm .total > span.tot-amt").addClass("ttlamt-black"))})});var t=$(".bank-payment").off("click.click10").on("click.click10",function(e){t.removeClass("active"),$(this).addClass("active")});if($(".selectpicker").off("change.change6").on("change.change6",function(){$(this).parents(".styled-select").siblings(".fileupload").removeClass("disable-file-upload"),$(this).parents(".styled-select").siblings(".fileupload").find("input[type=file]").removeAttr("disabled")}),$(".upload-document-cont .styled-select .btn-group  .dropdown-menu .dropdown-menu").mCustomScrollbar(),$(".selectpicker").off("change.change7").on("change.change7",function(){$(this).parents(".styled-select").siblings(".fileupload").removeClass("disable-file-upload"),$(this).parents(".styled-select").siblings(".fileupload").find("input[type=file]").removeAttr("disabled")}),$(".upload-document-cont .styled-select .btn-group  .dropdown-menu .dropdown-menu").mCustomScrollbar(),$(".tool-tip-link").off("click.click11").on("click.click11",function(e){e.preventDefault(),$(".tool-tip-container").hide(),$(this).parent().find(".tool-tip-container").show()}),setTimeout(function(){$("#date0").datepicker().on("input change",function(e){$(this).parents("li").find(".tool-tip-container").show()})},50),$(".popup-container .popup-form-details ul li .tool-tip-container .close-btn").off("click.click12").on("click.click12",function(){$(this).parents(".tool-tip-container").hide()}),$(".popup-container ul li .tool-tip-container .close-btn").off("click.click13").on("click.click13",function(){$(this).parents(".tool-tip-container").hide()}),$("#salaried").off("ifChecked.ifChecked1").on("ifChecked.ifChecked1",function(e){$(".fund-cont.salaried").show()}),$(".selectpicker").off("change.change8").on("change.change8",function(){$(this).parents(".styled-select").siblings(".fileupload").removeClass("disable-file-upload"),$(this).parents(".styled-select").siblings(".fileupload").find("input[type=file]").removeAttr("disabled")}),$(".upload-document-cont .styled-select .btn-group  .dropdown-menu .dropdown-menu").mCustomScrollbar(),$("a.kyc-floater-btn").off("click.click14").on("click.click14",function(){$(this).parent(".kyc-floater").toggleClass("open")}),$(".timepicker-input").timepicker({disableFocus:!0}),$(".issuers-list li").off("click.click15").on("click.click15",function(){$(".issuers-list li").removeClass("selected"),$(this).closest(".issuers-list li").toggleClass("selected")}),$(".new-user .btn-standard").off("click.click16").on("click.click16",function(){$("#ms_timer").countdowntimer({minutes:3,seconds:0,size:"lg"})}),$(".otp-popup-link.btn-standard").off("click.click17").on("click.click17",function(){$("#ms_timer").countdowntimer({minutes:3,seconds:0,size:"lg"})}),$(".amt-1").length){$(".amt-1 em").html();var i=$(".amt-2 em").html(),o=$(".amt-4 em").html(),a=0;$(".ul-type-02 li.multi-prod").each(function(){a+=parseFloat($(this).find("em").text().replace(/,/g,""))});var n=parseFloat(i.replace(/,/g,"")),l=parseFloat(o.replace(/,/g,"")),c=(m=a+n)+l;function s(e){for(;/(\d+)(\d{3})/.test(e.toString());)e=e.toString().replace(/(\d+)(\d{3})/,"$1,$2");return e}$(".tot-amt em").html(s(m)),$(".btn-details").off("click.click18").on("click.click18",function(e){$(".btn-details").removeClass("active"),$(".express-delivery-btn").removeClass("active"),$(".add-prod").addClass("active"),$(".main-head .rgt-sec").addClass("tot-amt"),$(".exp-prod").removeClass("active"),$(".gst-added").show(),$(".gst-amt").hide();var t=$(".btn-details em").html();$(".amt-2 em").html(t);$(".amt-1 em").html();var i=$(".amt-2 em").html(),o=$(".amt-5 em").html(),a=0;$(".ul-type-02 li.multi-prod").each(function(){a+=parseFloat($(this).find("em").text().replace(/,/g,""))});var n=parseFloat(i.replace(/,/g,"")),l=parseFloat(o.replace(/,/g,"")),c=a+n+l;return $(".tot-amt em").html(function(e){for(;/(\d+)(\d{3})/.test(e.toString());)e=e.toString().replace(/(\d+)(\d{3})/,"$1,$2");return e}(c)),$(this).addClass("active"),!1});var r=$(".amt-1 em").html(),d=$(".amt-3 em").html(),h=(parseFloat(r.replace(/,/g,"")),parseFloat(d.replace(/,/g,"")),0);$(".ul-type-02 li.multi-prod").each(function(){h+=parseFloat($(this).find("em").text().replace(/,/g,""))});var f=parseFloat(d.replace(/,/g,""));c=h+f;function s(e){for(;/(\d+)(\d{3})/.test(e.toString());)e=e.toString().replace(/(\d+)(\d{3})/,"$1,$2");return e}$(".tot-amt em").html(s(c)),$(".express-delivery-btn").off("click.click19").on("click.click19",function(e){$(".btn-details").removeClass("active"),$(".express-delivery-btn").removeClass("active"),$(".exp-prod").addClass("active"),$(".add-prod").removeClass("active");var t=$(".express-delivery-btn em").html();$(".amt-3 em").html(t);var i=$(".amt-1 em").html(),o=$(".amt-3 em").html(),a=(parseFloat(i.replace(/,/g,"")),parseFloat(o.replace(/,/g,"")),0);$(".ul-type-02 li.multi-prod").each(function(){a+=parseFloat($(this).find("em").text().replace(/,/g,""))});var n=parseFloat(o.replace(/,/g,"")),l=a+n;return $(".tot-amt em").html(function(e){for(;/(\d+)(\d{3})/.test(e.toString());)e=e.toString().replace(/(\d+)(\d{3})/,"$1,$2");return e}(l)),$(this).addClass("active"),!1})}if($(".amt-1").length){$(".amt-1 em").html(),i=$(".amt-2 em").html(),o=$(".amt-4 em").html(),a=0;$(".ul-type-02 li.multi-prod").each(function(){a+=parseFloat($(this).find("em").text().replace(/,/g,""))});var m;n=parseFloat(i.replace(/,/g,"")),l=parseFloat(o.replace(/,/g,"")),c=(m=a-n)-l;function s(e){for(;/(\d+)(\d{3})/.test(e.toString());)e=e.toString().replace(/(\d+)(\d{3})/,"$1,$2");return e}$(".tot-amt em").html(s(m)),$(".btn-details.sell-gst").off("click.click20").on("click.click20",function(e){$(".btn-details").removeClass("active"),$(".express-delivery-btn").removeClass("active"),$(".add-prod").addClass("active"),$(".main-head .rgt-sec").addClass("tot-amt"),$(".exp-prod").removeClass("active"),$(".gst-added").show(),$(".gst-amt").hide();var t=$(".btn-details em").html();$(".amt-2 em").html(t);$(".amt-1 em").html();var i=$(".amt-2 em").html(),o=$(".amt-5 em").html(),a=0;$(".ul-type-02 li.multi-prod").each(function(){a+=parseFloat($(this).find("em").text().replace(/,/g,""))});var n=parseFloat(i.replace(/,/g,"")),l=parseFloat(o.replace(/,/g,"")),c=a-n-l;return $(".tot-amt em").html(function(e){for(;/(\d+)(\d{3})/.test(e.toString());)e=e.toString().replace(/(\d+)(\d{3})/,"$1,$2");return e}(c)),$(this).addClass("active"),!1});r=$(".amt-1 em").html(),d=$(".amt-3 em").html(),parseFloat(r.replace(/,/g,"")),parseFloat(d.replace(/,/g,"")),h=0;$(".ul-type-02 li.multi-prod").each(function(){h+=parseFloat($(this).find("em").text().replace(/,/g,""))});f=parseFloat(d.replace(/,/g,"")),c=h-f;function s(e){for(;/(\d+)(\d{3})/.test(e.toString());)e=e.toString().replace(/(\d+)(\d{3})/,"$1,$2");return e}$(".tot-amt em").html(s(c)),$(".express-delivery-btn.sell-gst").off("click.click21").on("click.click21",function(e){$(".btn-details").removeClass("active"),$(".express-delivery-btn").removeClass("active"),$(".exp-prod").addClass("active"),$(".add-prod").removeClass("active");var t=$(".express-delivery-btn em").html();$(".amt-3 em").html(t);var i=$(".amt-1 em").html(),o=$(".amt-3 em").html(),a=(parseFloat(i.replace(/,/g,"")),parseFloat(o.replace(/,/g,"")),0);$(".ul-type-02 li.multi-prod").each(function(){a+=parseFloat($(this).find("em").text().replace(/,/g,""))});var n=parseFloat(o.replace(/,/g,"")),l=a-n;return $(".tot-amt em").html(function(e){for(;/(\d+)(\d{3})/.test(e.toString());)e=e.toString().replace(/(\d+)(\d{3})/,"$1,$2");return e}(l)),$(this).addClass("active"),!1})}$(".custom-tabs.type3").length&&$(window).off("load.load3").on("load.load3",function(){$(".custom-tabs.type3 .resp-tab-active").removeClass("resp-tab-active"),$(".custom-tabs.type3 .resp-tab-content-active").removeClass("resp-tab-content-active").hide()}),$(".req-field select").length&&$(".req-field select").change(function(){$(this).parent().addClass("DropDownStyle")}),$(".second-trvl").length&&($(".second-trvl").off("ifChecked.ifChecked2").on("ifChecked.ifChecked2",function(e){$(this).parent("li").find(".lead-pax-lbl").show()}),$(".second-trvl").off("ifUnchecked.ifUnchecked1").on("ifUnchecked.ifUnchecked1",function(e){$(this).parent("li").find(".lead-pax-lbl").hide()})),$(".lead-pax-lbl").off("ifChecked.ifChecked3").on("ifChecked.ifChecked3",function(e){$(".other-trvl .styled-checkbox").iCheck("check")}),$(".other-trvl").off("ifChecked.ifChecked4").on("ifChecked.ifChecked4",function(e){$(this).parent("li").find(".other-lead-pax-lbl").show()}),$(".other-trvl").off("ifUnchecked.ifUnchecked2").on("ifUnchecked.ifUnchecked2",function(e){$(this).parent("li").find(".other-lead-pax-lbl").hide()}),$(".second-trvl").off("ifUnchecked.ifUnchecked3").on("ifUnchecked.ifUnchecked3",function(e){$(".other-trvl .styled-checkbox").iCheck("uncheck"),$(".lead-pax-lbl .styled-radio").iCheck("uncheck")}),$(".round-icn").length&&($(".round-icn").off("click.click22").on("click.click22",function(e){e.preventDefault(),$(".trvl-list").show()}),$(".trvl-list .close-btn").off("click.click23").on("click.click23",function(){$(this).parents(".trvl-list").hide()})),$(".new-trvl").off("ifChecked.ifChecked5").on("ifChecked.ifChecked5",function(e){e.preventDefault(),$(".scenario-two").show(),$(".scenario-one").hide()}),$(window).off("load.load4").on("load.load4",function(){$(".trvl-scroller").mCustomScrollbar({axis:"x",advanced:{autoExpandHorizontalScroll:!0}})}),$(".upload-document-cont .btn-wht").off("click.click24").on("click.click24",function(e){e.preventDefault(),$.magnificPopup.close()}),$(".aadhaar-address-no").off("ifChecked.ifChecked6").on("ifChecked.ifChecked6",function(e){e.preventDefault(),$(".adhaar-add").show()}),$(".aadhaar-address-yes").off("ifChecked.ifChecked7").on("ifChecked.ifChecked7",function(e){e.preventDefault(),$(".adhaar-add").hide()}),$(".other-add").off("ifChecked.ifChecked8").on("ifChecked.ifChecked8",function(e){e.preventDefault(),$(".other-add-dtl").show()}),$(".current-address").off("ifChecked.ifChecked9").on("ifChecked.ifChecked9",function(e){e.preventDefault(),$(".other-add-dtl").hide()}),$(".aadhaar-yes").off("ifChecked.ifChecked10").on("ifChecked.ifChecked10",function(e){e.preventDefault(),$(".adhaar-verify").show()}),$(".aadhaar-no").off("ifChecked.ifChecked11").on("ifChecked.ifChecked11",function(e){e.preventDefault(),$(".adhaar-verify").hide()}),$(".sell.prepaid-card").off("ifChecked.ifChecked12").on("ifChecked.ifChecked12",function(e){1==$(".sell.prepaid-card .styled-checkbox").iCheck("update")[0].checked&&($(".sell.prepaid-card-dtl").show(),$(".show-branch").show(),$(".hide-branch").hide()),$(".bdr-input").addClass("frm-btm"),$(".budgt-amt").show(),$(".blc-amt").show(),$(".fa-rupee").addClass("yellow"),$(".budgt-amt").addClass("wht-txt"),$(".blnk-amt").hide()}),$(".sell.prepaid-card").off("ifUnchecked.ifUnchecked4").on("ifUnchecked.ifUnchecked4",function(e){0==$(".sell.prepaid-card .styled-checkbox").iCheck("update")[0].checked&&$(".sell.prepaid-card-dtl").hide()}),$(".sell.cash input").off("ifChecked.ifChecked13").on("ifChecked.ifChecked13",function(e){$(this).closest(".bdr-input").find(".cash-dtl").show()}),$(".sell.cash input").off("ifUnchecked.ifUnchecked4").on("ifUnchecked.ifUnchecked4",function(e){$(this).closest(".bdr-input").find(".cash-dtl").hide()}),$(".cashout-chk").off("ifChecked.ifChecked14").on("ifChecked.ifChecked14",function(){$(this).parents("tr").find(".cashout-label").show(),$(this).parents("tbody").find(".select-payout").hide()}),$(".cashout-chk").off("ifUnchecked.ifUnchecked5").on("ifUnchecked.ifUnchecked5",function(){$(this).parents("tr").find(".cashout-label").hide(),$(this).parents("tbody").find(".select-payout").hide(),$(this).parents("tbody").find(".cashout-tr").hide(),$(this).parents("tbody").find(".cash-note").hide()}),$(".btn-add-currency").off("click.click25").on("click.click25",function(e){$(".more-currency-added").show()}),$(".reload-card.close-section").off("click.click26").on("click.click26",function(e){$(".more-currency-added").hide()}),counterCall++};function openMenu(){return $(".user-login-opt").toggle(),$(".usr-menu").toggleClass("active"),!0}function initAccord(){console.log("Accord called"),$(".faqslist dt").click(function(){var e=$(this).next("dd");$(this).next(e).slideToggle(),$(this).toggleClass("active")})}function initMyAccountJS(e){console.log("initMyAccountJS"),$(".lead-pax-details").each(function(){$(this).find(".link-dtls").click(function(e){e.preventDefault(),$(this).parents("tr").next().hasClass("view-dtls")&&($(this).parents("tr").next(".view-dtls").toggleClass("active").toggle(),$(this).toggleClass("active"))})}),$(".tab1").off("click.click27").on("click.click27",function(e){e.preventDefault(),$(".trvl-dtls").toggle(),$(".tab1").toggleClass("active"),$(".tab2").removeClass("active"),$(".dlvr-dtls").hide(),$(".pay-dtls").hide(),$(".forex-dtls").hide(),$(".trvl-dtl-cont").show(),$(".tab3").removeClass("active"),$(".tab4").removeClass("active")}),$(".tab2").off("click.click28").on("click.click28",function(e){e.preventDefault(),$(".dlvr-dtls").toggle(),$(".trvl-dtls").hide(),$(".pay-dtls").hide(),$(".forex-dtls").hide(),$(".tab2").toggleClass("active"),$(".tab1").removeClass("active"),$(".tab3").removeClass("active"),$(".tab4").removeClass("active")}),$(".tab3").off("click.click29").on("click.click29",function(e){e.preventDefault(),$(".pay-dtls").toggle(),$(".trvl-dtls").hide(),$(".dlvr-dtls").hide(),$(".tab3").toggleClass("active"),$(".tab1").removeClass("active"),$(".tab2").removeClass("active"),$(".tab4").removeClass("active")}),$(".tab4").off("click.click30").on("click.click30",function(e){e.preventDefault(),$(".forex-dtls").toggle(),$(".pay-dtls").hide(),$(".trvl-dtls").hide(),$(".dlvr-dtls").hide(),$(".tab4").toggleClass("active"),$(".tab1").removeClass("active"),$(".tab2").removeClass("active"),$(".tab3").removeClass("active")})}


/* Standalone Visa and Insurance */

/**float box mob popup**/
if (window.matchMedia('(max-width: 767px)').matches) {
    $('.popup-box').addClass('mfp-hide');
    $(document).on('click', '.pop-list', function () {
        var targetDiv = $(this).attr("href");
        $.magnificPopup.open({
            type: 'inline',
            items: { src: targetDiv },
            fixedContentPos: true,
            fixedBgPos: true,
            overflowY: 'auto',
            closeBtnInside: true,
            preloader: false,
            midClick: true,
            removalDelay: 300,
            mainClass: 'my-mfp-slide-bottom'
        });
    });
} else {
    $('.Float-box').hide();
}
/****01-06-18***/

/************05-06-18*************/
//var options = {
//    debug: true,
//}
//$('.exit-popup').ysExit(options);
/************05-06-18*************/




/*********Visa Standalone***********/
/* $('#parentHorizontalTab, #parentHorizontalTab2').easyResponsiveTabs({
    type: 'default', //Types: default, vertical, accordion
    width: 'auto', //auto or any width like 600px
    fit: true, // 100% fit in a container
    tabidentify: 'hor_1', // The tab groups identifier
    activate: function(event) { // Callback function if tab is switched
        var $tab = $(this);
        var $info = $('#nested-tabInfo');
        var $name = $('span', $info);
        $name.text($tab.text());
        $info.show();
    }
});*/
function visaTabs(){
    $('.HorizontalTab').each(function (i) {
        var newClass = "hor_" + i++;
    
        $(this).find('.resp-tabs-list').addClass(newClass),
            $(this).find('.resp-tabs-container').addClass(newClass);
    
        $(this).easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: newClass // The tab groups identifier
        });
    });
}



$('.radio-box > .radio-inline > label').on('click', function () {
    $(this).addClass('active');

});

/*********Visa Standalone***********/


/******Insurance flow start****/
/*Range Slider :: Starts*/
// $(".rangeSlider").slider({ tooltip: 'hide', min: 25000, max: 500000, value: [25000, 500000] });
// $(".rangeSlider").on("slide", function (slideEvt) {
//     $(".range-1-slider").text(slideEvt.value[0]);
//     $(".range-2-slider").text(slideEvt.value[1]);
// });
/*Range Slider :: Ends*/




// $('.flexible-dates .owl-carousel').owlCarousel({
//     items: 5, loop: true, center: true, margin: 0, nav: true, dots: false, mouseDrag: false, pullDrag: false, drag: false, navText: [,], responsive: { 0: { items: 1 }, 480: { items: 3 }, 600: { items: 4 }, 1000: { items: 5 } }
// });

$('.addTravellers-MultiTrip .count-up').click(function () {
    if ($('.addTravellers-MultiTrip .form-control').val() == '2') {
        $(".travelDateMultiTrip").show();
    }
});

$('.addTravellers-MultiTrip .count-down').click(function () {
    if ($('.addTravellers-MultiTrip .form-control').val() == '1') {
        $(".travelDateMultiTrip").hide();
    }
});
$('.single-trip').on('ifChecked', function () {
    $('#single-trip').show();
    $('#multi-trip').hide();
});

$('.multi-trip').on('ifChecked', function () {
    $('#multi-trip').show();
    $('#single-trip').hide();
});


$('.addTravellers-SingleTrip .count-up').click(function () {
    //alert('SingleTrip');
    if ($('.addTravellers-SingleTrip .form-control').val() == '2') {
        $(".travelDate").show();
    }
});

$('.addTravellers-SingleTrip .count-down').click(function () {
    if ($('.addTravellers-SingleTrip .form-control').val() == '1') {
        $(".travelDate").hide();
    }
});

$('.addTravellers-MultiTrip .count-up').click(function () {
    if ($('.addTravellers-MultiTrip .form-control').val() == '2') {
        $(".travelDateMultiTrip").show();
    }
});

$('.addTravellers-MultiTrip .count-down').click(function () {
    if ($('.addTravellers-MultiTrip .form-control').val() == '1') {
        $(".travelDateMultiTrip").hide();
    }
});
$('.room-spinner .count-up').click(function () {
    if ($('.room-spinner .form-control').val() == '2') {
        $(".add-room-two").show();
    } else {
        $(".add-room-two").hide();
    }
});

$('.pre-disease-yes').click(function () {
    $('.existing-disease').show();
});
$('.pre-disease-no').click(function () {
    $('.existing-disease').hide();
});

$('.room-spinner .count-up').click(function () {
    if ($('.room-spinner .form-control').val() == '1') {
        $(".add-room-two").show();
    }
});

$('.room-spinner .count-down').click(function () {
    if ($('.room-spinner .form-control').val() == '2') {
        $(".add-room-two").hide();
    }
});
/******Insurance flow end****/


/***** Itinerary Sub  tabs starts *****/
var initSubItinerary = function () {

    var fixednavbar = $('.itenary-details'),
        DivoOffset = fixednavbar.offset().top - $('header').outerHeight();


    $(window).resize(function () {
        if ($(window).width() < 767) {
            $('.itenary-details .itenary-heading').removeClass('fixedPos');
            $('.itenary-heading-btn a').addClass('fixedPos');
            $('.itenary-details .itenary-heading').addClass('mobile');


        } else {
            $('.itenary-details .itenary-heading').removeClass('mobile');
            $('.itenary-section').show();
            $('.itenary-details .itenary-heading').slideDown();


        }
    }).resize();

    $(".itenary-heading > li a").click(function (event) {
        if ($(".itenary-details .itenary-heading.mobile").length) {
            event.preventDefault();
            $('.itenary-details .itenary-heading li a').removeClass('active');
            $(this).addClass("active");

            var $TargetAside = $('.itenary-details'),
                $BtnAside = $TargetAside.find('.itenary-heading-btn'),
                $ContAside = $TargetAside.find('.itenary-heading'),
                $BtnActiveAside = $ContAside.find('.active').text();
            $BtnActiveAside = $BtnActiveAside;

            $BtnAside.find('a').text($BtnActiveAside);
            var dataLabel = $(this).attr('data-label');
            $('.itenary-section').hide()
            $("#tab-" + dataLabel + "-sect").show()
            $('.itenary-details .itenary-heading').slideUp();
        }
        else {
            $(this).parents('.itenary-heading').find('li a').removeClass("active");
            $(this).addClass("active");
            var dataLabel = $(this).attr('data-label');
            var topStickers = $("header").outerHeight() + $(".pkg-bar").outerHeight();
            var itneraryFixPos = $('.itenary-details .itenary-heading.fixedPos');
            if (itneraryFixPos.length) {
                $('html, body').animate({ scrollTop: $("#tab-" + dataLabel + "-sect").offset().top - 190 }, 300);
            }
            else {
                $('html, body').animate({ scrollTop: $("#tab-" + dataLabel + "-sect").offset().top - topStickers - 150 }, 300);
            }
        }

    });


    $('.itenary-heading-btn a').click(function (event) {
        event.preventDefault();
        if ($(".itenary-details .itenary-heading.mobile").length) {

            $('.itenary-details .itenary-heading').slideToggle();
            $(this).toggleClass("active");
        }
    });
}
/***** Itinerary Sub  tabs Ends *****/

/** Compare holidays accordins starts ***/
$(".comp-accordian .dwn-accd-arrw").click(function (e) {
    $(this).parent().next(".comp-tbl-res").slideToggle("slow");
    $(this).toggleClass("active");
    initScrollPanel();
});
/** Compare holidays accordins Ends ***/


/** Compare **/
$('.pkg-listing > li .compare-check').find('input[type=checkbox]').on('ifChecked', function () {
    var targeTrip = $(this).closest('li'),
        TripTl = $(this).closest('.compare-check').parent().children('.pkg-thumbnail').find('.pkg-tl'),
        Tripname = $(this).closest('.compare-check').parent().children('.pkg-thumbnail').find('.pkg-tl').text(),
        TripId = $(this).closest('.compare-check').parent().children('.pkg-thumbnail').find('.pkg-tl').text().toLowerCase().replace(/[\ \*\^\'\!\&]/g, ''),
        TripLength = $('.pkg-listing > li.selected').length;

    if (TripLength < 3) {
        if (TripLength > 0) {
            $('.cm-mand-txt').hide();
            $('.cm-btn').show();
        }
        else {
            $('.cm-mand-txt').show();
            $('.cm-btn').hide();
        }

        $('.compare-list').fadeIn();
        targeTrip.addClass('selected');


        if (!$(TripTl).attr('rel') == '') {
            var TripTlRel = $(TripTl).attr('rel');
            $('.compare-list .cm-trips').find('li:nth-child(' + (TripLength + 1) + ')').addClass('filled').addClass(TripId).find('b').html(Tripname + '<small>' + TripTlRel + '</small>');
        }
        else {
            $('.compare-list .cm-trips').find('li:nth-child(' + (TripLength + 1) + ')').addClass('filled').addClass(TripId).find('b').text(Tripname);
        }

        targeTrip.addClass(TripId);
    }

    else {
        alert('You can choose maximum 3 trips for compare.');
        var cual = this;
        setTimeout(function () { $(cual).iCheck('uncheck'); }, 1);
    }
    //alert('Check');
}).on('ifUnchecked', function () {

    //$(this).closest('li').removeClass('selected')

    var targeTrip = $(this).closest('li'),
        Tripname = $(this).closest('.compare-check').parent().children('.pkg-thumbnail').find('.pkg-tl').text(),
        TripId = $('.cm-trips > .' + $(this).closest('.compare-check').parent().children('.pkg-thumbnail').find('.pkg-tl').text().toLowerCase().replace(/[\ \*\^\'\!\&]/g, '')),


        TripLength = $('.pkg-listing > li.selected').length;


    // targeTrip.removeClass('selected');
    //alert(TripLength);
    if (!TripLength < 2) {
        if (!(TripLength > 2)) { $('.cm-mand-txt').show(); $('.cm-btn').hide(); }
        if (!(TripLength > 1)) { $('.compare-list').fadeOut(); }
    }
    else {
        if (TripLength > 2) {
            $('.cm-mand-txt').hide();
            $('.cm-btn').show();
        }
        else {
            $('.cm-mand-txt').show();
            $('.cm-btn').hide();
        }
    }

    // alert('Uncheck');
    //alert(TripId);
    $('.compare-list .cm-trips').find(TripId).find('b').text('');

    $(TripId).attr('class', '');
    //$(TripId).removeClass('selected'); 
    targeTrip.removeClass(TripId).removeClass('selected');

});

$('.compare-list .btn-remove').click(function (evt1) {
    evt1.preventDefault();
    $(this).parent().find('b').text('');
    $(this).parent().removeClass('filled');

    var TripId = '.' + $(this).parent().attr('class');
    //alert(TripId);
    $(TripId).find('input[type=checkbox]').iCheck('uncheck');

});

$('.compare-list .btn-close').click(function (evt) {
    evt.preventDefault();
    $('.compare-list').fadeOut();
    $('.compare-list .cm-trips li').removeClass('filled').find('b').text('');
    $('.pkg-listing > li').removeClass('selected');
    $('.pkg-listing > li').find('input[type=checkbox]').iCheck('uncheck');
});

/* Share Custom Functionality : Starts */
$(document).on("click", ".share-tooltip a", function (e) {
    e.preventDefault();
    $(".share-tooltip a, .tool-tip.info a").removeClass("active");
    $('.share-collapse, .tooltip-cont').hide();
    $('.pkg-listing > li').css({ 'z-index': '0' });
    $(this).parents('li').css({ 'z-index': '1' });
    $(this).parent().find('.share-collapse').show();
    var containerPos = $(this).parents('.container').offset().left;
    var containerWdth = $(this).parents('.container').outerWidth();
    var ContPos = $(this).closest('.share-tooltip').children('.share-collapse').offset().left;
    var ContWdth = $(this).closest('.share-tooltip').children('.share-collapse').outerWidth();
    var pos = ContPos - containerPos;
    var totWdth = pos + ContWdth;
    var margin = totWdth - containerWdth + 30;
    if (totWdth > containerWdth) {
        $(this).closest('.share-tooltip').children('.share-collapse').offset({ left: ContPos - margin });
    }
    var isMobile = window.matchMedia("only screen and (max-width: 767px)");
    if (isMobile.matches) {
        $(this).closest('.share-tooltip').children('.share-collapse').offset({ left: ContPos - margin });
    }
    $(this).toggleClass("active");
    e.stopPropagation();
});


$(document).on("click", ".tool-tip > a, .tool-tip > i", function (e) {
    e.preventDefault();
    $('.tool-tip .tooltip-cont').hide();
    $('.tool-tip > a').removeClass('active');
    $('.tooltip-cont, .share-collapse').hide();
    $('.pkg-listing > li').css({ 'z-index': '0' });
    $('.pkg-bar-list > li').css({ 'z-index': 'unset' });
    //$('.share-sec > li').css({'z-index':'unset'});
    //$('.share-sec').parents('li').css({'z-index':'unset'});
    $(this).parents('li').css({ 'z-index': '2' });
    $(this).parent().find(".tooltip-cont").show();

    var containerPos = $(this).parents('.pkg-listing').offset().left;
    var containerWdth = $(this).parents('.pkg-listing').outerWidth();
    var ContPos = $(this).closest('.tool-tip').children('.tooltip-cont').offset().left;
    var ContWdth = $(this).closest('.tool-tip').children('.tooltip-cont').outerWidth();
    var pos = ContPos - containerPos;
    var totWdth = pos + ContWdth;
    var margin = totWdth - containerWdth + 30;
    if (totWdth > containerWdth) { $(this).closest('.tool-tip').children('.tooltip-cont').offset({ left: ContPos - margin }); }
    $(".tool-tip > a, .tool-tip > i, .share-tooltip > a").removeClass("active");
    $(this).addClass("active");
});

$('.filter-pannel-cont .tool-tip > a').click(function (e) {
    e.stopPropagation();
    $('.filter-pannel-cont .tool-tip .tooltip-cont').hide();
    $('.tool-tip > a').removeClass('active');

    $(".tool-tip > a, .tool-tip > i, .share-tooltip > a").removeClass("active");
    $(this).addClass("active");
    $(this).parent().find(".tooltip-cont").show();
    e.preventDefault();

})

$(document).on("click", ".tooltip-cont .btn-close", function (e) {
    $(this).parent(".tooltip-cont").hide();
    $(".tool-tip > a, .tool-tip > i").removeClass("active");
    e.preventDefault();
});
/* Share Custom Functionality : Ends */
/*** Compare Ends ***/


//Horizontal Tab
var initHorizontalTab = function () {
    $('#HorizontalTab, #HorizontalTab1').responsiveTabs({
        startCollapsed: 'accordion',
        collapsible: 'accordion'
    });
}
// set default tab
$(function () {
    $('#HorizontalTab1 ul .owl-stage .owl-item:first-child li').addClass('r-tabs-state-active');
    $('#HorizontalTab1 .resp-tabs-container > div:nth-child(2)').addClass('r-tabs-state-active')
});
$("#HorizontalTab1 ul li ").on("click", function () {
    //$('#HorizontalTab1 ul li').removeClass('r-tabs-state-active');
    $(this).addClass('r-tabs-state-active');
    $('#HorizontalTab1 .resp-tabs-container > div').removeClass('r-tabs-state-active');
});

/*Filter Selection boxed list starts */
$('.fltr-slt-list.single-selct > li > a').click(function (e) {
    e.preventDefault();
    $(this).parents('.fltr-slt-list').find('a').removeClass('selected');
    $(this).parents('.fltr-slt-list').find('li').removeClass('selected');
    $(this).addClass('selected');
});

$('.fltr-slt-list.multi-selct > li > a').click(function (e) {
    e.preventDefault();
    $(this).toggleClass('selected');
});
/*Filter Selection boxed list ends */

$('.saved-traveler input').on('ifChecked', function () {
    if ($(this).parents('label').hasClass('rd-child')) {
        $(this).parents('label').addClass('err');
        $(this).parents('.saved-traveler').find('.err-msg').show();
    }
    else {
        $(this).parents('.saved-traveler').find('label').removeClass('err');
        $(this).parents('.saved-traveler').find('.err-msg').hide();
    }
    $(this).closest("form").find(".btn-cont .btn").removeClass("disabled");
});

$('.radio-group').each(function () {
    $(this).find('.styled-radio').children('input').on('ifChecked', function (event) {
        $(this).parents('.radio-group').find('.radio-inline').removeClass('selected');
        $(this).parents('.radio-inline').addClass('selected');
    });
});
    /* Standalone Visa and Insurance */
