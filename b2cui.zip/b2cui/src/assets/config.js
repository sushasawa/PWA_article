//    for test purpose use T218263 as merchant id
//    for PRODUCTION purpose use L218263 as merchant id

const SERVERS = {
  PRODUCTION: {
    API_URL: "https://forex.coxandkings.com:8080",
    MERCHANT_ID: "L218263"
  },
  UAT: {
    API_URL: "http://172.21.203.224:8094",
    MERCHANT_ID: "T218263"
  },
  LOCAL: {
    API_URL: "http://10.21.21.210:5000",
    MERCHANT_ID: "T218263"
  }
};


module.exports.Url = SERVERS.LOCAL;
