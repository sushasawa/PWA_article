import { Component, OnInit } from '@angular/core';
import { MasterService } from '../../../services/master.service';
import { SessionHelper } from '../../../helpers/session-helper';
@Component({
  selector: 'app-get-threshold',
  templateUrl: './get-threshold.component.html',
  styleUrls: ['./get-threshold.component.css']
})
export class GetMarginThresholdComponent implements OnInit {
  public MarginData: any = [];
  public bankData: any;
  public category: any;
  public categoryLength: any;
  public bankLength: any = 0;
  public superAgentList: any = [];
  public selectedAgent: any = '';
  public currencyListDisplay: any = [];
  public currencyListNew: any = [];
  public allCurrencyList: any = [];
  public selectedAgentModel: any = '';
  public bankCodes: any = [];
  public currencyList: Array<any>;
  public planNameFilter: any;
  public marginNotSet: any = false;
  constructor(private _MasterService: MasterService) { }

  ngOnInit() {
    // this.getCategoryAndBanks();
    this.getAllCurrency();
    this.getAgents();
    this.setAgentMarginObj();
  }

  getAgents() {
    this._MasterService.getSuperAgentId().subscribe((res) => {
      let agentList: any = res;
      let agentListDisplay :any = []
      agentList.forEach(element => {
        if (!element.AliasName) {
          element.AliasName = '';
        }
        agentListDisplay.push({ label: element.AliasName + ' ' + element.agentId, Id: element.UserId, value: '' + element.UserId, Name: element.AliasName + ' ' + element.agentId })
      });
      let agentId = SessionHelper.getSession('agentId') ? SessionHelper.getSession('agentId') : ((agentListDisplay[0] && agentListDisplay[0].value) ? agentListDisplay[0].value : '');
      this.selectedAgent = agentId;
      this.selectedAgentModel = agentId;
      this.setAgentMarginObj();
      this.superAgentList = agentListDisplay;
    });
  }

  updateBranch(newValue: any) {
    SessionHelper.setSession('agentId', newValue);
  }
  
  setAgentMarginObj() {
    if (this.selectedAgent) {
      this._MasterService.getAgentMargin(this.selectedAgent).subscribe((data) => {
        const retData: any = data;
        this.currencyList = retData.root.element;
        this.marginNotSet = false;
        this.setDefaults();
      }, (error) => {
        this.marginNotSet = true;
        console.log('can not fetch agent margin details');
      });
    }
  }

  setDefaults(){
    this.currencyList.forEach((currencyEle) => {
      if (!currencyEle.buyCash.perTh) {
        currencyEle.buyCash.perTh = 0;
      }
      if (!currencyEle.buyCash.inrTh) {
        currencyEle.buyCash.inrTh = 0;
      }
      if (!currencyEle.buyDD.perTh) {
        currencyEle.buyDD.perTh = 0;
      }
      if (!currencyEle.buyDD.inrTh) {
        currencyEle.buyDD.inrTh = 0;
      }
      if (!currencyEle.buyPrepaid.perTh) {
        currencyEle.buyPrepaid.perTh = 0;
      }
      if (!currencyEle.buyPrepaid.inrTh) {
        currencyEle.buyPrepaid.inrTh = 0;
      }
      if (!currencyEle.sellCash.perTh) {
        currencyEle.sellCash.perTh = 0;
      }
      if (!currencyEle.sellCash.inrTh) {
        currencyEle.sellCash.inrTh = 0;
      }
      if (!currencyEle.sellPrepaid.perTh) {
        currencyEle.sellPrepaid.perTh = 0;
      }
      if (!currencyEle.sellPrepaid.inrTh) {
        currencyEle.sellPrepaid.inrTh = 0;
      }
    })
  }

  selected($event) {
    this.selectedAgent = $event.value;
    this.setAgentMarginObj();
  }

  getAllCurrency() {
    this._MasterService.AllCurrency().subscribe((res) => {
      let allCurrency: any = res;
      this.allCurrencyList = allCurrency;
    });
  }

}
