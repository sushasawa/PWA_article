
import { Component, OnInit, ViewChild, AfterViewInit, DoCheck } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { MasterService } from '../../../services/master.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare function initAccord(): any;

@Component({
  selector: 'app-set-margin',
  templateUrl: './set-margin.component.html',
  styleUrls: ['./set-margin.component.css']
})
export class SetMarginComponent implements OnInit {
  public categoryLength: any;
  public bankData: any;
  public currentUserEmail: any;
  public currentUserId: any;
  public _primaryComp: any;
  public currencyListNew: any = [];
  public currencyListDisplay: any = [];
  public currencyList: Array<any>;
  public marginSet: Array<any>;
  public bankLength: any = 2;
  public offerSelected: any;
  public selectedAgent: any = '';
  public superAgentList: any = [];
  public planNameFilter: any;
  public allCurrencyList: any = [];
  public category: any = ['A', 'B'];
  public bankCodes: any = [];
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private router: Router) {
    this.currencyListNew = [];
    this.getCategoryAndBanks();
    this.getAgents();
  }

  setAllMargins() {
    this._MasterService.AllCurrency().subscribe((res) => {
      let allCurrency: any = res;
      this.allCurrencyList = allCurrency;
      allCurrency.forEach(element => {
        let categoriesObj: any = [];
        for (let index = 0; index < this.categoryLength; index++) {
          let categoryObj = this.getCategoryA(element.Code, this.category[index].Category);
          categoriesObj.push(categoryObj);
          this.currencyListNew.push(categoryObj);
        }
        this.currencyListDisplay.push(categoriesObj);
      });
    });
  }

  getAgents() {
    this._MasterService.getSuperAgentId().subscribe((res) => {
      let agentList: any = res;
      let agentListDisplay: any = []
      agentList.forEach(element => {
        if (!element.AliasName) {
          element.AliasName = '';
        }
        agentListDisplay.push({ label: element.AliasName + ' ' + element.agentId, Id: element.UserId, value: element.UserId, Name: element.AliasName + ' ' + element.agentId })
      });
      this.superAgentList = agentListDisplay;
    });
  }

  selected($event) {
    this.selectedAgent = $event.value;
    this.setAgentMarginObj();
  }

  setAgentMarginObj() {
    if (this.selectedAgent) {
      this._MasterService.getMarginAll(this.selectedAgent).subscribe((res) => {
        let marginSets: any = res;
        let currencyListDisplay: any = [], currencyListNew: any = [];
        this.allCurrencyList.forEach(element => {
          let currCurrencyMargin = marginSets.filter((marginElement) => {
            return marginElement.CurrencyCode == element.Code;
          });
          if (currCurrencyMargin.length > 0) {
            let firstElement: any = currCurrencyMargin[0];
            firstElement.banks = currCurrencyMargin;
            let categoriesObj: any = [];
            for (let index = 0; index < this.categoryLength; index++) {
              let categoryObj = this.getCategoryAContent(firstElement, this.category[index].Category);
              categoriesObj.push(categoryObj);
              currencyListNew.push(categoryObj);
            }
            currencyListDisplay.push(categoriesObj);
          } else {
            let categoriesObj: any = [];
            for (let index = 0; index < this.categoryLength; index++) {
              let categoryObj = this.getCategoryA(element.Code, this.category[index].Category);
              categoriesObj.push(categoryObj);
              currencyListNew.push(categoryObj);
            }
            currencyListDisplay.push(categoriesObj);
          }
        });
        this.currencyListDisplay = currencyListDisplay;
        this.currencyListNew = currencyListNew;
      });
    }
  }

  getCategoryAndBanks() {
    this._MasterService.getCategoryBankData()
      .subscribe(data => {
        let result: any = data;
        this.bankData = result[0];
        this.bankData.forEach(bank => {
          this.bankCodes.push(bank.CustomerCode);
        })
        this.bankLength = this.bankData.length;
        this.category = result[1];
        this.categoryLength = this.category.length;
        this.setAllMargins();
      });
  }

  ngOnInit() {
    setTimeout(function () {
      initAccord();
    }, 200);
  }

  submitMargins() {
    if (!this.selectedAgent) {
      // alert("Please select agents to whom rate margin to be applied.")
      Snackbar.show({
        text: "Please select agents to whom rate margin to be applied.",
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    let marginObj = {
      agentIdArray: [this.selectedAgent],
      agentConfigArray: this.currencyListNew
    }
    console.log(marginObj)
    this._MasterService.setMargin(marginObj)
      .subscribe((res) => {
        if (res[0] && res[0].status) {
          Snackbar.show({
            text: "Submitted Successfully.",
            pos: 'bottom-right',
            actionTextColor: '#05ff01',
          });
        }
      });
  }

  clickedCurrencyList() {
    if (!this.selectedAgent) {
      Snackbar.show({
        text: "Please select agent from dropdown before adding rate margin details.",
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }
  }

  isNumberKeyWithDecimals(registrationInfo, value: any, index) {
    let oldValue,
      patt,
      res;
    oldValue = registrationInfo[index];
    value = value.toString();
    patt = new RegExp("^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$");
    res = patt.test(value);
    if (!res && value !== '') {
      setTimeout(() => {
        registrationInfo[index] = oldValue;
      }, 0);
    }
  }

  setDefaultZero(registrationInfo, index) {
    if (registrationInfo[index] === '' || registrationInfo[index] === '.') {
      registrationInfo[index] = 0;
    }
  }

  getCategoryA(currencyName, category) {
    let objStucture = {
      "Category": category,
      "CurrencyCode": currencyName,
      "CashConfig": {
        "Cash_Buy_IBR_GreaterThan_Holding_Type": 2,
        "Cash_Buy_IBR_GreaterThan_Holding_Value": 0,
        "Cash_Buy_IBR_SmallerThan_Holding_Type": 2,
        "Cash_Buy_IBR_SmallerThan_Holding_Value": 0,
        "Cash_Sell_Type": 2,
        "Cash_Sell_Value": 0
      },
      "PrepaidConfig": [],
      "TTConfig": {
        "TT_Buy_Type": 2,
        "TT_Buy_Value": 0
      }
    };
    objStucture.PrepaidConfig = [];
    this.bankData.forEach((element) => {
      let bankObj = {
        "Issuer": element.CustomerCode,
        "Prepaid_Buy_Type": 2,
        "Prepaid_Buy_Value": 0,
        "Prepaid_Sell_Type": 2,
        "Prepaid_Sell_Value": 0
      }
      objStucture.PrepaidConfig.push(bankObj);
    });
    return objStucture;
  }

  getCategoryAContent(currencyMarginObj, Category) {
    let objStucture;
    currencyMarginObj.banks.forEach((element) => {
      if (element.Category == Category) {
        objStucture = {
          "Category": Category,
          "CurrencyCode": element.CurrencyCode,
          "CashConfig": {
            "Cash_Buy_IBR_GreaterThan_Holding_Type": element.Cash_Buy_I_GT_H_Type,
            "Cash_Buy_IBR_GreaterThan_Holding_Value": element.Cash_Buy_I_GT_H_Value,
            "Cash_Buy_IBR_SmallerThan_Holding_Type": element.Cash_Buy_I_ST_H_Type,
            "Cash_Buy_IBR_SmallerThan_Holding_Value": element.Cash_Buy_I_ST_H_Value,
            "Cash_Sell_Type": element.Cash_Sell_Type,
            "Cash_Sell_Value": element.Cash_Sell_Value
          },
          "PrepaidConfig": [],
          "TTConfig": {
            "TT_Buy_Type": element.TT_Buy_Type,
            "TT_Buy_Value": element.TT_Buy_Value
          }
        }
      }
    });
    objStucture.PrepaidConfig = [];
    currencyMarginObj.banks.forEach((element) => {
      let codeIndex = this.bankCodes.indexOf(element.CustomerCode);
      if (element.Category == Category && this.bankCodes.indexOf(element.CustomerCode) > -1) {
        let bankObj = {
          "Issuer": element.CustomerCode,
          "Prepaid_Buy_Type": element.Prepaid_Buy_Type,
          "Prepaid_Buy_Value": element.Prepaid_Buy_Value,
          "Prepaid_Sell_Type": element.Prepaid_Sell_Type,
          "Prepaid_Sell_Value": element.Prepaid_Sell_Value
        }
        objStucture.PrepaidConfig[codeIndex] = bankObj;
      }
    });
    for (let i = 0; i < this.bankCodes.length; i++) {
      if (!objStucture.PrepaidConfig[i]) {
        objStucture.PrepaidConfig[i] = {
          "Issuer": this.bankCodes[i],
          "Prepaid_Buy_Type": '2',
          "Prepaid_Buy_Value": 0,
          "Prepaid_Sell_Type": '2',
          "Prepaid_Sell_Value": 0
        }
      }
    }
    return objStucture;
  }



  setCurrencyList(rateMargins) {
    let newMarginArr: any = [], currencyNameDone: any = [], currCurrencyArr;
    if (rateMargins && rateMargins.length > 0) {
      rateMargins.forEach(currencyMarginObj => {
        currCurrencyArr = [];
        let currCurrency = currencyMarginObj.CurrencyCode;
        if (currencyNameDone.indexOf(currCurrency) == -1) {
          rateMargins.forEach(currencyMarginObj2 => {
            if (currencyMarginObj2.CurrencyCode === currCurrency) {
              currCurrencyArr.push(currencyMarginObj2);
            }
          });
          newMarginArr.push(currCurrencyArr);
          currencyNameDone.push(currCurrency);
        }
      });
    }
  }

}
