import { Component, OnInit } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Constants } from '../../../helpers/constants';

// import { AuthenticationService, User } from '../../../services/authentication.service';
import { MasterService } from '../../../services/master.service';

import { SessionHelper } from '../../../helpers/session-helper';
import { jsonpCallbackContext } from '@angular/common/http/src/module';


@Component({
  selector: 'app-agent-margin',
  templateUrl: './agent-margin.component.html',
  styleUrls: ['./agent-margin.component.css']
})
export class AgentMarginComponent implements OnInit {
  public resData: any;
  public currentSelectedPage: any = 'viewTh';
  public tabs: any = ['viewTh', 'setTh'];
  constructor(private masterService: MasterService, private http: HttpClient, private route: ActivatedRoute,
    private router: Router) {
    // this._authservice.checkCredentials();
  }


  ngOnInit() {
    if (this.tabs.indexOf(this.route.snapshot.fragment) != -1) {
      this.currentSelectedPage = this.route.snapshot.fragment;
    } else {
      this.currentSelectedPage = 'viewTh';
    }
  }

  logout() {
    // this._authservice.logout();
  }

  selectPage(value) {
    this.currentSelectedPage = value;
    this.router.navigate(['/layout/margin/agentMargin'], { fragment: value });
  }

}
