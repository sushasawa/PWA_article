
import { Component, OnInit, ViewChild, AfterViewInit, DoCheck } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { MasterService } from '../../../services/master.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare function initAccord(): any;

@Component({
  selector: 'app-set-threshold',
  templateUrl: './set-threshold.component.html',
  styleUrls: ['./set-threshold.component.css']
})
export class SetMarginThresholdComponent implements OnInit {
  public categoryLength: any;
  public bankData: any;
  public currentUserEmail: any;
  public currentUserId: any;
  public _primaryComp: any;
  public currencyListNew: any = [];
  public currencyListDisplay: any = [];
  public currencyList: Array<any>;
  public marginSet: Array<any>;
  public bankLength: any = 2;
  public selectedAgent: any = '';
  public superAgentList: any = [];
  public planNameFilter: any;
  public allCurrencyList: any = [];
  public category: any = ['A', 'B'];
  public bankCodes: any = [];
  public offerSelected: any;
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private router: Router) {
    this.currencyListNew = [];
    this.getAgents();
  }

  getAgents() {
    this._MasterService.getSuperAgentId().subscribe((res) => {
      let agentList: any = res;
      let agentListDisplay: any = []
      agentList.forEach(element => {
        if (!element.AliasName) {
          element.AliasName = '';
        }
        agentListDisplay.push({ label: element.AliasName + ' ' + element.agentId, Id: element.UserId, value: element.UserId, Name: element.AliasName + ' ' + element.agentId })
      });
      this.superAgentList = agentListDisplay;
      this.getCurrencyList();
    });
  }

  selected($event) {
    this.selectedAgent = $event.value;
    this.getCurrencyList();
  }

  ngOnInit() {
    setTimeout(function () {
      initAccord();
    }, 200);
  }

  getCurrencyList() {
    this._MasterService.getAgentMargin(this.selectedAgent).subscribe((data) => {
      const retData: any = data;
      this.currencyList = retData.root.element;
      this.setDefaults();
    }, (error) => {
      this._MasterService.AllCurrency().subscribe((res) => {
        const currancyListArray: any = [];
        const resultData: any = res;
        resultData.forEach(e => {
          const CurrencyJson = {
            "buyCash": {
              "perTh": 0,
              "inrTh": 0,
              'type': '2',
              'value': 0
            },
            "buyDD": {
              "perTh": 0,
              "inrTh": 0,
              'type': '2',
              'value': 0
            },
            "buyPrepaid": {
              "perTh": 0,
              "inrTh": 0,
              'type': '2',
              'value': 0
            },
            "currencyName": e.Code,
            "sellCash": {
              "perTh": 0,
              "inrTh": 0,
              'type': '2',
              'value': 0
            },
            "sellPrepaid": {
              "perTh": 0,
              "inrTh": 0,
              'type': '2',
              'value': 0
            }
          };
          // console.log(CurrencyJson);
          currancyListArray.push(CurrencyJson);
        });
        this.currencyList = currancyListArray;
      });
    });
  }

  setDefaults() {
    this.currencyList.forEach((currencyEle) => {
      if (!currencyEle.buyCash.perTh) {
        currencyEle.buyCash.perTh = 0;
      }
      if (!currencyEle.buyCash.inrTh) {
        currencyEle.buyCash.inrTh = 0;
      }
      if (!currencyEle.buyDD.perTh) {
        currencyEle.buyDD.perTh = 0;
      }
      if (!currencyEle.buyDD.inrTh) {
        currencyEle.buyDD.inrTh = 0;
      }
      if (!currencyEle.buyPrepaid.perTh) {
        currencyEle.buyPrepaid.perTh = 0;
      }
      if (!currencyEle.buyPrepaid.inrTh) {
        currencyEle.buyPrepaid.inrTh = 0;
      }
      if (!currencyEle.sellCash.perTh) {
        currencyEle.sellCash.perTh = 0;
      }
      if (!currencyEle.sellCash.inrTh) {
        currencyEle.sellCash.inrTh = 0;
      }
      if (!currencyEle.sellPrepaid.perTh) {
        currencyEle.sellPrepaid.perTh = 0;
      }
      if (!currencyEle.sellPrepaid.inrTh) {
        currencyEle.sellPrepaid.inrTh = 0;
      }
    })
  }

  submitMargins() {
    this.saveMargin();
  }

  saveMargin() {
    if (!this.selectedAgent) {
      Snackbar.show({
        text: "Please select agents to whom rate margin threshold to be applied.",
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    const elementArray: any = [];
    this.currencyList.forEach(element => {
      elementArray.push(element);
    });

    const payload = {
      'agentId': this.selectedAgent,
      'xml': { 'element': elementArray }
    };

    this._MasterService.setAgentMargin(payload).subscribe((data) => {
      Snackbar.show({
        text: 'Margin set successfully.',
        pos: 'bottom-right',
        actionTextColor: '#00880d',
      });
      console.log(data);
    }, (err) => {
      console.log('Something went wrong.');
    });

  }

  clickedCurrencyList() {
    if (!this.selectedAgent) {
      Snackbar.show({
        text: "Please select agent from dropdown before adding rate margin threshold details.",
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }
  }

  isNumberKeyWithDecimals(registrationInfo, value: any, index) {
    let oldValue,
      patt,
      res;
    oldValue = registrationInfo[index];
    value = value.toString();
    patt = new RegExp("^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$");
    res = patt.test(value);
    if (!res && value !== '') {
      setTimeout(() => {
        registrationInfo[index] = oldValue;
      }, 0);
    }
  }

  setDefaultZero(registrationInfo, index) {
    if (registrationInfo[index] === '' || registrationInfo[index] === '.') {
      registrationInfo[index] = 0;
    }
  }




  setCurrencyList(rateMargins) {
    let newMarginArr: any = [], currencyNameDone: any = [], currCurrencyArr;
    if (rateMargins && rateMargins.length > 0) {
      rateMargins.forEach(currencyMarginObj => {
        currCurrencyArr = [];
        let currCurrency = currencyMarginObj.CurrencyCode;
        if (currencyNameDone.indexOf(currCurrency) == -1) {
          rateMargins.forEach(currencyMarginObj2 => {
            if (currencyMarginObj2.CurrencyCode === currCurrency) {
              currCurrencyArr.push(currencyMarginObj2);
            }
          });
          newMarginArr.push(currCurrencyArr);
          currencyNameDone.push(currCurrency);
        }
      });
    }
  }

}
