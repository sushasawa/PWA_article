import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetMarginComponent } from './get-margin.component';

describe('GetMarginComponent', () => {
  let component: GetMarginComponent;
  let fixture: ComponentFixture<GetMarginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetMarginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetMarginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
