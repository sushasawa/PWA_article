import { Component, OnInit } from '@angular/core';
import { MasterService } from '../../../services/master.service';
import { SessionHelper } from '../../../helpers/session-helper';
@Component({
  selector: 'app-get-margin',
  templateUrl: './get-margin.component.html',
  styleUrls: ['./get-margin.component.css']
})
export class GetMarginComponent implements OnInit {
  public MarginData: any = [];
  public bankData: any;
  public category: any;
  public categoryLength: any;
  public bankLength: any = 0;
  public superAgentList: any = [];
  public selectedAgent: any = '';
  public currencyListDisplay: any = [];
  public currencyListNew: any = [];
  public allCurrencyList: any = [];
  public selectedAgentModel: any = '';
  public bankCodes: any = [];
  public planNameFilter: any;
  public marginNotSet: any = false;
  constructor(private _MasterService: MasterService) { }

  ngOnInit() {
    this.getCategoryAndBanks();
    this.getAllCurrency();
    this.getAgents();
    this.setAgentMarginObj();
  }

  getAgents() {
    this._MasterService.getSuperAgentId().subscribe((res) => {
      let agentList: any = res;
      let agentListDisplay :any = []
      agentList.forEach(element => {
        if (!element.AliasName) {
          element.AliasName = '';
        }
        agentListDisplay.push({ label: element.AliasName + ' ' + element.agentId, Id: element.UserId, value: '' + element.UserId, Name: element.AliasName + ' ' + element.agentId })
      });
      let CNKAgentId = SessionHelper.getSession('CNKAgentId') ? SessionHelper.getSession('CNKAgentId') : ((agentListDisplay[0] && agentListDisplay[0].value) ? agentListDisplay[0].value : '');
      this.selectedAgent = CNKAgentId;
      this.selectedAgentModel = CNKAgentId;
      this.setAgentMarginObj();
      this.superAgentList = agentListDisplay;
    });
  }

  updateBranch(newValue: any) {
    SessionHelper.setSession('CNKAgentId', newValue);
  }

  getCategoryAndBanks() {
    this._MasterService.getCategoryBankData()
      .subscribe(data => {
        let result: any = data;
        this.bankData = result[0];
        this.bankLength = this.bankData.length;
        this.bankData.forEach(bank => {
          this.bankCodes.push(bank.CustomerCode);
        })
        this.category = result[1];
        this.categoryLength = this.category.length;
      });
  }
  
  setAgentMarginObj() {
    if (this.selectedAgent) {
      this._MasterService.getMarginAll(this.selectedAgent).subscribe(
        (res) => {
        let marginSets: any = res;
        this.marginNotSet = false;
        if(marginSets.length == 0){
          this.marginNotSet = true;
        }
        let currencyListDisplay = [], currencyListNew = [];
        this.allCurrencyList.forEach(element => {
          let currCurrencyMargin = marginSets.filter((marginElement) => {
            return marginElement.CurrencyCode == element.Code;
          });
          if (currCurrencyMargin.length > 0) {
            let firstElement: any = currCurrencyMargin[0];
            firstElement.banks = currCurrencyMargin;
            let categoriesObj = [];
            for(let index = 0; index < this.categoryLength; index++){
              let categoryObj = this.getCategoryAContent(firstElement, this.category[index].Category);
              categoriesObj.push(categoryObj);
            }
            currencyListDisplay.push(categoriesObj);
          }
        });        
        this.currencyListDisplay = currencyListDisplay;
        this.currencyListNew = currencyListNew;
      }, (error) => {
        console.log('can not fetch agent margin details')
      });
    }
  }

  selected($event) {
    this.selectedAgent = $event.value;
    this.setAgentMarginObj();
  }

  getAllCurrency() {
    this._MasterService.AllCurrency().subscribe((res) => {
      let allCurrency: any = res;
      this.allCurrencyList = allCurrency;
    });
  }

  getCategoryAContent(currencyMarginObj, Category) {
    let objStucture;
    currencyMarginObj.banks.forEach((element) => {      
      if (element.Category == Category) {
        objStucture = {
          "Category": Category,
          "CurrencyCode": element.CurrencyCode,
          "CashConfig": {
            "Cash_Buy_IBR_GreaterThan_Holding_Type": element.Cash_Buy_I_GT_H_Type,
            "Cash_Buy_IBR_GreaterThan_Holding_Value": element.Cash_Buy_I_GT_H_Value,
            "Cash_Buy_IBR_SmallerThan_Holding_Type": element.Cash_Buy_I_ST_H_Type,
            "Cash_Buy_IBR_SmallerThan_Holding_Value": element.Cash_Buy_I_ST_H_Value,
            "Cash_Sell_Type": element.Cash_Sell_Type,
            "Cash_Sell_Value": element.Cash_Sell_Value
          },
          "PrepaidConfig": [],
          "TTConfig": {
            "TT_Buy_Type": element.TT_Buy_Type,
            "TT_Buy_Value": element.TT_Buy_Value
          }
        }
      }
    });
    objStucture.PrepaidConfig = [];
    currencyMarginObj.banks.forEach((element) => {
      let codeIndex = this.bankCodes.indexOf(element.CustomerCode);
      if (element.Category == Category && this.bankCodes.indexOf(element.CustomerCode) > -1) {
        let bankObj = {
          "Issuer": element.CustomerCode,
          "Prepaid_Buy_Type": element.Prepaid_Buy_Type,
          "Prepaid_Buy_Value": element.Prepaid_Buy_Value,
          "Prepaid_Sell_Type": element.Prepaid_Sell_Type,
          "Prepaid_Sell_Value": element.Prepaid_Sell_Value
        }
        objStucture.PrepaidConfig[codeIndex] = bankObj;
      }
    });
    for (let i = 0; i < this.bankCodes.length; i++) {
      if (!objStucture.PrepaidConfig[i]) {
        objStucture.PrepaidConfig[i] = {
          "Issuer": '',
          "Prepaid_Buy_Type": '',
          "Prepaid_Buy_Value": 0,
          "Prepaid_Sell_Type": '',
          "Prepaid_Sell_Value": 0
        }
      }
    }
    return objStucture;
  }
}
