import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes} from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { DataTableModule } from 'angular2-datatable';
import { SelectModule } from 'ng-select';
import { DpDatePickerModule} from 'ng2-date-picker';

import { MasterService } from '../../services/master.service';
// import { AuthenticationService } from '../../services/authentication.service';

import { PipesModule } from '../../pipes/pipes.module';
import { PageHeaderModule } from './../../shared';

import { SetMarginComponent } from './set-margin/set-margin.component';
import { GetMarginComponent } from './get-margin/get-margin.component';
import { MarginComponent } from './margin/margin.component';
import { SetMarginThresholdComponent } from './set-threshold/set-threshold.component';
import { GetMarginThresholdComponent } from './get-threshold/get-threshold.component';
import { AgentMarginComponent } from './agent-margin/agent-margin.component';


const routes: Routes = [
  {
    path: '',
    component: MarginComponent
  },
  {
    path: 'agentMargin',
    component: AgentMarginComponent
  }
];


@NgModule({
  declarations: [SetMarginComponent, GetMarginComponent, MarginComponent, SetMarginThresholdComponent, GetMarginThresholdComponent, AgentMarginComponent],
  imports: [
    CommonModule,
    DataTableModule,
    SelectModule,
    DpDatePickerModule,
    PipesModule,
    PageHeaderModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  providers: []
})
export class MarginModule { }
