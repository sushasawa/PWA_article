import { Component, OnInit } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Constants } from '../../../helpers/constants';

// import { AuthenticationService, User } from '../../../services/authentication.service';
import { MasterService } from '../../../services/master.service';

import { SessionHelper } from '../../../helpers/session-helper';
import { jsonpCallbackContext } from '@angular/common/http/src/module';






@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  filterQuery = '';
  public resData: any;
  public planDisplay: any;
  public timeInterval: any;
  public allResData: any;
  public payStatus: any = 'All';
  public searchTransaction: any = '';

  constructor(private masterService: MasterService, private http: HttpClient, private route: ActivatedRoute,
    private router: Router) { // , private _authservice: AuthenticationService
    // this._authservice.checkCredentials();
    this.planDisplay = [
      { value: 'Successful', label: 'Successful' },
      { value: 'Pending', label: 'Pending' },
      { value: 'All', label: 'All' }
    ];
    this.getAllTransactions();
    this.timeInterval = setInterval(() => {
      this.getAllTransactions();
    }, 180000);
  }

  getAllTransactions() {
    const resData = JSON.parse(sessionStorage.getItem('user'));
    this.masterService.TemplateOrderService(resData[0].BranchCode,resData[0].Username)
      .subscribe((data) => {
        let rData: any = data;
        rData = this.processJSON(rData);
        this.resData = rData;
        this.searchTextChanged(void 0);
      });
  }

  processJSON(rData) {
    const rDataLength = rData.length, transactions = {};
    for (let loopVar = 0; loopVar < rDataLength; loopVar++) {
      if (rData[loopVar].IExchangeResponseDataJson) {
        rData[loopVar].IExchangeResponseDataJsonString = rData[loopVar].IExchangeResponseDataJson;
        rData[loopVar].IExchangeResponseDataJson = JSON.parse(rData[loopVar].IExchangeResponseDataJson);

      }
      if (transactions[rData[loopVar].TransactionId]) {
        transactions[rData[loopVar].TransactionId].transactions.push(JSON.parse(JSON.stringify(rData[loopVar])));
      } else {
        transactions[rData[loopVar].TransactionId] = rData[loopVar];
        transactions[rData[loopVar].TransactionId].transactions = [JSON.parse(JSON.stringify(rData[loopVar]))];
      }
    }
    rData = Object.keys(transactions).map((key) => transactions[key]);
    this.allResData = JSON.parse(JSON.stringify(rData));
    return rData;
  }

  filterSelectedPayStatus() {
    const event = this.payStatus;
    this.resData = this.allResData.filter(transaction => {
      if (event === 'All') {
        return true;
      }
      if (event === 'Successful' && (transaction.OrderStatus !== '0' || transaction.Operation === 'sell')) {
        return true;
      }
      if (event === 'Pending' && (transaction.OrderStatus === '0' && transaction.Operation !== 'sell')) {
        return true;
      }
      return false;
    });

  }

  searchTextChanged(event) {
    this.filterSelectedPayStatus();
    // if (!event) {
    //   console.log('not found', this.searchTransaction)
    //   event = this.searchTransaction;
    // }
    if (event) {
      event = event.toLowerCase();
      this.resData = this.resData.filter(it => {
        const matchAgents = [];
        if ((it.TransactionId && it.TransactionId.toLowerCase().includes(event))
          || (it.Date && it.Date.toLowerCase().includes(event))
          || (it.Operation && it.Operation.toLowerCase().includes(event))
          || (it.BranchCode && it.BranchCode.toLowerCase().includes(event))) {
          return true;
        }
        it.transactions.forEach(transaction => {
          if (transaction.OrderID.toLowerCase().includes(event)
            || transaction.CustomerName.toLowerCase().includes(event)
            || transaction.TotalAmount.toLowerCase().includes(event)) {
            matchAgents.push(true);
          } else {
            matchAgents.push(false);
          }
        });
        if (matchAgents.indexOf(true) !== -1) {
          return true;
        }
        return false;
      });
    }
    // else {
    //   this.resData = this.resData.filter(it => {
    //     return true;
    //   });
    // }
  }

  clickFunction(value, type) {
    // this.router.navigateByUrl('/admin-panel/details');
    // this.router.navigateByUrl('/TranDetail/' + value);
    SessionHelper.setSession('transactionType', type);

    this.masterService.TemplateOrderDetailService(value)
      .subscribe((data) => {
        const resData = data;
        if (resData[1][0].url) {
          SessionHelper.setSession('invoiceUrl', resData[1][0].url);
        } else {
          SessionHelper.removeSession('invoiceUrl');
        }
        if (type === 'buy') {
          SessionHelper.setSession('userSessionInfo', resData[1][0].UserSessionJson);
          // this.router.navigateByUrl('/buy');
        } else if (type === 'sell') {
          SessionHelper.setSession('userSessionInfoSale', resData[1][0].UserSessionJson);
          // this.router.navigateByUrl('/sell');
        } else if (type === 'reload') {
          SessionHelper.setSession('userSessionInfoRealoadCard', resData[1][0].UserSessionJson);
          // this.router.navigateByUrl('/reload-card');
        } else if (type === 'send') {
          SessionHelper.setSession('userSessionInfoSend', resData[1][0].UserSessionJson);
          // this.router.navigateByUrl('/send-money');
        }
        this.router.navigateByUrl('/layout/transaction/Detail');
      });

  }

  ngOnInit() { }

  logout() {
    // this._authservice.logout();
  }

  ngOnDestroy() {
    clearInterval(this.timeInterval);
  }

}
