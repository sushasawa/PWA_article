import { Component, OnInit } from '@angular/core';
import { SessionHelper } from '../../../helpers/session-helper';
// import { AuthenticationService, User } from '../../../app/authentication.service';
import { MasterService } from '../../../services/master.service';
declare function initDocument(): any;
declare function initForms(): any;
declare var $: any;
declare var Snackbar: any;

@Component({
  selector: 'app-transaction-details',
  templateUrl: './transaction-details.component.html',
  styleUrls: ['./transaction-details.component.css']
})
export class TransactionDetailsComponent implements OnInit {

  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public userSessionInfoScreen: any;
  public currentTravellerIndex: any;
  public selIndex: any;
  public transactionType: any;
  public processType: any;
  public destination: any;
  public branchName: any;
  public invoiceUrl: any;
  public exchangeRates: any = {};
  public travellerOfficeAddress: any = [];
  constructor(private masterService: MasterService) {  // , private _authservice: AuthenticationService
    // console.log(SessionHelper.getSession('userSessionInfo'));

    this.transactionType = SessionHelper.getSession('transactionType');
    console.log(SessionHelper.getSession('invoiceUrl'));
    if (SessionHelper.getSession('invoiceUrl') && SessionHelper.getSession('invoiceUrl') !== 'null') {
      this.invoiceUrl = 'http://forex.coxandkings.com:8081/' + SessionHelper.getSession('invoiceUrl');
    } else {
      this.invoiceUrl = '';
    }

    switch (this.transactionType) {
      case 'buy':
        this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfo'));
        this.userSessionInfoRegistration = this.userSessionInfo.buyScreen.traveller[0].registrationInfo;
        this.userSessionInfoTravellingDetails = this.userSessionInfo.buyScreen.traveller[0].travellingDetails;
        this.userSessionInfoTravellers = this.userSessionInfo.buyScreen.traveller;
        this.userSessionInfoSelectedTraveller = this.userSessionInfo.buyScreen.traveller[0];
        this.userSessionInfoScreen = this.userSessionInfo.buyScreen;
        this.processType = 'Buy';
        break;
      case 'sell':
        this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSale'));
        this.userSessionInfoRegistration = this.userSessionInfo.sellScreen.traveller[0].registrationInfo;
        this.userSessionInfoTravellingDetails = this.userSessionInfo.sellScreen.traveller[0].travellingDetails;
        this.userSessionInfoTravellers = this.userSessionInfo.sellScreen.traveller;
        this.userSessionInfoSelectedTraveller = this.userSessionInfo.sellScreen.traveller[0];
        this.userSessionInfoScreen = this.userSessionInfo.sellScreen;
        this.processType = 'Sell';
        this.setExchange();
        break;
      case 'send':
        this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSend'));
        this.userSessionInfoRegistration = this.userSessionInfo.sendMoneyScreen.traveller[0].registrationInfo;
        this.userSessionInfoTravellingDetails = this.userSessionInfo.sendMoneyScreen.traveller[0].travellingDetails;
        this.userSessionInfoTravellers = this.userSessionInfo.sendMoneyScreen.traveller;
        this.userSessionInfoSelectedTraveller = this.userSessionInfo.sendMoneyScreen.traveller[0];
        this.userSessionInfoScreen = this.userSessionInfo.sendMoneyScreen;
        this.processType = 'Send';
        break;
      case 'reload':
        this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoRealoadCard'));
        this.userSessionInfoRegistration = this.userSessionInfo.reloadCardScreen.traveller[0].registrationInfo;
        this.userSessionInfoTravellingDetails = this.userSessionInfo.reloadCardScreen.traveller[0].travellingDetails;
        this.userSessionInfoTravellers = this.userSessionInfo.reloadCardScreen.traveller;
        this.userSessionInfoSelectedTraveller = this.userSessionInfo.reloadCardScreen.traveller[0];
        this.userSessionInfoScreen = this.userSessionInfo.reloadCardScreen;
        this.processType = 'Reload';
        break;
      default:
        break;
    }
    this.setDestination();
    this.concatOfficeAddress();
    this.getBranchDetails(this.userSessionInfoScreen.branch);
    this.userSessionInfoTravellers[0].selected = true;
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];
    this.currentTravellerIndex = 0;
  }

  getBranchDetails(newValue) {
    this.masterService.getBranchDetails(newValue)
      .subscribe(data => {
        const BranchDetails: any = data;
        this.branchName = BranchDetails[0].BranchName;
      });
  }

  setDestination() {
    if (this.userSessionInfoScreen.destination) {
      this.destination = this.userSessionInfoScreen.destination.split('#')[1];
    }
  }

  ngOnInit() {
    initDocument();
    initForms();
    $('body').attr('id', '');
  }

  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.currentTravellerIndex = travellerIndex;
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }

  setExchange() {
    this.userSessionInfo.sellScreen.traveller.forEach((traveller) => {
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.forEach((prepaidCard) => {
          this.exchangeRates[prepaidCard.currencyCode] = prepaidCard.exchangeRate.rate;
        });
      }
    });
  }

  logout() {
    // this._authservice.logout();
  }

  concatOfficeAddress() {
    const nonAdressParam = ['conpanyName', 'companyName', 'designation', 'companyDivision', 'pincode'];
    this.travellerOfficeAddress = [];
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      let addressText = '', officeAddress = traveller.registrationInfo.officeAddress, counter = 0, pincodeAdded = false;
      for (const travellerData in officeAddress) {
        if (nonAdressParam.indexOf(travellerData) === -1 && officeAddress[travellerData]) {
          addressText += officeAddress[travellerData] + ', ';
          counter++;
        }
        if (travellerData === 'pincode' && officeAddress[travellerData]) {
          if (counter > 0) {
            addressText = this.replaceLastCommaWith(addressText, '-') + officeAddress[travellerData];
          } else {
            addressText += officeAddress[travellerData];
          }
          pincodeAdded = true;
        }
      }
      if ((counter > 0 && pincodeAdded) || pincodeAdded) {
        addressText += '.';
      } else if (counter > 0) {
        addressText += this.replaceLastCommaWith(addressText, '.');
      }
      this.travellerOfficeAddress[index] = addressText;
    });
  }

  replaceLastCommaWith(text, element) {
    const pos = text.lastIndexOf(',');
    return text.substring(0, pos) + ' ' + element + ' ' + text.substring(pos + 1);
  }
}
