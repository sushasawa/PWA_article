import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { RouterModule, Routes} from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { DataTableModule } from 'angular2-datatable';
import { SelectModule } from 'ng-select';
import { DpDatePickerModule} from 'ng2-date-picker';

import { MasterService } from '../../services/master.service';
// import { AuthenticationService } from '../../services/authentication.service';

import { PipesModule } from '../../pipes/pipes.module';
import { PageHeaderModule } from './../../shared';
import { EnquiryDetailsComponent } from './enquiry-details/enquiry-details.component';

const routes: Routes = [
  {
    path: '',
    component: EnquiryComponent
  }, {
    path: 'Detail',
    component: EnquiryDetailsComponent
  }
];


@NgModule({
  declarations: [EnquiryComponent, EnquiryDetailsComponent],
  imports: [
    CommonModule,
    DataTableModule,
    SelectModule,
    DpDatePickerModule,
    PipesModule,
    PageHeaderModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  providers: [] // AuthenticationService
})
export class EnquiryModule { }






// import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { TransactionComponent } from './transaction/transaction.component';
// import { RouterModule, Routes} from '@angular/router';






// const routes: Routes = [
//   {
//     path: '',
//     component: TransactionComponent
//   }
// ];


// @NgModule({
//   declarations: [TransactionComponent],
//   imports: [
//     CommonModule,

//     RouterModule.forChild(routes)
//   ],
//   providers: []
// })
// export class TransactionModule { }
