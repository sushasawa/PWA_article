import { Component, OnInit } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Constants } from '../../../helpers/constants';

// import { AuthenticationService, User } from '../../../services/authentication.service';
import { MasterService } from '../../../services/master.service';

import { SessionHelper } from '../../../helpers/session-helper';
import { jsonpCallbackContext } from '@angular/common/http/src/module';






@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.css']
})
export class EnquiryComponent implements OnInit {

  filterQuery = '';
  public resData: any;
  public planDisplay: any;
  public timeInterval: any;
  public allResData: any;
  public payStatus: any = 'All';
  public branchList: any = '';
  public selectedbranch: any = '';
  public searchTransaction: any = '';
  public adminBranchCode: any;
  public showBranchSelection: any = false;
  constructor(private masterService: MasterService, private http: HttpClient, private route: ActivatedRoute,
    private router: Router) {
    this.planDisplay = [
      { value: 'Successful', label: 'Successful' },
      { value: 'Pending', label: 'Pending' },
      { value: 'All', label: 'All' }
    ];
    this.branchList = this.getBranchList();
    this.getAllTransactions();
    this.timeInterval = setInterval(() => {
      this.getAllTransactions();
    }, 900000);
  }

  getAllTransactions() {
    const resData = JSON.parse(sessionStorage.getItem('user'));
    this.adminBranchCode = resData[0].BranchCode;

    this.masterService.GetAllEnquiries(resData[0].BranchCode)
      .subscribe((data) => {
        let rData: any = data;
        rData = this.processJSON(rData);
        this.resData = rData;
        this.searchTextChanged(void 0);
      });
    if (this.adminBranchCode == Constants.getAllBranchCode()) {
      this.showBranchSelection = true;
    }
  }

  processJSON(rData) {
    this.allResData = JSON.parse(JSON.stringify(rData));
    return rData;
  }

  filterSelectedBranch() {
    const event = this.selectedbranch;
    this.resData = this.allResData.filter(item => {
      if (!this.selectedbranch || this.selectedbranch == 'ALL') {
        return true;
      }
      if (this.selectedbranch === item.Data.branch.branchCode) {
        return true;
      }
      return false;
    });
  }

  searchTextChanged(event) {
    this.filterSelectedBranch();
    if (event) {
      this.resData = this.resData.filter(item => {
        if ((item.Data.applicationType && item.Data.applicationType.toLowerCase().includes(event))
          || (item.Data.city && item.Data.city.toLowerCase().includes(event))
          || (item.Data.branch.branchCode && item.Data.branch.branchCode.toLowerCase().includes(event))
          || (item.Data.countryToVisit && item.Data.countryToVisit.toLowerCase().includes(event))
          || (item.Data.currency.currencyCode && item.Data.currency.currencyCode.toLowerCase().includes(event))
          || (item.Data.name && item.Data.name.toLowerCase().includes(event))
          || (item.Data.mobileNumber && item.Data.mobileNumber.toLowerCase().includes(event))
          || (item.Data.amount && item.Data.amount.toLowerCase().includes(event))) {
          return true;
        }
        return false;
      });
    }
    else {
      this.resData = this.resData.filter(it => {
        return true;
      });
    }
  }

  clickFunction(index) {
    SessionHelper.setSession('enquiryDetails', JSON.stringify(this.resData[index]));
    this.router.navigateByUrl('/layout/enquiry/Detail');
  }

  ngOnInit() { }

  logout() {
    // this._authservice.logout();
  }

  ngOnDestroy() {
    // clearInterval(this.timeInterval);
  }

  getBranchList() {
    return [
      { value: 'ALL', label: 'ALL' },
      { value: 'GJ0001', label: 'Ambawadi, Ahmedabad - GJ0001' },
      { value: 'TN1001', label: 'Annanagar, Chennai - TN1001' },
      { value: 'KA0001', label: 'Banglore - KA0001' },
      { value: 'GJ1003', label: 'Bodakdev, Ahmedabad - GJ1003' },
      { value: 'TN0001', label: 'Chennai - TN0001' },
      { value: 'DL0001', label: 'Connaught Place, Delhi - DL0001' },
      { value: 'HR0001', label: 'Gurgaon (Gurugram), Delhi - HR0001' },
      { value: 'HR1003', label: 'Gurgaon, Sushant Lok - HR1003' },
      { value: 'TS1001', label: 'Hitech City, Hyderabad - TS1001' },
      { value: 'TS0001', label: 'Hyderabad - TS0001' },
      { value: 'MH1001', label: 'J.B. Nagar, Mumbai - MH1001' },
      { value: 'KA1004', label: 'Jayanagar, Chennai - KA1004' },
      { value: 'MH1010', label: 'Kandivali, Mumbai - MH1010' },
      { value: 'KA1005', label: 'Koramangala, Bangalore - KA1005' },
      { value: 'DL1007', label: 'Laxmi Nagar, Delhi - DL1007' },
      { value: 'KA1006', label: 'Malleswaram, Bangalore - KA1006' },
      { value: 'MH1032', label: 'Opera House, Mumbai - MH1032' },
      { value: 'DL1004', label: 'Pitampura, Delhi - DL1004' },
      { value: 'MH1021', label: 'Prabhat Rd, Pune - MH1021' },
      { value: 'DL1005', label: 'Rajouri Garden, Delhi - DL1005' },
      { value: 'WB0001', label: 'Russell Street, Kolkata - WB0001' },
      { value: 'WB1004', label: 'Salt Lake, Kolkata - WB1004' },
      { value: 'MH1024', label: 'Thane, Mumbai - MH1024' },
      { value: 'MH0001', label: 'Turner Morrison, Mumbai - MH0001' },
      { value: 'MH0002', label: 'Vaman Building, Mumbai - MH0002' },
      { value: 'MH1027', label: 'Wanowrie, Pune - MH1027' },
      { value: 'Others', label: 'Others' },
    ];
  }

}
