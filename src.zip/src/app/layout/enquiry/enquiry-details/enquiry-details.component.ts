import { Component, OnInit } from '@angular/core';
import { SessionHelper } from '../../../helpers/session-helper';
// import { AuthenticationService, User } from '../../../app/authentication.service';
import { MasterService } from '../../../services/master.service';
declare function initDocument(): any;
declare function initForms(): any;
declare var $: any;
declare var Snackbar: any;

@Component({
  selector: 'app-enquiry-details',
  templateUrl: './enquiry-details.component.html',
  styleUrls: ['./enquiry-details.component.css']
})
export class EnquiryDetailsComponent {

  public enquiryDetails: any;
  public selIndex: any;
  public transactionType: any;
  public processType: any;
  public destination: any;
  public branchName: any;
  public invoiceUrl: any;
  public exchangeRates: any = {};
  public travellerOfficeAddress: any = [];
  constructor(private masterService: MasterService) {
    if(SessionHelper.getSession('enquiryDetails')) {
      this.enquiryDetails = JSON.parse(SessionHelper.getSession('enquiryDetails'));
    }    
  }

  ngOnInit() {
    initDocument();
    initForms();
    $('body').attr('id', '');
  }

  logout() {
    // this._authservice.logout();
  }
}
