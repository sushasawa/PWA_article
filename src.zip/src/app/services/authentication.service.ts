import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constants } from '../helpers/constants';
// import * as sha from 'sha.js';
import { MasterService } from '../services/master.service';

export class User {
    constructor(
        public username: string,
        public password: string) { }
}

// var users = [
//     new User('admin@admin.com', 'admin'),
//     new User('user@gmail.com', 'user')
// ];

@Injectable()
export class AuthenticationService {

    constructor(private http: HttpClient, private masterService: MasterService,
        private _router: Router) { }

    logout() {
        sessionStorage.removeItem('user');
        sessionStorage.removeItem('isLoggedin');
        this._router.navigate(['/']);
    }

    login(user) {
        // const password = sha('sha256').update(user.password, 'utf8').digest('hex');
        const postData = {
            'Username': user.username,
            'Password': user.password,
            'ApplicationName': 'TransactionAdmin'
        };

        this.masterService.AuthenticateStaffService(postData)
        // this.http.post(Constants.AuthenticateStaffService(), postData)
            .subscribe((data) => {
                console.log('data',data);
                const result: any = data;
                if (result[0].Msg.indexOf('Success') !== -1) {
                    sessionStorage.setItem('user', JSON.stringify(result));
                    // this._router.navigate(['/']);
                    this._router.navigate(['/layout/transaction']);
                    sessionStorage.setItem('isLoggedin', 'true');
                    return true;
                }
                return false;
            });

    }

    checkCredentials() {
        if (!sessionStorage.getItem('user')) {
            this._router.navigate(['/login']);
        } else {
            this._router.navigate(['/']);
        }
    }
}
