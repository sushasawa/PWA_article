import { Injectable } from '@angular/core';

import { Constants } from '../../app/helpers/constants';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as moment from 'moment';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class MasterService {
    constructor(private http: HttpClient) { }
    public branchIdFromOverview;
    public turnerMorrisonBranchId = 25;



    TemplateOrderService(value, userName) {
        return this.http.get(Constants.TemplateOrderService(value, userName));
    }

    GetAllEnquiries(BranchCode) {
        if (!BranchCode || BranchCode == Constants.getAllBranchCode()) {
            BranchCode = '';
        }
        return this.http.get(Constants.GetAllEnquiries(BranchCode));
    }

    TemplateOrderDetailService(value) {
        return this.http.get(Constants.TemplateOrderDetailService(value));
    }

    SetOrderStatusService() {
        return this.http.get(Constants.SetOrderStatusService());
    }

    // static getPlanAgentMapDetails() {
    //     return this.serviceUrl + 'transaction/getPlanAgentMapDetails';
    // }

    AuthenticateStaffService(info) {
        return this.http.post(Constants.AuthenticateStaffService(), info);
    }


    getCurrentLocation() {
        return this.http.get('http://freegeoip.net/json/');
    }

    getAgentMargin(AgentId) {
        return this.http.get(Constants.getAgentMargin(AgentId));
    }

    getBranchList(cityName: any) {
        return this.http.get(Constants.getBranchListService(cityName));
    }

    getBranchDetails(val) {
        return this.http.get(Constants.getBranchDetailsService(val));
    }

    getDestinationList() {
        // return this.http.get(Constants.getDestinationListService());
        if (sessionStorage.getItem('destinationList') === null) {
            this.http.get(Constants.getDestinationListService()).subscribe(data => {
                const retObj: any = data;
                sessionStorage.setItem('destinationList', JSON.stringify(retObj));
            });
            return this.http.get(Constants.getDestinationListService());
        } else {
            const subject = new Subject();
            setTimeout(() => {
                subject.next(JSON.parse(sessionStorage.getItem('destinationList')));
            }, 0);
            return subject;
        }
    }

    getNationalityList() {
        return this.http.get(Constants.getNationality());
    }

    getExchangeRate(currencyCode: string, branchId: number, productType: string, operationType: string = null) {
        return this.http.get(Constants.getExchangeRateService() + '?currencyCode=' + currencyCode
            + '&branchId=' + branchId + '&productType=' + productType + '&operationType=' + operationType);
    }

    getCurrencyList(productId: any, destinationId: number = 56) {
        return this.http.get(Constants.getCurrencyListService() + '?destinationId=' + destinationId + '&productId=' + productId);
    }

    getDocumentList() {
        const checkListId = {
            'id': '59c485c30ecf845e2c7da157'
        };
        return this.http.post(Constants.getDocumentListService(), checkListId);
    }


    getDocumentCheckList(list) {
        console.log(Constants.getDocumentListService());
        return this.http.post(Constants.getDocumentListService(), list);
    }

    setUserRegistration(info) {
        return this.http.post(Constants.setUserInfo(), info);
    }

    updateUserRegistration(info) {
        return this.http.post(Constants.updateUserInfo(), info);
    }

    getCityList() {
        return this.http.get(Constants.getCityListService());
    }

    getDeliveryAmt(Mode) {
        const headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${localStorage.getItem('accessToken')}`
        });
        return this.http.get(Constants.getDeliveryAmtService() + '?Mode=' + Mode, { headers: headers });
    }

    setUserRegisterAdhar(jsonData) {
        return this.http.post(Constants.setUserDetailWithAdharService(), jsonData);
    }

    getDeliveryTypeList() {
        return this.http.get(Constants.getDeliveryTypeListService());
    }

    getPurposeList(processId: any) {
        return this.http.get(Constants.getPurposeListService(processId));
    }

    getBankList(currencyCode: string) {
        return this.http.get(Constants.getBanksListService() + '?code=' + currencyCode);
    }

    getBank() {
        return this.http.get(Constants.getBanksService());
    }

    getPinCodeDetails(pinCode: string) {
        return this.http.get(Constants.getPincodeDetailsService() + '?pinCode=' + pinCode);
    }

    getAirlineNames() {
        return this.http.get(Constants.getAirlineNamesService());
    }

    getDocumentSellList() {
        const checkListId = {
            'id': '59d5f3bd0144e44453a5067d'
        };

        const checkListDetail = {
        };
        return this.http.post(Constants.getDocumentListService(), checkListId);
    }

    uploadTravellerDocuments(payload: any) {
        return this.http.post(Constants.getDocUploadApi(), payload);
    }

    loginUser(payload: any) {
        return this.http.post(Constants.getLoginService(), payload);
    }

    forgotPassword(forgotInfo: any) {
        return this.http.post(Constants.getForgotPasswordService(), forgotInfo);
    }

    resetPassword(passwordInfo: any) {
        return this.http.post(Constants.getResetPasswordService(), passwordInfo);
    }

    validateUrl(passwordInfo: any) {
        return this.http.post(Constants.validateResetPasswordService(), passwordInfo);
    }

    getCardDetails(passportNumber: string) {
        return this.http.get(Constants.getCardDetailsService() + '?passportNo=' + passportNumber);
    }

    paymentgateway(paymentInfo) {
        return this.http.post(Constants.callPaymentGateway(), paymentInfo, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'text'
        });
    }

    paymentgatewayPaynimo(paymentInfo) {
        return this.http.post(Constants.callPaymentGatewayPaynimo(), paymentInfo, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'text'
        });
    }


    getEmailValidation(email: string) {
        return this.http.get(Constants.getCheckEmail() + '?emailId=' + email);
    }





    dumpSessionData(sessionData: any) {
        return this.http.post(Constants.sessionDumpService(), sessionData, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'text'
        });
    }

    getLoggedInUserInfo(uid: any) {
        return this.http.get(Constants.getLoggedInUserInfoService(uid));
    }

    getUserProfilePic(payload: any) {
        return this.http.post(Constants.getUserProfilePicService(), payload);
    }

    createAlert(payload: any) {
        return this.http.post(Constants.createAlertService(), payload);
    }

    getTemporaryOrderNumber() {
        return this.http.get(Constants.getTempOrderNumber());
    }

    getOrderData(tempNo: string, userId: number) {
        return this.http.get(Constants.getOrderData() + '?tempNumber=' + tempNo + '&userId=' + userId);
    }

    getOrderDataFromEmail(tempNo: string, emailId: string) {
        return this.http.get(Constants.getOrderDataFromEmail() + '?tempNumber=' + tempNo + '&emailId=' + emailId);
    }

    getLiveForexData() {
        return this.http.get(Constants.getLiveForex());
    }

    getLiveForexDataOverview() {
        return this.http.get(Constants.getLiveForexOverview());
    }

    getLiveForexDataFromBranchId(val) {
        return this.http.get(Constants.getLiveForexFromBranchId(val));
    }

    getForexTrend(currencyCode) {
        return this.http.get(Constants.getForexTrend(currencyCode));
    }

    getForexTrendFromBranchId(currencyCode, branchId) {
        return this.http.get(Constants.getForexTrendFromBranchId(currencyCode, branchId));
    }

    getForexTrendSell(currencyCode) {
        return this.http.get(Constants.getForexTrendSell(currencyCode));
    }

    getForexTrendSellFromBranchId(currencyCode, branchId) {
        return this.http.get(Constants.getForexTrendSellFromBranchId(currencyCode, branchId));
    }

    getForexTrendSellDaywise(currencyCode) {
        return this.http.get(Constants.getForexTrendSellDaywise(currencyCode));
    }

    getForexTrendSellDaywiseFromBranchId(currencyCode, branchId) {
        return this.http.get(Constants.getForexTrendSellDaywiseFromBranchId(currencyCode, branchId));
    }

    getForexTrendBuyDaywise(currencyCode) {
        return this.http.get(Constants.getForexTrendBuyDaywise(currencyCode));
    }

    getForexTrendBuyDaywiseFromBranchId(currencyCode, branchId) {
        return this.http.get(Constants.getForexTrendBuyDaywiseFromBranchId(currencyCode, branchId));
    }


    getAlert(payload: any) {
        return this.http.post(Constants.getAlertService(), payload);
    }

    deleteAlert(payload: any) {
        return this.http.post(Constants.deleteAlertService(), payload);
    }

    updateAlert(payload: any) {
        return this.http.post(Constants.updateAlertService(), payload);
    }

    getWishList(UserId: any) {
        return this.http.get(Constants.wishListService(UserId));
    }

    getUserDocuments(UserId: any) {
        return this.http.get(Constants.getUserDocumentsService(UserId));
    }

    updateKyc(formdata: FormData) {
        return this.http.post(Constants.updateKycService(), formdata);
    }

    sendOtp(payload: any) {
        return this.http.post(Constants.sendAadhaarOtp(), payload);
    }

    validateOtp(payload: any) {
        return this.http.post(Constants.validateAadhaarOtp(), payload);
    }

    getOrdersList(uid: any) {
        return this.http.get(Constants.getOrdersListService(uid));
    }

    changePassword(payload: any) {
        return this.http.post(Constants.changePasswordService(), payload);
    }

    setGrievances(payload: any) {
        return this.http.post(Constants.setGrievancesService(), payload);
    }

    getTaxes(totalPayable: number) {
        return this.http.get(Constants.getTaxes(totalPayable));
    }

    releaseTempNo(tempNo: number) {
        return this.http.get(Constants.releaseTempNo(tempNo));
    }

    /* checkCardAvailable(cardNo: number) {
         let promise = new Promise((resolve, reject) => {

             this.http.get(Constants.checkCardAvailable(cardNo))
                 .toPromise()
                 .then(
                 res => { // Success
                     console.log('service call');
                     console.log(res);
                     resolve(res);
                 },
                 msg => { // Error
                     reject(msg);
                 }
                 );
         });
         return promise;
     }*/


    /*async checkCardAvailable(cardNo: number): Promise<any> {

        const response = await this.http.get(Constants.checkCardAvailable(cardNo)).toPromise();

        console.log(response);
        return response;
    }*/

    checkCardAvailable(cardNo: number) {
        return this.http.get(Constants.checkCardAvailable(cardNo));
    }

    setFeedback(payload) {
        return this.http.post(Constants.setFeedback(), payload);
    }

    deleteDocument(payload: any) {
        return this.http.post(Constants.deleteDocumentService(), payload);
    }

    RuleTest(sessionData: any) {
        return this.http.post(Constants.RuleTest(), sessionData, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'text'
        });
    }
    getTodaysDate() {
        let monthDateCal = '',
            todaysDate,
            // tslint:disable-next-line:prefer-const
            dateObj = new Date(),
            dayDate: any = +dateObj.getDate(),
            // tslint:disable-next-line:prefer-const
            monthDate = +dateObj.getMonth() + 1;
        if (monthDate.toString().length < 2) {
            monthDateCal = '0' + monthDate;
        } else {
            monthDateCal = monthDate.toString();
        }
        if (dayDate.toString().length < 2) {
            dayDate = '0' + dayDate;
        } else {
            dayDate = dayDate.toString();
        }
        todaysDate = dayDate + '-' + monthDateCal + '-' + dateObj.getFullYear();
        return todaysDate;
    }

    validateAdhaar(info) {
        return this.http.post(Constants.getAdaarValidationService(), info);
    }

    getCharges() {
        return this.http.get(Constants.getChargesService());
    }

    /* adds days, months and years to given date(in DD-MM-YYYY)
    * dateString: date string in 'DD-MM-YYYY' format.
    * count: number of days, months or years.
    * type: this can be 'days', 'months' or 'years'
    */
    addDateMoment(dateString, count, type) {
        const new_date = moment(dateString, 'DD-MM-YYYY').add(type, count);
        const day = new_date.format('DD');
        const month = new_date.format('MM');
        const year = new_date.format('YYYY');
        return day + '-' + month + '-' + year;
    }

    /* subtracts days, months and years to given date(in DD-MM-YYYY)
    * dateString: date string in 'DD-MM-YYYY' format.
    * count: number of days, months or years.
    * type: this can be 'days', 'months' or 'years'
    */
    substractDateMoment(dateString, count, type) {
        const new_date = moment(dateString, 'DD-MM-YYYY').subtract(type, count);
        const day = new_date.format('DD');
        const month = new_date.format('MM');
        const year = new_date.format('YYYY');
        return day + '-' + month + '-' + year;
    }

    getCurrentTime(): any {
        const new_date = moment();
        const hours = new_date.format('HH');
        const mins = new_date.format('mm');
        return { hour: hours, mins: mins };
    }

    getDateDifference(date1, date2) {
        const new_date1 = moment(date1, 'DD-MM-YYYY'), new_date2 = moment(date2, 'DD-MM-YYYY');
        return new_date1.diff(new_date2, 'days');
    }


    newLeadLoginService(payload) {
        return this.http.post(Constants.newLeadLoginService(), payload);
    }

    addNewLead(payload) {
        return this.http.post(Constants.addNewLeadService(), payload);
    }

    updateLeadPassService(payload) {
        return this.http.post(Constants.updateLeadPassService(), payload);
    }

    removeTraveller(payload) {
        return this.http.post(Constants.removeTravellerService(), payload);
    }

    checkActiveUrl(url: any) {
        return this.http.get(Constants.checkActiveUrlService(url));
    }

    getUserInfo(url: any) {
        return this.http.get(Constants.getUserInfoService(url));
    }

    getCurrencyRateForRule(branchId: any) {
        return this.http.get(Constants.getCurrencyRateForRuleService(branchId));
    }

    setUserIdToSession(tempNumber, emailId, id) {
        return this.http.get(Constants.setUserIdToSessionService(tempNumber, emailId, id));
    }

    PlanDetails() {
        return this.http.get(Constants.PlanDetails());
    }

    getPlanAgentMapDetails() {
        return this.http.get(Constants.getPlanAgentMapDetails());
    }

    submitAgentOffers(info) {
        return this.http.post(Constants.submitAgentOffers(), info);
    }

    uploadAgentDocument(info) {
        return this.http.post(Constants.uploadAgentDocument(), info);
    }

    AddNewPlan(info) {
        return this.http.post(Constants.AddNewPlan(), info);
    }

    AllCurrency() {
        return this.http.get(Constants.getAllCurrency());
    }

    getSuperAgentId() {
        return this.http.get(Constants.getSuperAgentId());
    }

    getMarginAll(agentId) {
        return this.http.get(Constants.getMarginAll(agentId));
    }

    setMargin(info) {
        return this.http.post(Constants.setMargin(), info);
    }

    getCategoryBankData() {
        return this.http.get(Constants.getCategoryBankData());
    }

    setAgentMargin(payload) {
        return this.http.post(Constants.setAgentMargin(), payload);
    }
}

