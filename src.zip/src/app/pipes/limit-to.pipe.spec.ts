import { LimitToPipe } from './limit-to.pipe';

describe('LimitToPipe', () => {
  it('create an instance', () => {
    const pipe = new LimitToPipe();
    expect(pipe).toBeTruthy();
  });
});
