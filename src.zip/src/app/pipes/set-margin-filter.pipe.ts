import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'setMarginFilter'
})
export class SetMarginFilter implements PipeTransform {
    transform(items: any[], searchText: any): any[] {
        if (!items) return [];
        if (!searchText) return items;
        searchText = searchText.toLowerCase();
        return items.filter(it => {
            if(it[0] && it[0].CurrencyCode) {
                return it[0].CurrencyCode.toLowerCase().includes(searchText);
            } else {
                return it.currencyName.toLowerCase().includes(searchText);
            }            
        });
    }
}