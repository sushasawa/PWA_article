import { OrderFilterPipe } from './order-filter.pipe';

describe('OrderFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new OrderFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
