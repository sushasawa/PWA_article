import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'split'
})
export class SplitPipe implements PipeTransform {
  transform(val: string, params: string): string {
    console.log(typeof (val));
    console.log((val));
    if (val == null) {
      return;
    } else if (typeof (val) === 'object') {
      return;
    } else if (val.indexOf(params) !== -1) {
      return val.split(params)[1];
    } else {
      return val;
    }
  }
}
