export class SessionHelper {

        static setSession(key: string, value: string) {
            sessionStorage.setItem(key, btoa(value));
        }


        static getSession(key: string): string {
            // return sessionStorage.getItem(key) ? atob(sessionStorage.getItem(key)) : undefined;
            try {
                return sessionStorage.getItem(key) ? atob(sessionStorage.getItem(key)) : undefined;
            } catch (err) {
                sessionStorage.removeItem(key);
                return undefined;
            }
        }

        static removeSession(key: string): string {
            try {
                const result = sessionStorage.getItem(key) ? atob(sessionStorage.getItem(key)) : undefined;
                sessionStorage.removeItem(key);
                return result;
            } catch (err) {
                sessionStorage.removeItem(key);
                return undefined;
            }
        }

        static setLocal(key: string, value: string) {
            localStorage.setItem(key, btoa(value));
        }


        static getLocal(key: string): string {
            // return localStorage.getItem(key) ? atob(localStorage.getItem(key)) : undefined;
            try {
                return localStorage.getItem(key) ? atob(localStorage.getItem(key)) : undefined;
            } catch (err) {
                localStorage.removeItem(key);
                return undefined;
            }
        }

        static removeLocal(key: string): string {
            try {
                const result = localStorage.getItem(key) ? atob(localStorage.getItem(key)) : undefined;
                localStorage.removeItem(key);
                return result;
            } catch (err) {
                localStorage.removeItem(key);
                return undefined;
            }
        }
    }

