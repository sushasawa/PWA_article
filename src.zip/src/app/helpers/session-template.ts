export class SessionTemplate {

    static getSessionTemplate(info: any) {
        // console.log('Check');
         console.log(info);
        return {
            'serviceCharge' : 0,
            'loadFees' : 0,
            'activationFees' : 0,
            'discount' : 0,
            'reloadFees' : 0,
            'charges' : 0,
            'registrationInfo': {
                'invoiceNo' : null,
                'firstName': { 'value': info.firstName },
                'middleName': info.middleName,
                'lastName': info.lastName,
                'dateOfBirth': { 'value': info.dateOfBirth },
                'adharCardNo': { 'value': info.adharCardNo },
                'gender': { 'value': info.gender },
                'nationality': info.nationality,
                'mothersMaidenName': { 'value': info.mothersMaidenName },
                'PAN': { 'value': info.PAN },
                'passportNumber': info.passportNumbar,
                'ParentId': info.Parent_Id,
                'dateOfIssue': info.dateOfIssue,
                'placeOfIssue': info.placeOfIssue,
                'expiryDate': info.expiryDate,
                'address': '',
                'isPassportAddressAsAdhar': '',
                'adharAddress': {
                    'flatNumber': '',
                    'buildingName': '',
                    'streetName': '',
                    'landmark': '',
                    'area': '',
                    'city': '',
                    'state': '',
                    'pincode': '',
                },
                'passportAddress': {
                    'flatNumber': info.flatNumber,
                    'buildingName': info.buildingName,
                    'streetName': info.streetName,
                    'landmark': info.landmark,
                    'area': info.area,
                    'city': info.city,
                    'state': info.state,
                    'pincode': info.pincode,
                },
                'currentAddressAs': info.IsCurrentAd_As_Passport_Address,
                'otherAddress': {
                    'flatNumber': info.C_Ad_FlatNo,
                    'buildingName': info.C_Ad_BuildingName,
                    'streetName': info.C_Ad_StreetName,
                    'landmark': info.C_Ad_Landmark,
                    'area': info.C_Ad_Area_Locality,
                    'city': info.C_Ad_City,
                    'state': info.C_Ad_State,
                    'pincode': info.C_Ad_PinCode,
                },
                'contactDetails': {
                    'countryCode': info.ContactCountryCodeMob,
                    'mobileNo': info.mobileNo,
                    'countryCode2': info.ContactCountryCodeTel,
                    'cityCode': info.ContactCityCodeTel,
                    'telephoneNo': info.ContactTel,
                    'emailId': info.emailId,
                },
                'alternateContactDetails': {
                    'countryCode': info.AMobile_CountryCode,
                    'mobileNo': info.AMobileNo,
                    'countryCode2': info.ATelephone_CountryCode,
                    'cityCode': info.ATelephone_CityCode,
                    'telephoneNo': info.Atelephone,
                    'emailId': info.AEmailId,
                },
                'officeAddress': {
                    'designation': info.designation,
                    'conpanyName': info.companyName,
                    'companyDivision': info.companyDivision,
                    'flatNumber': info.Office_Ad_FlatNo,
                    'building': info.Office_Ad_Building,
                    'streetName': info.Office_Ad_StreetName,
                    'landmark': info.Office_LandMark,
                    'area': info.Office_Area,
                    'city': info.Office_City,
                    'state': info.Office_State,
                    'pincode': info.Office_PinCode
                },
                'officeContactDetails': {
                    'countryCode': info.Office_TelePhone_CountryCode,
                    'telephoneNumber': info.Office_TelePhoneNo,
                    'officeExtension': info.Office_ExtensionNo,
                },
                'parentId': info.User_Id,
                'userId': info.User_Id !== undefined ? info.User_Id : info.Id,
                'parent': info.parent === true ? true : false,
            },
            'parentId': info.User_Id,
            'rowId': info.Id,
            'parent': info.parent,
            'selected': info.selected,
            'profileInfo': {
                'picture': 'assets/images/my-account/profile/profile-img.jpg',
                'cover': 'assets/images/my-account/my-account-banner.jpg'
            },
            'travellingDetails': {
                'dateOfTravel': '',
                'dateOfArrival': '',
                'airlineName': '',
                'ticketNumber': ''
            }
        };
    }


}
