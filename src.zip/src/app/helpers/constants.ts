import {Url} from '../../assets/config';
console.log(Url.server1);
export class Constants {
    // static serviceUrl = Url.server1;
    //    static serviceUrl = 'http://10.21.21.210:5000';
     // static serviceUrl = 'http://172.21.203.38:8081';
         //static serviceUrl = 'http://10.21.21.33:5000';
      // static serviceUrl = 'http://172.21.203.224:8094';
    static serviceUrl = 'http://forex.coxandkings.com:8070';
    
    static allBranchCode = '9999999';
    static serviceUrl_Local = 'http://10.21.21.210:5000';

    static getAllBranchCode() {
        return this.allBranchCode;
    }

    static getAgentMargin(AgentId) {
        return this.serviceUrl + '/master/getAgentMargin?id=' + AgentId;
    }


    static getBranchListService(cityName: any) {
        return this.serviceUrl + '/master/Branch?City=' + cityName;
    }

    static getBranchDetailsService(val) {
        return this.serviceUrl + '/master/BranchDetails?branchId=' + val;
    }

    static getDestinationListService() {
        return this.serviceUrl + '/master/Destination';
    }

    static getNationality() {
        return this.serviceUrl + '/master/nationality';
    }

    static getCurrencyListService() {
        return this.serviceUrl + '/master/Currency';
    }

    static getExchangeRateService() {
        return this.serviceUrl + '/master/ExchangeRate';
    }

    static getDocumentListService() {
        return this.serviceUrl + '/document/documentList';
    }

    static getDeliveryTypeListService() {
        return this.serviceUrl + '/master/deliveryType';
    }

    static getPurposeListService(processId: any) {
        return this.serviceUrl + '/master/TravelPurpose?processId=' + processId;
    }

    static getBanksListService() {
        return this.serviceUrl + '/master/Banks';
    }

    static getBanksService() {
        return this.serviceUrl + '/master/getBanksList';
    }

    static getCityListService() {
        return this.serviceUrl + '/master/CityList';
    }

    static getDeliveryAmtService() {
        return this.serviceUrl + '/document/DeliveryAmt';
    }

    static setUserDetailWithAdharService() {
        return this.serviceUrl + '/register/registerAdhar';
    }

    static getPincodeDetailsService() {
        return this.serviceUrl + '/register/getPincodeDetails';
    }

    static getDocUploadApi() {
        return this.serviceUrl + '/upload';
    }

    static setUserInfo() {
        return this.serviceUrl + '/users/userInfo';
    }

    static updateUserInfo() {
        return this.serviceUrl + '/UpdateUser/UpdateUserInfo';
    }


    static getLoginService() {
        return this.serviceUrl + '/master/login';
    }

    static getForgotPasswordService() {
        return this.serviceUrl + '/master/forgotPassword';
    }

    static getResetPasswordService() {
        return this.serviceUrl + '/master/resetPassword';
    }

    static validateResetPasswordService() {
        return this.serviceUrl + '/master/validateResetPasswordUrl';
    }

    static getCardDetailsService() {
        return this.serviceUrl + '/users/cardDetails';
    }

    static sessionDumpService() {
        return this.serviceUrl + '/mongodump/sessiondump';
    }

    static transactionDumpService() {
        return this.serviceUrl + '/transaction/SaveRequestData';
    }
    static callPaymentGateway() {
        return this.serviceUrl + '/master/paymentGatewayService';
        // return "http://10.21.20.86:8001/api/values";
    }

    static callPaymentGatewayPaynimo() {
        return this.serviceUrl + '/master/paymentGatewayServicePaynimo';
        // return "http://10.21.20.86:8001/api/values";
    }

    static getLoggedInUserInfoService(val) {
        return this.serviceUrl + '/account/userInfo?uid=' + val;
    }

    static getUserProfilePicService() {
        return this.serviceUrl + '/profile';
    }

    static createAlertService() {
        return this.serviceUrl + '/createAlert';
    }

    static getTempOrderNumber() {
        return this.serviceUrl + '/master/OrderNumber';
    }

    static generateInvoiceNoService() {
        return this.serviceUrl + '/transaction/generateInvoiceNo';
    }

    static getOrderData() {
        return this.serviceUrl + '/mongoDump/getSessionFromMongo';
    }

    static getOrderDataFromEmail() {
        return this.serviceUrl + '/mongoDump/getSessionFromMongoCheckEmail';
    }

    static getLiveForex() {
        return this.serviceUrl + '/liveForex/LiveForexRates';
    }

    static getLiveForexOverview() {
        return this.serviceUrl + '/liveForex/LiveForexRatesOverview';
    }

    static getLiveForexFromBranchId(val) {
        return this.serviceUrl + '/liveForex/LiveForexRatesFromBranchId?BranchId=' + val;
    }


    static getForexTrend(val) {
        return this.serviceUrl + '/liveForex/ForexTrend?currencyCode=' + val;
    }

    static getForexTrendFromBranchId(currencyCode, branchId) {
        return this.serviceUrl + '/liveForex/ForexTrendBranchId?currencyCode=' + currencyCode + '&branchId=' + branchId;
    }


    static getForexTrendSell(val) {
        return this.serviceUrl + '/liveForex/ForexTrendSell?currencyCode=' + val;
    }

    static getForexTrendSellFromBranchId(currencyCode, branchId) {
        return this.serviceUrl + '/liveForex/ForexTrendSellBranchId?currencyCode=' + currencyCode + '&branchId=' + branchId;
    }

    static getCheckEmail() {
        return this.serviceUrl + '/CheckEmail';
    }



    static getForexTrendSellDaywise(val) {
        return this.serviceUrl + '/liveForex/ForexTrendSellDaywise?currencyCode=' + val;
    }

    static getForexTrendSellDaywiseFromBranchId(currencyCode, branchId) {
        return this.serviceUrl + '/liveForex/ForexTrendSellDaywiseBranchId?currencyCode=' + currencyCode + '&branchId=' + branchId;
    }


    static getForexTrendBuyDaywise(val) {
        return this.serviceUrl + '/liveForex/ForexTrendBuyDaywise?currencyCode=' + val;
    }

    static getForexTrendBuyDaywiseFromBranchId(currencyCode, branchId) {
        return this.serviceUrl + '/liveForex/ForexTrendBuyDaywiseBranchId?currencyCode=' + currencyCode + '&branchId=' + branchId;
    }

    static getAlertService() {
        return this.serviceUrl + '/createAlert/getAlert';
    }

    static deleteAlertService() {
        return this.serviceUrl + '/createAlert/delete';
    }

    static updateAlertService() {
        return this.serviceUrl + '/createAlert/update';
    }

    static wishListService(UserId) {
        return this.serviceUrl + '/WishList?userId=' + UserId;
    }

    static getUserDocumentsService(UserId) {
        return this.serviceUrl + '/Document/getUserDocuments?uid=' + UserId;
    }

    static updateKycService() {
        return this.serviceUrl + '/Document/kyc';
    }

    static sendAadhaarOtp() {
        return this.serviceUrl + '/adharAuth/sendOtp';
    }

    static validateAadhaarOtp() {
        return this.serviceUrl + '/adharAuth/validateOtp';
    }

    static getOrdersListService(uid) {
        return this.serviceUrl + '/orders/GetOrdersList?uid=' + uid;
    }

    static changePasswordService() {
        return this.serviceUrl + '/users/ChangePassword';
    }

    static setGrievancesService() {
        return this.serviceUrl + '/createAlert/Grievances';
    }

    static getTaxes(totalPayable: number) {
        return this.serviceUrl + '/master/Taxes?totalPayable=' + totalPayable;
    }

    static releaseTempNo(tempNo: number) {
        return this.serviceUrl + '/master/releaseTempNo?tempNo=' + tempNo;
    }

    static setFeedback() {
        return this.serviceUrl + '/footerAssets/feedback';
    }

    static checkCardAvailable(cardNo: number) {
        return this.serviceUrl + '/master/checkCardAvailable?cardNo=' + cardNo;
    }

    static deleteDocumentService() {
        return this.serviceUrl + '/DeleteDoc';
    }

    static RuleTest() {
        return this.serviceUrl + '/master/setData';
    }

    static getAdaarValidationService() {
        return this.serviceUrl + '/adharAuth/validateAdharDemo';
    }

    static getAirlineNamesService() {
        return this.serviceUrl + '/master/AirlineName';
    }

    static getChargesService() {
        return this.serviceUrl + '/Charges/';
    }

    static newLeadLoginService() {
        return this.serviceUrl + '/account/newLeadLogin';
    }

    static addNewLeadService() {
        return this.serviceUrl + '/account/addNewLead';
    }

    static updateLeadPassService() {
        return this.serviceUrl + '/account/updateLeadPass';
    }

    static checkActiveUrlService(url) {
        return this.serviceUrl + '/account/checkUrlServie?url=' + url;
    }

    static getUserInfoService(url) {
        return this.serviceUrl + '/BTBRegister/B2CUserInfo?EmailId=' + url;
    }

    static removeTravellerService() {
        return this.serviceUrl + '/account/removeTraveller';
    }


    static generateTransactionIdService() {
        return this.serviceUrl + '/transaction/generateTransactionId';
    }

    static initTransactionSavingService() {
        return this.serviceUrl + '/transaction/saveTransactionRequest';
    }

    static getTransactionByIdService(id) {
        return this.serviceUrl + '/transaction/transactionById?transactionId=' + id;
    }

    static sendSellInvoiceDataService() {
        return this.serviceUrl + '/transaction/sellIexchnagePOST';
    }


    static getCurrencyRateForRuleService(branchId) {
        return this.serviceUrl + '/master/getCurrencyRateForRule?branchId=' + branchId;
    }

    static setUserIdToSessionService(tempNumber, emailId, id) {
        return this.serviceUrl + '/mongodump/setIdSession?' + 'tempNumber=' + tempNumber + '&emailId=' + emailId + '&id' + id;
     }


    ///// ADMIN PANEL
    static TemplateOrderService(value, userName) {
        console.log('value', value);
        console.log('userName', userName);
        return this.serviceUrl + '/transaction/getTemplateOrdersBranchWise?branchCode=' + value + '&userName=' + userName;
    }

    static GetAllEnquiries(BranchCode) {
        return this.serviceUrl + '/promotion/getAllLeads?BranchCode=' + BranchCode;
    }

    static TemplateOrderDetailService(value) {
        return this.serviceUrl + '/transaction/getTemplateOrdersDetail?orderId=' + value;
    }

    static SetOrderStatusService() {
        return this.serviceUrl + '/transaction/setOrdersStatus';
    }

    static getPlanAgentMapDetails() {
        return this.serviceUrl_Local + '/transaction/getPlanAgentMapDetails';
    }

    static AuthenticateStaffService() {
        return this.serviceUrl + '/master/AuthenticateStaff';
    }

    static PlanDetails() {
        return this.serviceUrl_Local + '/transaction/getPlanDetails';
    }

    static AddNewPlan() {
        return this.serviceUrl_Local + '/transaction/setPlanDetails';
    }

    static submitAgentOffers() {
        return this.serviceUrl_Local + '/transaction/setAgentIncentiveMap';
    }

    static uploadAgentDocument() {
        return this.serviceUrl_Local + '/AgentDocumentUpload';
    }

    static getAllCurrency() {
        return this.serviceUrl + '/master/AllCurrency';

    }

    static getSuperAgentId() {
        return this.serviceUrl + '/liveForex/getSuperAgentId';
    }

    static getMarginAll(agentId) {
        return this.serviceUrl + '/liveForex/getMarginAll?agentId=' + agentId;
    }

    static setMargin() {
        return this.serviceUrl + '/liveForex/setMargin';
    }

    static getCategoryBankData() {
        return this.serviceUrl + '/liveForex/getCategoryBankData';
    }

    static setAgentMargin() {
        return this.serviceUrl + '/master/setAgentMargin';
    }
}
