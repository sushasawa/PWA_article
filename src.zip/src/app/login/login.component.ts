import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { routerTransition } from '../router.animations';
import { AuthenticationService } from '../services/authentication.service';
import * as sha from 'sha.js';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    animations: [routerTransition()]
})
export class LoginComponent implements OnInit {
    public user: any = {};
    public errorMsg = '';


    constructor(
        private translate: TranslateService,
        public router: Router, private _authservice: AuthenticationService
        ) {
            this.translate.addLangs(['en', 'fr', 'ur', 'es', 'it', 'fa', 'de', 'zh-CHS']);
            this.translate.setDefaultLang('en');
            const browserLang = this.translate.getBrowserLang();
            this.translate.use(browserLang.match(/en|fr|ur|es|it|fa|de|zh-CHS/) ? browserLang : 'en');
    }

    onLoggedin() {
        this.user.password = sha('sha256').update(this.user.password, 'utf8').digest('hex');
        this.onLoginClick();
    }

    ngOnInit() {
        this._authservice.checkCredentials();
    }

    onLoginClick() {
        this._authservice.login(this.user);
        // if (!this._authservice.login(this.user)) {
        //     this.errorMsg = 'Failed to login';
        // }
    }
}
