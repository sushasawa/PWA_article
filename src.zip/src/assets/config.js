const servers = {
  PRODUCTION: 'https://forex.coxandkings.com:8080',
  UAT: 'http://172.21.203.224:8080',
  // LOCAL: 'http://10.21.21.210:5000',
  LOCAL: 'http://10.21.21.33:4000',
}

var Url = {
  server1: servers.LOCAL,
}
module.exports.Url = Url;
