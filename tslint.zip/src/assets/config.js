const servers = {
  PRODUCTION: 'https://forex.coxandkings.com:8080',
  UAT: 'http://172.21.203.224:8094',
  LOCAL: 'http://10.21.21.210:5000',
  PREPROD: 'http://forex.coxandkings.com:8070',
  // LOCAL: 'http://10.21.21.33:4000',  
}

var Url = {
  server1: servers.PREPROD,
}
module.exports.Url = Url;


