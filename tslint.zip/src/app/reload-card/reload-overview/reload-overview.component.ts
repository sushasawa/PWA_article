import { Component, OnInit, ElementRef } from '@angular/core';
import { Location } from '../../helpers/location';
import { GenericEntity } from '../..//helpers/generic';
import { MasterService } from '../../services/master.services';
import { Constants } from '../../helpers/constants';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { Router } from '@angular/router';
import { UUID } from 'angular2-uuid';
import { SessionTemplate } from '../../helpers/session-template';
import { Observable } from 'rxjs/Observable';
import { LocationStrategy } from '@angular/common';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { SharedService } from './../../shared/shared.service';
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;

@Component({
    selector: 'app-reload-overview',
    templateUrl: './reload-overview.component.html',
    styleUrls: ['./reload-overview.component.css']
})
export class ReloadOverviewComponent implements OnInit {
    public branchOptions: any;
    public destinationOptions: any;
    public currencyList: any;
    public currencyListCash: any;
    public purposeOptions: any;
    public bankOptions = [];
    public userSessionInfoRealoadCard: any;
    private currentTravellerIndex: number;
    public ValidCard: Boolean = false;
    public isLoggedIn: boolean;
    public travellerList: any;
    public newTravellerCount: number;
    public invalidsubmitted: boolean;
    public navigate: any = true;
    public CurrentBranchId: any;
    public _primaryComp: any;
    public AgentTheme: any;
    public textContents: any = {};
    public backGroungImage: any = 'assets/images/forex-bg-img.jpg';
    constructor(public masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _elementRef: ElementRef, private location: LocationStrategy, public _SharedService: SharedService) {
        this.location.onPopState(() => {
            this.navigate = false;
            return false;
        });
        this._primaryComp = '/' + navUrl.navUrl();
        this.userSessionInfoRealoadCard = {
            'sessionId': '',
            'mode': 'b2c',
            'type': 'reloadCardScreen',
            'isActive': true,
            'created_On': new Date(),
            'reloadCardScreen': {
                'budgetAmount': '',
                'usedAmount': 0,
                'tranId': '',
                'balanceAmount': '0',
                'currentLocation': '',
                'branch': '',
                'destination': '',
                'deliveryInfo': {
                    'Mode': 'Home Delivery',
                    'type': 'Standard',
                    'DeliverySchedule': {
                        'date': '',
                        'time': ''
                    },
                    'rate': 0
                },
                'traveller': [{
                    'prepaidCard': true,
                    'purpose': '',
                    'lead': true,
                    'selected': true,
                    'serviceCharge' : 0,
                    'loadFees' : 0,
                    'reloadFees' : 0,
                    'activationFees' : 0,
                    'discount' : 0,
                    'charges' : 0,
                    'prepaidCardDetails': [{
                        'cardNo': '',
                        'currencyDetails': [
                            {
                                'currencyCode': '',
                                'forexAmount': '',
                                'promisedRate': '',
                                'promisedRateTime': '',
                                'startTime': ''
                            }]

                    }],
                    'cash': false,
                    'registrationInfo': {
                        'userId': '',
                        'invoiceNo': null,
                        'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                        'middleName': '',
                        'lastName': '',
                        'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
                        'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                        'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                        // "nationality": { "id": "", "name": "" } ,
                        'nationality': '',
                        'mothersMaidenName': {
                            'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                                + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                                + 'event.target.style.background=\'#f8f8f8\'}'
                        },
                        'PAN': {
                            'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                                + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                                + 'event.target.style.background=\'#f8f8f8\'}'
                        },
                        'passportNumber': '',
                        'ParentId': true,
                        'dateOfIssue': '',
                        'placeOfIssue': '',
                        'expiryDate': '',
                        'address': '101 5A Galaxy apartment',
                        'isPassportAddressAsAdhar': 'yes',
                        'adharAddress': {
                            'flatNumber': '',
                            'buildingName': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': '',
                        },
                        'passportAddress': {
                            'flatNumber': '',
                            'buildingName': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': '',
                        },
                        'currentAddressAs': 'asPerAdhar',
                        'otherAddress': {
                            'flatNumber': '',
                            'buildingName': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': '',
                        },
                        'contactDetails': {
                            'mobileNo': '',
                            'emailId': ''
                        },
                        'alternateContactDetails': {
                            'countryCode': '',
                            'mobileNo': '',
                            'countryCode2': '',
                            'cityCode': '',
                            'telephoneNo': '',
                            'emailId': '',
                        },
                        'officeAddress': {
                            'designation': '',
                            'conpanyName': '',
                            'companyDivision': '',
                            'flatNumber': '',
                            'building': '',
                            'streetName': '',
                            'landmark': '',
                            'area': '',
                            'city': '',
                            'state': '',
                            'pincode': ''
                        },
                        'officeContactDetails': {
                            'countryCode': '',
                            'telephoneNumber': '',
                            'officeExtension': '',
                        },
                        'password': '',
                        'confirmPassword': '',
                    },
                    'travellingDetails': {
                        'dateOfTravel': '',
                        'dateOfArrival': '',
                        'airlineName': '',
                        'ticketNumber': ''
                    },
                    'PaymentDetails': {
                        'PaymentStatus': 'Fully Paid',
                        'PaymentMode': 'Online Credit Card',
                        'Amount': '6945.00',
                        'PaymentDateTime': 'Jul 27, 2016 13:50 PM',
                        'TransactionId': 'ID986524586',
                        'Last4DigitCardNum': 'xxx xxx xxxx 4646',
                        'CardHolderName': 'Kaushar R',
                        'CreditCardType': 'Visa',
                        'PaymentReceiptNo': 'CKF11',
                        'PaymentReceiptDate': '9 Jun 2016 11:01 am',
                        'OrderType': 'Buy Forex'
                    },
                    'ForexDetails': {
                        'TravellerName': 'Kaushal Ranpura',
                        'InvoiceNum': 'CNF 12352',
                        'PurposeOfTravel': 'Business',
                        'ForexProduct': 'Forex Card',
                        'bank': 'Axis Bank',
                        'AccoutNumber': '4986801000358796',
                        'ForexAmount': 'USD 100',
                        'AppliedRate': '68.23',
                        'TotalTransactionValue': '6,823.00',
                        'Discount': '0',
                        'TotalAfterDisc': '6723.00',
                        'DelivaryCharges': '150.00',
                        'taxes': {
                            'OnFxTrns': '45.00',
                            'OnServCharge': '27.00'
                        },
                        'TotalPayable': '6,945'

                    },
                    'deliveryInfo': {
                        'Mode': '',
                        'type': '',
                        'DeliverySchedule': {
                            'date': '',
                            'time': ''
                        },
                        'rate': 0
                    },

                }]

            }
        };

        // if (SessionHelper.getSession('userInfo')) {
        //     const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));

        //     // Added after Aadhaar implementation
        //     if (userInfo.uid) {
        //         this.isLoggedIn = userInfo.loggedin;
        //         this.masterService.getLoggedInUserInfo(userInfo.uid)
        //             .subscribe(data => {
        //                 const result: any = data;
        //                 this.travellerList = [];
        //                 this.travellerList.push({
        //                     name: result.response[0][0].firstName + ' ' + result.response[0][0].lastName,
        //                     data: result.response[0][0]
        //                 });
        //                 this.travellerList[0].data.lead = true;
        //                 this.travellerList[0].selected = true;

        //                 this.userSessionInfoRealoadCard.reloadCardScreen.traveller[0].registrationInfo
        //                     = SessionTemplate.getSessionTemplate(this.travellerList[0].data).registrationInfo;

        //                 result.response[1].forEach(element => {
        //                     this.travellerList.push({ name: element.firstName + ' ' + element.lastName, data: element });
        //                     this.newTravellerCount = 0;
        //                 });
        //             }, err => {
        //                 // swal('Oops', 'Error fetching traveler data!', 'error');
        //                 Snackbar.show({
        //                     text: 'Oops! Error fetching traveler data',
        //                     pos: 'bottom-right',
        //                     actionTextColor: '#ff4444',
        //                 });
        //             });
        //     }
        // } else {
        //     this.isLoggedIn = false;
        // }

        // region Logic to restore values from session if present...
        if (SessionHelper.getSession('userSessionInfoRealoadCard')) {
            this.userSessionInfoRealoadCard = JSON.parse(SessionHelper.getSession('userSessionInfoRealoadCard'));
        } else {
            this.userSessionInfoRealoadCard.sessionId = UUID.UUID();
        }
        // endregion Logic to restore values from session if present...


        this.populateBranch('');
        if (sessionStorage.getItem('currentLocation') === null) {
            this.masterService.getCurrentLocation()
            .subscribe(data => {
                this.userSessionInfoRealoadCard.reloadCardScreen.currentLocation = data;
                sessionStorage.setItem('currentLocation', JSON.stringify(this.userSessionInfoRealoadCard.reloadCardScreen.currentLocation));
                this.populateBranch(this.userSessionInfoRealoadCard.reloadCardScreen.currentLocation.city);

                if (SessionHelper.getLocal('branchIdFromOverviewReload')) {
                    const branchIdObj = { BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewReload')) };
                    this.selected(branchIdObj);
                } else {
                    const branchIdObj = { BranchID: 11910 };
                    this.selected(branchIdObj);
                }
            }, err => {
                // swal('Oops...', 'Unable to detect current location!', 'error');
                this.populateBranch('');
                Snackbar.show({
                    text: 'Unable to detect current location!',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            });
        } else {
            this.userSessionInfoRealoadCard.reloadCardScreen.currentLocation = JSON.parse(sessionStorage.getItem('currentLocation'));
            this.populateBranch(this.userSessionInfoRealoadCard.reloadCardScreen.currentLocation.city);
            if (SessionHelper.getLocal('branchIdFromOverviewReload')) {
                const branchIdObj = { BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewReload')) };
                this.selected(branchIdObj);
            } else {
                const branchIdObj = { BranchID: 11910 };
                this.selected(branchIdObj);
            }
        }








        // this.masterService.getCurrentLocation()
        //     .subscribe(data => {
        //         this.userSessionInfoRealoadCard.reloadCardScreen.currentLocation = data;
        //         this.populateBranch(this.userSessionInfoRealoadCard.reloadCardScreen.currentLocation.city);

        //         if (SessionHelper.getLocal('branchIdFromOverviewReload')) {
        //             let branchIdObj = { BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewReload')) };
        //             this.selected(branchIdObj);
        //         } else {
        //             let branchIdObj = { BranchID: 11910 };
        //             this.selected(branchIdObj);
        //         }
        //     }, err => {
        //         // swal('Oops...', 'Unable to detect current location!', 'error');
        //         this.populateBranch('');
        //         Snackbar.show({
        //             text: 'Unable to detect current location!',
        //             pos: 'bottom-right',
        //             actionTextColor: '#ff4444',
        //         });
        //     });


            if (sessionStorage.getItem('destinationList') === null) {
                this.masterService.getDestinationList()
                    .subscribe(data => {
                        this.destinationOptions = data;
                        sessionStorage.setItem('destinationList', JSON.stringify(this.destinationOptions));
                    }, err => {
                        // swal('Oops...', 'Unable to fetch destination list!', 'error');
                        Snackbar.show({
                            text: 'Unable to fetch destination list!',
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                    });
            } else {
                this.destinationOptions = JSON.parse(sessionStorage.getItem('destinationList'));
            }

        // this.masterService.getDestinationList()
        //     .subscribe(data => {
        //         this.destinationOptions = data;
        //     });

        // FOR PURPOSE LIST  @precessId values :
        // 1	Buy Forex
        // 2	Sell Forex
        // 3	Reload Card
        // 4	Send Money Abroad
        this.masterService.getPurposeList(3)
            .subscribe(data => {
                this.purposeOptions = data;
                // tslint:disable-next-line:max-line-length
                this.userSessionInfoRealoadCard.reloadCardScreen.purposeCode = this.purposeOptions.filter((value, i) => i === 0)[0].purposeCode;
                this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].purposeCode =
                    this.purposeOptions.filter((value, i) => i === 0)[0].purposeCode;
            });
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        const destination = this.userSessionInfoRealoadCard.reloadCardScreen.destination.split('#')[0];
        this.masterService.getCurrencyList(1, destination)
            .subscribe(data => {
                this.currencyList = data;
            });

        this.currentTravellerIndex = 0;
        this.CurrentBranchId = Number.parseInt(SessionHelper.getLocal('branchIdFromOverview'));
        this.populateCurrencyRateForRule(this.CurrentBranchId);
    }

    ngOnInit() {
        $('body').attr('id', 'home');
        initDocument();
        this.textContents.convenienceTitle = "Buying forex have never become easier!";
        this.textContents.convenienceContents = "Cox & Kings helps you choose the right forex solutions.<br> When you are on the move, just place the order and visit any of the nearest Cox & Kings location to avail our forex solutions.<br> When you are busy, just place the order and relax. We will get you the required forex solutions at your door step.";
        if (this._SharedService.AgentsTheme) {
            this.AgentTheme = this._SharedService.AgentsTheme.success ? this._SharedService.AgentsTheme.Docs : this._SharedService.AgentsTheme;
            this.applyTheme();
        }
        $('.custom-tabs > .resp-tabs-list > li[aria-controls="hor_1_tab_item-1"]').trigger('click');

        /// temporary number
        if (sessionStorage.getItem('userInfo') !== null) {
            const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
            this.masterService.getTemporaryOrderNumber()
                .subscribe(data => {
                    const result: any = data;
                    console.log(result);
                    this.userSessionInfoRealoadCard.temporaryOrderNumber = result.response.OrderNumber;
                    this.userSessionInfoRealoadCard.userId = userInfo.uid;
                });
        }
        this.selectTraveller(0);
    }

    ngDoCheck() {
        this._SharedService.AgentTheme.subscribe((theme) => {
            this.AgentTheme = theme.success ? theme.Docs : theme;
            this.applyTheme();
        });
    }

    applyTheme() {
        this.textContents.convenienceTitle = this.AgentTheme.convenienceTitle;
        this.textContents.convenienceContents = this.AgentTheme.convenienceContents;
        this.backGroungImage = this.AgentTheme.mainScreenBackGround;
    }


    populateCurrencyRateForRule(branchId) {
        this.masterService.getCurrencyRateForRule(branchId).subscribe(
            (data) => {
                const result: any = data;
                   this.userSessionInfoRealoadCard.cashRateBuy =  result[0].cashRateBuy;
                   this.userSessionInfoRealoadCard.prepaidRateBuy =  result[0].prepaidRateBuy;
                   this.userSessionInfoRealoadCard.ddRateBuy =  result[0].ddRateBuy;
                   this.userSessionInfoRealoadCard.cashRateSell =  result[0].cashRateSell;
                   this.updateSession();
            },
            (error) => {
                console.error('getCurrencyRateForRule');
                console.log(error);
            }
        );
    }
    populateBranch(cityname) {
        this.masterService.getBranchList(cityname)
            .subscribe(data => {
                this.branchOptions = data;
            });
    }
    addExistingTraveller(data: any, event: any, index: number) {
        if (event.target.checked) {
            if (this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length === 4) {
                // swal('Sorry', 'Maximum 4 travelers allowed', 'error');
                Snackbar.show({
                    text: 'Sorry! Maximum 4 travelers allowed',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                event.target.checked = false;
            } else {
                this.userSessionInfoRealoadCard.reloadCardScreen.traveller.push({
                    'prepaidCard': false,
                    'purpose': '',
                    'lead': false,
                    'selected': false,
                    'prepaidCardDetails': [{
                        'cardNo': '',
                        'currencyDetails': [
                            {
                                'currencyCode': '',
                                'forexAmount': '',
                                'promisedRate': '',
                                'promisedRateTime': '',
                                'startTime': ''
                            }]

                    }],
                    'travellingDetails': SessionTemplate.getSessionTemplate(data).travellingDetails,
                    'registrationInfo': SessionTemplate.getSessionTemplate(data).registrationInfo
                });
                this.selectTraveller(this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length - 1);
            }
        } else {
            if (!this.travellerList[index].data.lead) {
                if (this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length > 1) {
                    const obj = this.userSessionInfoRealoadCard.reloadCardScreen.traveller
                        .find(item => item.registrationInfo.contactDetails.emailId === data.emailId);

                    this.removeTraveller(this.userSessionInfoRealoadCard.reloadCardScreen.traveller.indexOf(obj));
                } else {
                    // swal('Sorry', 'Minimum 1 traveler needed', 'error');
                    Snackbar.show({
                        text: 'Sorry! Minimum 1 traveler needed',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    event.target.checked = true;
                }
            } else {
                // swal('Sorry', 'You cannot remove lead pax. Change any other traveler to lead before this operation', 'error');
                Snackbar.show({
                    text: 'Sorry! You cannot remove lead pax. Change any other traveler to lead before this operation',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });

                event.target.checked = true;
            }
        }

        this.travellerList[index].selected = event.target.checked;
        this.updateSession();
    }

    addNewTraveller(event: any) {
        if (event.target.checked) {
            if (this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length === 4) {
                // swal('Sorry', 'Maximum 4 travelers allowed', 'error');
                Snackbar.show({
                    text: 'Sorry! Maximum 4 travelers allowed',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                event.target.checked = false;
            } else {
                this.newTravellerCount++;
                this.addTraveller();
                this.selectTraveller(this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length - 1);
            }
        } else {
            if (this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length > 1) {
                const obj = this.userSessionInfoRealoadCard.reloadCardScreen.traveller
                    .find(item => item.registrationInfo.contactDetails.emailId === '');
                this.removeTraveller(this.userSessionInfoRealoadCard.reloadCardScreen.traveller.indexOf(obj));
                this.newTravellerCount--;
            } else {
                // swal('Sorry', 'Minimum 1 traveler needed', 'error');
                Snackbar.show({
                    text: 'Sorry! Minimum 1 traveler needed',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                event.target.checked = true;
            }
        }
        this.updateSession();
    }

    changeLeadPax(event: any, data: any, index: number) {
        console.log(event);
        console.log(data);
        console.log(index);

        this.travellerList.forEach(item => {
            item.data.lead = false;
        });

        this.travellerList[index].data.lead = true;

        this.userSessionInfoRealoadCard.reloadCardScreen.traveller.forEach(traveller => {
            traveller.lead = false;
        });
        const obj = this.userSessionInfoRealoadCard.reloadCardScreen.traveller
            .find(item => item.registrationInfo.contactDetails.emailId === data.emailId);
        const i = this.userSessionInfoRealoadCard.reloadCardScreen.traveller.indexOf(obj);

        this.userSessionInfoRealoadCard.reloadCardScreen.traveller[i].lead = true;
        console.log(this.userSessionInfoRealoadCard.reloadCardScreen.traveller);
        this.updateSession();
    }

    showTravellerChoice() {
        this._elementRef.nativeElement.querySelector('.trvl-list').style.display = 'block';
    }

    hideTravellerChoice() {
        this._elementRef.nativeElement.querySelector('.trvl-list').style.display = 'none';
    }

    saveBudgetAmount(newValue) {
        this.userSessionInfoRealoadCard.reloadCardScreen.budgetAmount = newValue;
        this.updateBalanceAmount();
    }

    updateBranch(newValue: number) {
        this.userSessionInfoRealoadCard.reloadCardScreen.branch = newValue;
        this.updateSession();
    }

    updateDestination(newValue: number) {
        this.userSessionInfoRealoadCard.reloadCardScreen.destination = newValue;
        this.masterService.getCurrencyList(1, this.userSessionInfoRealoadCard.reloadCardScreen.destination.split('#')[0])
            .subscribe(data => {
                this.currencyList = data;
            });
        this.updateSession();
    }

    updateCurrencyCode(prepaidDetailIndex: number, currencyIndex: number, newValue: string) {
        this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
            .currencyDetails[currencyIndex].currencyCode = newValue ? newValue : 'USD';
        // tslint:disable-next-line:max-line-length
        this.masterService.getExchangeRate(newValue ? newValue : 'USD', this.userSessionInfoRealoadCard.reloadCardScreen.branch, 'prepaid', 'buy')
            .subscribe(data => {
                const result: any = data;
                this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex]
                    .prepaidCardDetails[prepaidDetailIndex].currencyDetails[currencyIndex].exchangeRate = result;
                    if (result.rate !== 0 ) {
                        this.updateUsedAmount();
                        this.updateSession();
                        this.populateCurrencyRateForRule(this.CurrentBranchId);
                    }else {
                        Snackbar.show({
                            text: 'No Rates Found for <b>' + newValue + '</b>',
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                    }
            });
        this.updateSession();
    }

    updatePrepaidPurpose(newPurpose) {
        this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.purpose = newPurpose;


        this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].purposeCode =
            this.purposeOptions.filter((value, i) => value.value === newPurpose)[0].purposeCode;

        this.updateSession();
    }



    /*checkCardAvailable(prepaidCardDetail) {
        console.log('function call before service call');


        let data = this.masterService.checkCardAvailable(prepaidCardDetail.cardNo);
        console.log('function call');
        console.log(data);
        if (data) {
            this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.cardNo = prepaidCardDetail.cardNo;
        } else {
            console.log('in else');
            return false;
        }
    }*/

    updateValue(newValue, prepaidIndex, currencyIndex) {
        if (newValue === '' || isNaN(newValue)) {
            newValue = '0';
        }
        // tslint:disable-next-line:max-line-length
        const checkRateCondition =  this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidIndex]
        .currencyDetails[currencyIndex].exchangeRate.rate !== 0;
        if (checkRateCondition) {
            this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidIndex]
            .currencyDetails[currencyIndex].forexAmount = parseFloat(newValue);
        this.updateUsedAmount();
        }else {
            this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidIndex]
            .currencyDetails[currencyIndex].forexAmount = '' ;
        }

    }

    updateUsedAmount() {
        let travellerTotal = 0;
        this.userSessionInfoRealoadCard.reloadCardScreen.traveller.forEach(traveller => {
            let currentTravellerTotal = 0;
            this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.forEach(element => {
                element.currencyDetails.forEach(elementCurrency => {
                    if (!(elementCurrency.forexAmount === undefined || elementCurrency.exchangeRate === undefined)) {
                        currentTravellerTotal += elementCurrency.forexAmount * elementCurrency.exchangeRate.rate;
                    }
                });
            });
            travellerTotal += currentTravellerTotal;
            traveller.usedAmount = currentTravellerTotal;
        });

        this.userSessionInfoRealoadCard.reloadCardScreen.usedAmount = travellerTotal;

        if (this.userSessionInfoRealoadCard.reloadCardScreen.usedAmount !== 0) {
            this.masterService.getTaxes(this.userSessionInfoRealoadCard.reloadCardScreen.usedAmount)
                .subscribe(res => {
                    const result: any = res;
                    this.userSessionInfoRealoadCard.reloadCardScreen.usedAmount += result.TotalTax;
                    this.updateBalanceAmount();
                }, err => {
                    // swal('Oops', 'Error fetching taxes', 'error');
                    Snackbar.show({
                        text: 'Oops! Error fetching taxes',
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                });
        }

        this.updateBalanceAmount();
    }

    updateBalanceAmount() {
        if (Number.isNaN(Number.parseInt(this.userSessionInfoRealoadCard.reloadCardScreen.budgetAmount))) {
            this.userSessionInfoRealoadCard.reloadCardScreen.balanceAmount = '0';
        } else if (this.userSessionInfoRealoadCard.reloadCardScreen.budgetAmount !== '0'
            && this.userSessionInfoRealoadCard.reloadCardScreen.budgetAmount !== 0) {
            this.userSessionInfoRealoadCard.reloadCardScreen.balanceAmount = (this.userSessionInfoRealoadCard.reloadCardScreen.budgetAmount
                - this.userSessionInfoRealoadCard.reloadCardScreen.usedAmount).toString();
            this.userSessionInfoRealoadCard.reloadCardScreen.balanceAmount =
                // tslint:disable-next-line:max-line-length
                this.userSessionInfoRealoadCard.reloadCardScreen.balanceAmount < 0 ? 0 : this.userSessionInfoRealoadCard.reloadCardScreen.balanceAmount;
            if (this.userSessionInfoRealoadCard.reloadCardScreen.budgetAmount
                - this.userSessionInfoRealoadCard.reloadCardScreen.usedAmount <= 0) {
                // swal('Oops', 'You have exceeded your budget!!', 'warning');
                Snackbar.show({
                    text: 'Oops! You have exceeded your budget',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
            }
        }
        this.updateSession();
    }

    addMoreCard(travellerIndex: any) {
        this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.push({
        });
        this.addMoreCurrency();
        this.updateSession();
    }

    addMoreCurrency() {
        const prepaidCardIndex = this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex]
            .prepaidCardDetails.length - 1;
        if (this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex]
            .prepaidCardDetails[prepaidCardIndex].currencyDetails !== undefined) {
            console.log('added currency details' + this.currentTravellerIndex + 'prepaidcardindex' + prepaidCardIndex);
            this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex]
                .prepaidCardDetails[prepaidCardIndex].currencyDetails.push({});
        } else {
            this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex]
                .prepaidCardDetails[prepaidCardIndex].currencyDetails = [{}];
        }
        this.updateSession();
    }

    removeCurrencyRegion(prepaidIndex: any, currencyIndex: any) {
        console.log('removed currency of ' + prepaidIndex + ' with currency index' + currencyIndex);
        this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex]
            .prepaidCardDetails[prepaidIndex].currencyDetails.splice(currencyIndex, 1);
        this.updateSession();
    }

    removePrepaidRegion(travellerIndex: number, prepaidIndex: number) {
        console.log('taveller:' + this.currentTravellerIndex + ' prepaidIndex' + prepaidIndex);
        this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.splice(prepaidIndex, 1);
        this.updateUsedAmount();
    }

    // remove traveller
    removeTraveller(index: number) {
        if (!this.userSessionInfoRealoadCard.reloadCardScreen.traveller[index].lead) {
            if (this.userSessionInfoRealoadCard.reloadCardScreen.traveller[index].selected) {
                this.selectTraveller(index === 0 ? 1 : index - 1);
            }
            if (this.userSessionInfoRealoadCard.reloadCardScreen.traveller[index].registrationInfo.contactDetails.emailId === '') {
                if (this._elementRef.nativeElement.querySelector('#chkbox-new-' + this.newTravellerCount) !== null) {
                    this._elementRef.nativeElement.querySelector('#chkbox-new-' + this.newTravellerCount).checked = false;
                }
                this.newTravellerCount--;
            }
            this.userSessionInfoRealoadCard.reloadCardScreen.traveller.splice(index, 1);
            this.updateUsedAmount();
        } else {
            // swal('Sorry', 'You cannot remove lead pax. Change any other traveler to lead before this operation', 'error');
            Snackbar.show({
                text: 'Sorry! You cannot remove lead pax. Change any other traveler to lead before this operation',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
        }
        this.updateSession();
    }

    // select traveller
    selectTraveller(travellerIndex) {
        this.currentTravellerIndex = travellerIndex;

        this.userSessionInfoRealoadCard.reloadCardScreen.traveller.forEach(traveller => {
            traveller.selected = false;
        });

        this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].selected = true;
        this.updateSession();
    }

    addTravellerOption() {
        this.isLoggedIn ? this.showTravellerChoice() : this.addTraveller();
        this.selectTraveller(this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length - 1);
    }

    // add traveller
    addTraveller() {
        if (this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length < 4) {
            this.userSessionInfoRealoadCard.reloadCardScreen.traveller.push({
                'prepaidCard': true,
                'purpose': '',
                'selected': false,
                'serviceCharge' : 0,
                'loadFees' : 0,
                'reloadFees' : 0,
                'activationFees' : 0,
                'discount' : 0,
                'charges' : 0,
                'prepaidCardDetails': [{
                    'cardNo': '',
                    'currencyDetails': [
                        {
                            'currencyCode': '',
                            'forexAmount': '',
                            'promisedRate': '',
                            'promisedRateTime': '',
                            'startTime': ''
                        }]

                }],
                'cash': false,
                'registrationInfo': {
                    'userId': '',
                    'invoiceNo': null,
                    'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                    'middleName': '',
                    'lastName': '',
                    'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
                    'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                    'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
                    // "nationality": { "id": "", "name": "" } ,
                    'nationality': '',
                    'mothersMaidenName': {
                        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                            + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                            + 'event.target.style.background=\'#f8f8f8\'}'
                    },
                    'PAN': {
                        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                            + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                            + 'event.target.style.background=\'#f8f8f8\'}'
                    },
                    'passportNumber': '',
                    'ParentId': true,
                    'dateOfIssue': '',
                    'placeOfIssue': '',
                    'expiryDate': '',
                    'address': '101 5A Galaxy apartment',
                    'isPassportAddressAsAdhar': 'yes',
                    'adharAddress': {
                        'flatNumber': '',
                        'buildingName': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': '',
                    },
                    'passportAddress': {
                        'flatNumber': '',
                        'buildingName': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': '',
                    },
                    'currentAddressAs': 'asPerAdhar',
                    'otherAddress': {
                        'flatNumber': '',
                        'buildingName': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': '',
                    },
                    'contactDetails': {
                        'mobileNo': '',
                        'emailId': ''
                    },
                    'alternateContactDetails': {
                        'countryCode': '',
                        'mobileNo': '',
                        'countryCode2': '',
                        'cityCode': '',
                        'telephoneNo': '',
                        'emailId': '',
                    },
                    'officeAddress': {
                        'designation': '',
                        'conpanyName': '',
                        'companyDivision': '',
                        'flatNumber': '',
                        'building': '',
                        'streetName': '',
                        'landmark': '',
                        'area': '',
                        'city': '',
                        'state': '',
                        'pincode': ''
                    },
                    'officeContactDetails': {
                        'countryCode': '',
                        'telephoneNumber': '',
                        'officeExtension': '',
                    },
                    'password': '',
                    'confirmPassword': '',
                },
                'travellingDetails': {
                    'dateOfTravel': '',
                    'dateOfArrival': '',
                    'airlineName': '',
                    'ticketNumber': ''
                },
                'PaymentDetails': {
                    'PaymentStatus': 'Fully Paid',
                    'PaymentMode': 'Online Credit Card',
                    'Amount': '6945.00',
                    'PaymentDateTime': 'Jul 27, 2016 13:50 PM',
                    'TransactionId': 'ID986524586',
                    'Last4DigitCardNum': 'xxx xxx xxxx 4646',
                    'CardHolderName': 'Kaushar R',
                    'CreditCardType': 'Visa',
                    'PaymentReceiptNo': 'CKF11',
                    'PaymentReceiptDate': '9 Jun 2016 11:01 am',
                    'OrderType': 'Buy Forex'
                },
                'ForexDetails': {
                    'TravellerName': 'Kaushal Ranpura',
                    'InvoiceNum': 'CNF 12352',
                    'PurposeOfTravel': 'Business',
                    'ForexProduct': 'Forex Card',
                    'bank': 'Axis Bank',
                    'AccoutNumber': '4986801000358796',
                    'ForexAmount': 'USD 100',
                    'AppliedRate': '68.23',
                    'TotalTransactionValue': '6,823.00',
                    'Discount': '0',
                    'TotalAfterDisc': '6723.00',
                    'DelivaryCharges': '150.00',
                    'taxes': {
                        'OnFxTrns': '45.00',
                        'OnServCharge': '27.00'
                    },
                    'TotalPayable': '6,945'

                },
                'deliveryInfo': {
                    'Mode': 'At Home',
                    'type': 'Standard Delivery',
                    'DeliverySchedule': {
                        'date': '7 Mar 2017',
                        'time': '3:00 pm to 4:00 pm'
                    }
                }
            });
        } else {
            // swal('Oops', 'Maximum 4 travellers allowed!', 'error');
            Snackbar.show({
                text: 'Oops! Maximum 4 travellers allowed',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
        }
        this.updateSession();
    }

    updateSession() {
        SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfoRealoadCard));
    }

    // submitAndRedirect() {
    //     this.userSessionInfoRealoadCard['nextLink'] = '/reload-card/checklist';
    //     this.updateSession();
    //     if (this.validateSession()) {
    //         this.masterService.dumpSessionData(this.userSessionInfoRealoadCard)
    //             .subscribe(data => {
    //             }, err => {
    //                 console.log(err);
    //             });
    //         this.router.navigateByUrl(this.navUrl.navUrl() + '/reload-card/checklist');
    //     }
    // }

    submitAndRedirect() {
       //  this.populateCurrencyRateForRule(this.CurrentBranchId);
        this.userSessionInfoRealoadCard['nextLink'] = '/reload-card/checklist';
         this.updateSession();
        if (this.validateSession()) {
            // this.checkCard();
              this.masterService.RuleTest(this.userSessionInfoRealoadCard)
                .subscribe(data => {
                    const resData: any = JSON.parse(data);
                    if (resData.status === 1) {
                        this.checkCard();
                        this.masterService.dumpSessionData(this.userSessionInfoRealoadCard)
                            .subscribe(resD => {
                            }, err => {
                                console.log(err);
                            });
                        // this.router.navigateByUrl(this.navUrl.navUrl() + '/reload-card/checklist');

                    } else {
                        // swal('error', resData.message, 'error');
                        Snackbar.show({
                            text: resData.message,
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                    }
                });
        }
    }


    validateSession() {
        let result = true;

        if (this.userSessionInfoRealoadCard.reloadCardScreen.branch === ''
            || this.userSessionInfoRealoadCard.reloadCardScreen.branch === undefined) {
            // swal('Error', 'Please select branch', 'error');
            Snackbar.show({
                text: 'Please select branch!',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
            this.invalidsubmitted = true;
            result = false;
        } else if (this.userSessionInfoRealoadCard.reloadCardScreen.destination === ''
            || this.userSessionInfoRealoadCard.reloadCardScreen.destination === undefined) {
            // swal('Error', 'Please select destination', 'error');
            Snackbar.show({
                text: 'Please select destination!',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
            this.invalidsubmitted = true;
            result = false;
        } else {

            for (let travellerIndex = 0; travellerIndex < this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length;
                travellerIndex++) {
                const traveller = this.userSessionInfoRealoadCard.reloadCardScreen.traveller[travellerIndex];
                if (traveller.purpose === '' || traveller.purpose === undefined) {
                    // swal('Error', 'Please select purpose for traveler ' + (travellerIndex + 1), 'error');
                    Snackbar.show({
                        text: 'Please select purpose for traveler ' + (travellerIndex + 1),
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    this.selectTraveller(travellerIndex);
                    this.invalidsubmitted = true;
                    result = false;
                    break;
                }

                let index = 0, addedCardNos = [];
                for (; index < traveller.prepaidCardDetails.length; index++) {

                    const detail = traveller.prepaidCardDetails[index];
                    if (addedCardNos.indexOf(detail.cardNo) !== -1){
                        Snackbar.show({
                            text: 'Please input different card numbers for traveler ' + (travellerIndex + 1),
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                        this.selectTraveller(travellerIndex);
                        this.invalidsubmitted = true;
                        result = false;
                        break;
                    }
                    addedCardNos.push(detail.cardNo);
                    if (detail.cardNo == '' || detail.cardNo == undefined) {
                        // swal('Error', 'Please card number for traveler ' + (travellerIndex + 1), 'error');
                        Snackbar.show({
                            text: 'Please card number for traveler ' + (travellerIndex + 1),
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                        this.selectTraveller(travellerIndex);
                        this.invalidsubmitted = true;
                        result = false;
                        break;
                    }
                    else {

                        /* if (!this.checkCardAvailable(detail)) {
                             console.log('card not march');
                             result = false;
                             break;
                         }*/
                    }

                    let currrencyIndex = 0;
                    for (; currrencyIndex < detail.currencyDetails.length; currrencyIndex++) {
                        const currencyDetail = detail.currencyDetails[currrencyIndex];

                        if (currencyDetail.currencyCode == '' || currencyDetail.currencyCode == undefined) {
                            // swal('Error', 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            this.invalidsubmitted = true;
                            result = false;
                            break;
                        }
                        if (currencyDetail.forexAmount === '' || currencyDetail.forexAmount === undefined || currencyDetail.forexAmount <= 0) {
                            // swal('Error', 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                            Snackbar.show({
                                text: 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1),
                                pos: 'bottom-right',
                                actionTextColor: '#ff4444',
                            });
                            this.selectTraveller(travellerIndex);
                            this.invalidsubmitted = true;
                            result = false;
                            break;
                        }
                    }

                    if (currrencyIndex < detail.currencyDetails.length) { break; }
                }

                if (index < traveller.prepaidCardDetails.length) {
                    break;
                }
            }
        }
        return result;
    }


    selected($event) {
        this.CurrentBranchId = $event.BranchID;
        SessionHelper.setLocal('branchIdFromOverview', $event.BranchID);
        SessionHelper.setLocal('branchIdFromOverviewReload', $event.BranchID);
        if ($event.BranchCode) {
            this.userSessionInfoRealoadCard.reloadCardScreen.BranchCode = $event.BranchCode;
            this.updateSession();
          }
       this.populateCurrencyRateForRule(this.CurrentBranchId);
    }

    checkCard() {
        let cardIndex = 0;
        let maxIndex = 0;
        let proceed = true;

        Snackbar.show({
            text: 'Validating your card , please wait ',
            pos: 'bottom-right',
            actionTextColor: '#05ff01',
            duration: 900000
        });




        for (let travellerIndex = 0; travellerIndex < this.userSessionInfoRealoadCard.reloadCardScreen.traveller.length;
            travellerIndex++) {
            const traveller = this.userSessionInfoRealoadCard.reloadCardScreen.traveller[travellerIndex];

            for (let index = 0; index < traveller.prepaidCardDetails.length; index++) {
                maxIndex++;
                console.log(maxIndex);

                const detail = traveller.prepaidCardDetails[index];

                this.masterService.checkCardAvailable(detail.cardNo)
                    .subscribe(data => {
                        cardIndex++;
                        // tslint:disable-next-line:max-line-length
                        if (data) {
                            console.log(data);
                            console.log(cardIndex);

                            this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.cardNo = detail.cardNo;
                            //defaultV = true;
                            const retData: any = data;

                            if (retData.status === false) {
                                proceed = false;
                                Snackbar.show({
                                    text: 'Invalid card number ' + detail.cardNo,
                                    pos: 'bottom-right',
                                    actionTextColor: '#ff4444',
                                });
                            }


                            if (cardIndex === maxIndex) {
                                if (proceed === true) {
                                    Snackbar.show({ duration: 1 });
                                    this.router.navigateByUrl(this.navUrl.navUrl() + '/reload-card/checklist');
                                }

                            }

                        }
                    });



                // , err => {
                //     detail.cardNo = null;
                //     this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.cardNo = '';
                //     // swal('Oops', 'Card No does not match in system', 'error');
                //     Snackbar.show({
                //         text: 'Oops! Card No does not match in system',
                //         pos: 'bottom-right',
                //         actionTextColor: '#ff4444',
                //     });
                //     console.log('not working');
                // });




            }


        }
    }






    // check card no available in I exchange
    checkCardAvailable(prepaidCardDetail) {
        let defaultV;
        console.log(prepaidCardDetail);
        this.masterService.checkCardAvailable(prepaidCardDetail.cardNo)
            .subscribe(data => {
                // tslint:disable-next-line:max-line-length
                if (data) {
                    this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.cardNo = prepaidCardDetail.cardNo;
                    defaultV = true;
                } else {
                    defaultV = false;
                }

            }, err => {
                prepaidCardDetail.cardNo = null;
                this.userSessionInfoRealoadCard.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.cardNo = '';
                // swal('Oops', 'Card No does not match in system', 'error');
                Snackbar.show({
                    text: 'Oops! Card No does not match in system',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                console.log('not working');

                defaultV = false;
            });

        return defaultV;
    }

    canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
        if (this.navigate === true) {
            return true;
        } else {
            Snackbar.show({
                text: 'You can not go back from this page. Please go through application flow.',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
                duration: 3000
            });
            window.scrollTo(0, 0);
            this.navigate = true;
            return false;
        }
    }
}
