import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReloadOverviewComponent } from './reload-overview.component';

describe('ReloadOverviewComponent', () => {
  let component: ReloadOverviewComponent;
  let fixture: ComponentFixture<ReloadOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReloadOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReloadOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
