import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-account-adhar',
  templateUrl: './create-account-adhar.component.html',
  styleUrls: ['./create-account-adhar.component.css']
})
export class CreateAccountAdharComponent implements OnInit {

  constructor() {

  }

  ngOnInit() {

  }



}
