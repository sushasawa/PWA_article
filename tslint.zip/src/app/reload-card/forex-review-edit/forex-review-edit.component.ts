import { Component, OnInit } from '@angular/core';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { Constants } from '../../../app/helpers/constants';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { DpDatePickerModule } from 'ng2-date-picker';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;
declare function initForms(): any;
declare var $: any;
declare var Snackbar: any;
declare function swal(headerMessage, message, type): any;
@Component({
  selector: 'app-forex-review-edit',
  templateUrl: './forex-review-edit.component.html',
  styleUrls: ['./forex-review-edit.component.css']
})
export class ForexReviewEditComponent implements OnInit {
  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public discount: any;
  public serviceCharge: any;
  public gst: any;
  public reloadFees: any;
  public TotalPayableMultiTraveller: any;
  public currencyLists: any = [];
  public popupData: any;
  public config: any;
  public todaysDate: any;
  public airlineNames: any;
  public currencyList: any;
  public _primaryComp: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router) {
    // console.log(SessionHelper.getSession('userSessionInfoRealoadCard'));
    this.discount = 0;
    this.serviceCharge = 0;
    this.gst = 0;
    this.reloadFees = 0;
    this.TotalPayableMultiTraveller = 0;
    this._primaryComp = '/' + navUrl.navUrl();
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoRealoadCard'));
    this.userSessionInfoRegistration = this.userSessionInfo.reloadCardScreen.traveller[0].registrationInfo;
    this.userSessionInfoTravellingDetails = this.userSessionInfo.reloadCardScreen.traveller[0].travellingDetails;

    this.userSessionInfoTravellers = this.userSessionInfo.reloadCardScreen.traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.reloadCardScreen.traveller[0];

    // this.TotalPayableMultiTraveller = this.TotalPayableMultiTraveller;
    this.userSessionInfoTravellers[0].selected = true;
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];
    this.masterService.getCurrencyList(1).subscribe((data) => {
      this.currencyLists = data;
    });
    this.getCharges()
    // this.syncSession();
    this.masterService.getAirlineNames()
      .subscribe(data => {
        this.airlineNames = data;
      });

    this.todaysDate = this.masterService.getTodaysDate();
    this.config = {
      format: 'DD-MM-YYYY',
      showMultipleYearsNavigation: true,
      disableKeypress: true,
      min: this.todaysDate,
    };
    this.userSessionInfoTravellers[0].selected = true;
    const destination = this.userSessionInfo.reloadCardScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(1, destination)
      .subscribe(data => {
        this.currencyList = data;
      });
  }

  ngOnInit() {
    $('body').attr('id', '');
    initDocument();
    this.userSessionInfoTravellers[0].selected = true;
  }
  
  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.serviceCharge = Charges.response.serviceCharge;
      this.reloadFees = Charges.response.LoadFee;
      this.syncSession();
      
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
    // console.log(this.userSessionInfoSelectedTraveller);
  }


  travellingStartDate(event, TravellerIndex) {
    console.log(event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfoTravellers[TravellerIndex].travellingDetails.dateOfTravel = event;
    }
  }

  travellingArrivaltDate(event, TravellerIndex) {
    console.log(event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfoTravellers[TravellerIndex].travellingDetails.dateOfArrival = event;
    }
  }

  syncSession() {
    let totalAmount: any = 0;
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      let charges = 0;
      totalAmount = 0;
      traveller.prepaidCardDetails.map((prepaidCardDetail) => {
        prepaidCardDetail.currencyDetails.map((currency) => {
          totalAmount += (currency.forexAmount * currency.exchangeRate.rate) - this.discount;
        });
      });
      traveller.totalAmount = totalAmount + this.serviceCharge + this.reloadFees;
      charges += this.serviceCharge + this.reloadFees;
      this.userSessionInfo.reloadCardScreen.traveller[index].totalAmount = traveller.totalAmount;
      const totalTaxableAmount = totalAmount + this.serviceCharge + this.reloadFees;
      this.masterService.getTaxes(totalTaxableAmount).subscribe((data) => {
        const result: any = data;
        traveller.totalAmount += result.TotalTax;
        traveller.gst = result.TotalTax;
        // charges += result.TotalTax;
        traveller.Charges = charges;
        // tslint:disable-next-line:radix
        this.TotalPayableMultiTraveller += parseInt(traveller.totalAmount);
        this.userSessionInfo.reloadCardScreen.usedAmount = this.TotalPayableMultiTraveller;
        SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
        // this.updateSession();
        totalAmount = 0;
      });
    });
  }

  updateCurrencyCode(TravellerIndex: any, prepaidDetailIndex: number, currencyIndex: number, newValue: string) {
    // tslint:disable-next-line:max-line-length
    // console.log('TravellerIndex '+TravellerIndex+ 'prepaidDetailIndex '+prepaidDetailIndex+' currencyIndex'+currencyIndex+' currency'+newValue);
    this.userSessionInfoTravellers[TravellerIndex].prepaidCardDetails[prepaidDetailIndex]
      .currencyDetails[currencyIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.reloadCardScreen.branch, 'prepaid', 'buy')
      .subscribe(data => {
        this.userSessionInfoTravellers[TravellerIndex]
          .prepaidCardDetails[prepaidDetailIndex].currencyDetails[currencyIndex].exchangeRate = data;
        this.syncSession();
      });

  }

  updateReview(editReview: NgForm, e: Event) {
    e.preventDefault();
    //  console.log(this.userSessionInfo);
    if (this.validateSession()) {
      this.masterService.RuleTest(this.userSessionInfo)
        .subscribe(data => {
          const resData: any = JSON.parse(data);
          if (resData.status === 1) {
            SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
            Snackbar.show({
              text: 'Updated .',
              pos: 'bottom-right',
              actionTextColor: '#05ff01',
            });
            this.router.navigateByUrl(this.navUrl.navUrl() + '/reload-card/forex-review');
          } else {
            // swal('error', resData.message, 'error');
            Snackbar.show({
              text: resData.message,
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
            });
          }
        });
    }
  }

  updateUsedAmount() {
    let travellerTotal = 0;
    this.userSessionInfo.reloadCardScreen.traveller.map((traveller, TravellerIndex) => {
      let currentTravellerTotal = 0;
      this.userSessionInfo.reloadCardScreen.traveller[TravellerIndex].prepaidCardDetails.forEach(element => {
        element.currencyDetails.forEach(elementCurrency => {
          if (!(elementCurrency.forexAmount === undefined || elementCurrency.exchangeRate === undefined)) {
            currentTravellerTotal += elementCurrency.forexAmount * elementCurrency.exchangeRate.rate;
          }
        });
      });
      travellerTotal += currentTravellerTotal;
      traveller.usedAmount = currentTravellerTotal;
    });

    this.userSessionInfo.reloadCardScreen.usedAmount = travellerTotal;

    if (this.userSessionInfo.reloadCardScreen.usedAmount !== 0) {
      this.masterService.getTaxes(this.userSessionInfo.reloadCardScreen.usedAmount)
        .subscribe(res => {
          const result: any = res;
          this.userSessionInfo.reloadCardScreen.usedAmount += result.TotalTax;
          this.updateBalanceAmount();
        }, err => {
          // swal('Oops', 'Error fetching taxes', 'error');
          Snackbar.show({
            text: 'Oops! Error fetching taxes',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        });
    }

    this.updateBalanceAmount();
  }

  updateBalanceAmount() {
    if (Number.isNaN(Number.parseInt(this.userSessionInfo.reloadCardScreen.budgetAmount))) {
      this.userSessionInfo.reloadCardScreen.balanceAmount = '0';
    } else if (this.userSessionInfo.reloadCardScreen.budgetAmount !== '0'
      && this.userSessionInfo.reloadCardScreen.budgetAmount !== 0) {
      this.userSessionInfo.reloadCardScreen.balanceAmount = (this.userSessionInfo.reloadCardScreen.budgetAmount
        - this.userSessionInfo.reloadCardScreen.usedAmount).toString();
      this.userSessionInfo.reloadCardScreen.balanceAmount =
        // tslint:disable-next-line:max-line-length
        this.userSessionInfo.reloadCardScreen.balanceAmount < 0 ? 0 : this.userSessionInfo.reloadCardScreen.balanceAmount;
      if (this.userSessionInfo.reloadCardScreen.budgetAmount
        - this.userSessionInfo.reloadCardScreen.usedAmount <= 0) {
        // swal('Oops', 'You have exceeded your budget!!', 'warning');
        Snackbar.show({
          text: 'Oops! You have exceeded your budget',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }
    }

  }

  validateSession() {
    let result = true;

    if (this.userSessionInfo.reloadCardScreen.branch === ''
        || this.userSessionInfo.reloadCardScreen.branch === undefined) {
        // swal('Error', 'Please select branch', 'error');
        Snackbar.show({
            text: 'Please select branch!',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
        });
        // this.invalidsubmitted = true;
        result = false;
    } else if (this.userSessionInfo.reloadCardScreen.destination === ''
        || this.userSessionInfo.reloadCardScreen.destination === undefined) {
        // swal('Error', 'Please select destination', 'error');
        Snackbar.show({
            text: 'Please select destination!',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
        });
        // this.invalidsubmitted = true;
        result = false;
    } else {

        for (let travellerIndex = 0; travellerIndex < this.userSessionInfo.reloadCardScreen.traveller.length;
            travellerIndex++) {
            const traveller = this.userSessionInfo.reloadCardScreen.traveller[travellerIndex];
            if (traveller.purpose === '' || traveller.purpose === undefined) {
                // swal('Error', 'Please select purpose for traveler ' + (travellerIndex + 1), 'error');
                Snackbar.show({
                    text: 'Please select purpose for traveler ' + (travellerIndex + 1),
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.selectTraveller(travellerIndex);
                // this.invalidsubmitted = true;
                result = false;
                break;
            }

            let index = 0, addedCardNos = [];
            for (; index < traveller.prepaidCardDetails.length; index++) {

                const detail = traveller.prepaidCardDetails[index];
                if (addedCardNos.indexOf(detail.cardNo) !== -1){
                    Snackbar.show({
                        text: 'Please input different card numbers for traveler ' + (travellerIndex + 1),
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    this.selectTraveller(travellerIndex);
                    // this.invalidsubmitted = true;
                    result = false;
                    break;
                }
                addedCardNos.push(detail.cardNo);
                if (detail.cardNo == '' || detail.cardNo == undefined) {
                    // swal('Error', 'Please card number for traveler ' + (travellerIndex + 1), 'error');
                    Snackbar.show({
                        text: 'Please card number for traveler ' + (travellerIndex + 1),
                        pos: 'bottom-right',
                        actionTextColor: '#ff4444',
                    });
                    this.selectTraveller(travellerIndex);
                    // this.invalidsubmitted = true;
                    result = false;
                    break;
                }
                else {

                    /* if (!this.checkCardAvailable(detail)) {
                         console.log('card not march');
                         result = false;
                         break;
                     }*/
                }

                let currrencyIndex = 0;
                for (; currrencyIndex < detail.currencyDetails.length; currrencyIndex++) {
                    const currencyDetail = detail.currencyDetails[currrencyIndex];

                    if (currencyDetail.currencyCode == '' || currencyDetail.currencyCode == undefined) {
                        // swal('Error', 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                        Snackbar.show({
                            text: 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1),
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                        this.selectTraveller(travellerIndex);
                        // this.invalidsubmitted = true;
                        result = false;
                        break;
                    }
                    if (currencyDetail.forexAmount === '' || currencyDetail.forexAmount === undefined || currencyDetail.forexAmount <= 0) {
                        // swal('Error', 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                        Snackbar.show({
                            text: 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1),
                            pos: 'bottom-right',
                            actionTextColor: '#ff4444',
                        });
                        this.selectTraveller(travellerIndex);
                        // this.invalidsubmitted = true;
                        result = false;
                        break;
                    }
                }

                if (currrencyIndex < detail.currencyDetails.length) { break; }
            }

            if (index < traveller.prepaidCardDetails.length) {
                break;
            }
        }
    }
    return result;
}


}
