import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from 'ng-select';
import { CanDeactivateGuard } from '../services/can-deactivate-guard.service';
import { ForexCommonModule } from '../forex-common/forex-common.module';
import { PipesModule } from '../pipes/pipes.module';
import { ReloadOverviewComponent } from './reload-overview/reload-overview.component';
import { MasterService } from '../services/master.services';
import { AuthService } from '../services/auth.service';
import { AuthGuardService as AuthGuard } from '../services/auth-guard.service';
import { CreateAccountAdharComponent } from './create-account-adhar/create-account-adhar.component';
import { ForexReviewComponent } from './forex-review/forex-review.component';
import {DpDatePickerModule} from 'ng2-date-picker';
import { CommonChecklistComponent } from '../forex-common/common-checklist/common-checklist.component';
import { CommonFormComponent } from '../forex-common/common-form/common-form.component';
import { CommonUsercreationComponent } from '../forex-common/common-usercreation/common-usercreation.component';
import { CommonRegisterLoginComponent } from '../forex-common/common-register-login/common-register-login.component';
import { CommonRegisterLoginAdharComponent } from '../forex-common/common-register-login-adhar/common-register-login-adhar.component';
import { CommonConfirmationComponent } from '../forex-common/common-confirmation/common-confirmation.component';
import { CommonReviewUserDetailsComponent } from '../forex-common/common-review-user-details/common-review-user-details.component';



import { CommonPaymentGatewayComponent } from '../forex-common/common-payment-gateway/common-payment-gateway.component';
import { FailComponent } from '../forex-common/fail/fail.component';
import { ForexReviewEditComponent } from './forex-review-edit/forex-review-edit.component';

const sessDataObj: any = {
  sessionDataProcess: 'userSessionInfoRealoadCard',
  sessionDataProcessScreen: 'reloadCardScreen',
  processType: 'Reload'
};


const routes: Routes = [
  {
    path: '', children: [
      { path: '', component: ReloadOverviewComponent, canDeactivate: [CanDeactivateGuard] },
      {
        path: 'checklist',
        component: CommonChecklistComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '2',
          nextLink: '/reload-card/register-login'
        }
      },
      {
        path: 'register-login', component: CommonRegisterLoginComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/reload-card/review-userdetail-adhar'
        }
      },
      {
        path: 'register-login-adhar',
        component: CommonRegisterLoginAdharComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
        }
      },
      { path: 'create-account-adhar', component: CreateAccountAdharComponent,
      data: {
        sessData: sessDataObj,
        wizardStepNumber: '3',
        nextLink: '/reload-card/review-userdetail-adhar'
      } },
      {
        path: 'review-userdetail-adhar', component: CommonReviewUserDetailsComponent,
        // canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/reload-card/forex-review'
        }
      },
      { path: 'forex-review', component: ForexReviewComponent, canActivate: [AuthGuard] },
      { path: 'forex-review-edit', component: ForexReviewEditComponent, canActivate: [AuthGuard] },
      {
        path: 'lrs-form', component: CommonFormComponent, canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '5',
          nextLink: '/reload-card/payment-gateway'
        }
      },
      {
        path: 'payment-gateway', component: CommonPaymentGatewayComponent, canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '6',
        }
      },
      {
        path: 'confirmation', component: CommonConfirmationComponent, canActivate: [AuthGuard],
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '7',
          deliveryMode: false,
          deliveryTxt: '',
          purpose: true
        }
      },
      {
        path: 'create-account', component: CommonUsercreationComponent,
        data: {
          sessData: sessDataObj,
          wizardStepNumber: '3',
          nextLink: '/reload-card/review-userdetail-adhar'
        }
      },
      {
        path : 'fail',
        component : FailComponent
      }
    ]
  }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ForexCommonModule,
    PipesModule,
    SelectModule,
    DpDatePickerModule
  ],
  declarations: [ReloadOverviewComponent, CreateAccountAdharComponent, ForexReviewComponent, ForexReviewEditComponent],
  providers: [MasterService, AuthGuard, AuthService, CanDeactivateGuard],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})


export class ReloadCardModule { }
