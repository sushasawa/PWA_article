import { Component, OnInit } from '@angular/core';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { BulkExchangeRateService } from './../../services/bulk-exchange-rate.service';
import { Router } from '@angular/router';
declare var Snackbar: any;
declare var $: any;
declare function initDocument(): any;
@Component({
  selector: 'app-forex-review',
  templateUrl: './forex-review.component.html',
  styleUrls: ['./forex-review.component.css']
})
export class ForexReviewComponent implements OnInit {
  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public discount: any;
  public serviceCharge: any;
  public gst: any;
  public reloadFees: any;
  public TotalPayableMultiTraveller: any;
  public currencyLists: any = [];
  public popupData: any;
  public _primaryComp: any;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _BulkExchangeRateService: BulkExchangeRateService) {
    // console.log(SessionHelper.getSession('userSessionInfoRealoadCard'));
    this.discount = 0;
    this.serviceCharge = 0;
    this.gst = 0;
    this.reloadFees = 0;
    this.TotalPayableMultiTraveller = 0;
    this.getCharges();
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoRealoadCard'));
    this.userSessionInfoRegistration = this.userSessionInfo.reloadCardScreen.traveller[0].registrationInfo;
    this.userSessionInfoTravellingDetails = this.userSessionInfo.reloadCardScreen.traveller[0].travellingDetails;
    this._primaryComp = '/' + navUrl.navUrl();
    this.userSessionInfoTravellers = this.userSessionInfo.reloadCardScreen.traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.reloadCardScreen.traveller[0];

  }

  syncSession() {
    let totalAmount: any = 0;
    let grantTotalAmount: any = 0;
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      let charges = 0;
      totalAmount = 0;
      traveller.selected = false;
      traveller.prepaidCardDetails.map((prepaidCardDetail) => {
        prepaidCardDetail.currencyDetails.map((currency) => {
          totalAmount += (currency.forexAmount * currency.exchangeRate.rate) - this.discount;
        });
      });
      traveller.totalAmount = totalAmount + this.serviceCharge + this.reloadFees;
      charges += this.serviceCharge + this.reloadFees;
      this.userSessionInfo.reloadCardScreen.traveller[index].totalAmount = traveller.totalAmount;
      let totalTaxableAmount = totalAmount + this.serviceCharge + this.reloadFees;

      this.masterService.getTaxes(totalTaxableAmount).subscribe((data) => {
        const result: any = data;
        totalTaxableAmount += result.TotalTax;
        traveller.totalAmount = totalTaxableAmount;
        traveller.gst = result.TotalTax;
        // charges += result.TotalTax;
        traveller.Charges = charges;
        grantTotalAmount += parseInt(traveller.totalAmount);
        this.userSessionInfo.reloadCardScreen.usedAmount = grantTotalAmount;
        SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
        this.updateSession();
        totalAmount = 0;
      });
      this.updateSession();
    });
    // this.TotalPayableMultiTraveller = this.TotalPayableMultiTraveller;
    this.userSessionInfoTravellers[0].selected = true;
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];
    this.masterService.getCurrencyList(1).subscribe((data) => {
      this.currencyLists = data;
    });
  }

  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.serviceCharge = Charges.response.serviceCharge;
      this.reloadFees = Charges.response.LoadFee;
      this.syncSession();
      this.updateSession();

    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }
  ngOnInit() {
    $('body').attr('id', '');
    initDocument();
}
  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
    // console.log(this.userSessionInfoSelectedTraveller);
  }

  populatePopup(currencyCode, forexAmount, exchangeRate) {
    this.currencyLists.map((currency, index) => {
      if (currency.Code === currencyCode) {
        this.popupData =
          '1 ' + currency.label + ' = <i class="fa-rupee"></i>' + exchangeRate + '<br>' +
          forexAmount + ' ' + currency.Code + ' = ' + '<i class="fa-rupee"></i>' + (forexAmount * exchangeRate).toFixed(2);
      }
    });
  }

  onSaveAndTemporaryExit(isGenerateLink = false) {
    if (isGenerateLink) {
      console.log('%%%%%%%%%%%%', isGenerateLink);
      this.userSessionInfo.userId = this.userSessionInfo.tempUserId;
      const individualLeadData = {
        AgentId: JSON.parse(SessionHelper.getSession('userInfo')).uid,
        Url: '',
        FirstName: this.userSessionInfoTravellers[0].registrationInfo.firstName.value,
        MiddleName: this.userSessionInfoTravellers[0].registrationInfo.middleName,
        LastName: this.userSessionInfoTravellers[0].registrationInfo.lastName,
        City: this.userSessionInfo.reloadCardScreen.currentLocation.city,
        CountryCode: this.userSessionInfoTravellers[0].registrationInfo.contactDetails.countryCode,
        Mobile: this.userSessionInfoTravellers[0].registrationInfo.contactDetails.mobileNo,
        EmailId: this.userSessionInfoTravellers[0].registrationInfo.contactDetails.emailId,
        AlternateCountryCode: this.userSessionInfoTravellers[0].registrationInfo.alternateContactDetails.emailId,
        AlternateMobileNo: this.userSessionInfoTravellers[0].registrationInfo.alternateContactDetails.mobileNo,
        AlternateEmailId: this.userSessionInfoTravellers[0].registrationInfo.alternateContactDetails.emailId,
        TempNo: this.userSessionInfo.temporaryOrderNumber
      };
      this.updateSession();
      const mailData = [];
      mailData.push(individualLeadData);
      // console.log(test);
      this.masterService.sendMailLeadPax(mailData)
        .subscribe(data => {
          console.log(data);
        });
      this.userSessionInfo.EmailId = this.userSessionInfoTravellers[0].registrationInfo.contactDetails.emailId;
    }
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession('userSessionInfoReloadCard');
    this.router.navigateByUrl(this.navUrl.navUrl() + `/reload-card`);
  }

  submitAndRedirect() {
    this.masterService.dumpSessionData(this.userSessionInfo)
    .subscribe(data => {
    }, err => {
      console.log(err);
    });
    SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
    this.router.navigateByUrl(this.navUrl.navUrl() + '/reload-card/lrs-form');
  }



  updateSession() {
    SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
  }
}
