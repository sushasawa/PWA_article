import { TransactionService } from './../../services/transaction.service';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { SessionHelper } from '../../helpers/session-helper';
import { MasterService } from '../../../app/services/master.services';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { DatePipe } from '@angular/common';
import * as jsPDF from 'jspdf';
import * as d3 from 'd3';
import * as html2canvas from 'html2canvas';
import { parse } from 'querystring';
declare var Snackbar: any;
declare function initDocument(): any;
@Component({
  selector: 'app-common-confirmation',
  templateUrl: './common-confirmation.component.html',
  styleUrls: ['./common-confirmation.component.css']
})
export class CommonConfirmationComponent implements OnInit {
  public deliveryMode: any;
  public cardType: any;
  public deliveryTxt: any;
  public purpose: any;
  public currentSession: any;
  public pageSession: any;
  public deliverycharge: any;
  public discount: any = 0;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public gst: any;
  public userSessionInfo: any;
  public userSessionInfoSelectedTraveller: any;
  public userSessionInfoTravellers: any;
  public travellersAmount: any = [];
  public SessionInfo: any;
  public Switch: any;
  public exchangeRates: any = {};
  public sessionDataProcess: any;
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public orderType: any;
  public wizardStepNumber: any;
  public grantTotalAmount: any = 0;
  public temporaryOrderNumber;
  public travellerTotalAmount: any;
  public travellerOfficeAddress: any = [];
  public transactionId: any;
  public hiddenLogo: any = false;
  public reloadTotalIntArray: any = [];
  public orderDate: any;
  @ViewChild('printsection') element: ElementRef;
  // tslint:disable-next-line:max-line-length
  constructor(public masterService: MasterService, private navUrl: NavigatePathService, private route: ActivatedRoute, private router: Router, public _TransactionService: TransactionService) {
    SessionHelper.removeSession('userSessionInfo');
    SessionHelper.removeSession('userSessionInfoSale');
    SessionHelper.removeSession('userSessionInfoRealoadCard');
    SessionHelper.removeSession('userSessionInfoSend');
    this.serviceCharge = 10;
    this.activationFees = 10;
    this.loadFees = 10;
    this.gst = 72;


  }

  ngOnInit() {
    this.transactionId = this.route.snapshot.queryParams.transactionId; console.log(this.transactionId);
    this._TransactionService.getTransactionById(this.transactionId)
      .subscribe((data) => {
        console.log(data);
        const result: any = data;
        this.sessionDataProcess = this.route.snapshot.data.sessData.sessionDataProcess;
        this.sessionDataProcessScreen = this.route.snapshot.data.sessData.sessionDataProcessScreen;
        this.processType = this.getProcessType(this.sessionDataProcessScreen);
        this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;
        console.log('this.sessionDataProcess  :' + this.sessionDataProcess);
        console.log('this.sessionDataProcessScreen  :' + this.sessionDataProcessScreen);
        console.log('this.processType :' + this.processType);


        this.deliveryMode = JSON.parse(this.route.snapshot.data.deliveryMode);
        this.purpose = JSON.parse(this.route.snapshot.data.purpose);
        this.deliveryTxt = this.route.snapshot.data.deliveryTxt;
        this.orderDate = result[0].OrderDate;
        this.pageSession = result[0].UserSessionJson;
        this.currentSession = JSON.parse(result[0].UserSessionJson).type;
        this.SessionInfo = JSON.parse(result[0].UserSessionJson);
        this.userSessionInfo = this.SessionInfo[this.currentSession];

        this.userSessionInfoTravellers = this.SessionInfo[this.currentSession].traveller;
        this.userSessionInfoSelectedTraveller = this.SessionInfo[this.currentSession].traveller[0];

        this.temporaryOrderNumber = this.SessionInfo.temporaryOrderNumber;
        this.userSessionInfo.tranId = '';
        this.SessionInfo['is_complete'] = true;
        this.grantTotalAmount = this.userSessionInfo.usedAmount;
        console.log(this.userSessionInfo);

        this.userSessionInfo.traveller.forEach(traveller => {
          if (this.processType === 'Sell') {
            // this.getExchangeRates(traveller);
            // this.getTransactionCount(traveller);
          }
          // this.travellerTotalAmount += traveller.totalAmount;
          console.log('totalAmount', traveller.totalAmount);
          console.log('this.userSessionInfo.deliveryInfo.rate', Number(this.userSessionInfo.deliveryInfo.rate));
          console.log('traveller.serviceCharge', traveller.serviceCharge);
          console.log('traveller.activationFees', traveller.activationFees);
          console.log('traveller.loadFees', traveller.loadFees);
          console.log('traveller.gst', traveller.loadFees);
        });



        if (this.processType === 'Reload') {
          console.log('this.userSessionInfoSelectedTraveller.prepaidCardDetail', this.userSessionInfoSelectedTraveller.prepaidCardDetails);
          this.userSessionInfoSelectedTraveller.prepaidCardDetails.forEach(prepaidDetail => {
            let reloadInternal: any = 0;
            prepaidDetail.currencyDetails.forEach(currencyDetail => {
              reloadInternal += currencyDetail.forexAmount * currencyDetail.exchangeRate.rate;
            });
            this.reloadTotalIntArray.push(reloadInternal);
          });
           console.log('this.reloadTotalIntArray', this.reloadTotalIntArray);
        }


        this.masterService.dumpSessionData(this.SessionInfo)
          .subscribe(data => {
          }, err => {
            console.log(err);
          });
        this.masterService.releaseTempNo(this.SessionInfo.temporaryOrderNumber)
          .subscribe(data => {
          }, err => {
            console.log(err);
          });
          initDocument();

      });

    // this.grantTotalAmount = 0;
    // this.travellerTotalAmount = 0;

    // this.calculateGTotalAmount();
    this.updateSession();
    // SessionHelper.removeSession(this.pageSession);

    this.setOrderType();
  }


  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.traveller[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }




  // calculateGTotalAmount() {
  //   if (this.processType === 'Sell') {
  //     this.grantTotalAmount = this.getSellTotalAmount();
  //   } else {
  //     this.grantTotalAmount = this.getOtherTotalAmount();
  //   }
  // }

  // getCharges() {
  //   this.masterService.getCharges().subscribe((data) => {
  //     const Charges: any = data;
  //     this.serviceCharge = Charges.response.serviceCharge;
  //     this.loadFees = Charges.response.LoadFee;
  //     this.activationFees = Charges.response.ActivationCharge;
  //   }, (error) => {
  //     Snackbar.show({
  //       text: 'Error fetching Charges',
  //       pos: 'bottom-right',
  //       actionTextColor: '#ff4444',
  //     });
  //   });
  // }

  // getSellTotalAmount() {
  //   this.masterService.getTaxes(this.travellerTotalAmount).subscribe((data) => {
  //     const result: any = data;
  //     this.travellerTotalAmount -= (result.TotalTax + this.serviceCharge + this.loadFees + this.activationFees);
  //     this.gst = result.TotalTax;
  //     this.grantTotalAmount = this.travellerTotalAmount;
  //   });
  // }

  // getOtherTotalAmount() {
  //   this.masterService.getTaxes(this.travellerTotalAmount).subscribe((data) => {
  //     const result: any = data;
  //     this.travellerTotalAmount += (result.TotalTax + this.serviceCharge + this.loadFees + this.activationFees);
  //     this.gst = result.TotalTax;
  //     this.grantTotalAmount = this.travellerTotalAmount;
  //   });
  // }

  setOrderType() {   console.log('ORDER TYPE CALLED ' + this.processType);
    switch (this.processType) {
      case 'Buy':
        this.orderType = 'Buy Forex';
        break;
      case 'Sell':
        this.orderType = 'Sell Forex';
        break;
      case 'Reload':
        this.orderType = 'Reload Card';
        break;
      case 'Send':
        this.orderType = 'Send Money Abroad';
        break;
    }
  }

  concatOfficeAddress() {
    const nonAdressParam = ['conpanyName', 'companyName', 'designation', 'companyDivision', 'pincode'];
    this.travellerOfficeAddress = [];
    this.userSessionInfo.traveller.forEach((traveller, index) => {
      let addressText = '', officeAddress = traveller.registrationInfo.officeAddress, counter = 0, pincodeAdded = false;
      for (const travellerData in officeAddress) {
        if (nonAdressParam.indexOf(travellerData) === -1 && officeAddress[travellerData]) {
          addressText += officeAddress[travellerData] + ', ';
          counter++;
        }
        if (travellerData === 'pincode' && officeAddress[travellerData]) {
          if (counter > 0) {
            addressText = this.replaceLastCommaWith(addressText, '-') + officeAddress[travellerData];
          } else {
            addressText += officeAddress[travellerData];
          }
          pincodeAdded = true;
        }
      }
      if ((counter > 0 && pincodeAdded) || pincodeAdded) {
        addressText += '.';
      } else if (counter > 0) {
        addressText += this.replaceLastCommaWith(addressText, '.');
      }
      this.travellerOfficeAddress[index] = addressText;
    });
  }

  replaceLastCommaWith(text, element) {
    const pos = text.lastIndexOf(',');
    return text.substring(0, pos) + ' ' + element + ' ' + text.substring(pos + 1);
  }


  updateSession() {

    SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));
  }


  print(): void {
    this.hiddenLogo = true;
    setTimeout(() => {
      let printContents = '', popupWin;

      printContents += document.getElementById('print-section').innerHTML;

      popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
      popupWin.document.open();
      popupWin.document.write(`
            <html>
              <head>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link href="/assets/css/bootstrap.css" rel="stylesheet">
                <!-- Bootstrap core CSS -->
                <link href="/assets/css/plugin.min.css" rel="stylesheet" type="text/css" media="all">
                <!-- icons -->
                <!-- Custom styles for this template -->
                <link href="/assets/css/style.min.css" rel="stylesheet">
                <link href="/assets/css/media.min.css" rel="stylesheet">
                <script>
                    function clearSignSpace() {
                      var elements = document.getElementsByClassName('sign-space');
                      for(var i = 0; i < elements.length; i++) {
                        elements[i].innerHTML = '';
                      }
                    }
                </script>
              </head>
              <body onload="clearSignSpace();window.print();window.close();">${printContents}</body>
            </html>`
      );
      popupWin.document.close();
      this.hiddenLogo = false;
    }, 100);

  }

  download(): void {
    this.hiddenLogo = true;
    setTimeout(() => {
      let timeNow,
        pageDimentions = [595, 841],
        imageWidth = 570,
        imageHeight = 820,
        pagePadding = 5,
        qualityParam = 1.0,
        fileName;
      timeNow = (new DatePipe('en-US').transform(new Date(), 'MMM d y h mma')).replace(/ /g, '_');
      fileName = 'confirmation_' + '_' + timeNow;
      html2canvas(this.element.nativeElement).then((canvas: HTMLCanvasElement) => {
        const img = canvas.toDataURL('image/png', qualityParam);
        const canvasWidth = +canvas.getAttribute('width'),
          canvasHeight = +canvas.getAttribute('height');
        const imageDimantions = this.calculateHeightWidth(pageDimentions, canvasWidth, canvasHeight);
        const doc = new jsPDF('p', 'pt', pageDimentions);
        doc.addImage(img, 'JPEG', imageDimantions.pagePadding, pagePadding, imageDimantions.imageWidth, imageDimantions.imageHeight);
        doc.save(fileName + '.pdf');
        this.hiddenLogo = false;
      });
    }, 100);

  }

  calculateHeightWidth(pageDimentions, imageWidth, imageHeight) {
    let pageWidth = pageDimentions[0] - 20,
      pageHeight = pageDimentions[1] - 20,
      imageRatio,
      newImageHeight,
      newImageWidth,
      paddingValue = 5,
      pageRatio;
    imageRatio = imageHeight / imageWidth;
    pageRatio = pageHeight / pageWidth;
    if (imageRatio < pageRatio && imageWidth > pageWidth) {
      newImageWidth = pageWidth;
      newImageHeight = imageRatio * pageWidth;
    } else if (imageRatio > pageRatio && imageHeight > pageHeight) {
      newImageHeight = pageHeight;
      newImageWidth = pageHeight / imageRatio;
      paddingValue = (pageWidth - newImageWidth) / 2;
    } else if (imageWidth < pageWidth && imageHeight < pageHeight) {
      newImageHeight = imageWidth;
      newImageWidth = imageHeight;
    }
    return { imageWidth: newImageWidth, imageHeight: newImageHeight, pagePadding: paddingValue };
  }

  // getExchangeRates(traveller) {
  //   let prepaidCardDetails = traveller.prepaidCardDetails;
  //   if (traveller.prepaidCard) {
  //     for (let prepaidCard in prepaidCardDetails) {
  //       this.exchangeRates[prepaidCardDetails[prepaidCard].currencyCode] = prepaidCardDetails[prepaidCard].exchangeRate.rate;
  //     }
  //   }
  // }

  // getTransactionCount(traveller) {
  //   let transactionCount = 0;
  //   if (this.processType === 'Sell') {
  //     if (traveller.prepaidCard) {
  //       traveller.cardData.forEach((prepaidCardDetails) => {
  //         let balanceCount = 0;
  //         prepaidCardDetails.balance.forEach((balance) => {
  //           if (balance.cashout && balance.cashoutAmount) {
  //             transactionCount++;
  //             balanceCount++;
  //           }
  //         });
  //         prepaidCardDetails.balanceCount = balanceCount;
  //       });
  //     }
  //     transactionCount += traveller.cashDetails.length;
  //     traveller.transactionCount = transactionCount;
  //   }
  // }



  ngOnDestroy() {
    // this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession));
    SessionHelper.removeSession(this.pageSession);
    this.router.navigateByUrl(this.navUrl.navUrl() + '/buy');
  }

  getProcessType(type) { console.log('GET PROCESS TYPE');
    let processType: any = '';
    switch (type) {
      case 'buyScreen':
        processType = 'Buy';
        break;
      case 'sellScreen':
        processType = 'Sell';
        break;
      case 'reloadCardScreen':
        processType = 'Reload';
        break;
      case 'sendMoneyScreen':
        processType = 'Send';
        break;
    }

    return processType;
  }

}
