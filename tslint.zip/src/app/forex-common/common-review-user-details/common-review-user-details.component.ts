import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import * as sha from 'sha.js';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { DpDatePickerModule } from 'ng2-date-picker';

declare var jquery: any;
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-common-review-user-details',
  templateUrl: './common-review-user-details.component.html',
  styleUrls: ['./common-review-user-details.component.css']
})
export class CommonReviewUserDetailsComponent implements OnInit {
  public userSessionInfo: any;
  public userSessionInfoTravellers: any;

  public sessionDataProcess: any;
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public wizardStepNumber: any;
  public userInfo:    any;
  public configsMin:  any = [];
  public configsMax:  any = [];
  public disabledArr: any = [];
  public todaysDate: any;
  public selIndex: any;
  public airlineNames: any;
  public commonDetails: any;
  public travellerOfficeAddress: any = [];
  public skipAdhaarValidationFlag: any = false;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private route: ActivatedRoute, private router: Router) {
  }
  ngOnInit(): void {
    this.skipAdhaarValidationFlag = this.masterService.getSkipAdhaarValidationFlag();
    this.sessionDataProcess = this.route.snapshot.data.sessData.sessionDataProcess;
    this.sessionDataProcessScreen = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.nextLink = this.route.snapshot.data.nextLink;
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;
    this.userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
    $('body').attr('id', '');
    this.masterService.getAirlineNames()
      .subscribe(data => {
        this.airlineNames = data;
      });
    initDocument();
    this.userSessionInfo = JSON.parse(SessionHelper.getSession(this.sessionDataProcess));
    this.userSessionInfoTravellers = this.userSessionInfo[this.sessionDataProcessScreen].traveller;
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      traveller.selected = false;
      this.setDateConfig(traveller.travellingDetails.dateOfTravel, traveller.travellingDetails.dateOfArrival, index);
    });
    this.userSessionInfoTravellers[0].selected = true;
    this.concatOfficeAddress();
  }

  setDateConfig(startDate, endDate, index) {
    let maxDate = '',
      minDate = '';
    this.todaysDate = this.masterService.getTodaysDate();
    if (startDate !== '') {
      minDate = startDate;
    } else {
      minDate = this.todaysDate;
    }
    if (endDate !== '') {
      maxDate = endDate;
    }
    this.configsMin[index] = {
      format: 'DD-MM-YYYY',
      min: minDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.configsMax[index] = {
      format: 'DD-MM-YYYY',
      max: this.masterService.addDateMoment(this.todaysDate, 60, 'days'),
      min: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }


  dataChangeStart(event, i): void {

    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].travellingDetails.dateOfTravel = event;
      this.userSessionInfoTravellers[i].travellingDetails.dateOfTravel = event;
      SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));

        this.configsMin[i] = {
          format: 'DD-MM-YYYY',
          min : event,
          showMultipleYearsNavigation: true,
          disableKeypress: true,
        };
    }
    if (i === 0 && this.commonDetails === true){
      this.userSessionInfoTravellers.forEach((traveller, index) => {
        if (index !== 0){
          this.userSessionInfoTravellers[index].travellingDetails.dateOfTravel = event;
        }
      });
    }
  }

  dataChangeEnd(event, i): void {
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].travellingDetails.dateOfArrival = event;
      this.userSessionInfoTravellers[i].travellingDetails.dateOfArrival = event;
      SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
      let validationDate = this.masterService.addDateMoment(this.todaysDate, 60, 'days'),
        diff = this.masterService.getDateDifference(validationDate, event), validDate;
      if (diff > 0) {
        validDate = event;
      } else {
        validDate = validationDate;
      }
      this.configsMax[i] = {
        format: 'DD-MM-YYYY',
        max: validDate,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
        min: this.todaysDate
      };
    }

    if (i === 0 && this.commonDetails === true) {
      this.userSessionInfoTravellers.forEach((traveller, index) => {
        if (index !== 0) {
          this.userSessionInfoTravellers[index].travellingDetails.dateOfArrival = event;
        }
      });
    }
  }

  airlineNameChanged(event, index){
    if (index === 0 && this.commonDetails === true){
      this.userSessionInfoTravellers.forEach((traveller, index) => {
        if (index !== 0){
          this.userSessionInfoTravellers[index].travellingDetails.airlineName = event;
          this.userSessionInfo[this.sessionDataProcessScreen].traveller[index].travellingDetails.airlineName = event;
        }
      });
      SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
    }
  }



  selectTraveller(travellerIndex) {
    this.selIndex = travellerIndex;
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }

  checkForNewTraveller(){
    for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {
      let password: any, currentTravellerInfo = this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo;
      if (currentTravellerInfo.firstName.value === '' || currentTravellerInfo.lastName === '') {
        Snackbar.show({
          text: 'Oops!,Some of the required fields are empty',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        this.selIndex = i;
        setTimeout(() => {
          this.onEditClick();
        }, 100);
        return false;
      }
    }
    return true;
  }

  onSubmit() {
    if (!this.checkForNewTraveller()){
      return;
    }

    //   if (this.userSessionInfo[this.sessionDataProcessScreen].edited === true) {
    //   const sendRegistrationInfo = [];
    //   for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {
    //     let password: any, currentTravellerInfo = this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo;
    //     if (i === 0) {
    //       if(currentTravellerInfo.userId === '') {
    //         password = currentTravellerInfo.password;
    //         password = sha('sha256').update(password, 'utf8').digest('hex');
    //         currentTravellerInfo.password = '';
    //         currentTravellerInfo.password = password;
    //       }
    //       currentTravellerInfo.parent = true;

    //     } else {
    //       currentTravellerInfo.parent = false;
    //     }
    //     currentTravellerInfo.travellerNo = i;

    //     sendRegistrationInfo.push(currentTravellerInfo);
    //   }


    //   if (sendRegistrationInfo[0].userId === '') {
    //     console.log('Insert will be called !!');
    //     this.masterService.setUserRegistration(sendRegistrationInfo)
    //       .subscribe(data => {
    //         const result: any = data;
    //         for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {
    //           if (i === 0) {
    //             this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.userId = result.data[i].ParentId;
    //             this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.parentId = result.data[i].ParentId;
    //           } else {
    //             this.userSessionInfo[this.sessionDataProcessScreen].traveller[result.data[i - 1].travellerNo].registrationInfo.userId = result.data[i - 1].childId;
    //             this.userSessionInfo[this.sessionDataProcessScreen].traveller[result.data[i - 1].travellerNo].registrationInfo.ParentId = result.data[i - 1].ParentId;
    //           }
    //         }
    //         SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));

    //         localStorage.setItem('accessToken', result.token);

    //         this.userInfo.loggedin = true,
    //         this.userInfo.uid = sendRegistrationInfo[0].userId;
    //         this.userInfo.userName = sendRegistrationInfo[0].firstName.value + ' ' + sendRegistrationInfo[0].middleName + ' '
    //           + sendRegistrationInfo[0].lastName;
    //         SessionHelper.setSession('userInfo', JSON.stringify(this.userInfo));


            // this.masterService.getTemporaryOrderNumber()
            // .subscribe(retData => {
            //     const retResult: any = retData;
            //     console.log(retResult);
            //     this.userSessionInfo.temporaryOrderNumber = retResult.response.OrderNumber;
            //     this.userSessionInfo.userId = this.userInfo.uid;
            // });





    //       });
    //   } else {
    //     console.log('Update will be called !!');
    //     // this.userInfo.userName = sendRegistrationInfo[0].firstName.value + ' ' + sendRegistrationInfo[0].middleName + ' '
    //     //   + sendRegistrationInfo[0].lastName;
    //     // SessionHelper.setSession('userInfo', JSON.stringify(this.userInfo));
    //     console.log(sendRegistrationInfo);


    //     this.masterService.updateUserRegistration(sendRegistrationInfo)
    //       .subscribe(data => {
    //         console.log('&&&&&&&&&&&&&&&&&&&&&&&&&&&&& HERE HERE');
    //         console.log(data);
    //         const retData: any = data;


    //         this.userInfo.loggedin = true,
    //         this.userInfo.uid = sendRegistrationInfo[0].userId;
    //         this.userInfo.userName = sendRegistrationInfo[0].firstName.value + ' ' + sendRegistrationInfo[0].middleName + ' '
    //           + sendRegistrationInfo[0].lastName;
    //         SessionHelper.setSession('userInfo', JSON.stringify(this.userInfo));


    //         const result: any = data;
    //         if (result.hasOwnProperty('newUserRecords')) {

    //           for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {
    //             if (i === 0) {
    //               this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.userId = result.newUserRecords.data[0].ParentId;
    //             } else {
    //               this.userSessionInfo[this.sessionDataProcessScreen].traveller[result.newUserRecords.data[i - 1].travellerNo].registrationInfo.userId = result.newUserRecords.data[i - 1].childId;
    //               this.userSessionInfo[this.sessionDataProcessScreen].traveller[result.newUserRecords.data[i - 1].travellerNo].registrationInfo.ParentId = result.newUserRecords.data[i - 1].ParentId;
    //             }
    //           }
    //           SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
    //         }
    //       });
    //   }
    // }



    // for (let i = 0; i <= this.userSessionInfo[this.sessionDataProcessScreen].traveller.length - 1; i++) {
    //   if (this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].prepaidCard) {
    //     if (this.userSessionInfo[this.sessionDataProcessScreen].traveller[i].registrationInfo.mothersMaidenName.value === '') {
    //       // swal('Oops', 'Some of the required fields are empty !', 'error');
    //       Snackbar.show({text: 'Oops!,Some of the required fields are empty',
    //       pos: 'bottom-right' ,
    //       actionTextColor: '#ff4444',
    //      });
    //       if (this.processType === 'Buy') {
    //         this.router.navigateByUrl(this.navUrl.navUrl() + `/buy/create-account`);
    //         return;
    //       } else if (this.processType === 'Sell') {
    //         this.router.navigateByUrl(this.navUrl.navUrl() + `/sell/create-account`);
    //         return;
    //       } else if (this.processType === 'Reload') {
    //         this.router.navigateByUrl(this.navUrl.navUrl() + `/reload-card/create-account`);
    //         return;
    //       } else if (this.processType === 'Send') {
    //         this.router.navigateByUrl(this.navUrl.navUrl() + `/send-money/create-account`);
    //         return;
    //       }
    //     }
    //   }
    // }

    if (this.userSessionInfo.temporaryOrderNumber === undefined) {
      this.masterService.getTemporaryOrderNumber()
        .subscribe(retData => {
          const retResult: any = retData;
          console.log('TEMP NUMBER STARTED GENERATED');
          console.log(retResult);
          this.userSessionInfo.temporaryOrderNumber = retResult.response.OrderNumber;
          // this.userSessionInfo.tempUserId = sendRegistrationInfo[0].userId;
          this.userSessionInfo.userId = this.userInfo.uid;
          this.userSessionInfo.agentId = this.userInfo.uid;
          SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
        });
    } else {
    }


    this.userSessionInfo['nextLink'] = this.nextLink;
    console.log(this.sessionDataProcess);
    this.updateSession();
    console.log(this.userSessionInfo);
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });

    if (this.processType !== 'Sell' && this.processType !== 'Send') {

      setTimeout(function () {
        $.magnificPopup.open({
          items: {
            src: '#details-traveller-popup'
          },
          type: 'inline'
        });
      }, 5);
    } else {
      this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
    }
  }



  updateSession() {
    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
  }

  onTravellerSubmit() {
    if (this.processType !== 'buy') {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller.forEach(element => {
        if (element.demandDraft) {
          this.nextLink = '/buy/transaction-details';
        }
      });
    }
    console.log(this.userSessionInfoTravellers.length);
    // console.log(this.userSessionInfoTravellers[0].travellingDetails.ticketNumber);

    // if (this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].travellingDetails.ticketNumber === '') {
    // }
    // tslint:disable-next-line:one-line

    if (this.processType !== 'Send') {
      for (let i = 0; i <= this.userSessionInfoTravellers.length - 1; i++) {
        // if (this.userSessionInfoTravellers[i].travellingDetails.ticketNumber === '') {
        //   return Snackbar.show({text: 'Oops!,Ticket number is empty',
        //   pos: 'bottom-right' ,
        //   actionTextColor: '#ff4444',
        //  });
        //   // swal('Oops', 'Ticket number is empty!', 'error');   // console.log('Ticket number empty');
        // }
        // if (this.userSessionInfoTravellers[i].travellingDetails.airlineName === '') {
        //   return Snackbar.show({text: 'Oops!,Airline Name is empty',
        //   pos: 'bottom-right' ,
        //   actionTextColor: '#ff4444',
        //  });
        //   // swal('Oops', 'Airline Name is empty!', 'error');
        // }
        if (this.userSessionInfoTravellers[i].travellingDetails.dateOfTravel === '' && this.processType !== 'Reload') {
          return Snackbar.show({text: 'Oops!,Date of Travel is empty',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
          // return swal('Oops', 'Date of Travel is empty!', 'error');
        }
      }
    }



    $.magnificPopup.close();
    this.userSessionInfo[this.sessionDataProcessScreen].traveller = this.userSessionInfoTravellers;
    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
    this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
  }

  onEditClick() {
    switch (this.processType) {
      case 'Buy':
        this.router.navigate([this.navUrl.navUrl() + '/buy/create-account'], {queryParams: {traveller: this.selIndex}});
        break;
      case 'Sell':
        this.router.navigate([this.navUrl.navUrl() + '/sell/create-account'], {queryParams: {traveller: this.selIndex}});
        break;
      case 'Reload':
        this.router.navigate([this.navUrl.navUrl() + '/reload-card/create-account'], {queryParams: {traveller: this.selIndex}});
        break;
      case 'Send':
        this.router.navigate([this.navUrl.navUrl() + '/send-money/create-account'], {queryParams: {traveller: this.selIndex}});
        break;
      default:
        break;
    }
  }


  onSaveAndTemporaryExit(isGenerateLink = false) {
    if (isGenerateLink) {
      console.log('%%%%%%%%%%%%', isGenerateLink);
      this.userSessionInfo.userId = this.userSessionInfo.tempUserId;
      const individualLeadData = {
        AgentId: JSON.parse(SessionHelper.getSession('userInfo')).uid,
        Url: '',
        FirstName: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.firstName.value,
        MiddleName: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.middleName,
        LastName: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.lastName,
        City: this.userSessionInfo[this.sessionDataProcessScreen].currentLocation.city,
        CountryCode: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.contactDetails.countryCode,
        Mobile: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.contactDetails.mobileNo,
        EmailId: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.contactDetails.emailId,
        AlternateCountryCode: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.alternateContactDetails.emailId,
        AlternateMobileNo: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.alternateContactDetails.mobileNo,
        AlternateEmailId: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.alternateContactDetails.emailId,
        TempNo: this.userSessionInfo.temporaryOrderNumber
      };
      const route: any = this.route;
      this.userSessionInfo.nextLink = route.snapshot._routerState.url;
      this.updateSession();
      const mailData = [];
      mailData.push(individualLeadData);
      // console.log(test);
      this.masterService.sendMailLeadPax(mailData)
        .subscribe(data => {
          console.log(data);
        });
      this.userSessionInfo.EmailId = this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.contactDetails.emailId;
    }
    $.magnificPopup.close();
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession(this.sessionDataProcess);
    switch (this.processType) {
      case 'Buy':
        this.router.navigateByUrl(this.navUrl.navUrl() + `/buy`);
        //   /register-login
        break;
      case 'Sell':
        this.router.navigateByUrl(this.navUrl.navUrl() + `/sell`);
        break;
      case 'Reload':
        this.router.navigateByUrl(this.navUrl.navUrl() + `/reload-card`);
        break;
      case 'Send':
        this.router.navigateByUrl(this.navUrl.navUrl() + `/send-money`);
        break;
      default:
        break;
    }
  }

  commonDetailsChnecked(event) {
    const dateOfArrival = this.userSessionInfoTravellers[0].travellingDetails.dateOfArrival,
    dateOfTravel = this.userSessionInfoTravellers[0].travellingDetails.dateOfTravel,
    airlineName = this.userSessionInfoTravellers[0].travellingDetails.airlineName;
    if (event === true){
      this.userSessionInfoTravellers.forEach((traveller, index) => {
        if (index !== 0){
          this.disabledArr[index] = true;
          this.userSessionInfoTravellers[index].travellingDetails.dateOfArrival = dateOfArrival;
          this.userSessionInfoTravellers[index].travellingDetails.dateOfTravel = dateOfTravel;
          this.userSessionInfoTravellers[index].travellingDetails.airlineName = airlineName;
        } else {
          this.disabledArr[index] = false;
        }
      });
    } else {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller.forEach((traveller, index) => {
          this.disabledArr[index] = false;
      });
    }
    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
  }

  concatOfficeAddress() {
    const nonAdressParam = ['conpanyName', 'companyName', 'designation', 'companyDivision', 'pincode'];
    this.travellerOfficeAddress = [];
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      let addressText = '', officeAddress = traveller.registrationInfo.officeAddress, counter = 0, pincodeAdded = false;
      for (const travellerData in officeAddress) {
        if (nonAdressParam.indexOf(travellerData) === -1 && officeAddress[travellerData]) {
          addressText += officeAddress[travellerData] + ', ';
          counter++;
        }

        if (travellerData === 'pincode' && officeAddress[travellerData]) {
          if (counter > 0) {
            addressText = this.replaceLastCommaWith(addressText, '-') + officeAddress[travellerData];
          } else {
            addressText += officeAddress[travellerData];
          }
          pincodeAdded = true;
        }
      }
      if ((counter > 0 && pincodeAdded) || pincodeAdded) {
        addressText += '.';
      } else if (counter > 0) {
        addressText += this.replaceLastCommaWith(addressText, '.');
      }
      this.travellerOfficeAddress[index] = addressText;
    });

  }

  replaceLastCommaWith(text, element) {
    const pos = text.lastIndexOf(',');
    return text.substring(0, pos) + ' ' + element + ' ' + text.substring(pos + 1);
  }


  //  maskAdhar(adharNum){
  //   // this.adharNum  = adharNum.toString();
  //   var mainStr = '';
  //   for(var i = 0 ; i < adharNum.length ; i++){
  //             if(i > 5){
  //                  mainStr += adharNum[i];
  //        }else{
  //                 mainStr += '*';
  //         }
  //   }
  //   return mainStr;
  //   }


}
