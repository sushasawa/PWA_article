import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonDeliveryModeComponent } from './common-delivery-mode.component';

describe('CommonDeliveryModeComponent', () => {
  let component: CommonDeliveryModeComponent;
  let fixture: ComponentFixture<CommonDeliveryModeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonDeliveryModeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonDeliveryModeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
