import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RateAlertComponent } from './rate-alert.component';

describe('RateAlertComponent', () => {
  let component: RateAlertComponent;
  let fixture: ComponentFixture<RateAlertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RateAlertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RateAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
