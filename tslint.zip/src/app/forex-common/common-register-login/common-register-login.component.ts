import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms';
import * as sha from 'sha.js';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;

@Component({
  selector: 'app-common-register-login',
  templateUrl: './common-register-login.component.html',
  styleUrls: ['./common-register-login.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CommonRegisterLoginComponent implements OnInit {

  public invalidsubmitted: any;
  public authorized: Boolean;
  public signinmsg: String;
  public currentlocation: any;
  public userSessionInfo: any;
  public SessionInfo: any;
  public travellersRegistrationInfo: any;
  public nextLink: any;
  public currentSession: any;
  public pageSession: any;
  public wizardStepNumber: any;
  public processType: any;
  public travellerList: any;
  public _primaryComp: any;
  private totalSelectionCount: number;

  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private location: Location, private route: ActivatedRoute) {
    this.authorized = true;
    this.signinmsg = 'Sign In';
    this.travellersRegistrationInfo = [];
    this.currentlocation = this.location.path().split('/');
    this.totalSelectionCount = 0;
    this._primaryComp = navUrl.navUrl();
  }

  ngOnInit() {
    $('body').attr('id', '');
    this.nextLink = this.route.snapshot.data.nextLink;
    this.pageSession = this.route.snapshot.data.sessData.sessionDataProcess;
    this.currentSession = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession));
    this.userSessionInfo = this.SessionInfo[this.currentSession];
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;
    this.processType = this.route.snapshot.data.sessData.processType;

    console.log('userSessionInfo');
    console.log(this.userSessionInfo);

    if (SessionHelper.getSession('userInfo')) {  console.log('TEMP NUMBER STARTED');
      const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
      console.log(this.nextLink);
      if (userInfo.loggedin) {
        if (this.SessionInfo.temporaryOrderNumber === undefined) {
          this.masterService.getTemporaryOrderNumber()
            .subscribe(data => {
              const result: any = data;
              console.log('TEMP NUMBER STARTED GENERATED');
              console.log(result);
              this.SessionInfo.temporaryOrderNumber = result.response.OrderNumber;
              this.SessionInfo.userId = userInfo.uid;
              SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));
              this.routePage();
            });
        } else {
          this.routePage();
        }
      }
    }
  }

  routePage() {
    // if (this.userSessionInfo.traveller.length === 1) {
    //   this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
    // }
    // if (this.userSessionInfo.traveller.find(item => item.registrationInfo.contactDetails.emailId === '')) {
    //   this.router.navigateByUrl(this.navUrl.navUrl() + '/' + this.currentlocation[1] + '/create-account');
    // } else {
    //   this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
    // }

    const UserInfo = SessionHelper.getSession('userInfo');
   if ((UserInfo != null || UserInfo !== undefined) && JSON.parse(UserInfo).loggedin === true && JSON.parse(UserInfo).uid !== undefined) {
      this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
    }
  }

  loginSubmit(UserInfo: NgForm) {
    this.invalidsubmitted = UserInfo.invalid;
    const payload: any = {};
    let password = UserInfo.value.upassword;
    const username = UserInfo.value.uname;
    password = sha('sha256').update(password, 'utf8').digest('hex');
    payload.upassword = password;
    payload.uname = username;
    console.log(payload);
    if (!this.invalidsubmitted) {
      this.signinmsg = 'Logging in ...';
      this.masterService.loginUser(payload).subscribe(data => {
        console.log(data);
        const result: any = data;
        this.authorized = true;
        this.signinmsg = 'Redirecting...';
        const userinfo = {
          'loggedin': result.success,
          'uname': result.response[0][0].EmailId,
          'uid': result.response[0][0].Id,
          'userName': result.response[1][0].firstName + ' ' + result.response[1][0].middleName + ' ' + result.response[1][0].lastName
        };
        localStorage.setItem('accessToken', result.token);
        // sessionStorage.setItem('userInfo', setSession JSON.stringify(userinfo));
        SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
        this.SessionInfo.userId = userinfo.uid;
        this.createTravellersArray(result);
        this.createTravellerOptions(result);

        console.log('Getting temporary order number.');
        this.masterService.getTemporaryOrderNumber()
          .subscribe(data => {
            const result: any = data;
            console.log(result);
            this.SessionInfo.temporaryOrderNumber = result.response.OrderNumber;
            this.SessionInfo.userId = userinfo.uid;
            SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));


            if (this.userSessionInfo.traveller.length === 1) {
              this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
            }
          });
      }, err => {
        this.signinmsg = 'Sign in';
        this.authorized = false;
        const userinfo = { 'loggedin': false };
        this.router.navigateByUrl(this.navUrl.navUrl() + '/' + this.currentlocation[1] + '/register-login');
        SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
      });
    }
  }

  createTravellerOptions(data) {
    console.log(data);
    if (this.userSessionInfo.traveller.length > 1) {
      this.travellerList = [];
      this.travellerList.push({
        name: data.response[1][0].firstName + ' ' + data.response[1][0].lastName,
        data: data.response[1][0]
      });
      this.travellerList[0].data.lead = true;
      this.travellerList[0].selected = false;

      data.response[2].forEach(element => {
        this.travellerList.push({
          name: element.firstName + ' ' + element.lastName,
          data: element
        });
      });

      console.log(this.travellerList);

      $.magnificPopup.open({
        items: {
          src: '#trvl-list'
        },
        type: 'inline'
      });
    }
  }

  addExistingTraveller(data: any, event: any, index: number) {
    console.log(event);
    if (event.target.checked) {
      if (this.userSessionInfo.traveller.length === this.totalSelectionCount) {
        // swal('Sorry', 'Maximum ' + this.userSessionInfo.traveller.length + ' travelers allowed', 'error');
        Snackbar.show({text: 'Sorry , Maximum ' + this.userSessionInfo.traveller.length + ' travelers allowed',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });

        event.target.checked = false;
      } else {
        console.log('Add traveller');
        const templateData = SessionTemplate.getSessionTemplate(data);
        this.userSessionInfo.traveller[this.totalSelectionCount].registrationInfo = templateData.registrationInfo;
        this.userSessionInfo.traveller[this.totalSelectionCount].travellingDetails = templateData.travellingDetails;
        this.totalSelectionCount++;
      }
    } else {
      if (this.userSessionInfo.traveller.length > 1) {
        const obj = this.userSessionInfo.traveller
          .find(item => item.registrationInfo.contactDetails.emailId === data.emailId);

        this.totalSelectionCount--;
        this.removeTraveller(this.userSessionInfo.traveller.indexOf(obj));
      } else {
        // swal('Sorry', 'Minimum 1 traveler needed', 'error');
        Snackbar.show({text: 'Minimum 1 traveler needed',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
        event.target.checked = true;
      }
    }
    this.travellerList[index].selected = event.target.checked;
  }

  addTraveller(index: number) {
    this.userSessionInfo.traveller[index].registrationInfo = {
      'userId': '',
      'firstName': {
        'value': '', 'checkCondition': {
          'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false'
        }
      },
      'middleName': '',
      'lastName': '',
      'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
      'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
      'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
      'nationality': {
        'value': 'Indian', 'checkCondition': {
          'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false'
        }
      },
      'mothersMaidenName': {
        'value': '', 'checkCondition':
          'if(value.trim()==\'\'){console.log(\'Not ok\');event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}'
          + 'else{console.log(\'Ok\');event.target.style.background=\'#f8f8f8\'}'
      },
      'PAN': {
        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
          + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
          + 'event.target.style.background=\'#f8f8f8\'}'
      },
      'passportNumber': '',
      'ParentId': false,
      'dateOfIssue': '',
      'placeOfIssue': '',
      'expiryDate': '',
      'address': '101 5A Galaxy apartment',
      'isPassportAddressAsAdhar': 'false',
      'adharAddress': {
        'flatNumber': '',
        'buildingName': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': '',
      },
      'passportAddress': {
        'flatNumber': '',
        'buildingName': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': '',
      },
      'currentAddressAs': 'asPerAdhar',
      'otherAddress': {
        'flatNumber': '',
        'buildingName': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': '',
      },
      'contactDetails': {
        'countryCode': '',
        'mobileNo': '',
        'countryCode2': '',
        'cityCode': '',
        'telephoneNo': '',
        'emailId': '',
      },
      'alternateContactDetails': {
        'countryCode': '',
        'mobileNo': '',
        'countryCode2': '',
        'cityCode': '',
        'telephoneNo': '',
        'emailId': '',
      },
      'officeAddress': {
        'designation': '',
        'conpanyName': '',
        'companyDivision': '',
        'flatNumber': '',
        'building': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': ''
      },
      'officeContactDetails': {
        'countryCode': '',
        'telephoneNumber': '',
        'officeExtension': '',
      }
    };
    this.userSessionInfo.traveller[index].travellingDetails = {
      'dateOfTravel': '',
      'dateOfArrival': '',
      'airlineName': '',
      'ticketNumber': ''
    };
  }

  removeTraveller(index: number) {
    console.log('Remove : ' + index);
    this.userSessionInfo.traveller[index].registrationInfo = {
      'userId': '',
      'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
      'middleName': '',
      'lastName': '',
      'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
      'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
      'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
      // "nationality": { "id": "", "name": "" } ,
      'nationality': '',
      'mothersMaidenName': {
        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
          + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
          + 'event.target.style.background=\'#f8f8f8\'}'
      },
      'PAN': {
        'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
          + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
          + 'event.target.style.background=\'#f8f8f8\'}'
      },
      'passportNumber': '',
      'ParentId': true,
      'dateOfIssue': '',
      'placeOfIssue': '',
      'expiryDate': '',
      'address': '101 5A Galaxy apartment',
      'isPassportAddressAsAdhar': 'yes',
      'adharAddress': {
        'flatNumber': '',
        'buildingName': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': '',
      },
      'passportAddress': {
        'flatNumber': '',
        'buildingName': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': '',
      },
      'currentAddressAs': 'asPerAdhar',
      'otherAddress': {
        'flatNumber': '',
        'buildingName': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': '',
      },
      'contactDetails': {
        'mobileNo': '',
        'emailId': ''
      },
      'alternateContactDetails': {
        'countryCode': '',
        'mobileNo': '',
        'countryCode2': '',
        'cityCode': '',
        'telephoneNo': '',
        'emailId': '',
      },
      'officeAddress': {
        'designation': '',
        'conpanyName': '',
        'companyDivision': '',
        'flatNumber': '',
        'building': '',
        'streetName': '',
        'landmark': '',
        'area': '',
        'city': '',
        'state': '',
        'pincode': ''
      },
      'officeContactDetails': {
        'countryCode': '',
        'telephoneNumber': '',
        'officeExtension': '',
      },
      'password': '',
      'confirmPassword': '',
    };
  }

  addNewTraveller(event: any) {
    if (event.target.checked) {
      if (this.userSessionInfo.traveller.length === this.totalSelectionCount) {
        // swal('Sorry', 'Maximum ' + this.userSessionInfo.traveller.length + ' travelers allowed', 'error');
        Snackbar.show({text: 'Sorry , Maximum ' + this.userSessionInfo.traveller.length + ' travelers allowed',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
        event.target.checked = false;
      } else {
        this.addTraveller(this.totalSelectionCount);
        this.totalSelectionCount++;
      }
    } else {
      if (this.userSessionInfo.traveller.length > 1) {
        const obj = this.userSessionInfo.traveller
          .find(item => item.registrationInfo.contactDetails.emailId === '');
        this.removeTraveller(this.userSessionInfo.traveller.indexOf(obj));
        this.totalSelectionCount--;
      } else {
        // swal('Sorry', 'Minimum 1 traveler needed', 'error');
        Snackbar.show({text: 'Sorry , Minimum 1 traveler needed',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
        event.target.checked = true;
      }
    }
  }

  continue() {
    if (this.userSessionInfo.traveller.length === this.totalSelectionCount) {
      $.magnificPopup.close();
      SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));

      if (this.userSessionInfo.traveller.find(item => item.registrationInfo.contactDetails.emailId === '')) {
        this.router.navigateByUrl(this.navUrl.navUrl() + '/' + this.currentlocation[1] + '/create-account');
      } else {
        this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
      }
    } else {
      // swal('Oops', 'Please select ' + this.userSessionInfo.traveller.length + 'travelers in total to proceed', 'error');
      Snackbar.show({text: 'Please select ' + this.userSessionInfo.traveller.length + 'travelers in total to proceed',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
    }
  }

  createTravellersArray(responseData: any) {
    if (responseData.response[1].length > 0) {
      this.travellersRegistrationInfo.push(responseData.response[1][0]);
      this.populateTraverllersSession(responseData.response[1][0]);
    }

    if (responseData.response[2].length > 0) {
      responseData.response[2].map((traveller) => {
        this.travellersRegistrationInfo.push(traveller);
      });
    }
  }

  populateTraverllersSession(travellersRegistration) {
    console.log(this.SessionInfo);
    const templateData = SessionTemplate.getSessionTemplate(travellersRegistration);
    this.userSessionInfo.traveller[0].registrationInfo = templateData.registrationInfo;
    this.userSessionInfo.traveller[0].travellingDetails = templateData.travellingDetails;
    console.log(this.SessionInfo);
    SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));
  }
}
