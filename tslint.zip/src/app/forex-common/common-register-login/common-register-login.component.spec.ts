import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonRegisterLoginComponent } from './common-register-login.component';

describe('CommonRegisterLoginComponent', () => {
  let component: CommonRegisterLoginComponent;
  let fixture: ComponentFixture<CommonRegisterLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonRegisterLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonRegisterLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
