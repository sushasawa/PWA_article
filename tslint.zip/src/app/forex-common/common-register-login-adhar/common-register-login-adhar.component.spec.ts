import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonRegisterLoginAdharComponent } from './common-register-login-adhar.component';

describe('CommonRegisterLoginAdharComponent', () => {
  let component: CommonRegisterLoginAdharComponent;
  let fixture: ComponentFixture<CommonRegisterLoginAdharComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonRegisterLoginAdharComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonRegisterLoginAdharComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
