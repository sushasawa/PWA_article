import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '../../../app/helpers/location';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { LocationStrategy } from '@angular/common';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import {DpDatePickerModule} from 'ng2-date-picker';

// import { setInterval } from 'timers';

declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;

@Component({
  selector: 'app-common-usercreation',
  templateUrl: './common-usercreation.component.html',
  styleUrls: ['./common-usercreation.component.css']
})
export class CommonUsercreationComponent implements OnInit {
    public cityOptions: any; // : GenericEntity[];
  public nationalityOptions: any; // : GenericEntity[];

  public userSessionInfo: any;
  public userSessionInfoTravellers: any;
  public selIndex = 0;
  public sessionDataProcess: any;
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public wizardStepNumber: any;
  public termsAcceptance = false;
  public DatepickerOptions: any;
  public todaysDate: any;
  public configDob: any;
  public configsMin: any = [];
  public configsMax: any = [];
  public invalidsubmitted: any;
  public isNRI: any = [];
  public termsAcceptanceAdhar: any;
  public pageSessionParam = 'pageSessionParam';
  public skipAdhaarValidationFlag: any = false;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private route: ActivatedRoute, private location: LocationStrategy) {
    this.location.onPopState(() => {
      if (SessionHelper.getSession(this.pageSessionParam)){
        SessionHelper.removeSession(this.pageSessionParam);
      }
    });
    this.skipAdhaarValidationFlag = this.masterService.getSkipAdhaarValidationFlag();
  }

  ngOnInit(): void {

    $('body').attr('id', '');
    this.sessionDataProcess = this.route.snapshot.data.sessData.sessionDataProcess;
    this.sessionDataProcessScreen = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.nextLink = this.route.snapshot.data.nextLink;
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;
    this.todaysDate = this.masterService.getTodaysDate();
    this.configDob = {
      format: 'DD-MM-YYYY',
      max : this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    if (SessionHelper.getSession(this.pageSessionParam) && JSON.parse(SessionHelper.getSession(this.pageSessionParam))[this.sessionDataProcessScreen]){
      this.userSessionInfo = JSON.parse(SessionHelper.getSession(this.pageSessionParam));
      this.userSessionInfoTravellers = JSON.parse(SessionHelper.getSession(this.pageSessionParam))[this.sessionDataProcessScreen].traveller;
    } else {
      this.userSessionInfo = JSON.parse(SessionHelper.getSession(this.sessionDataProcess));
      this.userSessionInfoTravellers = JSON.parse(SessionHelper.getSession(this.sessionDataProcess))[this.sessionDataProcessScreen].traveller;
    }


    this.userSessionInfoTravellers.forEach((traveller, index) => {
      traveller.selected = false;
      traveller.password = '';
      traveller.confirmPassword = '';
      traveller.registrationInfo.password = '';
      traveller.registrationInfo.confirmPassword = '';
      if (traveller.registrationInfo.userId !== ''){
        this.isNRI[index] = 'Yes';
      }
      this.setDateConfig(traveller.registrationInfo.dateOfIssue, traveller.registrationInfo.expiryDate, index);
    });
    this.userSessionInfoTravellers[0].selected = true;
    this.masterService.getCityList()
      .subscribe(data => {
        this.cityOptions = data;
        const currentDocument = this;
      });

    this.masterService.getNationalityList()
      .subscribe(data => {
        this.nationalityOptions = data;
      });


      setTimeout(function(){
        $('ng-select > div').css('border', '0px solid black');
        $('.dp-picker-input').css('height', '44px').css('width', '275px');
        initDocument();
      }, 5);

      if (this.route.snapshot.queryParams && this.route.snapshot.queryParams.traveller){
        this.selectTraveller(+this.route.snapshot.queryParams.traveller);
      }
  }
  callPinCodeService(event, type) {
    const pinCode = event.target.value;

    // this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['city'] = '##Service offline##';
    // this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['state'] = '##Service offline##';
    // this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['area'] = '##Service offline##';

    this.masterService.getPinCodeDetails(pinCode)
      .subscribe(data => {
        const Retdata: any = data;
        if (Retdata.Status === 'Success') {
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['city'] = Retdata.PostOffice[0].District;
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['state'] = Retdata.PostOffice[0].State;
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['area'] = Retdata.PostOffice[0].Name;
        } else {
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['city'] = '';
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['state'] = '';
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['area'] = '';
        }
      });
  }
  // GENERIC FUNCTION TO UPDATE SESSION DATA
  updateSession() {
    this.userSessionInfo[this.sessionDataProcessScreen].traveller[this.selIndex] = this.userSessionInfoTravellers[this.selIndex];
    SessionHelper.setSession(this.pageSessionParam, JSON.stringify(this.userSessionInfo));
  }

  updateSession1(registrationInfo, value, index){
    setTimeout(() => {
      registrationInfo[index] = value.split(/\b/g).map(word => this.titleCaseWord(word)).join('');
    }, 10);
  }

  titleCaseWord(word: string) {
    if (!word) return word;
    return word[0].toUpperCase() + word.substr(1).toLowerCase();
  }


  dataChangeBirth(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller[this.selIndex].registrationInfo.dateOfBirth.value = event;
      SessionHelper.setSession(this.pageSessionParam, JSON.stringify(this.userSessionInfo));
    }
  }

  dataChangeStart(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller[this.selIndex].registrationInfo.dateOfIssue = event;
      SessionHelper.setSession(this.pageSessionParam, JSON.stringify(this.userSessionInfo));
      this.configsMin[this.selIndex] = {
        format: 'DD-MM-YYYY',
        min : this.masterService.addDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    }
  }

  dataChangeEnd(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfo[this.sessionDataProcessScreen].traveller[this.selIndex].registrationInfo.expiryDate = event;
      SessionHelper.setSession(this.pageSessionParam, JSON.stringify(this.userSessionInfo));
      this.configsMax[this.selIndex] = {
        format: 'DD-MM-YYYY',
        max : this.masterService.substractDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    }
  }

  isValidateEmailOnPage(emailText) {
    const emailArr = [];
    this.userSessionInfoTravellers.forEach((traveller, index) => {
      if (index !== this.selIndex) {
        emailArr.push(traveller.registrationInfo.contactDetails.emailId);
      }
    });
    if (emailArr.indexOf(emailText) !== -1){
      return false;
    }
    return true;
  }

  checkEmail(event, userForm: NgForm) {
    if (!this.isValidateEmailOnPage(event.target.value)) {
      this.userSessionInfoTravellers[this.selIndex].registrationInfo.contactDetails.emailId = '';
      Snackbar.show({
        text: 'This email ID already exists, please log-in with your email ID.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    this.masterService.getEmailValidation(event.target.value)
      .subscribe(data => {
        const retData: any = data;
        if (retData.message.status === 'emailNotExists') {
          this.userSessionInfo[this.sessionDataProcessScreen].traveller[this.selIndex] = this.userSessionInfoTravellers[this.selIndex];
          SessionHelper.setSession(this.pageSessionParam, JSON.stringify(this.userSessionInfo));
          $('.confirmEmailId0 > div > ul > li').css('background-color', 'rgb(0, 255, 0)');
        } else if (retData.message.status === 'emailExists') {
          this.userSessionInfoTravellers[this.selIndex].registrationInfo.contactDetails.emailId = '';
          $('.confirmEmailId0 > div > ul > li').css('background-color', 'red');
          Snackbar.show({
            text: 'This email ID already exists, please log-in with your email ID.',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        }
        // console.log(retData.message.status);
      });
  }

  confirmPassword(event) {
    if (event.target.value === this.userSessionInfoTravellers[0].registrationInfo.password) {
       $('.confirmPassword > div > ul > li').css('background-color', 'rgb(0, 255, 0)');
    }else {
      $('.confirmPassword > div > ul > li').css('background-color', 'red');
    }
  }





  // SUBMIT FUNCTION TO REDIRECT PAGE
  submitFunction(userForm: NgForm, event: Event): void {

    event.preventDefault();
    this.invalidsubmitted = userForm.invalid;
    let isNRIFlag = false, notSelected = false;
    this.userSessionInfoTravellers.forEach((traveller, travellerIndex) => {
      if (this.isNRI[travellerIndex] === 'No'){
        isNRIFlag = true;
      }
      if(!this.isNRI[travellerIndex]){
        notSelected = true;
      }
    });
    if (notSelected) {
      Snackbar.show({
        text: "Please select option from 'Are you currently residing in India?'",
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    if (isNRIFlag) {
      Snackbar.show({
        text: 'Cannot proceed!, You can not create account as you or your co-traveller are not residing in India.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      setTimeout(() => {
        this.router.navigateByUrl(this.navUrl.navUrl() + '/buy');
      }, 500);
      return;
    }
    if (userForm.valid) {
      if (!this.termsAcceptance) {
        // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
        Snackbar.show({text: 'Please fill the mandatory fields highlighted.',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
      } else {
        if(this.skipAdhaarValidationFlag){
          this.skipAdhaarValidation();
        } else {
        setTimeout(() => {
          $.magnificPopup.open({
            items: {
              src: '#consent-popup'
            },
            type: 'inline'
          });
        }, 100);
      }
    }
    }else {
      // swal('Cannot proceed', 'Please fill required inputs', 'error');
      Snackbar.show({text: 'Cannot proceed , Please fill the mandatory fields highlighted.',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
    }

    this.userSessionInfo[this.sessionDataProcessScreen].edited = true;
    SessionHelper.setSession(this.pageSessionParam, JSON.stringify(this.userSessionInfo));

  }

  skipAdhaarValidation(){
    $.magnificPopup.close();
    if (SessionHelper.getSession('userInfo') === undefined) {
      const userinfo = {
        'loggedin': false,
        'uname': '-',
        'uid': 1,
        'userName': this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.firstName.value
      };
      SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
    }
    SessionHelper.removeSession(this.pageSessionParam);
    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
    this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
  }

  // tslint:disable-next-line:one-line
  ValidateAdhar(){
    if (!this.termsAcceptanceAdhar) {
      // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
      Snackbar.show({text: 'Cannot proceed!, Please accept Adhaar terms and conditions to proceed',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
      });
      return;
    }
    $.magnificPopup.close();
    let travellerLength, currentTravellerIndex = 0;
    travellerLength = this.userSessionInfo[this.sessionDataProcessScreen].traveller.length;
    this.userSessionInfo[this.sessionDataProcessScreen].traveller.forEach(traveller => {
      // tslint:disable-next-line:max-line-length
      this.masterService.validateAdhaar({'adharNo': traveller.registrationInfo.adharCardNo.value, 'name': traveller.registrationInfo.firstName.value})
      .subscribe(data => {
        const returnDate: any = data;
        // tslint:disable-next-line:one-line
        if (returnDate.ReturnType !== 'Error'){
          currentTravellerIndex++;
          // tslint:disable-next-line:one-line
          if (travellerLength === currentTravellerIndex){
            // if (SessionHelper.setSession('userInfo', JSON.stringify('userinfo')) === undefined) {
            //   const userinfo = {
            //     'loggedin': true,
            //     'uname': '-',
            //     'uid': 1,
            //     'userName': this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.firstName.value
            //   };
            //   SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
            // }

            if (SessionHelper.getSession('userInfo') === undefined) {
              const userinfo = {
                'loggedin': false,
                'uname': '-',
                'uid': 1,
                'userName': this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.firstName.value
              };
              SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
            }
            SessionHelper.removeSession(this.pageSessionParam);
            SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
            this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
          }
        } else {
          // swal('Cannot proceed', 'Adhar validation failed. Please enter correct adhar details.', 'error');
          Snackbar.show({text: 'Cannot proceed , Adhar validation failed. Please enter correct adhar details.',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
        }
      }, err => {
      });
    });
  }
  // GENDER RADIO CHANGE
  Gender(newValue: any) {
    this.userSessionInfoTravellers[this.selIndex].registrationInfo.gender.value = newValue;
    this.updateSession();
  }

  isINRCheck(newValue: any, travellerIndex: any) {
    this.isNRI[travellerIndex] = newValue;
  }

  // ADHARADDRESS RADIO CHANGE
  radioAdharAddress(status) {
    this.userSessionInfoTravellers[this.selIndex].registrationInfo.isPassportAddressAsAdhar = status;
    this.updateSession();
  }
  // RADIO FUNCTION FOR CURRENT ADDRESS SELECTION
  radioCurrentAddress(statusName) {
    this.userSessionInfoTravellers[this.selIndex].registrationInfo.currentAddressAs = statusName;
    this.updateSession();
  }

  selectTraveller(travellerIndex) {
    this.selIndex = travellerIndex;
    for (let i = 0; i <= this.userSessionInfoTravellers.length - 1; i++) {
      this.userSessionInfoTravellers[i].selected = false;
    }
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }

  // tslint:disable-next-line:one-line
  setDateConfig(startDate, endDate, index){
    let maxDate = '',
        minDate = '';
    this.todaysDate = this.masterService.getTodaysDate();
    if (startDate !== '') {
      minDate = startDate;
    }
    if (endDate !== '') {
      maxDate = endDate;
    }
    this.configsMin[index] = {
      format: 'DD-MM-YYYY',
      min : minDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.configsMax[index] = {
      format: 'DD-MM-YYYY',
      max : maxDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }

  // tslint:disable-next-line:one-line
  termsConditions(){
    $.magnificPopup.close();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#terms-conditions'
        },
        type: 'inline'
      });
    }, 100);
  }

  privacyPolicy(){
    $.magnificPopup.close();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#privacy-policy'
        },
        type: 'inline'
      });
    }, 100);
  }
}
