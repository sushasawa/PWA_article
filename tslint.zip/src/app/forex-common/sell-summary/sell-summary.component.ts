import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { Constants } from '../../helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument();
declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-sell-summary',
  templateUrl: './sell-summary.component.html',
  styleUrls: ['./sell-summary.component.css']
})
export class SellSummaryComponent implements OnInit {
  public _primaryComp: any;
  public userSessionInfo: any;
  public userSessionInfoSummary: any;
  public selectedTraveller: any;
  public purposeOptions: any;
  public destinationOptions: any;
  public currencyList: any;
  public charges: any;
  public currencyListCash: any;
  public bankOptions = [];
  public currentTravellerIndex: number;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  @Input() nextLink: string;
  @Input() disableEdit: boolean;
  @Input() paymentScreen: boolean;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router) {
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSale'));
    this._primaryComp = '/' + navUrl.navUrl();
    this.populateCashCurrency();
    this.populatePrepaidCurrency();
  }

  ngOnInit() {

    this.userSessionInfoSummary = this.userSessionInfo;
    this.getCharges();
    console.log(this.userSessionInfo);
    // this.masterService.getPurposeList()
    //   .subscribe(data => {
    //     this.purposeOptions = data;
    //   });
    this.masterService.getDestinationList()
      .subscribe(data => {
        this.destinationOptions = data;
      });

    this.userSessionInfo.sellScreen.traveller.forEach(traveller => {
      if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.forEach((detail, index) => {
          this.masterService.getBankList(detail.currencyCode)
            .subscribe(data => {
              this.bankOptions[index] = data;

              this.bankOptions[index].forEach(element => {
                element.Logo = Constants.serviceUrl + '/' + element.Logo;
              });
            });
        });
      }
    });

    this.setCurrentTraveller(0);

    setTimeout(function () {
      initDocument();
    }, 1);
  }

  setCurrentTraveller(index: number) {
    this.selectedTraveller = this.userSessionInfo.sellScreen.traveller[index];
    this.currentTravellerIndex = index;
  }

  updatePrepaidValue(newValue, index) {
    if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    this.userSessionInfo.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index].forexAmount = parseFloat(newValue);
    this.updateUsedAmount();
  }

  updateCashValue(newValue, index) {
    if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    this.userSessionInfo.sellScreen.traveller[this.currentTravellerIndex].cashDetails[index].forexAmount = parseFloat(newValue);
    this.updateUsedAmount();
  }

  updatePrepaidCurrencyCode(prepaidDetailIndex: number, newValue: string) {
    this.userSessionInfo.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.sellScreen.branch, 'prepaid', 'sell')
      .subscribe(data => {
        this.userSessionInfo.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex].exchangeRate = data;
      });

  }


  updateCashCurrencyCode(cashDetailIndex: number, newValue: string) {
    this.userSessionInfo.sellScreen.traveller[this.currentTravellerIndex].cashDetails[cashDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.sellScreen.branch, 'cash', 'sell')
      .subscribe(data => {
        this.userSessionInfo.sellScreen.traveller[this.currentTravellerIndex].cashDetails[cashDetailIndex].exchangeRate = data;
      });
  }

  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.charges = Charges;

      this.updateSummaryUsedAmount();
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  updateUsedAmount() {
    let travellerTotal = 0;

    this.userSessionInfo.sellScreen.traveller.forEach(currentTraveller => {
      let currentTravellerTotal = 0;
      if (currentTraveller.prepaidCard) {
        currentTraveller.prepaidCardDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.cash) {
        currentTraveller.cashDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      travellerTotal += currentTravellerTotal;
      currentTraveller.usedAmount = currentTravellerTotal;
    });


    this.userSessionInfo.sellScreen.usedAmount = travellerTotal
      + this.userSessionInfo.sellScreen.deliveryInfo.rate * this.userSessionInfo.sellScreen.traveller.length;
    this.updateBalanceAmount();
  }

  updateSummaryUsedAmount() {
    let travellerTotal = 0;
    this.userSessionInfoSummary.sellScreen.usedAmount = 0;
    this.userSessionInfoSummary.sellScreen.taxData = {
      'CGST': 0,
      'SGST': 0,
      'IGST': 0
    };
    this.serviceCharge = 0;
    let mastercal = 0;
    let CGST = 0;
      let SGST = 0;
      let IGST = 0;
    this.userSessionInfoSummary.sellScreen.traveller.forEach(currentTraveller => {
      let charges = 0;
      let currentTravellerTotal = 0;
      let currentTravellerAmount = 0;

      if (currentTraveller.prepaidCard) {
        currentTraveller.prepaidCardDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.cash) {
        currentTraveller.cashDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }

      travellerTotal += currentTravellerTotal;
      currentTravellerAmount += currentTravellerTotal - (parseInt(this.userSessionInfoSummary.sellScreen.deliveryInfo.rate) +
        this.charges.response.serviceCharge
      );
      this.serviceCharge += this.charges.response.serviceCharge;
      charges += this.charges.response.serviceCharge;
      this.masterService.getTaxes(currentTravellerAmount).subscribe((data) => {
        const result: any = data;
        currentTravellerAmount -= result.TotalTax;
        CGST += result.CGST;
        SGST += result.SGST;
        IGST += result.IGST;
        this.userSessionInfoSummary.sellScreen.taxData.CGST = CGST;
        this.userSessionInfoSummary.sellScreen.taxData.SGST = SGST;
        this.userSessionInfoSummary.sellScreen.taxData.IGST = IGST;
        // charges += result.TotalTax;
        currentTraveller.Charges = charges;
        mastercal += currentTravellerAmount;
        this.userSessionInfoSummary.sellScreen.usedAmount = mastercal;
        currentTravellerAmount = 0;
        SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfoSummary));
      });
      currentTraveller.usedAmount = currentTravellerTotal;
    });

    // the amount is subtracted and not added.. plz note
    // this.userSessionInfoSummary.sellScreen.usedAmount = travellerTotal
    //   - this.userSessionInfoSummary.sellScreen.deliveryInfo.rate * this.userSessionInfoSummary.sellScreen.traveller.length;

    // if (travellerTotal !== 0) {
    //   this.masterService.getTaxes(travellerTotal)
    //     .subscribe(res => {
    //       this.userSessionInfoSummary.sellScreen.taxData = res;
    //       this.userSessionInfoSummary.sellScreen.usedAmount -= this.userSessionInfoSummary.sellScreen.taxData.TotalTax;
    //       SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfoSummary));

    //       if (this.userSessionInfoSummary.sellScreen.deliveryInfo.rate * this.userSessionInfoSummary.sellScreen.traveller.length !== 0) {
    //         this.masterService.getTaxes(this.userSessionInfoSummary.sellScreen.deliveryInfo.rate
    //           * this.userSessionInfoSummary.sellScreen.traveller.length)
    //           .subscribe(data => {
    //             const response: any = data;
    //             this.userSessionInfoSummary.sellScreen.usedAmount -= response.TotalTax;
    //             this.userSessionInfoSummary.sellScreen.taxData.SGST += response.SGST;
    //             this.userSessionInfoSummary.sellScreen.taxData.CGST += response.CGST;
    //             this.userSessionInfoSummary.sellScreen.taxData.IGST += response.IGST;


    //             SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfoSummary));
    //           }, fault => {
    //             console.log(fault);
    //           });
    //       }

    //     }, err => {
    //       console.log(err);
    //     });
    // }
  }

  updateBalanceAmount() {
    if (this.userSessionInfo.sellScreen.budgetAmount !== 0) {
      this.userSessionInfo.sellScreen.balanceAmount =
        (this.userSessionInfo.sellScreen.budgetAmount - this.userSessionInfo.sellScreen.usedAmount).toString();
    }
  }

  updateSession() {
    $.magnificPopup.close();
    SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfo));
    this.userSessionInfoSummary = JSON.parse(SessionHelper.getSession('userSessionInfoSale'));
    this.updateSummaryUsedAmount();
  }

  updateSessionFromDeliveryMode(deliveryInfo) {
    this.userSessionInfo.sellScreen.deliveryInfo = deliveryInfo;
    this.updateSession();
  }

  populatePrepaidCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.sellScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(1, destination)
      .subscribe(data => {
        this.currencyList = data;
      }, err => {
        // swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({text: 'Oops... , Unable to fetch currency list!',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
      });
  }

  populateCashCurrency() {
    // 1	Prepaid Card	    FC
    // 2	Cash	            FCN
    // 3	Traveller's Check	TC
    // 4	Demand Draft	    DD
    // 5	Send money abroad 	TT
    const destination = this.userSessionInfo.sellScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(2, destination)
      .subscribe(data => {
        this.currencyListCash = data;
      }, err => {
        // swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({text: 'Oops... , Unable to fetch currency list!',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
      });
  }

}
