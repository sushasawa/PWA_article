import { Component, OnInit, Input } from '@angular/core';
import { Location } from '@angular/common';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';

declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-common-checklist',
  templateUrl: './common-checklist.component.html',
  styleUrls: ['./common-checklist.component.css']
})
export class CommonChecklistComponent implements OnInit {
  public DocCheckList;
  public userSessionInfoChecklist: any;
  public userSessionInfoTravellers: any;
  public List = ['Cash', 'Travellers Cheque', 'Demand Draft'];
  public reqData: any = [];
  public checklistDataListFromDb;

  public sessionDataProcess: any;
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public wizardStepNumber: any;
  public SessionInfo: any;
  public pageSession: any;

  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private route: ActivatedRoute, private router: Router, private location: Location) { }

  ngOnInit(): void {
    $('body').attr('id', '');
    this.sessionDataProcess = this.route.snapshot.data.sessData.sessionDataProcess;
    this.sessionDataProcessScreen = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.nextLink = this.route.snapshot.data.nextLink;
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;

    this.pageSession = this.route.snapshot.data.sessData.sessionDataProcess;
    this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession));

    this.userSessionInfoTravellers = JSON.parse(SessionHelper.getSession(this.sessionDataProcess))[this.sessionDataProcessScreen].traveller;
    for (const travellerInfo of this.userSessionInfoTravellers) {
      this.reqData.push({
        'process': this.processType,
        'purpose': travellerInfo.purpose ? travellerInfo.purpose : '',
        'hasPrepaid': travellerInfo.hasOwnProperty('prepaidCard') ? travellerInfo.prepaidCard : false
      });
    }

    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[0].selected = true;

    console.log(this.reqData);

    // this.masterService.getDocumentCheckList(this.reqData)
    this.masterService.getDocumentCheckList(this.SessionInfo)
      .subscribe(data => {
        console.log(data);
        if (data !== 'error') {
          this.checklistDataListFromDb = data;
          this.DocCheckList = data[0].Checklist;
        } else {
          // swal('Oops', 'Unable to fetch checklist', 'error');
          // alert('Checklist missing from Database !!');
          Snackbar.show({
            text: 'Checklist missing from Database !!',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        }
      }, error => {
        // swal('Oops', error, 'warning');
        // alert('Checklist missing from Database !!');
        Snackbar.show({
          text: 'Checklist missing from Database !!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  selectTraveller(travellerIndex) {
    const filteredEvents = this.checklistDataListFromDb.filter(function (event) {
      return event.traveller === travellerIndex;
    });
    this.DocCheckList = filteredEvents[0].Checklist;
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }


  updateSession() {
    SessionHelper.setSession(this.pageSession, JSON.stringify(this.SessionInfo));
  }

  routePage() {
    const UserInfo = SessionHelper.getSession('userInfo');
    const UserNextLink = this.navUrl.navUrl() + '/' + this.location.path().split('/')[2] + '/create-account';
    if ((UserInfo != null || UserInfo !== undefined) && JSON.parse(UserInfo).loggedin === true && JSON.parse(UserInfo).uid !== undefined) {
      this.router.navigateByUrl(UserNextLink);
    } else {
      this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
    }
  }

  submitAndRedirect() {

    if (this.processType === 'Sell') {
      this.masterService.dumpSessionData(this.SessionInfo)
        .subscribe(data => {
          // this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
          this.routePage();
        }, err => {
          console.log(err);
        });
    } else {
      // console.log

      this.masterService.RuleTest(this.SessionInfo)
        .subscribe(data => {
          const resData: any = JSON.parse(data);
          console.log(resData);
          if (resData.status === 1) {
            // this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
            this.masterService.dumpSessionData(this.SessionInfo)
              .subscribe(resD => {
                this.routePage();
                //    this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
              }, err => {
                console.log(err);
              });
          } else {
            // swal('error', data, 'error');
            Snackbar.show({
              text: data,
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
            });
          }
        }, err => {
          console.log(err);
        });
    }

    // this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
  }


  parentSaveSession(event) {
    this.SessionInfo = event; console.log(event);
    this.updateSession();
  }


}
