import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonChecklistComponent } from './common-checklist.component';

describe('CommonChecklistComponent', () => {
  let component: CommonChecklistComponent;
  let fixture: ComponentFixture<CommonChecklistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonChecklistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonChecklistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
