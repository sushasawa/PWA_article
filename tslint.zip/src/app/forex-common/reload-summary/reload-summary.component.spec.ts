import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReloadSummaryComponent } from './reload-summary.component';

describe('ReloadSummaryComponent', () => {
  let component: ReloadSummaryComponent;
  let fixture: ComponentFixture<ReloadSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReloadSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReloadSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
