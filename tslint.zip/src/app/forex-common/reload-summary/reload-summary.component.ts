import { Component, Input, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { MasterService } from '../../services/master.services';
import { Constants } from '../../helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { BulkExchangeRateService } from './../../services/bulk-exchange-rate.service';
declare function initDocument(): any;
declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;


@Component({
  selector: 'app-reload-summary',
  templateUrl: './reload-summary.component.html',
  styleUrls: ['./reload-summary.component.css']
})
export class ReloadSummaryComponent implements OnInit  , OnDestroy {
  public _primaryComp: any;
  public userSessionInfo: any;
  public userSessionInfoSummary: any;
  public selectedTraveller: any;
  public purposeOptions: any;
  public destinationOptions: any;
  public currencyList: any;
  public bankOptions = [];
  public currentTravellerIndex: number;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public charges: any;
  public reloadFee: any = 0;
  @Input() nextLink: string;
  @Input() disableEdit: boolean;
  @Input() paymentScreen: boolean;
  @Output() saveSession: EventEmitter<any> = new EventEmitter<any>();
  _BulkEvent: any;
  getChargesSub: any;
  getTaxes: any;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _BulkExchangeRateService: BulkExchangeRateService) {
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoRealoadCard'));
    const destination = this.userSessionInfo.reloadCardScreen.destination.split('#')[0];
    this._primaryComp = '/' + navUrl.navUrl();
    this.masterService.getCurrencyList(1, destination)
      .subscribe(data => {
        this.currencyList = data;
      });

  }

  ngOnInit() {
    $('body').attr('id', '');

    this.userSessionInfoSummary = JSON.parse(SessionHelper.getSession('userSessionInfoRealoadCard'));
    this.getCharges();

    console.log(this.userSessionInfo);
    // FOR PURPOSE LIST  @precessId values :
    // 1	Buy Forex
    // 2	Sell Forex
    // 3	Reload Card
    // 4	Send Money Abroad
    this.masterService.getPurposeList(3)
      .subscribe(data => {
        this.purposeOptions = data;
      });
    this.masterService.getDestinationList()
      .subscribe(data => {
        this.destinationOptions = data;
      });


    this.setCurrentTraveller(0);

    setTimeout(function () {
      initDocument();
    }, 1);

  }

  getLatestRate() {
    if (this.paymentScreen) {
      this._BulkExchangeRateService.getBulkExchangeRate(this.userSessionInfo, 'CLICK');
      this._BulkEvent = this._BulkExchangeRateService.emitSession.subscribe((session) => {
        this.userSessionInfo = session;
        this.updateSession();
      });
    }else {
      this.updateSummaryUsedAmount();
    }
  }


  setCurrentTraveller(index: number) {
    this.selectedTraveller = this.userSessionInfo.reloadCardScreen.traveller[index];
    this.currentTravellerIndex = index;
  }

  updateSession() {
    $.magnificPopup.close();
    SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfo));
    this.userSessionInfoSummary = JSON.parse(SessionHelper.getSession('userSessionInfoRealoadCard'));
    this.updateSummaryUsedAmount();
    //  this.saveSession.emit(this.userSessionInfoSummary);
  }
  updateSessionFromDeliveryMode(deliveryInfo) {
    this.userSessionInfo.reloadCardScreen.deliveryInfo = deliveryInfo;
    this.updateSession();
  }

  updateUsedAmount() {
    let travellerTotal = 0;
    this.userSessionInfo.reloadCardScreen.traveller.forEach(traveller => {
      let currentTravellerTotal = 0;
      this.userSessionInfo.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.forEach(element => {
        element.currencyDetails.forEach(elementCurrency => {
          if (!(elementCurrency.forexAmount === undefined || elementCurrency.exchangeRate === undefined)) {
            currentTravellerTotal += elementCurrency.forexAmount * elementCurrency.exchangeRate.rate;
          }
        });
      });
      travellerTotal += currentTravellerTotal;
      traveller.usedAmount = currentTravellerTotal;
    });

    this.userSessionInfo.reloadCardScreen.usedAmount = travellerTotal
      + this.userSessionInfo.reloadCardScreen.deliveryInfo.rate * this.userSessionInfo.reloadCardScreen.traveller.length;
    if (this.paymentScreen) {
      this.userSessionInfo.reloadCardScreen.billingAmount = this.userSessionInfo.reloadCardScreen.usedAmount;
      this.userSessionInfo.reloadCardScreen.usedAmount = Math.round(this.userSessionInfo.reloadCardScreen.usedAmount);
    }
    this.updateBalanceAmount();
  }

  getCharges() {
   this.getChargesSub  =   this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.charges = Charges;

      this.getLatestRate();
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  updateSummaryUsedAmount() {
    let travellerTotal = 0;
    this.userSessionInfoSummary.reloadCardScreen.usedAmount = 0;
    this.userSessionInfoSummary.reloadCardScreen.taxData = {
      'CGST': 0,
      'SGST': 0,
      'IGST': 0
    };
    this.serviceCharge = 0;
    this.reloadFee = 0;
    let travellerCount = this.userSessionInfoSummary.reloadCardScreen.traveller.length, currentCount = 0;
    this.userSessionInfoSummary.reloadCardScreen.traveller.forEach(traveller => {
      let charges = 0;
      let currentTravellerTotal = 0;
      let currentTravellerAmount = 0;
      traveller.prepaidCardDetails.forEach(element => {
        element.currencyDetails.forEach(elementCurrency => {
          if (!(elementCurrency.forexAmount === undefined || elementCurrency.exchangeRate === undefined)) {
            currentTravellerTotal += elementCurrency.forexAmount * elementCurrency.exchangeRate.rate;
          }
        });
      });
      this.serviceCharge += this.charges.response.serviceCharge;
      this.reloadFee += this.charges.response.LoadFee;
      travellerTotal += currentTravellerTotal;
      // currentTravellerAmount += currentTravellerTotal + parseInt(this.userSessionInfoSummary.reloadCardScreen.deliveryInfo.rate);
      //  console.log(currentTravellerAmount);
      // tslint:disable-next-line:max-line-length
      currentTravellerAmount += currentTravellerTotal + this.charges.response.serviceCharge + Number.parseInt(this.userSessionInfoSummary.reloadCardScreen.deliveryInfo.rate)
        + this.charges.response.LoadFee;
      charges += this.charges.response.serviceCharge + this.charges.response.LoadFee;
     this.getTaxes =  this.masterService.getTaxes(currentTravellerAmount).subscribe((data) => {
        const result: any = data;
        currentCount++;
        currentTravellerAmount += result.TotalTax;
        this.userSessionInfoSummary.reloadCardScreen.taxData.CGST += result.CGST;
        this.userSessionInfoSummary.reloadCardScreen.taxData.SGST += result.SGST;
        this.userSessionInfoSummary.reloadCardScreen.taxData.IGST += result.IGST;
        // charges += result.TotalTax;
        traveller.Charges = charges;
        this.userSessionInfoSummary.reloadCardScreen.usedAmount += currentTravellerAmount;
        if (currentCount === travellerCount && this.paymentScreen) {
          this.userSessionInfo.reloadCardScreen.billingAmount = this.userSessionInfo.reloadCardScreen.usedAmount;
          this.userSessionInfoSummary.reloadCardScreen.usedAmount = Math.round(this.userSessionInfoSummary.reloadCardScreen.usedAmount);
          this.saveSession.emit(this.userSessionInfoSummary);
        }
        currentTravellerAmount = 0;
        SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfoSummary));
      });
      traveller.usedAmount = currentTravellerTotal;

    });

    // this.userSessionInfoSummary.reloadCardScreen.usedAmount = travellerTotal
    //   + this.userSessionInfoSummary.reloadCardScreen.deliveryInfo.rate * this.userSessionInfoSummary.reloadCardScreen.traveller.length;

    // if (this.userSessionInfoSummary.reloadCardScreen.usedAmount !== 0) {
    //   this.masterService.getTaxes(this.userSessionInfoSummary.reloadCardScreen.usedAmount)
    //     .subscribe(res => {
    //       this.userSessionInfoSummary.reloadCardScreen.taxData = res;
    //       this.userSessionInfoSummary.reloadCardScreen.usedAmount += this.userSessionInfoSummary.reloadCardScreen.taxData.TotalTax;
    //       SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(this.userSessionInfoSummary));
    //     }, err => {
    //       console.log(err);
    //     });
    // }
  }


  updateBalanceAmount() {
    this.userSessionInfo.reloadCardScreen.balanceAmount =
      (this.userSessionInfo.reloadCardScreen.budgetAmount - this.userSessionInfo.reloadCardScreen.usedAmount).toString();
  }

  updateCurrencyCode(prepaidDetailIndex: number, currencyIndex: number, newValue: string) {
    this.userSessionInfo.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
      .currencyDetails[currencyIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.reloadCardScreen.branch, 'prepaid')
      .subscribe(data => {
        this.userSessionInfo.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
          .currencyDetails[currencyIndex].exchangeRate = data;
      });
  }

  updateValue(newValue, prepaidIndex, currencyIndex) {
    console.log(' newValue: ' + newValue);
    console.log(' prepaidIndex : ' + prepaidIndex);
    console.log(' currencyIndex : ' + currencyIndex);
    console.log('travellerIndex :' + this.currentTravellerIndex);
    if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    this.userSessionInfo.reloadCardScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidIndex]
      .currencyDetails[currencyIndex].forexAmount = parseFloat(newValue);
    this.updateUsedAmount();
  }

  submitAndRedirect() {
    this.masterService.RuleTest(this.userSessionInfoSummary)
      .subscribe(data => {
        const resData: any = JSON.parse(data);
        console.log(resData);
        if (resData.status === 1) {
          this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
        } else {
          // swal('error', resData.message, 'error');
          Snackbar.show({
            text: resData.message,
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });

        }
      }, err => {
        console.log(err);
      });
  }

  ngOnDestroy() {
    if (this._BulkEvent) {
      this._BulkEvent.unsubscribe();
    }
    if (this.getChargesSub) {
      this.getChargesSub.unsubscribe();
    }
    if (this.getTaxes) {
      this.getTaxes.unsubscribe();
    }
  }
}
