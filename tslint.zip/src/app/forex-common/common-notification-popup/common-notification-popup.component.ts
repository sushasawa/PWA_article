import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MasterService } from '../../services/master.services';

declare var Snackbar: any;
declare var $: any;
@Component({
  selector: 'app-common-notification-popup',
  templateUrl: './common-notification-popup.component.html',
  styleUrls: ['./common-notification-popup.component.css']
})
export class CommonNotificationPopupComponent implements OnInit {
  public NotificationType: string;
  public currencyCode: any;
  public invalidsubmitted: Boolean;
  public CurrenctBranchId: any;
  public requiredAmount: any;
  public AvailableStock: any;
  public NotificationFor: any;
  constructor(private _MasterService: MasterService) {
    console.log('app-common-notification-popup loaded !!!!');
  }

  ngOnInit() {
  }

  initializeNotification(type: string, currencyCode: any, BranchId, requiredAmount: any = 0, AvailableStock: any = 0) {
    console.log(type);
    this.NotificationFor = 'cash';
    this.currencyCode = currencyCode;
    this.NotificationType = type;
    this.CurrenctBranchId = BranchId;
    this.requiredAmount = requiredAmount;
    this.AvailableStock = AvailableStock;
    console.log('req : ' + this.requiredAmount, 'Avai : ' + this.AvailableStock);
    $.magnificPopup.open({
      items: {
        src: '#notification-popup'
      },
      type: 'inline'
    });
  }


  initializeIssuerNotification() {
    this.NotificationFor = 'prepaid';
    $.magnificPopup.open({
      items: {
        src: '#notification-popup'
      },
      type: 'inline'
    });
  }



  createNotification(notificationForm: NgForm, event: Event) {
    event.preventDefault();
    this.invalidsubmitted = notificationForm.invalid;
    let payload: any = {};
    console.log(notificationForm);
    payload = notificationForm.value;
    payload.currencycode = this.currencyCode;
    payload.BranchId = this.CurrenctBranchId;
    payload.requiredAmount = this.requiredAmount;
    payload.AvailableStock = this.AvailableStock;
    // this._MasterService.currencyNotification(payload)
    // .subscribe((data) => {
    //   console.log(data);
    //   notificationForm.reset();
    // });

    if (payload.agree && notificationForm.valid) {
      this._MasterService.currencyNotification(payload)
        .subscribe((data) => {
          console.log(data);
          notificationForm.reset();
          $.magnificPopup.close();
          Snackbar.show({
            text: 'Sent.',
            pos: 'bottom-right',
            actionTextColor: '#1feb2a',
          });
        });
    } else {
      Snackbar.show({
        text: 'Please Accept Terms and Conditions.',
        pos: 'bottom-right',
        actionTextColor: '#ed0c0c',
      });
    }


  }

}
