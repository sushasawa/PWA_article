
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { TransactionService } from '../../../app/services/transaction.service';
import { SessionHelper } from '../../helpers/session-helper';
import { SessionValueResetService } from './../../services/session-value-reset.service';
import { DatePipe } from '@angular/common';
import * as jsPDF from 'jspdf';
import * as d3 from 'd3';
import * as html2canvas from 'html2canvas';
import { forEach } from '@angular/router/src/utils/collection';

declare function initDocument(): any;
declare function initForms(): any;
declare var $: any;
declare var jsPDF: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-common-form',
  templateUrl: './common-form.component.html',
  styleUrls: ['./common-form.component.css']
})
export class CommonFormComponent implements OnInit {
  public userSessionInfo: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public destination: any;
  public place: any;
  public currentDate: any;
  public userInfo: any;
  public sessionDataProcess: any;
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public wizardStepNumber: any;
  public userName: any;

  @ViewChild('printsection') element: ElementRef;

  // tslint:disable-next-line:max-line-length
  // tslint:disable-next-line:no-shadowed-variable
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private TransactionService: TransactionService, private route: ActivatedRoute, private router: Router, private _SessionValueResetService: SessionValueResetService) {

    this.sessionDataProcess = this.route.snapshot.data.sessData.sessionDataProcess;
    this.sessionDataProcessScreen = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;
    this.nextLink = this.route.snapshot.data.nextLink;
    this.userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
    console.log(JSON.parse(SessionHelper.getSession(this.sessionDataProcess))[this.sessionDataProcessScreen].traveller);
    JSON.parse(SessionHelper.getSession(this.sessionDataProcess))[this.sessionDataProcessScreen].traveller.forEach(element => {

      // tslint:disable-next-line:one-line
      if (element.lead) {
        // tslint:disable-next-line:max-line-length
        this.userName = element.registrationInfo.firstName.value + ' ' + element.registrationInfo.middleName + ' ' + element.registrationInfo.lastName;

      }
    });

  }

  ngOnInit(): void {
    $('body').attr('id', '');
    console.log(this.sessionDataProcess);
    // tslint:disable-next-line:max-line-length

    this.userSessionInfo = JSON.parse(SessionHelper.getSession(this.sessionDataProcess));
    this.userSessionInfoTravellers = this.userSessionInfo[this.sessionDataProcessScreen].traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo[this.sessionDataProcessScreen].traveller[0];
    this.destination = this.userSessionInfo[this.sessionDataProcessScreen].destination;
    this.place = this.userSessionInfo[this.sessionDataProcessScreen].currentLocation.city;
    this.currentDate = new Date();

    this.userSessionInfoTravellers[0].selected = true;

    initDocument();

    // console.log("Traveller",this.userSessionInfoTravellers);

   console.log(this.userSessionInfo[this.sessionDataProcessScreen].usedAmount);

    // tslint:disable-next-line:max-line-length


  }


  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfo[this.sessionDataProcessScreen]
      .traveller[travellerIndex];

    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }

  updateSession() {

    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
  }

  payment() {
    this.userSessionInfo['userName'] = this.userName;
    this.userSessionInfo['nextLink'] = this.nextLink;

    this.masterService.RuleTest(this.userSessionInfo)
      .subscribe(data => {
        const resData: any = JSON.parse(data);
        console.log(resData);
        if (resData.status === 1) {
          //  this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
          this.userSessionInfo.isActive = false;
          this.updateSession();
          console.log(this.userSessionInfo);
          this.masterService.dumpSessionData(this.userSessionInfo)
            .subscribe(resD => {
            }, err => {
              console.log(err);
            });
          // tslint:disable-next-line:max-line-length

   this.generateTransaction();
   //  this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
        } else {
          // swal('error', data, 'error');
          Snackbar.show({
            text: data,
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        }
      }, err => {
        console.log(err);
      });

  }
  generateTransaction() {
    Snackbar.show({
      text: 'Processing...',
      pos: 'bottom-right',
      actionTextColor: '#23e257',
      duration: 2000
    });
    // tslint:disable-next-line:max-line-length
    const checkTransactionIdExists = this.userSessionInfo[this.sessionDataProcessScreen]['tranId'] === undefined || this.userSessionInfo[this.sessionDataProcessScreen]['tranId'] === null || this.userSessionInfo[this.sessionDataProcessScreen]['tranId'] === '';

    if (checkTransactionIdExists) {

      this.TransactionService.TransactionId().subscribe((id) => {
        console.log(id);
        this.userSessionInfo[this.sessionDataProcessScreen]['tranId'] = id;
        this.updateSession();
        Snackbar.show({
          text: 'Please Wait...',
          pos: 'bottom-right',
          actionTextColor: '#23e257',
          duration: 3000
        });
        this.generateInvoice();

      }, (error) => {
        console.log(error);
      });
    } else {
      this.generateInvoice();
    }
  }
  generateInvoice() {
    const TravellerNo = this.userSessionInfoTravellers.length;
    this.TransactionService.generateInvoiceNo(TravellerNo)
      .subscribe(resD => {
        console.log(resD);
        for (let travellerIndex = 0; travellerIndex < this.userSessionInfoTravellers.length; travellerIndex++) {
          // tslint:disable-next-line:max-line-length
          this.userSessionInfo[this.sessionDataProcessScreen].traveller[travellerIndex].registrationInfo.invoiceNo = resD[travellerIndex][0].number;
          this.updateSession();
        }
        Snackbar.show({
          text: 'Initializing Payment Process...',
          pos: 'bottom-right',
          actionTextColor: '#23e257',
          duration: 2000
        });
    //    this.saveTransaction();
       this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
       // this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
      }, err => {
        console.log(err);
      });
  }

  saveTransaction() {
            Snackbar.show({
              text: 'Redirecting...',
              pos: 'bottom-right',
              actionTextColor: '#23e257',
              duration: 2000
            });
         this.TransactionService.initTransactionSaving(this.userSessionInfo).subscribe( (data) => {
               console.log(data);
               this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
         });
  }

  onSaveAndTemporaryExit(isGenerateLink = false) {
    if (isGenerateLink) {
      console.log('%%%%%%%%%%%%', isGenerateLink);
      this.userSessionInfo.userId = this.userSessionInfo.tempUserId;
      const individualLeadData = {
        AgentId: JSON.parse(SessionHelper.getSession('userInfo')).uid,
        Url: '',
        FirstName: this.userSessionInfoTravellers[0].registrationInfo.firstName.value,
        MiddleName: this.userSessionInfoTravellers[0].registrationInfo.middleName,
        LastName: this.userSessionInfoTravellers[0].registrationInfo.lastName,
        City: this.userSessionInfo[this.sessionDataProcessScreen].currentLocation.city,
        CountryCode: this.userSessionInfoTravellers[0].registrationInfo.contactDetails.countryCode,
        Mobile: this.userSessionInfoTravellers[0].registrationInfo.contactDetails.mobileNo,
        EmailId: this.userSessionInfoTravellers[0].registrationInfo.contactDetails.emailId,
        AlternateCountryCode: this.userSessionInfoTravellers[0].registrationInfo.alternateContactDetails.emailId,
        AlternateMobileNo: this.userSessionInfoTravellers[0].registrationInfo.alternateContactDetails.mobileNo,
        AlternateEmailId: this.userSessionInfoTravellers[0].registrationInfo.alternateContactDetails.emailId,
        TempNo: this.userSessionInfo.temporaryOrderNumber
      };
      this.updateSession();
      const mailData = [];
      mailData.push(individualLeadData);
      // console.log(test);
      this.masterService.sendMailLeadPax(mailData)
        .subscribe(data => {
          console.log(data);
        });
      this.userSessionInfo.EmailId = this.userSessionInfoTravellers[0].registrationInfo.contactDetails.emailId;
    }
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession(this.sessionDataProcess);
    switch (this.processType) {
      case 'Buy':
        this.router.navigateByUrl(this.navUrl.navUrl() + `/buy`);
        //   /register-login
        break;
      case 'Sell':
        this.router.navigateByUrl(this.navUrl.navUrl() + `/sell`);
        break;
      case 'Reload':
        this.router.navigateByUrl(this.navUrl.navUrl() + `/reload-card`);
        break;
      case 'Send':
        this.router.navigateByUrl(this.navUrl.navUrl() + `/send-money`);
        break;
      default:
        break;
    }
  }

  print(): void {
    let printContents = '', popupWin;

    printContents += document.getElementById('print-section').innerHTML;

    popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    popupWin.document.open();
    popupWin.document.write(`
      <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <link href="/assets/css/bootstrap.css" rel="stylesheet">
          <!-- Bootstrap core CSS -->
          <link href="/assets/css/plugin.min.css" rel="stylesheet" type="text/css" media="all">
          <!-- icons -->
          <!-- Custom styles for this template -->
          <link href="/assets/css/style.min.css" rel="stylesheet">
          <link href="/assets/css/media.min.css" rel="stylesheet">
          <script>
              function clearSignSpace() {
                var elements = document.getElementsByClassName('sign-space');
                for(var i = 0; i < elements.length; i++) {
                  elements[i].innerHTML = '';
                }
              }
          </script>
        </head>
        <body onload="clearSignSpace();window.print();window.close();">${printContents}</body>
      </html>`
    );
    popupWin.document.close();
  }

  download(): void {
    let userName,
      timeNow,
      // tslint:disable-next-line:prefer-const
      pageDimentions = [595, 841],
      // tslint:disable-next-line:prefer-const
      imageWidth = 570,
      // tslint:disable-next-line:prefer-const
      imageHeight = 820,
      // tslint:disable-next-line:prefer-const
      pagePadding = 5,
      // tslint:disable-next-line:prefer-const
      qualityParam = 1.0,
      fileName;
    userName = this.userSessionInfoSelectedTraveller.registrationInfo.firstName.value;
    timeNow = (new DatePipe('en-US').transform(new Date(), 'MMM d y h mma')).replace(/ /g, '_');
    fileName = 'lrs_' + userName + '_' + timeNow;
    html2canvas(this.element.nativeElement).then((canvas: HTMLCanvasElement) => {
      const img = canvas.toDataURL('image/png', qualityParam);
      const canvasWidth = +canvas.getAttribute('width'),
        canvasHeight = +canvas.getAttribute('height');
      const imageDimantions = this.calculateHeightWidth(pageDimentions, canvasWidth, canvasHeight);
      const doc = new jsPDF('p', 'pt', pageDimentions);
      doc.addImage(img, 'JPEG', imageDimantions.pagePadding, pagePadding, imageDimantions.imageWidth, imageDimantions.imageHeight);
      doc.save(fileName + '.pdf');
    });
  }

  calculateHeightWidth(pageDimentions, imageWidth, imageHeight) {
    // tslint:disable-next-line:prefer-const
    let pageWidth = pageDimentions[0] - 20,
      // tslint:disable-next-line:prefer-const
      pageHeight = pageDimentions[1] - 20,
      imageRatio,
      newImageHeight,
      newImageWidth,
      paddingValue = 5,
      pageRatio;
    imageRatio = imageHeight / imageWidth;
    pageRatio = pageHeight / pageWidth;
    if (imageRatio < pageRatio && imageWidth > pageWidth) {
      newImageWidth = pageWidth;
      newImageHeight = imageRatio * pageWidth;
    } else if (imageRatio > pageRatio && imageHeight > pageHeight) {
      newImageHeight = pageHeight;
      newImageWidth = pageHeight / imageRatio;
      paddingValue = (pageWidth - newImageWidth) / 2;
    } else if (imageWidth < pageWidth && imageHeight < pageHeight) {
      newImageHeight = imageWidth;
      newImageWidth = imageHeight;
    }
    return { imageWidth: newImageWidth, imageHeight: newImageHeight, pagePadding: paddingValue };
  }

  parentSaveSession(event) {
    this.userSessionInfo = event;
    this.updateSession();
  }
}
