import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { PipesModule } from '../pipes/pipes.module';
import { SelectModule } from 'ng-select';
import { NumberLocalePipe } from '../pipes/number-locale.pipe';
import { CommonRegisterLoginComponent } from './common-register-login/common-register-login.component';
import { CommonRegisterLoginAdharComponent } from './common-register-login-adhar/common-register-login-adhar.component';
import { CommonDeliveryModeComponent } from './common-delivery-mode/common-delivery-mode.component';
import { CommonUsercreationAdharComponent } from './common-usercreation-adhar/common-usercreation-adhar.component';
import { CommonUsercreationComponent } from './common-usercreation/common-usercreation.component';
import { CommonFormComponent } from './common-form/common-form.component';
import { CommonReviewUserDetailsComponent } from './common-review-user-details/common-review-user-details.component';
import { CommonConfirmationComponent } from './common-confirmation/common-confirmation.component';
import { CommonKycComponent } from './common-kyc/common-kyc.component';
import { ChartsModule } from 'ng2-charts';

// checklist component
import { CommonChecklistComponent } from './common-checklist/common-checklist.component';

// summary component
import { BuySummaryComponent } from './buy-summary/buy-summary.component';
import { SellSummaryComponent } from './sell-summary/sell-summary.component';
import { ReloadSummaryComponent } from './reload-summary/reload-summary.component';
import { SendSummaryComponent } from './send-summary/send-summary.component';

// wizard component
import { WizardComponent } from './wizard/wizard.component';
import { CommonPaymentGatewayComponent } from './common-payment-gateway/common-payment-gateway.component';
import { RateAlertComponent } from './rate-alert/rate-alert.component';
import { LiveRatesComponent } from './live-rates/live-rates.component';
import { PasswordStrengthBarModule } from 'ng2-password-strength-bar';

// import { EqualTextValidator } from 'angular2-text-equality-validator';


import { MomentModule } from 'angular2-moment';
import { FailComponent } from './fail/fail.component';

import {DpDatePickerModule} from 'ng2-date-picker';
import { AgmCoreModule } from '@agm/core';
import { CommonNotificationPopupComponent } from './common-notification-popup/common-notification-popup.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    PipesModule,
    SelectModule,
    MomentModule,
    PasswordStrengthBarModule,
    DpDatePickerModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAQaeIKoWfFMxZJxN3m4Bs1SJe4w-FX4Mk'
    }),
    ChartsModule
  ],
  declarations: [
    CommonDeliveryModeComponent,
    CommonChecklistComponent,
    CommonUsercreationAdharComponent,
    CommonUsercreationComponent,
    CommonRegisterLoginComponent,
    CommonRegisterLoginAdharComponent,
    CommonFormComponent,
    CommonReviewUserDetailsComponent,
    CommonConfirmationComponent,
    CommonKycComponent,
    BuySummaryComponent,
    SellSummaryComponent,
    ReloadSummaryComponent,
    SendSummaryComponent,
    WizardComponent,
    CommonPaymentGatewayComponent,
    RateAlertComponent,
    LiveRatesComponent,
    LiveRatesComponent,
    FailComponent,
    CommonNotificationPopupComponent
  ],
  exports: [
    CommonDeliveryModeComponent,
    CommonChecklistComponent,
    CommonUsercreationAdharComponent,
    CommonUsercreationComponent,
    CommonRegisterLoginComponent,
    CommonRegisterLoginAdharComponent,
    CommonFormComponent,
    CommonReviewUserDetailsComponent,
    CommonConfirmationComponent,
    CommonUsercreationAdharComponent,
    CommonKycComponent,
    BuySummaryComponent,
    SellSummaryComponent,
    ReloadSummaryComponent,
    SendSummaryComponent,
    WizardComponent,
    RateAlertComponent,
    CommonPaymentGatewayComponent,
    LiveRatesComponent,
    CommonNotificationPopupComponent
  ]
})
export class ForexCommonModule { }
