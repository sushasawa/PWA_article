import { Component, OnInit, Input } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;
@Component({
  selector: 'app-common-kyc',
  templateUrl: './common-kyc.component.html',
  styleUrls: ['./common-kyc.component.css']
})
export class CommonKycComponent implements OnInit {
  @Input() currentSession: any;
  @Input() pageSession: any;
  @Input() nextLink: any;
  @Input() processType: any;
  public userSessionInfo: any;
  public SessionInfo: any;
  public DocCheckList: any;
  public formdata: any;
  public docs: Array<any>;
  public documentScr: any;
  public close = document.getElementsByClassName('close')[0];
  public fileupload: Array<any>;
  public currentUserId: any;
  public showModal: Boolean;
  public showSnackBar: Boolean;
  public snackBarText: any;
  public invalidsubmitted: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private sanitizer: DomSanitizer, private route: Router ) {
    console.log('COMMON KYC LOADED...');
    const UserInfo: any = SessionHelper.getSession('userInfo');
    if (UserInfo !== null || UserInfo !== undefined) {
      this.currentUserId = JSON.parse(UserInfo).uid;
    }
    this.showModal = false;
    this.showSnackBar = false;
  }

  ngOnInit() {
    this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession)); console.log(this.SessionInfo);
    this.userSessionInfo = this.SessionInfo[this.currentSession];
    this.userSessionInfo.traveller.map((traveller, index) => {
      traveller.selected = false;
      this.masterService.getDocumentCheckList(this.SessionInfo).subscribe((data) => {
        const checklistData = data[index].Checklist;
        this.masterService.getUserDocuments(traveller.registrationInfo.userId).subscribe((uploadedDocs) => {
          const uploadedDocsResult: any = uploadedDocs;
          checklistData.map((checklist) => {
            uploadedDocsResult.response.map((docs, docsIndex) => {
              if (checklist.Doc.toUpperCase() === docs.type.toUpperCase() ||
                checklist.Doc.toUpperCase().indexOf(docs.type.toUpperCase()) !== -1) {
                checklist.showView = true;
                checklist.imageUrl = docs.imageUrl;
              }
            });
          });
        });
        traveller.DocCheckList = checklistData;
      });
    });
    this.userSessionInfo.traveller[0].selected = true;
  }



  uploadDoc(ele: any, doc: any, controlIndex: any, travellerIndex: any) {
    if (this.currentUserId) {

      Snackbar.show({text: 'Uploading...',
      pos: 'bottom-right' ,
      actionTextColor: '#00880d',
     });
      const docs = ele.target.files[0];
      this.formdata = new FormData();
      const doctype = { 'doc': doc };
      const userid = { 'id': this.currentUserId };
      this.formdata.append('Doctype', JSON.stringify(doctype));
      this.formdata.append('userdata', JSON.stringify(userid));
      const fileValidation = (docs.type.indexOf('jpeg') !== -1 || docs.type.indexOf('png') !== -1
        || docs.type.indexOf('gif') !== -1) && docs.size <= 500000;
      if (fileValidation) {
        this.formdata.append('sampleFile', docs, docs.name);
        this.masterService.uploadTravellerDocuments(this.formdata)
          .subscribe((data) => {
            const result: any = data;
            this.formdata = {};
            doc.imageUrl = result.response.imgUrl;
            doc.showView = true;
              Snackbar.show({text: 'File Uploaded Successfully...',
              pos: 'bottom-right' ,
              actionTextColor: '#00880d',
            });
           }, (error) => {
            doc.showView = false;
              Snackbar.show({text: 'Error Uploading File Please try Again.',
              pos: 'bottom-right' ,
              actionTextColor: '#00880d',
              });
           });
      } else {
        // swal('', 'Supports JPEG, PNG and GIF. The file size should not exceed 500 KB.', 'error');
        Snackbar.show({text: 'Supports JPEG, PNG and GIF. The file size should not exceed 500 KB.',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
      }
    }else {
      Snackbar.show({text: 'You are not Authorized.',
      pos: 'bottom-right' ,
      actionTextColor: '#00880d',
     });
    }
}

  viewDoc(Doc: any) {
    if (Doc.hasOwnProperty('imageUrl')) {
      console.log('openPopup');
      const imageValidation = Doc.imageUrl.indexOf('.jpg') !== -1 || Doc.imageUrl.indexOf('.png') !== -1
        || Doc.imageUrl.indexOf('.gif') !== -1;
      if (imageValidation) {
        this.documentScr = Doc.imageUrl;
        this.showModal = true;
      } else if (Doc.imageUrl.indexOf('.pdf') !== -1) {
        this.showModal = false;
        this.documentScr = Doc.imageUrl;
        const newtab = window.open(this.documentScr, '_blank');
        newtab.focus();
      }
    } else {
      this.showModal = false;
    }
  }
  removeDoc(Doc: any) {
    console.log(Doc);
    Doc.showView = false;
    const payload: any = {};
    payload.type = Doc.Doc;
    payload.userId = this.currentUserId;
    Snackbar.show({text: 'Removing...',
    pos: 'bottom-right' ,
    actionTextColor: '#00880d',
  });
    console.log(payload);
    if (this.currentUserId !== undefined || this.currentUserId !== null) {
       this.masterService.deleteDocument(payload).subscribe((data) => {
           const result: any = data;
           if (result.success) {
            Snackbar.show({text: 'Removed Successfully...',
            pos: 'bottom-right' ,
            actionTextColor: '#00880d',
          });
           }else {
            this.showSnackBar = true;
            this.snackBarText = result.message;
            this.closeSnackBar();
           }
       //  this.closeSnackBar();
       }, (error) => {
            Snackbar.show({text: 'Error Removing File Please try Again.',
            pos: 'bottom-right' ,
            actionTextColor: '#00880d',
            });
       });
    }
  }

  closeDocpopup() {
    this.showModal = false;
  }

  closePopupAuto() {
      setTimeout(() => {
        this.showSnackBar = false;
      }, 2000);
  }
  closeSnackBar() {
    this.showSnackBar = false;
    this.snackBarText = '';
  }
  selectTraveller(travellerIndex) {

    this.userSessionInfo.traveller.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfo.traveller[travellerIndex].selected = true;
    if (this.userSessionInfo.traveller[travellerIndex].lead) {
      this.currentUserId = this.userSessionInfo.traveller[travellerIndex].registrationInfo.parentId;
    } else {
      this.currentUserId = this.userSessionInfo.traveller[travellerIndex].registrationInfo.userId;
    }
  }

  submitAndRedirect(event: Event, kycForm: NgForm) {
         $.magnificPopup.close();
         event.preventDefault();
       //  this.invalidsubmitted = kycForm.invalid;
         console.log(kycForm);
        //  this.route.navigateByUrl(this.navUrl.navUrl() + this.nextLink);  // Disabled navigation to avoid skiping of steps.
  }
}
