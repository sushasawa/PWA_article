import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendSummaryComponent } from './send-summary.component';

describe('SendSummaryComponent', () => {
  let component: SendSummaryComponent;
  let fixture: ComponentFixture<SendSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
