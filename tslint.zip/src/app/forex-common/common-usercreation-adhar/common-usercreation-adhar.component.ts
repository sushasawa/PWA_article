import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '../../../app/helpers/location';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var $: any;

@Component({
  selector: 'app-common-usercreation-adhar',
  templateUrl: './common-usercreation-adhar.component.html',
  styleUrls: ['./common-usercreation-adhar.component.css']
})
export class CommonUsercreationAdharComponent implements OnInit {
  public cityOptions: any; // : GenericEntity[];
  public nationalityOptions: any; // : GenericEntity[];

  public userSessionInfo: any;
  public userSessionInfoTravellers: any;
  public selIndex = 0;
  public sessionDataProcess: any;
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public wizardStepNumber: any;
  public termsAcceptance = false;


  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private route: ActivatedRoute) { }


  ngOnInit(): void {
    $('body').attr('id', '');

    this.sessionDataProcess = this.route.snapshot.data.sessData.sessionDataProcess;
    this.sessionDataProcessScreen = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.nextLink = this.route.snapshot.data.nextLink;
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;


    this.userSessionInfo = JSON.parse(SessionHelper.getSession(this.sessionDataProcess));
    this.userSessionInfoTravellers = JSON.parse(SessionHelper.getSession(this.sessionDataProcess))[this.sessionDataProcessScreen].traveller;

    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[0].selected = true;

    this.masterService.getCityList()
      .subscribe(data => {
        this.cityOptions = data;
        const currentDocument = this;
      });

    this.masterService.getNationalityList()
      .subscribe(data => {
        this.nationalityOptions = data;
      });
      initDocument();
  }
  callPinCodeService(event, type) {
    const pinCode = event.target.value;

    this.masterService.getPinCodeDetails(pinCode)
      .subscribe(data => {
        const Retdata: any = data;
        if (Retdata.Status === 'Success') {
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['city'] = Retdata.PostOffice[0].District;
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['state'] = Retdata.PostOffice[0].State;
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['area'] = Retdata.PostOffice[0].Name;
        } else {
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['city'] = '';
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['state'] = '';
          this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['area'] = '';
        }
      });
  }
  // GENERIC FUNCTION TO UPDATE SESSION DATA
  updateSession() {
    this.userSessionInfo[this.sessionDataProcessScreen].traveller[this.selIndex] = this.userSessionInfoTravellers[this.selIndex];
    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
  }
  // SUBMIT FUNCTION TO REDIRECT PAGE
  submitFunction(userForm): void {

    if (!this.termsAcceptance) {
      swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
    } else {
      if (SessionHelper.setSession('userInfo', JSON.stringify('userinfo')) === undefined) {
        const userinfo = {
          'loggedin': true,
          'uname': '-',
          'uid': 1,
          'userName': this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.firstName.value
        };
        SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
      }
      this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
    }

  }
  // GENDER RADIO CHANGE
  Gender(newValue: any) {
    this.userSessionInfoTravellers[this.selIndex].registrationInfo.gender.value = newValue;
    this.updateSession();
  }
  // ADHARADDRESS RADIO CHANGE
  radioAdharAddress(status) {
    this.userSessionInfoTravellers[this.selIndex].registrationInfo.isPassportAddressAsAdhar = status;
    this.updateSession();
  }
  // RADIO FUNCTION FOR CURRENT ADDRESS SELECTION
  radioCurrentAddress(statusName) {
    this.userSessionInfoTravellers[this.selIndex].registrationInfo.currentAddressAs = statusName;
    this.updateSession();
  }
  selectTraveller(travellerIndex) {
    this.selIndex = travellerIndex;
    for (let i = 0; i <= this.userSessionInfoTravellers.length - 1; i++) {
      this.userSessionInfoTravellers[i].selected = false;
    }
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }
}
