import { Component, Input, OnInit } from '@angular/core';

import { SessionHelper } from '../../helpers/session-helper';

@Component({
  selector: 'app-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.css']
})
export class WizardComponent implements OnInit {

  @Input() process: string;
  @Input() stepNumber: number;
  public sevenStep: boolean;
  public extraStep : boolean;
  constructor() {
    if (SessionHelper.getSession('userSessionInfoSale')) {
      const userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSale'));

      userSessionInfo.sellScreen.traveller.forEach(element => {
        if (element.cash) {
          this.sevenStep = true;
        }
      });
    }

    if (SessionHelper.getSession("userSessionInfo")) {
      var userSessionInfo = JSON.parse(SessionHelper.getSession("userSessionInfo"));      
      userSessionInfo.buyScreen.traveller.forEach(element => {
        if (element.demandDraft) {
          this.extraStep = true;
        }
      });
    }
  }

  ngOnInit() {
  }

}
