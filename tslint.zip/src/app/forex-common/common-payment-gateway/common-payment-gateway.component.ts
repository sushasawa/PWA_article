import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '@angular/common';
import * as moment from 'moment';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { Constants } from '../../helpers/constants';
declare function initDocument(): any;
// tslint:disable-next-line:max-line-length
declare function paymentGatewayCall(deviceId, token, returnUrl, paymentMode, merchantId, consumerId, consumerMobileNo, consumerEmailId, txnId, itemId, amount, comAmt): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;

@Component({
  selector: 'app-common-payment-gateway',
  templateUrl: './common-payment-gateway.component.html',
  styleUrls: ['./common-payment-gateway.component.css']
})
export class CommonPaymentGatewayComponent implements OnInit {
  public userSessionInfo: any;
  public sessionDataProcess: any;
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public wizardStepNumber: any;
  public deviceId: any;
  public returnUrl: any;
  public paymentMode: any;
  public merchantId: any;
  public consumerId: any;
  public consumerMobileNo: any;
  public consumerEmailId: any;
  public txnId: any;
  public itemId: any;
  public amount: any;
  public comAmt: any;
  public UserName: any;
  public mobileNo: any;
  public emailId: any;
  public screen: any;
  public termsAcceptance: any;
  public termsAcceptance1: any;
  public saltKey: any;
  public pgurl: any;
  public billingAmount: any;
  public differenceAmount: any;

  // tslint:disable-next-line:no-shadowed-variable
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private route: ActivatedRoute, private location: Location, private Router: Router) { }

  ngOnInit() {

    this.sessionDataProcess = this.route.snapshot.data.sessData.sessionDataProcess;
    this.sessionDataProcessScreen = this.route.snapshot.data.sessData.sessionDataProcessScreen;
    this.processType = this.route.snapshot.data.sessData.processType;
    this.nextLink = this.route.snapshot.data.nextLink;
    this.wizardStepNumber = this.route.snapshot.data.wizardStepNumber;
    this.userSessionInfo = JSON.parse(SessionHelper.getSession(this.sessionDataProcess));
    // tslint:disable-next-line:max-line-length
    if (!this.userSessionInfo[this.sessionDataProcessScreen].billingAmount || this.numberTest(this.userSessionInfo[this.sessionDataProcessScreen].usedAmount, this.userSessionInfo[this.sessionDataProcessScreen].billingAmount)) {
      this.billingAmount = this.userSessionInfo[this.sessionDataProcessScreen].usedAmount;
      this.userSessionInfo[this.sessionDataProcessScreen].billingAmount = this.billingAmount;
    } else if (this.userSessionInfo[this.sessionDataProcessScreen].billingAmount) {
      this.billingAmount = this.userSessionInfo[this.sessionDataProcessScreen].billingAmount;
    }
    // tslint:disable-next-line:max-line-length
    this.userSessionInfo[this.sessionDataProcessScreen].usedAmount = Math.round(this.userSessionInfo[this.sessionDataProcessScreen].usedAmount);
    this.differenceAmount = this.userSessionInfo[this.sessionDataProcessScreen].usedAmount - this.billingAmount;
    this.userSessionInfo[this.sessionDataProcessScreen].differenceAmount = this.differenceAmount;
    SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
    this.screen = JSON.parse(SessionHelper.getSession(this.sessionDataProcess))[this.sessionDataProcessScreen];
    this.amount = this.screen.usedAmount;
    this.pgurl = Constants.serviceUrl + '/transaction/SaveResponseData?successurl=';
    initDocument();
    // this.pgurl = "http://10.21.20.42:5020/transaction/SaveResponseData?successurl=";
  }

  proceed() {
    if (!this.termsAcceptance) {
      // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
      Snackbar.show({text: 'Please accept terms and conditions to proceed',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
    }else if (!this.termsAcceptance1) {
      // swal('Cannot proceed', 'Please accept Cox and Kings terms and conditions to proceed', 'error');
      Snackbar.show({text: 'Please accept Cox and Kings terms and conditions to proceed',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
    } else {

      // GET lead pack info
      JSON.parse(SessionHelper.getSession(this.sessionDataProcess))[this.sessionDataProcessScreen].traveller.forEach(element => {
        if (element.lead) {
          // tslint:disable-next-line:max-line-length
          this.UserName = element.registrationInfo.firstName.value + ' ' + element.registrationInfo.middleName + ' ' + element.registrationInfo.lastName;
          this.mobileNo = element.registrationInfo.contactDetails.mobileNo;
          this.emailId = element.registrationInfo.contactDetails.emailId;
        }
      });

      // console.log(parseFloat(screen.usedAmount).toFixed(2));
      this.deviceId = 'WEBSH2';
      // tslint:disable-next-line:max-line-length
      // this.token = "ca25c3ecb179f82d06059d693b6ad4ad901671ea09e1bdec318d908cead1ed1eab3ca1265e833f98614ef92691d125d9d6eb92599e900c20eb593e95afbeedc5";
      this.returnUrl =  this.pgurl + window.location.href.replace('payment-gateway', 'confirmation') + '&failurl=' + window.location.href.replace('payment-gateway', 'fail');
      this.paymentMode = 'all';
      //    for test purpose use T218263 as merchant id
      //    for PRODUCTION purpose use L218263 as merchant id
      this.merchantId = 'L218263';
      this.consumerId = 'c964634';
      this.consumerMobileNo = this.mobileNo;
      this.consumerEmailId = this.emailId;
      this.txnId = this.screen.tranId;
      this.amount = this.amount;
      this.itemId = 'FIRST';
      this.saltKey = '2579342167VXYLTV';
      // this.consumerMobileNo = '9876543210';
      // this.consumerEmailId = 'test@test.com';
      // this.txnId = '1481197581115';
      // this.amount = "10";
      this.comAmt = '0';
      // tslint:disable-next-line:max-line-length
      const hashToken = { 'key' : this.merchantId + '|' + this.txnId + '|' + this.amount + '||' + this.consumerId + '|' + this.consumerMobileNo + '|' + this.consumerEmailId + '||||||||||' + this.saltKey};
      console.log('hash function');
      console.log(hashToken);
      this.masterService.paymentgatewayPaynimo(hashToken)
        .subscribe(data => {
         // var data = data.substr(1).slice(0, -1);
         console.log(data);
          // tslint:disable-next-line:max-line-length
          paymentGatewayCall(this.deviceId, data, this.returnUrl, this.paymentMode, this.merchantId, this.consumerId, this.consumerMobileNo, this.consumerEmailId, this.txnId, this.itemId, this.amount, this.comAmt);
        //  this.userSessionInfo[this.sessionDataProcessScreen]['tranId'] = '';
          this.updateSession();

        }, error => {

          console.log(error);
          // swal('Oops...', 'Payment Gateway failed!', 'error');
          Snackbar.show({text: 'Payment Gateway failed!',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
        });

    }
  }

  updateSession() {

        SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
      }

  onSaveAndTemporaryExit(isGenerateLink = false) {
    if (isGenerateLink) {
      console.log('%%%%%%%%%%%%', isGenerateLink, this.userSessionInfo);
      this.userSessionInfo.userId = this.userSessionInfo.tempUserId;
      const individualLeadData = {
        AgentId: JSON.parse(SessionHelper.getSession('userInfo')).uid,
        Url: '',
        FirstName: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.firstName.value,
        MiddleName: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.middleName,
        LastName: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.lastName,
        City: this.userSessionInfo[this.sessionDataProcessScreen].currentLocation.city,
        CountryCode: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.contactDetails.countryCode,
        Mobile: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.contactDetails.mobileNo,
        EmailId: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.contactDetails.emailId,
        AlternateCountryCode: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.alternateContactDetails.emailId,
        AlternateMobileNo: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.alternateContactDetails.mobileNo,
        AlternateEmailId: this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.alternateContactDetails.emailId,
        TempNo: this.userSessionInfo.temporaryOrderNumber
      };
      this.updateSession();
      const mailData = [];
      mailData.push(individualLeadData);
      // console.log(test);
      this.masterService.sendMailLeadPax(mailData)
        .subscribe(data => {
          console.log(data);
        });
      this.userSessionInfo.EmailId = this.userSessionInfo[this.sessionDataProcessScreen].traveller[0].registrationInfo.contactDetails.emailId;
    }
    $.magnificPopup.close();
    this.masterService.dumpSessionData(this.userSessionInfo)
      .subscribe(data => {
      }, err => {
        console.log(err);
      });
    SessionHelper.removeSession(this.sessionDataProcess);
    switch (this.processType) {
      case 'Buy':
        this.Router.navigateByUrl(this.navUrl.navUrl() + `/buy`);
        //   /register-login
        break;
      case 'Sell':
        this.Router.navigateByUrl(this.navUrl.navUrl() + `/sell`);
        break;
      case 'Reload':
        this.Router.navigateByUrl(this.navUrl.navUrl() + `/reload-card`);
        break;
      case 'Send':
        this.Router.navigateByUrl(this.navUrl.navUrl() + `/send-money`);
        break;
      default:
        break;
    }
  }

  numberTest(num, oldNumber) {
    const result = (num - Math.floor(num)) !== 0;
    if (result || num !== Math.round(oldNumber)) {
      return true;
    }
    return false;
  }



  // proceed() {

  //   var storename = "3300219112";
  //   var txndatetime = moment().format('YYYY:MM:DD-HH:mm:ss');
  //   //var chargetotal = JSON.parse(SessionHelper.getSession("userSessionInfo")).buyScreen.usedAmount;
  //   var chargetotal = 1;
  //   var sharedsecret = "WSRLm9ptqK";
  //   var currency = "356";

  //   var info = {
  //     "StoreName": storename,
  //     "TxnDateTime": txndatetime,
  //     "ChargeTotal": chargetotal,
  //     "SharedSecret": sharedsecret,
  //     "Currency": currency
  //   };

  //   this.masterService.paymentgateway(info)
  //     .subscribe(data => {

  //       console.log(info);
  //       console.log(data);

  // tslint:disable-next-line:max-line-length
  //       var formCode = "<form id=\"form1\" name=\"form1\" method=\"post\" action=\"https://www4.ipg-online.com/connect/gateway/processing\">" +
  //         "<input type=\"hidden\" name=\"txntype\" value=\"sale\">" +
  //         "<input type=\"hidden\" name=\"timezone\" value=\"IST\"/>" +
  //         "<input type=\"hidden\" name=\"txndatetime\" value=\""+txndatetime+"\"/>" +
  //         "<input type=\"hidden\" name=\"hash\" value=\""+data+"\"/>" +
  //         "<input type=\"hidden\" name=\"storename\" value=\""+storename+"\" />" +
  //         "<input type=\"hidden\" name=\"mode\" value=\"payonly\"/>" +
  //         "<input type=\"hidden\" name=\"currency\" value=\""+currency+"\" />" +
  //         "<input type=\"hidden\" name=\"chargetotal\" value=\""+chargetotal+"\"/>" +
  //         "<input type=\"hidden\" name=\"language\" value=\"en_EN\"/>" +

  //         "<input type=\"hidden\" name=\"authenticateTransaction\" value=\"true\"/>" +
  // tslint:disable-next-line:max-line-length
  //         "<input type=\"hidden\" name=\"responseFailURL\" value=\"http://localhost:4200/buy/confirmation\"/>" + //need to change as per merchant ip/url
  //         "<input type=\"hidden\" name=\"responseSuccessURL\" value=\"http://localhost:4200/buy/confirmation\"/>" + //need to change as per merchant ip/url
  //         "</form>";

  //       console.log(formCode);
  //       $('#paymentForm').append(formCode);
  //       $('#form1').submit();
  //     }, error => {
  //       console.log(info);
  //       console.log(error);
  //       swal('Oops...', 'Payment Gateway failed!', 'error')
  //     });





  // }

}
