import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonPaymentGatewayComponent } from './common-payment-gateway.component';

describe('CommonPaymentGatewayComponent', () => {
  let component: CommonPaymentGatewayComponent;
  let fixture: ComponentFixture<CommonPaymentGatewayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonPaymentGatewayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonPaymentGatewayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
