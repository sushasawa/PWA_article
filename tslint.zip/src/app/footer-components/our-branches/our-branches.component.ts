import { Component, OnInit } from '@angular/core';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { NgForm } from '@angular/forms/src/directives/ng_form';

declare var L: any;
declare var $: any;
@Component({
  selector: 'app-our-branches',
  templateUrl: './our-branches.component.html',
  styleUrls: ['./our-branches.component.css']
})
export class OurBranchesComponent implements OnInit {
  public branchOptions: any;
  public cityOptions: any;
  public CityDetails: any;
  public mymap: any;
  public BranchDetails: any;
  public BranchDetailsEnable: any;
  public branchPickupDetails: any;
  public userCity: any;
  public userBranch: any;
  public lat: number;
  public lng: number;
  public zoom = 15;
  public maploaded= false;

  constructor(private masterService: MasterService) {
    this.updateBranch(this.masterService.turnerMorrisonBranchId);
  }

  ngOnInit(): void {
    $('body').attr('id', '');
    this.masterService.getBranchList('mumbai')
      .subscribe(data => {
        this.branchOptions = data;

      });

    this.masterService.getCityList()
      .subscribe(data => {
        this.cityOptions = data;

      });
  }

 updateCity(newValue: string) {
    this.masterService.getBranchList(newValue.split('#')[1])
    .subscribe(data => {
      this.branchOptions = data;
    });
  }

  updateBranch(newValue: number) {
    this.masterService.getBranchDetails(newValue)
      .subscribe(data => {
        this.BranchDetails = data;
        this.BranchDetailsEnable = true;
        // const currentDocument = this;
        // setTimeout(function () {
        //   if (currentDocument.mymap === undefined) {
        //     currentDocument.mymap = L.map('mapidOurBranches', { attributionControl: false });
        //     L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
        //       attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors,'
        //         + ' <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>,'
        //         + ' Imagery © <a href="http://mapbox.com">Mapbox</a>',
        //       maxZoom: 18,
        //       id: 'mapbox.streets',
        //       accessToken: 'pk.eyJ1Ijoia2FtbGVzaC1jbmsiLCJhIjoiY2phN3d5bGRsMDB1MzM3cW1iOHYzbHN3ZCJ9.sy4v_2XvDe4zm1peJeSCXQ'
        //     }).addTo(currentDocument.mymap);
        //   }
        //   L.marker([currentDocument.BranchDetails[0].latitude, currentDocument.BranchDetails[0].longitude]).addTo(currentDocument.mymap);
        //   currentDocument.branchPickupDetails = currentDocument.BranchDetails[0].branchPickupDetails;
        //   currentDocument.mymap.setView([currentDocument.BranchDetails[0].latitude, currentDocument.BranchDetails[0].longitude], 15);
        // }, 5);
        this.lat = +this.BranchDetails[0].latitude;
          this.lng = +this.BranchDetails[0].longitude;
          if (this.BranchDetails[0].latitude && this.BranchDetails[0].longitude){
            this.maploaded = true;
          } else {
            this.maploaded = false;
          }
          this.branchPickupDetails = this.BranchDetails[0].branchPickupDetails;
      });
  }


}
