/* This component added to handle large HTML content of FAQ's.
Otherwise this is just static component can be merged in footer-static component. */
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { Component, OnInit } from '@angular/core';
declare function initAccord(): any;
declare function initDocument(): any;
declare var $: any;

@Component({
  selector: 'app-faqs',
  templateUrl: './faqs.component.html',
  styleUrls: ['./faqs.component.css']
})
export class FAQsComponent implements OnInit {
  public innerRequireSidebar = '0';
  public _primaryComp: any;
  constructor(private navUrl: NavigatePathService) { }

  ngOnInit(): void {
    this._primaryComp = '/' + this.navUrl.navUrl();
    $('body').attr('id', '');
    // initAccord();
    setTimeout(function(){
      initDocument();
    }, 5);
  }

}
