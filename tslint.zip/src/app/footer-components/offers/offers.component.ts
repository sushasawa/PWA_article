import { Component, OnInit } from '@angular/core';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { NgForm } from '@angular/forms/src/directives/ng_form';

declare function initDocument(): any;
// declare function swal(headerMessage, message, type): any;
declare var $: any;
declare var Snackbar: any;


export interface FormModel {
  captcha?: string;
}

declare var L: any;

@Component({
  selector: 'footer-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class FooterOffersComponent implements OnInit {
  public branchOptions: any;
  public cityOptions: any;
  public name: any;
  public email: any;
  public mobileNumber: any;
  public cityName: any;
  public feedback: any;
  public CityDetails: any;
  public mymap: any;
  public BranchDetails: any;
  public BranchDetailsEnable: any;
  public branchPickupDetails: any;
  public userCity: any;
  public userBranch: any;
  public lat: number;
  public lng: number;
  public zoom = 15;
  public maploaded= false;


  public formModel: FormModel = {};
  public catagoryOptions: any = [{
    'value': 'Complaint', 'label': 'Complaint'
  }, {
    'value': 'General Feedback', 'label': 'General Feedback'
  }];
  public catagory: any;

  constructor(private masterService: MasterService) {
    this.updateBranch(this.masterService.turnerMorrisonBranchId);
  }

  ngOnInit(): void {
    $('body').attr('id', '');

    // this.masterService.getCityList()
    // .subscribe(data => {
    //   this.cityOptions = data;
    //   const currentDocument = this;
    // });

    setTimeout(function(){
      $('ng-select > div').css('border', '0px solid black');
      initDocument();
    }, 5);

    this.masterService.getBranchList('mumbai')
      .subscribe(data => {
        this.branchOptions = data;

      });

    this.masterService.getCityList()
      .subscribe(data => {
        this.cityOptions = data;

      });
  }


  submitContactUs(captchaProtectedForm: NgForm, e: Event) {
     e.preventDefault();
    const payload = {
       'name': this.name,
       'email': this.email,
       'mobileNumber': this.mobileNumber,
       'city': this.cityName,
       'catagory': this.catagory,
       'feedback': this.feedback,
       'deliveryCity': this.userCity ? this.userCity : null,
       'deliveryBranch': this.userBranch ? this.userBranch : null
    };
    console.log(payload);
   this.masterService.setFeedback(payload).subscribe(data => {
     const retData: any = data;
     if (retData.status = 1) {
       // swal('', 'Feedback submitted successfully!', 'success');
       Snackbar.show({text: 'Feedback submitted successfully!',
       pos: 'bottom-right' ,
       actionTextColor: '#05ff01',
      });


       this.cityOptions = '';
       this.name = '';
       this.email = '';
       this.mobileNumber = '';
       this.cityName = '';
       this.feedback = '';
       this.userCity = '';
       this.userBranch = '';

     }
   }, error => {
     // swal('Oops', 'Something went wrong,Please try again ', 'error');
     Snackbar.show({text: 'Something went wrong,Please try again ',
     pos: 'bottom-right' ,
     actionTextColor: '#ff4444',
    });
   });
 }

  updateCity(newValue: string) {
    this.masterService.getBranchList(newValue.split('#')[1])
    .subscribe(data => {
      this.branchOptions = data;
    });
  }

  updateBranch(newValue: number) {
    this.masterService.getBranchDetails(newValue)
      .subscribe(data => {
        this.BranchDetails = data;
        this.BranchDetailsEnable = true;
        // const currentDocument = this;
        // setTimeout(function () {
          // if (currentDocument.mymap === undefined) {
          //   currentDocument.mymap = L.map('mapidContactUs', { attributionControl: false });
          //   L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
          //     attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors,'
          //       + ' <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>,'
          //       + ' Imagery © <a href="http://mapbox.com">Mapbox</a>',
          //     maxZoom: 18,
          //     id: 'mapbox.streets',
          //     accessToken: 'pk.eyJ1Ijoia2FtbGVzaC1jbmsiLCJhIjoiY2phN3d5bGRsMDB1MzM3cW1iOHYzbHN3ZCJ9.sy4v_2XvDe4zm1peJeSCXQ'
          //   }).addTo(currentDocument.mymap);
          // }
          // L.marker([currentDocument.BranchDetails[0].latitude, currentDocument.BranchDetails[0].longitude]).addTo(currentDocument.mymap);

          this.lat = +this.BranchDetails[0].latitude;
          this.lng = +this.BranchDetails[0].longitude;
          if (this.BranchDetails[0].latitude && this.BranchDetails[0].longitude){
            this.maploaded = true;
          } else {
            this.maploaded = false;
          }
          this.branchPickupDetails = this.BranchDetails[0].branchPickupDetails;
          // currentDocument.mymap.setView([currentDocument.BranchDetails[0].latitude, currentDocument.BranchDetails[0].longitude], 15);
        // }, 5);
      });
  }


}
