import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from 'ng-select';
import { MasterService } from '../services/master.services';
import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';
import { OffersModule } from '../offers-module/offers-module.module';
import { FooterOffersComponent } from './offers/offers.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { FooterStaticComponent } from './footer-static/footer-static.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { OurBranchesComponent } from './our-branches/our-branches.component';
import { FAQsComponent } from './faqs/faqs.component';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { AgmCoreModule } from '@agm/core';

//import { ReCaptchaModule } from 'angular2-recaptcha';


const routes: Routes = [
  {
    path: '', children: [
      { path: 'feedback', component: FeedbackComponent },
      { path: 'footerstatic', component: FooterStaticComponent },
      { path: 'contactUs', component: ContactUsComponent },
      { path: 'ourBranches', component: OurBranchesComponent },
      { path: 'offers', component: FooterOffersComponent },
      { path: 'faqs', component: FAQsComponent }
    ]
  },
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    // BrowserModule,
    HttpClientModule,
    OffersModule,
    FormsModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAQaeIKoWfFMxZJxN3m4Bs1SJe4w-FX4Mk'
    }),
    ReactiveFormsModule,
    SelectModule,
    //ReCaptchaModule
     RecaptchaModule.forRoot(),
     RecaptchaFormsModule
  ],
  declarations: [FeedbackComponent, FooterStaticComponent, FooterOffersComponent, ContactUsComponent, OurBranchesComponent, FAQsComponent],
  providers: [MasterService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class FooterComponentsModule { }
