import { Component, OnInit } from '@angular/core';
import { Route, ActivatedRoute, Params, NavigationEnd, Router } from '@angular/router';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

declare function initDocument(): any;
// declare function swal(headerMessage, message, type): any;
declare var $: any;

@Component({
  selector: 'app-footer-static',
  templateUrl: './footer-static.component.html',
  styleUrls: ['./footer-static.component.css']
})
export class FooterStaticComponent implements OnInit {
  public myTemplate: any;
  public innerTemplate: any;
  public innerTemplateNav: any;
  public innerRequireSidebar: any;
  public widthClass: any = 'col-md-9';
  public _primaryComp: any;
  constructor(private router: ActivatedRoute, private _router: Router, private navUrl: NavigatePathService) {
    this._primaryComp = '/' + navUrl.navUrl();
    this.myTemplate = {
      buyTemplate: `<h2 class="sub-ttl">Buy Forex</h2>
      <p>
      Buy foreign exchange in big and small denominations or encash your unspent foreign exchange currency.
       It’s always useful to have currency notes in hand for smaller expenses like
       public transport or buying a quick meal from a neighborhood eatery.
      </p>
      <ul class="common-bullet-list">
        <li>All leading currencies available</li>
        <li>Best exchange rates</li>
        <li>Instant availability </li>
        <li>Easy delivery and payment options </li></ul>
        <p>Cox & Kings Financial Service Limited is one of the most widely recognized and reputed brands in the world.
         It is the leading international provider of Travel and Foreign Exchange Services/Products to people who are on the move for business,
          higher studies or for leisure, directly and through its intermediaries.</p>
          <strong>Destination Currency: </strong><p>We offer a choice of 26 currencies to the traveler, thus preventing exchange conversion loss. All time availability and issuance of Amex Travellers Cheques in major currencies like US Dollars, Sterling Pounds and Euro and in most convenient denominations. </p>
          <strong>Issuance of Foreign Currency Drafts: </strong> <p> Issuance of foreign currency drafts for various purposes such as participation in conferences, trade fairs, training and higher studies. (Inclusive of application fees, examination fees etc.) </p>
          <strong>Travellers Cheque : </strong><p> Cox & kings Ltd are preferredsellers of American Express travelers cheques. Travelers cheque are ready available across the counter at all location. Travelers cheque are easy to use and one of safest mode of carring foreign exchange. </p>
          <strong>Prepaid Card  : </strong><p> Foreign exchange pre-paid card are the most cost effective safe and convient mode of payment mechansim. Prepaid cards are on Visa platforms and are extensively accepted across the globe for payment system. Prepaid cards are available over the counters at all Cox & Kings Financial Service Limited Branches. </p>
          <strong>Send Money Abroad : </strong><p> Foreign exchange can be remitted by SWIFT transfer or Telegraphic Transfer in nine currencies. Copy of the telegraphic transfer can be provided by next working day. </p>
          `,
      reloadTemplate: `<h2 class="sub-ttl">Reload Forex</h2>
      <p>
      In case you have exhausted the funds on the card, you can reload your card with additional funds.
      The easiest way to do this is to contact the Cox and Kings Branch where you bought it from.
      </p>`,
      sendMoneyTemplate: `<h2 class="sub-ttl">Send Money Abroad</h2>
      <p>Are you going abroad for studies or employment? Is your son or daughter studying abroad and do you want to send money to them to pay their tuition fees and living expenses? Look no further! Cox & Kings Financial Service Limited offers quick remittance services to ensure that the money reaches to the intended beneficiary.</p>
      <p>Cox & Kings Financial Service Limited always strives to provide you best deals. Simply give your requirements, upload your KYC documents, make payment online, rest we will take care of!</p>`,
      currencyNoteTemplate: `<h2 class="sub-ttl">Foreign Exchange Currency Notes</h2>
      <p>Forex Currency Notes</p>
      <p>Currency Notes are required when it comes to paying for local transport or at shops where cards are not accepted. We, at Cox & Kings Financial Service Limited provide our customers with authentic currency notes of 26 leading countries in the world. While currency notes are accepted everywhere, carrying currencies are not safe. Currencies always carry higher price than other instruments such as pre-paid cards. You can choose your desired denominations which will give you more flexibility over your finances.</p>
      <label>Frequently asked Questions about Currency Notes</label>
      <ul class="common-bullet-list">
      <li>
      <p>If I am travelling abroad, are currency notes the best way to carry currency?</p>
          <p>At Cox & Kings Financial Service Limited, you can avail currency notes of 26 countries to cater to your every day requirements. However, it is recommended that you carry a Pre-paid card for larger amounts and carry a very minimum amount in currencies. At Cox & Kings Financial Service Limited, we bring our expertise to provide you notes that are authentic that will not land you in trouble when are abroad. </p>
          </li>
          <li>
      <p>What is the maximum limit for carrying foreign currency and for foreign currency notes? </p>
          <p>The release of foreign exchange in currencies is in accordance with the regulations of the Reserve Bank of India and FEMA regulations. Presently, you may carry foreign currencies up to USD 3000 equivalent per trip to most countries. If you are travelling to Iraq and Libya, you may carry up to USD 5000 equivalent in currencies. If you travel to Islamic Republic of Iran, Russian Federation and Other Republics of Commonwealth of Independent States, you may carry all your requirements in currencies. If you are on Haj/Umrah pilgrimage, you may carry currencies up to the limit set by the Haj Committee of India. </p>
          </li>
          <li>
      <p>How do I know that the currency notes that are being given to me are genuine?</p>
          <p>Cox & Kings Financial Service Limited has 260 years of expertise in identifying and satisfying the needs of its customers. The Team at Cox & Kings Financial Service Limited have expertise in identifying currency notes. When you buy currencies from Cox & Kings Financial Service Limited, rest assured that your currency notes are genuine which will help you enjoy a great trip abroad. </p>
          </li>
      </ul>`,
      travellersChequeTemplate: `<h2 class="sub-ttl">Travellers Cheques</h2>
      <p>
      Cox and Kings Limited is a Preferred sellers of American Express travelers’ Cheques.
      Travellers Cheques are ready available across the counter at all locations.
      Travellers Cheques are easy to use and one of the safest mode of carrying Foreign exchange.
      </p>`,
      prepaidCardTemplate: `<h2 class="sub-ttl">Pre-paid Cards</h2>
      <p>Carrying your foreign exchange in pre-paid cards is the safest way when travelling abroad. Cox & Kings Financial Service Limited will help you in getting right solutions. You may purchase pre-paid cards of Axis bank and ICICI Bank. </p>
        <ul class="common-bullet-list">
        <li>
        <a href="/assets/images/common/Axis_MCC_Presentation.pdf"  target="_blank">Click here for Axis card benefites.</a>
        </li>
        <li>
        <a href="/assets/images/common/Travel_Card_features_and_benefits.pptx"  target="_blank">Click here for ICICI card benefites.</a>
        </li>
        </ul>`,
      aboutUsTemplate: `<h2 class="sub-ttl">About Cox & Kings Financial Service Limited</h2>
      <p>Cox & Kings Financial Service Limited. (‘CKFSL’) is a leading leisure and education travel group with operations in 22 countries across four continents. It is one of the most experienced travel companies in the world, having been in operation since 1758. Headquartered in India, CKFSL has over the last three decades transformed itself into a diversified, multinational travel conglomerate with a focus on the new-age global consumer. </p>
    <p>CKFSL operates across four key verticals; Leisure, Education, Hybrid Hotels and Visa Outsourcing Business. </p>
    <p>Leisure—India is best known by the ubiquitous Cox & Kings Financial Service Limited brand in India, where we are an integrated travel enterprise, offering the best and widest range of travel options to individuals, groups and businesses in the fastest growing major economy in the world. <a href ="http://www.coxandkings.com/"  target="_blank" >www.coxandkings.com</a> </p>
    <p>Leisure—International operates in multiple countries, mainly under the Cox & Kings Financial Service Limited brand, with a greater focus on premium-end travel. <a href ="http://www.coxandkings.co.uk/"  target="_blank" >www.coxandkings.co.uk</a>  </p>
    <p>Education operates under the brand names PGL and NST, among others. PGL and NST are market leaders in experiential learning in the UK and we intend to take these brands across the world; we have recently entered the Australian market. <a href ="http://www.pgl.co.uk/"  target="_blank" >www.pgl.co.uk</a> ,<a href ="http://www.nstgroup.co.uk/"  target="_blank" >www.nstgroup.co.uk</a>   </p>
    <p>Meininger currently operates more than 8,500 beds across 17 hotels in 11 European cities. The unique hybrid concept of Meininger combines the service and comfort of a hotel with the uncomplicated nature of a hostel; top locations, high-quality amenities, flexible room structure and reasonable prices. <a target="_blank" href="www.meininger-hotels.com">www.meininger-hotels.com</a></p>
    <p>Cox & Kings Financial Service Limited Global Services was incorporated in 2008 and is a specialist business process outsource agency which focuses on serving Consular sections of Diplomatic Missions. It renders services by providing administrative support and managing non-judgmental tasks related to the entire lifecycle of a Visa, Passport & Consular application process, hence enabling missions to focus on the key tasks of adjudication. As a core business, the organization is placed to address the need of the Diplomatic Missions Worldwide and focuses on addressing the concerns regarding security, integrity, speed and efficacy on the outsourced solution of the business.</p>

    <p>Cox & Kings Financial Service Limited Global Services is associated with various diplomatic missions as outsourced service delivery partner. It renders services related to Visa, Passport and other Consular services to various Diplomatic Missions across the globe - key customers being Ministries of India, Italy, Japan, Thailand, Vietnam, UAE, Oman and our latest addition is Morocco.  </p>
    <p>Cox & Kings Financial Service Limited is one of the founding members of the World Travel and Tourism Council (WTTC) and also a member of premier industry associations across the world. Over the years the company has won many awards which stand testimony to its excellence in service.</p>

    <label class="underline-label">Forex</label>

    <p>Cox & Kings Financial Service Limited is amongst the leading retail forex dealers in the country. We were one of the first travel companies to be granted the license as the Authorised Dealer - Category II under the new licensing regime. </p>

    <p>The enhancement of status from FFMC to Authorised Dealer - Category II opened a wide spectrum of activities which we can undertake; foremost among them is the ability to transact outward remittance requirements. The remittances or other exchange facilities for students pursuing studies abroad, medical treatment overseas, migrant travellers, salary and wages to crews on ships visiting in India, subscriptions for overseas publications, seminars, organization’s membership are some of the new businesses which we can undertake in addition to providing foreign exchange service to Leisure Travellers and Corporate / Business Travellers. </p>

    <p>This places Cox & Kings Financial Service Limited in league with Authorized Dealers like Foreign Exchange Nominated Banks to cater to the requirements of a whole host of customers. It works with more than 100 corporate clients and caters to its large leisure base. </p>

    <p>Recently, the board of Cox & Kings Financial Service Limited approved the demerger of its foreign exchange division into a separate financial services company to be named Cox & Kings Financial Service Limited Financial Service Ltd (CKFSL). CKFSL is also in the process of applying for a licence to operate as a non-banking finance company (NBFC) and will add multiple product lines to its suite of offerings over time, including holiday finance, overseas student finance etc., aimed primarily at the travel and tourism sector. </p>

    <label>Other Principal Services Offered by the Company in India.</label>

    <p>Cox & Kings Financial Service Limited is amongst the largest players offering a  range of specialist options. Innovative packaging, pricing and marketing have been the hallmarks of its success over the years.  Among its many products are Leisure Travel - Domestic (Bharat Deko), Inbound & International, Corporate Travel, MICE, Trade Fairs, Visa Processing and Foreign Exchange.  The Outbound Tours are segregated into Duniya Dekho (escorted tours), FlexiHols (customised tours), Luxury Escapades (unique & luxurious travel) & NRI (catering to Indians across the world).</p>

    <label class="underline-label">Leisure</label>

    <ul class="common-bullet-list">
    <li>Domestic Tourism</li>
    </ul>
    <p>Cox & Kings Financial Service Limited is amongst the first travel organisations to brand domestic holidays - 'Bharat Deko'. Under this brand, we market exclusive products that range from religious pilgrimage tours, education tours, weekend breaks, activity holidays, spa holidays, experiential holidays, budget holidays, summer and beach retreats, train vacations, coaching and touring holidays.</p>
    <ul class="common-bullet-list">
    <li>Inbound Tourism</li>
    </ul>
    <p>Inbound Travel business promotes India as a tourist destination. The company caters primarily to the high-end segment of the inbound market and conducts a range of group and individual tours throughout India for its clients from across the world. We provide destination management services and cover all aspects of ground tour management such as hotel bookings, air/ rail ticketing, roundtrip, airport transfer, land arrangements, excursion planning, meet and greet services, event planning, meetings and appointments, conference management, private air charter, etc.  We have our destination management services across South Asia.</p>
    <p>We also provide specialised services to foreign participants visiting India for international meetings, conferences, ad hoc incentives and exhibitions and cater to domestic conferences and corporate incentives as well. Additionally, we provide port-side services to international cruise companies touching Indian shores with a provision for shore excursions.</p>
    <ul class="common-bullet-list">
    <li>Outbound Tourism</li>
    </ul>
    <p>Cox & Kings Financial Service Limited is amongst the largest players with its range of specialist options. Innovative packaging, pricing and marketing have been the hallmarks of its success over the years. Among its many products are:</p>
    <ul class="common-bullet-list">
    <li>Duniya Dekho</li>
    </ul>
    <p>We design and market escorted tours to group travellers under our flagship brand “Duniya Dekho”. These are ready made packages where a group of travellers is escorted by a tour manager. The customer chooses a specific tour from the array of choices offered to suit his budget and preferences. These group tours cover some of the world's most enchanting places such as Australia, New Zealand, Europe, U.S.A., Canada, Far-East, Middle East, South Africa and Mauritius. These are specially designed for the ‘value traveller’.</p>
    <ul class="common-bullet-list">
    <li>FlexiHol</li>
    </ul>
    <p>These are targeted at the more discerning Free Individual Traveller (FIT), where every holiday is customised as per the convenience of the traveller. FIT can make its “FlexiHol” travel plans by selecting its travel destination and holiday option (ranging from romantic holidays, exotic cruises, rail holidays, family vacations, etc.), identifying travel interest (i.e. explorer, family, romance or explorer) and sharing his preference of sightseeing, airline and hotels.</p>
    <ul class="common-bullet-list">
    <li>Luxury Escapades</li>
    </ul>
    <p>This innovative niche caters to the crème de la crème and this concept in holidaying unveils one destination after another, laced with unique indulgences and fine living. One can experience the finest luxury hotels and the most exclusive entertainment avenues of the world.</p>
    <ul class="common-bullet-list">
    <li>NRI Division</li>
    </ul>
    <p>Indians across the world have always yearned to travel with a quality tour operator that understands its diverse needs, be it culinary preferences or holiday options. The NRI division caters to such travellers primarily from the Middle East, Europe, USA, Australia, Sri Lanka and Hong Kong. </p>

    <label class="underline-label">Business Travel</label>

    <p>The Corporate or Business Travel has witnessed a change from the traditional travel agency mode to total travel management mode. Corporates are looking for integrated travel solutions and thereby minimise the total travel budget for the corporate while maintaining high quality standards. </p>

    <p>The Corporate Travel market is a highly competitive market with the presence of both domestic and international travel companies. We believe our brand recall is very high amongst over 200 corporate clients, including major domestic and multinational companies. </p>

    <p>It is affiliated with Radius Inc., the world's largest conglomerate in business travel, as their Indian partner. Leveraging the partnership with Radius, Cox & Kings Financial Service Limited can offer travel fulfilment services to corporate clients in India and overseas.</p>

    <label class="underline-label">Trade Fairs</label>

    <p>Cox & Kings Financial Service Limited Trade Fairs ensures that you make the most of your business trip and that the smallest of details are taken care of, right from confirmed accommodation, city centre hotels during the fair period, and city tours to technical add-ons such as factory visits, buyer-seller meets and much more, all at the most attractive prices. Backed by a phenomenal trail of awards and expertise, Cox & Kings Financial Service Limited offers outbound tour management facilities and an array of value-added services that can arrange and handle the most complex and exacting business trips anywhere in the world.</p>



    <label class="underline-label">Meetings, Incentives, Conferences and Exhibitions (MICE)</label>


    <p>Leisure travel is increasingly being used as an incentive tool by many organisations to convey appreciation for recognising achievers. It has dual benefits, one by providing a holiday that enables an executive to unwind and recharge and the other serving as a reward for excellence that inspires the team. <p>

    <p>We cater to all aspects of conference organising, business meetings, event management, seminars, exhibitions, product launches and incentives. Every event is designed to meet specific requirements right from the pre-event preparations, during the event itself and through to post-event settlements.<p>

    <p>We have been constantly introducing innovative events and making suggestions to make every conference eventful and memorable like elephant polo matches, gala dinners in fairy tale castles and steam train journeys in princely carriages amongst others. <p>

    <p>Cox & Kings Financial Service Limited has also powered a few new initiatives in 2017 with the launch of the following product range.<p>


    <ol type="a">
    <li><label>Enable Travel: </label>India’s first accessible holiday specialist that aims to make travel for people with disabilities, easy and hassle-free. It is a product made by the disabled, for the disabled in India. Enable Travel has introduced specially curated itineraries to accessible destinations, for inbound and domestic tourists with disabilities and encourage them to celebrate their love for travel with the same freedom, choice and dignity as able-bodied people. The aim is to make all areas of travel accessible and barrier free. </li>
    <li><label>Trip 360: </label>Trip 360º powered by Cox & Kings Financial Service Limited, is a one-stop-shop for all things adventure. It offers exciting experiences in Cycling, Diving, Biking, Trekking and cruise within India and abroad. With Safety, Sustainability and Sociable forming the core values of Trip 360º, it aims to establish India as a global adventure destination by crafting high-quality expeditions and catering to the insatiable appetite of thrill seekers.  Trip 360º itineraries are tailored for individuals who love getting out of their comfort zones and embracing new passions and experiences. The itineraries vary from soft, medium and hard adventures and cater to all levels of adventure travellers. Trip 360º has handpicked and trained expert guides, leaders and suppliers to offer different adventures of international standards.</li>
    </ol>

    <label class="underline-label">The History of Cox & Kings Financial Service Limited</label>

    <p>Historically, Cox & Kings Financial Service Limited. has been an army agent, a travel agent, a printer and publisher. It has also worked as a news agent, cargo agent, ship-owner, banker, insurance agent, and dealer of several travel-related activities.</p>
    <p>The Founder, Mr Richard Cox was born in Yorkshire in 1718. Cox's career took off when Lord Ligonier led the Flanders campaigns of the War of the Austrian Succession. In one letter sent back to London, Richard Cox makes a demand that "suitable winter provisions and housing should be made available for the three English companies" and he became entwined with logistics and the general welfare of the troops. Ligonier made Cox his private secretary in the late 1740s, went on to become the colonel of the First Foot Guards (Grenadier Guards) in 1757, and rewarded Cox with the post of 'military agent' after the incumbent died in May 1758. Thus was born Cox & Co. <p>
    <p>During the 1930s, Lloyds sold its Indian interests to Grindlays Bank, who also took the travel and shipping agencies, which continued to flourish in India.<p>
    <p>The company was incorporated as ‘Eastern Carrying Company’ on 7 June 1939, under the Indian Companies Act, VII of 1913. The name of the company was changed to ‘Cox & Kings Financial Service Limited (India) Ltd.’ on 23 February 1950, after the introduction of Companies Act 1956.<p>`,
    termsAndConditionTemplate: `<h2 class="sub-ttl">Terms and Conditions</h2><ul class="common-bullet-list">
    <li>"You”/”Your” means the person / s in whose name and / or whose behalf the booking is made. Alternatively, the reference may be made in the third person as "Tour Participant" /"They" / "Client" / "Them" / "His" / "Her".</li>
    <li>"We" / "Us" / "Company" means Cox & Kings Financial Service Limited.</li>
    <li>"Terms and Conditions" means the terms and conditions contained herein below and other documents as may be notified from time to time. “Booking Documents” shall mean Booking Form and such other documents as we may deem fit.</li>
    <li>“Products” means any and all services offered us through the Website.</li>
    <li>"Brochure" means printed brochure, Website, itinerary, leaflets, booklet.</li>
    <li>"Website" means www.coxandkings.com</li>
    <li>"Web pages" means pages on the Website www.coxandkings.com</li>
    <li>"Cancellation Policy" means and includes all the cancellation charges levied by the Company from time to time, third party cancellation charges etc. as more particularly described hereinbelow or any other documents.</li>
    <li>"Jurisdiction" means the geographical area over which a Court or government body has the power and right to exercise authority. Parties hereto agree to confer exclusive Jurisdiction to Mumbai Courts / Forums.</li>
    </ul>
    <p>This Web site offers you Products, subject to your acceptance without modification of the terms, conditions, and notices contained herein. Your use of this Web site constitutes your agreement to all such terms, conditions, and notices that are subject to amendments without any notice. You agree to click on the links and familiarize yourself with the Terms of Use and other terms and guidelines found throughout this Web site and abide by them if you choose to use the sites, pages or services to which they apply.</p>
    <h4>GENERAL TERMS AND CONDITIONS</h4>
    <ul class="common-bullet-list">
    <li>As a user of foreign exchange services you agree and confirm being aware of all regulatory norms. If you need any information regulations, please call our helpline at _________ or visit our web page “KYC Policy of Cox & Kings Financial Service Limited”.</li>
    <li>Cox & Kings Financial Service Limited will not be responsible for any transaction executed through us by forge or unprofessed information. User will be solely responsible for such action and liable to regulatory actions</li>
    <li>All orders placed by you are subject to complete regulatory compliance by you; any deviation from the same will be the sole responsibility of you. (If you need any information on guidelines please write to forex.helpdesk@coxandkings.com or call us on _____________. </li>
    <li>All order values will be rounded off to the nearest currency unit.</li>
    <li>Deliveries only to the area covered by Cox & Kings Financial Service Limited, for location assistance please call our helpline. </li>
    <li>Rates are subject to change without any notice. Cox & Kings Financial Service Limited have the sole right to change, modify the rates of one or more currencies or suspend or remove quotes of one or more currencies without any notice.</li>
    <li>The terms and conditions of the third party products and the terms and conditions of the service providers of the third party products being promoted by Cox & Kings Financial Service Limited, shall all be applicable to you without dilution in addition to these Terms and Conditions.  You expressly understand and agree to the terms and conditions of the service providers of the third party products given in their respective web sites. </li>
    <li>The source of funds for making the purchases/remittances on this site belong to me and the foreign exchange shall not be used for prohibited purposes.</li>
    <li>The orders placed are not designed for the purpose of any contravention or evasion of the provisions of the FEMA 1999 Act or of any Rule, Regulation, Notification, Direction or Order made there under. </li>
    <li>You agree and undertake to provide such information /documents that will reasonably satisfy us about the transaction in terms of the RBI Limits for Foreign Exchange Purchases or sales. You shall be responsible and liable for any incorrect information provided by you.</li>
    <li>The foreign exchange purchased from this site should be used within 60 days of purchase. In case if You is unable to use the foreign exchange purchased from Cox & Kings Financial Service Limited, within the period of 60 days, same should be surrendered to an Authorised Person.</li>
    </ul>
    <h4>DOCUMENTATION</h4>
    <p>We would also require the following documents from you, under the Reserve Bank of India KYC Guidelines:</p>
    <ul class="common-bullet-list">
    <li>Physically signed LRS cum Form A2 by the traveller[Only for international travel]</li>
    <li>Signed photocopy of the first 2 pages and last 2 pages of your passport.</li>
    <li>Valid Visa issued by the country of visit.</li>
    <li>Air tickets</li>
    <li>Address Proof: Please  note  the  following  requirements for address proof:</li>
    </ul>
    <div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Features</th>
                <th>Documents</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>TRANSACTIONS WITH INDIVIDUALS <br/>
                    (Address proof)
                </td>
                <td>
                    <ul class="common-bullet-list">
                    <li>(i) Passport, (ii) PAN Card, (iii) Voter’s Identity Card, (iv) Driving License, (v) Job Card issued by NREGA (vi) Aadhar Card.</li>
                    <li>In case of LOW risk customers, “simplified measures” can be applied which shall be deemed to be “officially  valid documents”.</li>
                    <li>Identity card with applicant’s photograph issued by central/ state government departments, statutory/regulatory authorities, public sector undertakings, scheduled commercial banks and public financial institutions.</li>
                    <li>Letter issued by a gazette officer with a duly attested photograph of the person.</li>
                    </ul>
                    <p>Where “simplified measures” are applied for verifying for the limited purpose of proof of address, the following additional documents are deemed to be Officially Valid Documents (OVD):</p>
                    <ul class="common-bullet-list">
                    <li>
                    Utility bill which is not more than two months old of any service providers (electricity, telephone, post paid mobile
                     </li>
                     <li>phone, piped gas, water bill);</li>
                     <li>Property or municipal tax receipt;</li>
                     <li>Bank account or</li>
                     <li>Post office savings bank account statement;</li>
                     <li>Pension or family pension payment orders, only if they contain address;</li>
                     <li>Letter of allotment of accommodation.</li>
                    </ul>
                </td>
            </tr>
        </tbody>
    </table>
    </div>
    <p>If the proof of address you are providing is in the name of some other member of your family with whom you are living and are closely related, then you would need to provide us such proof of address as mentioned above along with a declaration from the person named in such proof of address stating that you are a relative and are staying with him / her.</p>
    <p>If the document of identity produced has an address which is the same as that declared by the prospective Client, the said document may be accepted as valid proof of both identity and address. If different or if a valid photo ID does not have address, then a separate address proof should be obtained.</p>
    <h4>PAYMENT OPTIONS</h4>
    <ul class="common-bullet-list">
    <li>You can transact directly on the Website by making online payment by way of CREDIT CARD / DEBIT CARD / NET BANKING. </li>
    <li>You can make a CASH PAYMENT offline, up to maximum of Rs.50,000/- (Rupees Fifty Thousand Only).</li>
    </ul>
    <h4>ONLINE PAYMENTS</h4>
    <p>All online payments that happen for any of the products booked via Website are secure. Cox & Kings Financial Service Limited does not store the credit card details of any customer in their database or in any data backup system or retrieval systems. Once you are ready to transact you are transferred to the bank site. The card details are captured on the bank site and not ours, hence we cannot be held responsible / liable for any misuse of credit card whatsoever.</p>
    <h4>PAYMENT GATEWAY CHARGES:</h4>
    <p>This fee is also known as 'Merchant Service fee', and is applicable for all transactions where customer pays online to Cox & Kings Financial Service Limited. This fee is subject to change as decided by respective service provider without any notice to you.</p>
    <h4>PERSONAL & NON COMMERCIAL USE LIMITATION</h4>
    <p>This Web site is for your personal and non-commercial use. You will not modify, copy, distribute, transmit, display, perform, reproduce, publish, license, create derivative works from, transfer, or sell any information, software, products or services obtained from this Web site.</p>
    <h4>REFUND POLICY</h4>
    <p>For order cancelled on client's request or non-compliance, the amount will be refunded after a deduction of cancellation charges and payment gateway charges. While arriving the refund amount in Indian Rupees, the prevailing card rates of Cox & Kings Financial Service Limited shall apply. In case of orders placed through Partial payment request, order confirmation fee of 2% will not be refunded.</p>
    <h4>ATM WITHDRAWAL CHARGES</h4>
    <ul class="common-bullet-list">
    <li>ATM withdrawal Charges are specific to each bank card. Please check the appropriate bank website for the same. General schedule of charges will also be available in the information booklet provided with the card kit.</li>
    <li>All encashment will be done only in favour of card holder, irrespective of payment being done by primary card holder. </li>
    <li>The information provided on our website is only to be used for the completion of services; we may share this information with our partners for completion of services with whom we have lawful contracts. We ensure all data collected is completely secure, safe and confidential.</li>
    <li>Cox & Kings Financial Service Limited may amend/ change the usage policy for betterment of client service and safety without any prior notice. User is advised to review these clauses at regular interval or you may write to us for any further query. </li>
    <li>Unauthorized use of the website may lead to a claim for damages and/or will be a criminal offense.</li>
    <li>You agree and understand that You is responsible for maintaining the confidentiality of password which together with his login e-mail address, allows him to access certain portions of the website.</li>
    <li>If you become aware of any unauthorized use of your registration information, you agree to notify us immediately.</li>
    <li>From time to time this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).</li>
    <li>Any material downloaded or otherwise obtained through the use of the website is done at your own discretion and risk and you are solely responsible for any damage to your computer system or loss of any data that results from the download of any such material.</li>
    <li>The Customer shall be responsible for regularly reviewing these Terms including amendments thereto as may be posted on the Website.</li>
    <li>The Customer agrees to protect and fully compensate Cox & Kings Financial Service Limited and their affiliates from any and all third party claims, liability, damages, expenses and costs, including, but not limited to, reasonable attorney's fees, caused by or arising from violation of the terms and conditions, infringement or infringement by any other user of Customer's account, intellectual property or other right of anyone.</li>
    <li>Cox & Kings Financial Service Limited is a service provider and does not own any of the products.</li>
    <li>Cox & Kings Financial Service Limited takes complete responsibility of servicing its clients for all transactions made through us in coordination with our service provider</li>
    <li>Cox & Kings Financial Service Limited may send newsletters, promotional messages & updates to registered users when required.</li>
    <li>This service is only available for Indian Nationals residing in India.</li>
    </ul>

    <h4> GST REGULATIONS</h4>
    <p>Wef. 1st July 2017 GST has been introduced to replace most of the indirect taxes including Service tax previously levied on the Foreign Exchange services. As per GST rules Foreign exchange transaction are taxable and Cox and Kings Ltd. use valuation method for arriving GST liability and payment of taxes.</p>
    <h4>Following are current GST slabs</h4>
    <ul class="common-bullet-list">
    <li>For the transaction value less than Rs. 1,00,000/- the taxable value will be 1% if the taxable value is less than Rs.250 then minimum taxable value will be considered as Rs.250.</li>
    <li>If the transaction value falls between Rs. 1 Lakh to 10 Lakh then taxable value will be Rs.1,000/- plus 0.50% of the value between Rs. 1 Lakh and Rs. 10 Lakh</li>
    <li>If the value of the transaction exceeds Rs. 10 Lakh then taxable value will be Rs.5,500/- plus 0.10% of the transaction value above Rs. 10 Lakh. </li>
    <li>If the taxable value exceeds Rs.60,000/- using above valuation method then maximum taxable value is restricted to Rs.60,000/-</li>
    <li>GST will be charged @18% flat on the taxable value.</li>
    <li>All payments made are routed directly to RBI authorised service provider, who will be delivering your forex.</li>
    <li>All Transactions to be executed by an RBI dealer.</li>
    </ul>
    <h4>COMPLIANCE WITH LAWS</h4>
    <p>You shall comply with all the applicable laws (including without limitation Foreign Exchange Management Act, 1999 or Anti-Money laundering Guidelines of the RBI) and the rules made and notifications issued there under and the Exchange Control Manual as may be issued by Reserve Bank of India from time to time, Information and Technology Act, 2000 as amended by the Information Technology (Amendment) Act 2008, Prevention of Money Laundering Act, 2002 and the rules made there under, Foreign Contribution Regulation Act, 1976 and the rules made there under, Income Tax Act, 1961 and the rules made there under, applicable to them respectively for using Payment Facility and .</p>
    <h4>PRIVACY OF INFORMATION</h4>
    <p>For our detailed privacy policy please refer to the link “PRIVACY POLICY”</p>
    <h4>INDEMNITY</h4>
    <p>You shall reimburse, indemnify and hold Cox & Kings Financial Service Limited harmless from all losses, claims, demands, suits, proceedings or judgements including costs, expenses and reasonable  attorney’s fees assessed against Cox & Kings Financial Service Limited, arising in whole or in part, from your actions, willful default, gross negligence or omissions, including but not limited to, breach of these Terms and Conditions or from the violation of any laws, rules, regulations or ordinances by you. </p>
    <h4>LIMITATION OF LIABILITY</h4>
    <p>PLEASE NOTE THAT COX & KINGS SHALL BE HELD RESPONSIBLE / LIABLE FOR ANY LOSSES, CLAIMS, DAMAGES ETC. INCURRED BY YOU ARISING DUE TO REASONS ATTRIBUTABLE TO SOLELY TO COX & KINGS. UNDER NO CIRCUMSTANCES SHALL COX & KINGS BE HELD RESPONSIBLE / LIABLE FOR ANY THIRD PARTY’S ACTS, OMISSIONS, NEGLIGENCE, DEFAULT, FRAUDULENT  MISREPRESENTATIONS ETC. </p>
    <p>THE MAXIMUM AGGREGATE LIABILITY ARISING UPON COX & KINGS TOWARDS YOU IN ANY CASE SHALL NOT EXCEED THE TOTAL AMOUNT PAID BY YOU TO COX & KINGS. </p>
    <p>FURTHER, UNDER NO CIRCUMSTANCES SHALL COX & KINGS BE LIABLE TO YOU FOR ANY ADDITIONAL LOSS OR DAMAGES INCLUDING BUT NOT LIMITED TO CONSEQUENTIAL, SPECIAL, INDIRECT, EXEMPLARY, INCIDENTAL, PUNITIVE OR ANY OTHER DAMAGES OR FOR LOSS OF PROFITS.</p>
    <h4>AMENDMENTS AND SEVERABILITY</h4>
    <p>The latest Terms, as amended, may be accessed any time on the Company’s Website at <a target="_blank" href= "http://www.coxandkings.com"> http://www.coxandkings.com </a> or will be sent to you upon your written request to the Company.</p>
    <p>If any provision of these Terms is found to be so broad as to be unenforceable, such provision shall be interpreted to be only so broad as is enforceable. The invalidity or unenforceability of any provision hereof shall in no way affect the validity or enforceability of any other provision.</p>
    <h4>INTERPRETATION</h4>
    <p>As to the interpretation of the aforesaid terms and conditions, the decision of Cox & Kings Financial Service Limited shall be final and binding upon you. The Company reserves its right to change the Terms & Conditions without assigning any reasons, any time without any prior notice.</p>
    <h4>LAW AND JURISDICTION</h4>
    <p>These Terms & conditions will be governed by Indian laws. You agree that in the event of a dispute or difference between the parties the exclusive jurisdiction shall vest in the competent court / forum / tribunal in Mumbai only.</p>
    <h4>YOUR SUGGESTIONS:</h4>
    <p>If you have any tips, which you might want to share with us, do write in to us at our Registered Office as listed above or email us at forex.helpdesk@coxandkings.com.</p>
    `,
     privacyPolicyTemplate: `<div id="left_part_inner">
     <div id="tours_display">
     <div>
     <div><h1>Privacy Policy</h1></div>
     </div>
     <div class="justify">
     <div>
     <strong>Cox &amp; Kings - Privacy Policy</strong><br>
     Cox &amp; Kings believes that customer who books or looks for any services at <a href="http://www.coxandkings.com" class="link_blue2u">www.coxandkings.com</a> / <a href="http://www.coxandkings.co.in" class="link_blue2u">www.coxandkings.co.in</a> has the right to know about the privacy policy that is followed by us. For the trust the client has on Cox &amp; Kings, we value the right to your privacy. <br><br>
     The idea of this policy is to educate the user as to what personal information is being captured by us and where the same is being used. It describes the principles and practices that apply to Personal Information (defined below) collected from users of our services ("you") on our Site, in telephone or e-mail communications, or in interviews, surveys, sweepstakes, contests, or raffles.<br> <br>

     In short
     <ol class = "common-ordered-list"><li>We will not collect Personal Information without your knowledge and permission; </li>
     <li>We will not knowingly disclose your Personal Information to third parties, except as provided in this Privacy Policy; </li>
     <li>We will take reasonable steps to protect the security of the Personal Information we collect from you. </li></ol>

     <strong>For unregistered users</strong><br>
     We encourage you to register with us in order to book services on our website and to take advantage of our customization features. However, you may choose not to register and take advantage of any feature of our site where registration is not required. <br>
     If you do not register, then the information we collect from you is limited.<br><br>

     We log your IP address in order to help diagnose problems with our server, administer our Web site and track usage statistics.<br><br>

     Your IP address may vary each time you visit, or it may be the same, depending on whether you access our site through an always-on type of Internet connection (e.g., cable modem or DSL), or through a dial-up connection (e.g., VSNL, MTNL etc). Either way, it would be extremely difficult for us to identify you through your IP address, and we make no attempt to do so.<br><br>

     If you reached our site by clicking on a link or advertisement on another site, then we also log that information. This helps us to maximize our Internet exposure, and to understand the interests of our users. All of this information is collected and used only in the aggregate; that is, it is entered into our database, where we can use it to generate overall reports on our visitors, but not reports about individual visitors.<br><br>

     We also place a small file known as a "cookie" on your computer's hard drive. A cookie may contain information that allows us to track your path through our Web site and to determine whether you have visited us before. However, unless you register with us, it contains no personally identifiable information that would allow us to identify you. Cookies cannot be used to read data off of your hard drive, and cannot retrieve information from any other cookies created by other Web sites. We use cookies in this manner to help us understand how visitors use our site, and to help us to improve our site. You may refuse to accept a cookie from us by following the procedures specific to your Web browser. Although you may do so, you may find that your browser reacts strangely when visiting not only our Web site, but other Web sites as well. Since cookies don't provide us with any information from which we can identify you, we suggest you allow us to place one on your computer. If you are visiting a site where you will be accessing your confidential account information, you will be required to accept cookies as it is essential for site administration and security.<br><br>

     If you visit our site by "clicking-through" from a site operated by one of our partners, and you have registered with that partner, then certain information about you that you have provided to that partner may be transmitted to us. You should review the privacy policy of the Web site from which you reached our site in order to determine what information was collected and how you agreed that our partner could use that information. Regardless of what information was transmitted to us, however, we don't keep it unless you register with us.<br><br>

     <strong>Registered Users</strong><br>
     All users who choose to register themselves on our site <a href="http://www.coxandkings.com" class="link_blue2u">www.coxandkings.com</a> will be able to do online transactions with us. You will be able to purchase services like Flights, Hotels, Car Rentals, Packages, Cruises etc. available on our site. <br><br>
     If you register with us, we will collect personal information from you in addition to the non-personal information described above. That personal information may include your name, email address, mailing address, telephone number, travel preferences, passport number, user name and password. The information we collect may vary, but we only collect the information that you manually enter into our forms. We may store all or some of that information in a cookie file on your hard drive, so that our system will recognize you each time you visit our site. In that way, we can save your preferences from visit to visit and present you with a customized Web site, without requiring you to log into our site every time you visit. To improve services and enhance personalization, we may periodically obtain information about you from other independent third-party sources and add it to your registration information. Additionally, authorized Cox &amp; Kings personnel may update your registration information to accurately reflect any new information included in communications received from you.<br><br>

     If you visit our site by "clicking-through" from a site operated by one of our partners, and you have registered with that partner, then certain information about you that you have provided to that partner may be transmitted to us. You should review the privacy policy of the Web site from which you reached our site in order to determine what information was collected and how you agreed that our partner could use that information. We may or may not retain that information; if we do, then we will only use it in accordance with our privacy policy, regardless of the policy of the partner site from which you came to us.<br><br>

     If you reach our site through one of our partners (whether or not you have registered with our partner), and you choose to register with us, we may be required to give our partner some or all of your registration information. We will only do so in accordance with this policy, but we cannot control how our partner uses the information. If you have questions about our partner's privacy policy, you should review their policy before providing information to us. Of course, you can ensure that the personal information you provide to us is not shared with our partners (except in accordance with this policy), by visiting us directly instead of clicking-through from one of our partners.<br><br>

     <strong>When you Purchase Products or Services for a third party</strong><br>
     When you Purchase Products or Services for a third party using your Member ID and password, we will collect that third party's name and contact information, and other information as required by the travel service provider(s), so that we can complete the booking. <br><br>

     <strong>How we use the personal information we collect.</strong><br>
     We use the personal information we collect to help both of us! As we mentioned above, registering with us allows you to personalize our Web site so that it is most useful to you. It also allows you to log into our site automatically each time you visit, rather than manually typing your user name and password every time. By registering you can also track your history of transactions that you have done on our site which is available in the form of a Dossier. We may also use this information to periodically contact you with news or important information from Cox &amp; Kings or to request your feedback on our site. In addition to these periodic updates, we may email you additional materials, but only if you specifically request them. These might include opt-in newsletters and other materials that you proactively request from Cox &amp; Kings. <br><br>
     In addition to these communications, if you have provided an email address, we may use your personal information to send you notifications about special offers or to tell you about opportunities available from our partners. You may opt-out of any or all marketing communications from Cox &amp; Kings in any commercial e-mail we send or at any time, as well as access and update your personal information, by visiting <a href="http://www.coxandkings.com" class="link_blue2u">www.coxandkings.com</a><br><br>

     <strong>Disclosure of your personal information.</strong><br>
     Cox &amp; Kings does not sell or rent any personal information to any third party, other than our partners, as discussed in this policy. We may aggregate personal information from all of our users and provide that information in the aggregate to other parties, including advertisers, for marketing and promotional purposes. However, if we do so, that information will not be in a form that will allow any third party to identify you personally. <br><br>

     We may share some of your personally identifiable information with our subsidiaries and sister companies around the world that are committed to providing you with a comprehensive array of travel packages and services to meet your travel needs. Sharing this information allows us to better understand the ways in which our various product and service offerings can assist travelers. It also enables us to provide you with information about travel opportunities in which you might be interested. We do not place restrictions on the use of personal information by our subsidiaries, or affiliates but they will treat it at least as protectively as they treat information they obtain from their other users. They also will comply with applicable laws governing the transmission of promotional communications, and give you an opportunity in any such email that they send to choose not to receive such promotional e-mail messages in the future.<br><br>

     We also may share your personal information with third-parties specifically engaged by Cox &amp; Kings to provide services to Cox &amp; Kings (such as Airlines, Hotels, Ground Handlers, Insurance Companies, Product Companies and advertising agencies), in which case we will require those parties to agree to use any such personally-identifiable data solely for the purpose of providing the specified services to Cox &amp; Kings. We may also use the information to provide to government agencies like RBI, Banks etc as per the laws of the country. As you might expect, Cox &amp; Kings must cooperate with legal authorities, and may in some circumstances be required to disclose personally identifiable information in response to requests from law enforcement authorities, or in response to a subpoena or other legal process. We don't expect this to happen, but if it does, we will provide only the information required. In other words, we will not simply turn over our database in response to a specific legal requirement. We also may share your information in connection with a corporate transaction, such as a divestiture, merger, consolidation, or asset sale, and in the unlikely event of bankruptcy.<br><br>

     <strong>How you can review and update your personal information.</strong><br>
     You can review and update the personal information you have provided through the registration process by visiting <a href="http://www.coxandkings.com" class="link_blue2u">www.coxandkings.com</a><br><br>

     <strong>Steps we take to protect your personal information.</strong><br>
     Cox &amp; Kings has implemented security procedures to help protect the personal information stored in our systems. For example, we limit access to personal information about you to employees who we believe reasonably need to come into contact with that information. We also employ processes (such as password hashing, login auditing, and idle session termination) to protect against unauthorized access to your personal information. <br><br>

     <strong>Minors</strong><br>
     Minors (as defined under the laws of their jurisdiction or residence) are not eligible to register for, use, or Purchase the Products or Services available on our Site. We do not knowingly collect Personal Information from any Minor, and will not use this information if we discover that it has been provided by a Minor.<br><br>

     <strong>Retention and storage</strong><br>
     We will retain your Personal Information in our databases in accordance with our document management, retention and destruction policy and applicable laws. This period may extend beyond the end of your relationship with us, but it will be only as long as it is necessary for us to have sufficient information to respond to any issues that may arise later. For example, we may need or be required to retain information to allow you to obtain credit for trip your Purchased but had to cancel. We may also need the retain certain information to prevent fraudulent activity; to protect ourselves against liability, permit us to pursue available remedies or limit any damages that we may sustain; or if we believe in good faith that a law, regulation, rule or guideline requires it. <br>
     Your Personal Information will be stored in secured locations, and on servers controlled by Cox &amp; Kings, located either at our offices, or at the offices of our service providers.<br><br>

     <strong>Third Party Advertisers</strong><br>
     Third parties advertise on our Site. We do not share any Personal Information about you with these advertisers unless you give us permission to do so, separate from any permission you provide during the Member registration process. These advertisers may seek to use cookies and pixel tags to track Session Data about the ads you have seen and types of things in which you appear interested. These advertisers may also use combined information about your visits to our Site and other sites in order to provide advertisements about related goods and services that may be of interest to you. <br>
     When you click on one of these advertisers' links, you are leaving our Site and entering another site. We are not responsible for such third party's sites. You should carefully review the privacy statements of any other site you visit, because those privacy statements will apply to your visit to that site, and may be very different from our policy. <br><br>

     <strong>Opting-Out</strong><br>
     As part of the registration process, we give you the ability to receive via e-mail or direct messaging information about our Products and Services, updates to our Site, customized advertisements and promotions that are targeted to your specific interest, such as flight specials, promotions, contests, sweepstakes and other travel opportunities available on our Site and/or sponsored by our travel service providers and advertisers. We send this information directly ourselves, or via third party service providers. <br>
     If you do not opt-out from receiving these communications about our Site, we will send them to you.<br><br>

     Links
     For your convenience, our Site provides links to other sites. When you click on one of these links, you are leaving our Site and entering another site. We are not responsible for such third party sites. Such sites are not under our control. You should carefully review the privacy statements of any other sites you visit, because those privacy statements will apply to your visit to such other sites. Access to any other Internet sites linked to the Site is at the user's own risk.. Cox and Kings (India) Ltd does not in anyway vouch or endorse the genuineness or the quality of the contents of such websites. It should not be construed that Cox and Kings (India) Ltd has any association with the operators or owners of such third party websites. <br><br>

     <strong>Changes to this Privacy Policy</strong><br>
     We reserve the right to change this policy should we deem it advisable to do so. If we make material changes that will affect personal information we have already collected from you, we will make reasonable efforts to notify you of the changes and to give you the opportunity to amend or cancel your registration.
     </div>
     </div>
     </div>
     </div>`,
       disclamerTemplate: `<div id="left_part_inner">

       <div class="clearboth"><img src="/resources/images/common/spacer.gif" width="1" height="20" border="0" alt=""></div>
       <div id="tours_display">
       <div>
       <div><h1>Disclaimer</h1></div>
       </div>
       <div class="clearboth"><img src="/resources/images/common/spacer.gif" width="1" height="10" border="0" alt=""></div>
       <div class="justify">
       <div>
       This page sets forth the terms and conditions under which COX &amp; KINGS provides the information on this Website, as well as the terms and conditions governing your use of this site. By making use of this site, you agree to be bound by the terms and conditions we have outlined below. If you do not accept these terms and conditions, do not continue to use or access this site.<br>
       <br>
       <strong>ACCURACY OF INFORMATION</strong> <br>
       Cox and Kings has taken reasonable care to ensure that the information posted on the website is accurate. However, .COX &amp; KINGS does not warrant or guarantee the accuracy or completeness of the information provided on this Website. Under no circumstances will COX &amp; KINGS be liable for any loss or direct, indirect, incidental, special or consequential damages caused by reliance on this information. The information on this Website / terms and conditions may be changed or updated without notice. Users are deemed to be apprised of and bound by such changes. COX &amp; KINGS may also make improvements and/or changes in the products, services and/or programs described on this site at any time without notice. Cox and Kings hereby disclaims all warranties and conditions with regard to this information, software, products, services and related graphics, including all implied warranties and conditions of merchantability, fitness for a particular purpose, title and non-infringement. <br><br>
       When you use the website for online booking of services, please ensure that all the information provided by you such as names, dates of travel, passport numbers etc is accurate. Cox and Kings cannot be liable for any erroneous information given by you. Cox and Kings will not in any way be liable for any loss or inconvenience suffered by you as a result of erroneous information provided by you.<br><br>

       Cox and Kings Ltd shall be in no way responsible for the content of the advertisers. It may be noted that Cox and Kings Ltd does not in any way or in any manner endorse the products or services advertised on its website by third party advertisers. Users would be responsible for verifying the contents and information provided in such advertisements before making any decisions based on the same.<br><br>

       <strong>THIRD PARTY PRODUCTS</strong><br>
       In case of third party products displayed on our website, we take no responsibility for the contents, quality or safety of the product in any way. Cox and Kings Ltd would not be in any way liable or responsible for any loss, damage or injury sustained by the User as a result of availing such products and services advertised by third parties on the website. <br><br>

       <strong>CONFIDENTIALITY</strong><br>
       Information concerning COX &amp; KINGS LIMITED, or any of its subsidiaries, their employees, customers, agents, or others on whom data is collected, stored, or processed is the property of COX &amp; KINGS LIMITED and is confidential except for the necessary disclosures required by law. <br><br>

       <strong>COPYRIGHT POLICY</strong><br>
       You may cite or refer to the information on this site and make copies of the information for your own non-commercial use. <br><br>

       <strong>INDEMNITY</strong><br>
       The User shall hold Cox and Kings Limited fully indemnified and harmless in case any suit, action, application, revision, writ petition, execution proceedings, claim, demand or any other legal proceedings are initiated against Cox and Kings Ltd due to any action /s of the User in using the website. <br><br>

       <strong>ENFORCEABILITY OF THESE PROVISIONS</strong><br>
       Should any of these terms and conditions be held invalid, that invalid provision shall be construed to be consistent with the applicable law, and in manner so as to remain consistent with the original intent of COX &amp; KINGS. Provisions not otherwise held invalid shall remain in force.<br><br>

       <strong>SECURITY WARNINGS</strong><br>
       It is up to you to take precautions to ensure that whatever you select for your use is free of such items as viruses, worms, trojan horses, malicious codes and other items of a destructive nature. <strong>IN NO EVENT WILL COX &amp; KINGS BE LIABLE TO ANY PARTY FOR ANY LOSS OR DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES CAUSED BY USE OF THIS WEBSITE, OR ANY OTHER HYPERLINKED WEBSITE.</strong><br><br>

       <strong>PRODUCTS &amp; SERVICES</strong><br>
       Please Note that none of the information contained in this Website should be viewed or construed as an offer to sell or as a solicitation to purchase any of our products or services. Rather, the information on our products and services is provided to you so that you can learn what products COX &amp; KINGS generally offers. The products and service statements on this Website are for general description purposes only. Furthermore, not all the products or services are available in every state or country. Send us a message via our Contact Us page for the name of an agent who can supply you with details regarding terms and conditions, exclusions, products, and services. <br><br>
       It must not be construed that by advertising itineraries and packages to various destinations, any warranty or representation is made by the website to the User as regards the suitability and safety of any particular destination.<br><br>

       <strong>LIMITATION OF LIABILITY</strong><br>
       In any case, no liability on the part of Cox and Kings Ltd arising in any way in respect of any tour, holiday, excursion facility shall not exceed the total amount paid for the tour, holiday, service and shall in no case include any consequential loss or additional expense whatsoever. <br><br>

       <strong>PROFESSIONAL ADVICE</strong><br>
       The information provided on this site is distributed with the understanding that COX &amp; KINGS is not providing professional advice of any type. If you have a question requiring professional advice, such as question relating to law, tax or financial planning, please seek the advice of a qualified professional in the relevant field. WARRANTIES
       <strong>COX &amp; KINGS LIMITED</strong> specifically disclaims all warranties with respect to this Web site or your use thereof, express, implied, or otherwise, including without limitation, all warranties of merchantability and fitness for a particular purpose. COX &amp; KINGS shall not be liable for any damages resulting from the use or misuse of this site or the information on this site.<br><br>

       This disclaimer, limitation of liability and exclusions shall apply irrespective of whether the damages arise from (a) Breach of Warranty, (b) Negligence (c) Breach of Contract and (d) any other cause of action to the extent such limitation and exclusion are not rendered invalid by applicable law.<br><br>

       <strong>COMMENTS AND SUGGESTIONS</strong><br>
       If you have any questions or suggestions please feel free to email us at <a class="link_blueu">forex.helpdesk@coxandkings.com</a>
       </div>
       </div>
       </div>
       <div><img src="/resources/images/common/spacer.gif" width="1" height="10" alt=""></div>

       </div>`,
         siteMapTemplate: `<div id="sitemap">
         <h1>Site Map</h1>
           <div id="row1">
             <div class="sitemap_col">
               <ul>
                 <li>
                   <div><a [routerLink]="[_primaryComp+'/buy']">Buy Forex</a></div>
                   <div><a [routerLink]="[_primaryComp+'/sell']">Sell Forex</a></div>
                   <div><a [routerLink]="[_primaryComp+'/reload-card']">Reload Card</a></div>
                   <div><a [routerLink]="[_primaryComp+'/send-money']">Send Money Abroad</a></div>
                   <div><a routerLink="{{_primaryComp}}/footer-components/footerstatic" [queryParams]="{screen:'offerTemplate',screenNav:'Offers',requireSideBar:0}">Offers</a></div>
                 </li>
               </ul>
             </div>
             <div class="clearboth"></div>
            </div>

       </div>`,
      sellTemplate: `<h2 class="sub-ttl">Sell Forex</h2>
       <p>After returning from your trip, never let your excess foreign currency create a question mark in your head? CKFSL will ensure that you get best prevailing rates for your balance foreign currency.</p>
       <p>Bills buying , Currency , Travel card, Travelers cheques, at the best possible rates.</p>`,
        demandDraftTemplate: `<h2 class="sub-ttl">Demand Drafts</h2>
        <p>Cox & Kings Financial Service Limited can issue Demand Drafts in Nine Currencies. If you travelling abroad for education, employment, immigration or for medical treatment, you may require to carry the foreign exchange in Demand Drafts.</p>
        <p>Demand Drafts are used to make payment to the service providers abroad. Please check with your service providers whether they require their payments is made in Demand Drafts. While Demand Drafts are safer to carry, the efficient way to carry your foreign exchange is to carry a pre-paid card. However, please check with your service provider in advance whether they accept the payments by cards.</p>
        <label>Frequently asked Questions about Demand Drafts</label>
        <ul class="common-bullet-list">
        <li>
        <p>How many countries currencies that Demand Drafts are available?</p>
        <p>Cox & Kings Financial Service Limited issue Demand Drafts in USD, GBP, Euro, AUD, CAD, SGD.</p>
        </li>
        <li>
        <p>Are there any limits for issuance of Demand Drafts? </p>
        <p>Release of foreign exchange is governed under the Liberalized Remittance Scheme guidelines of the Reserve Bank of India. Presently, you can buy up to USD 250000 in a financial year. Depending on your requirements, you may request for issuance of Demand Draft subject to above limit.</p>
        </li>
        </ul>`,
        offerTemplate: `
              <div class="main-content container inner  offer-cont">
              <div class="row">
              <div class="col-sm-12">
                          <h2 class="sub-ttl">Offers </h2>
                          <h3 class="sub-tl"><!--Sign In with forex and Avail great offers and discounts !--> </h3>
                      </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 col-sm-12 dummy-offer-comment">
                        <div class="offer-box equal-heights" style="text-align: center;">
                            <div class="offer-info" style="/* height: 62px; */">
                                <h3>Currently no offers available.</h3>
                            </div>
                        </div>
                    </div>
                  </div>
              </div>`,
      whyUsTemplate: `<h2 class="sub-ttl">Why Us?</h2>
          <p>Cox & Kings Financial Service Limited have always kept the interests of its customers as its top priority. Cox & Kings Financial Service Limited is the only travel company that is operational nonstop for the last 260 years since 1758.</p>
          <p>Cox & Kings Financial Service Limited have a trained team specialising the foreign exchange business.</p>
          <label>Our Core Values</label>
          <ul class="common-bullet-list">
          <li>Customer First</li>
          <li>Transparency</li>
          <li>Integrity</li>
          <li>Professionalism</li>
          </ul>`
    };

    this.innerTemplate = this.router.snapshot.queryParams['screen'];
    this.innerTemplateNav = this.router.snapshot.queryParams['screenNav'];
    this.innerRequireSidebar = this.router.snapshot.queryParams['requireSideBar'];
    if (this.innerTemplate === 'whyUsTemplate') {
      this.widthClass = 'col-md-12';
    } else {
      this.widthClass = 'col-md-9';
    }
  }

  ngOnInit(): void {
    this._router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
    this._router.events.subscribe((evt) => {
      if (evt instanceof NavigationEnd) {
        this._router.navigated = false;
        window.scrollTo(0, 0);
      }
    });
    $('body').attr('id', '');
    setTimeout(() => {
        initDocument();
    }, 5);
  }
}
