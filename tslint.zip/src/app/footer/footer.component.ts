import { Component, OnInit } from '@angular/core';
import { SessionHelper } from '../helpers/session-helper';
import { MasterService } from '../services/master.services';
import { Router, RouterModule } from '@angular/router';
import { SessionValueResetService } from '../services/session-value-reset.service';
import { NavigatePathService } from '../../app/services/navigate-path.service';
import { UserControl } from './../helpers/user-control';
// declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
    selector: 'forex-footer',
    templateUrl: 'footer.component.html',
    styleUrls: []
})
export class FooterComponent {
    public tempNo: any;
    public ACCESS_CTRL: any;
    public showOffers: any = true;
    public _UserControl: any = UserControl.getUserRules();
    public _primaryComp: any;
    // tslint:disable-next-line:max-line-length
    constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router , private _SessionValueResetService: SessionValueResetService) {
        this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
        this._primaryComp = '/' + navUrl.navUrl();
        if(this.ACCESS_CTRL && this.ACCESS_CTRL.MY_OFFERS.ALLOWED === false){
            this.showOffers = false;
        }
    }

    processTempNo() {
        console.log('tempNo: ' + this.tempNo);
        if (SessionHelper.getSession('userInfo')) {
            const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
            this.masterService.getOrderData(this.tempNo, userInfo.uid)
                .subscribe(data => {
                    const sessionData: any = data;
                    this.tempNo = '';
                    console.log(sessionData.buyScreen);
                    console.log(sessionData.sellScreen);
                    console.log(sessionData.reloadCardScreen);
                    console.log(sessionData.sendMoneyScreen);

                    if (sessionData.buyScreen) {
                       // SessionHelper.setSession('userSessionInfo', JSON.stringify(sessionData));
                        this._SessionValueResetService.getUserSessionInfo('userSessionInfo', sessionData);
                        this.router.navigateByUrl(this.navUrl.navUrl() + sessionData.nextLink);
                    } else if (sessionData.sellScreen) {
                      //  SessionHelper.setSession('userSessionInfoSale', JSON.stringify(sessionData));
                        this._SessionValueResetService.getUserSessionInfo('userSessionInfoSale', sessionData);
                        this.router.navigateByUrl(this.navUrl.navUrl() + sessionData.nextLink);
                    } else if (sessionData.reloadCardScreen) {
                       // SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(sessionData));
                        this._SessionValueResetService.getUserSessionInfo('userSessionInfoRealoadCard', sessionData);
                        this.router.navigateByUrl(this.navUrl.navUrl() + sessionData.nextLink);
                    } else if (sessionData.sendMoneyScreen) {
                       // SessionHelper.setSession('userSessionInfoSend', JSON.stringify(sessionData));
                        this._SessionValueResetService.getUserSessionInfo('userSessionInfoSend', sessionData);
                        this.router.navigateByUrl(this.navUrl.navUrl() + sessionData.nextLink);
                    }
                   // this.router.navigateByUrl(this.navUrl.navUrl() + sessionData.nextLink);
                }, err => {
                    // swal('Oops', 'Invalid order number!!', 'error');
                    Snackbar.show({text: 'Invalid order number!!',
                    pos: 'bottom-right' ,
                    actionTextColor: '#ff4444',
                   });

                });
        } else {
            // TODO: redirect to login with next values set..
            SessionHelper.setSession('tempNo', this.tempNo);
            this.router.navigateByUrl(this.navUrl.navUrl() + '/login');
        }
    }
}
