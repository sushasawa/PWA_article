import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms';
import * as sha from 'sha.js';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
@Component({
  selector: 'app-new-lead-login',
  templateUrl: './new-lead-login.component.html',
  styleUrls: ['./new-lead-login.component.css']
})
export class NewLeadLoginComponent implements OnInit {
  public invalidsubmitted: any;
  public newLeadLoginJSON: any = {
    'uname': '',
    'confirmPassword': '',
    'newPassword': '',
    'oldPassword': '',
    'LeadId': ''
  };
  public tempNo: any;
  public LeadId: any;
  public lead: any;
  constructor(private router: Router, private navUrl: NavigatePathService, private _ActivatedRoute: ActivatedRoute, private _MasterService: MasterService) {
    this.lead = this._ActivatedRoute.snapshot.queryParams.lead;
    this.checkActiveUrl();

  }

  ngOnInit() {
  }

  newLeadLoginSubmit(newLeadLogin, newLeadLoginJSON, event) {
    const lead = newLeadLoginJSON;
    this.invalidsubmitted = newLeadLogin.invalid;
    let password = lead.newPassword;
    password = sha('sha256').update(password, 'utf8').digest('hex');
    if (!this.invalidsubmitted) {
      if (lead.newPassword === lead.confirmPassword) {
        Snackbar.show({
          text: 'Checking...',
          pos: 'bottom-right',
          actionTextColor: '#2ae627',
        });
        lead.NewPassword = password;
        console.log(lead);
        // LOGIN FOR NEW AND EXISTING USERS CREATED BY  AGENT
        this._MasterService.newLeadLoginService(lead)
          .subscribe(
            (data) => {
              const newLeadReponse: any = data;
              console.log(data);
              if (newLeadReponse.success) {
                Snackbar.show({
                  text: 'Updating data please wait...',
                  pos: 'top-right',
                  actionTextColor: '#2ae627',
                });
                const userinfo = {
                  'loggedin': JSON.parse(newLeadReponse.success),
                  'uname': newLeadReponse.response.EmailId,
                  'uid': newLeadReponse.response.userId,
                  'userName': newLeadReponse.response.FirstName +
                    ' ' + newLeadReponse.response.MiddleName +
                    ' ' + newLeadReponse.response.LastName
                };
                SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
                SessionHelper.setSession('Lead', this.lead);
                this.redirectToTemp(userinfo);
              } else {
                Snackbar.show({
                  text: 'Incorrect Username Or password',
                  pos: 'bottom-right',
                  actionTextColor: '#ff4444',
                });
              }

            },
            (error) => {
              console.log(error);
              Snackbar.show({
                text: error.error.message,
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });
            }
          );
      } else {
        Snackbar.show({
          text: 'Password must match.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }
    } else {
      Snackbar.show({
        text: 'All fields are mandatory.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }
  }

  checkActiveUrl() {
    console.log(this.lead);
    this._MasterService.checkActiveUrl(this.lead)
      .subscribe((UrlStatus) => {
        console.log(UrlStatus);
        const status: any = UrlStatus;
        if (status.IsUrlActive) {
          this.newLeadLoginJSON.uname = status.EmailId;
          this.tempNo = JSON.parse(status.TempNo);
          this.LeadId = status.LeadId;
          this.newLeadLoginJSON.LeadId = this.LeadId;
        } else {
          Snackbar.show({
            text: 'Link has been Expired and This User Exists please Login...',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
          this.router.navigateByUrl(this.navUrl.navUrl() + '/login');
        }
       console.log();
        if (this.tempNo !== undefined || this.tempNo !== 'undefined' || this.tempNo !== null || this.tempNo !== 'null') {
          console.log('TEMP FOUND');
          SessionHelper.setSession('tempNo', this.tempNo);
        } else {
          SessionHelper.removeSession('tempNo');
          console.log('NO TEMP');
        }
      });
  }

  redirectToTemp(userinfo) {
    const CheckTempSession = SessionHelper.getSession('tempNo') === undefined
    || SessionHelper.getSession('tempNo') === 'undefined'
    || SessionHelper.getSession('tempNo') === null
    || SessionHelper.getSession('tempNo') === 'null';
    if (CheckTempSession) {
      console.log('NOT FOUND IN TEMP REDIRECT FUCNTION');
      SessionHelper.removeSession('tempNo');
      this.router.navigateByUrl(this.navUrl.navUrl() + '/buy');
    } else {
      console.log('FOUND IN TEMP REDIRECT FUCNTION');
      const tempNo = SessionHelper.removeSession('tempNo');

      console.log('CHECK CHECK CHECK CHECK', tempNo);
      this._MasterService.getOrderDataFromEmail(tempNo, 'abhishek.desai@coxandkings.com')
        .subscribe(data => {
          const sessionData: any = data;

          console.log(sessionData.buyScreen);
          console.log(sessionData.sellScreen);
          console.log(sessionData.reloadCardScreen);
          console.log(sessionData.sendMoneyScreen);
          console.log(sessionData.nextLink);
          if (sessionData.buyScreen) {
            sessionData.buyScreen.traveller[0].registrationInfo.userId = userinfo.uid;
            SessionHelper.setSession('userSessionInfo', JSON.stringify(sessionData));
          } else if (sessionData.sellScreen) {
            SessionHelper.setSession('userSessionInfoSale', JSON.stringify(sessionData));
          } else if (sessionData.reloadCardScreen) {
            SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(sessionData));
          } else if (sessionData.sendMoneyScreen) {
            SessionHelper.setSession('userSessionInfoSend', JSON.stringify(sessionData));
          }
          const routeLink = sessionData.nextLink.split('/')[1];
          // this.router.navigateByUrl(this.navUrl.navUrl() + sessionData.nextLink);
          this.router.navigateByUrl(this.navUrl.navUrl() + `/${routeLink}/create-account`);
        }, err => {
          // swal('Oops', 'Invalid order number !!!', 'error');
          Snackbar.show({
            text: 'Oops ! Invalid order number',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });

          this.router.navigateByUrl(this.navUrl.navUrl() + '/buy');
        });
    }
  }
}
