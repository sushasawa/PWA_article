import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import * as sha from 'sha.js';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { DpDatePickerModule } from 'ng2-date-picker';

declare var jquery: any;
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
@Component({
  selector: 'app-common-review-user-details',
  templateUrl: './common-review-user-details.component.html',
  styleUrls: ['./common-review-user-details.component.css']
})
export class CommonReviewUserDetailsComponent implements OnInit {
  public registrationInfo: any;
  public nextLink: any;
  public userInfo: any;
  public configsMin: any = [];
  public configsMax: any = [];
  public todaysDate: any;
  public selIndex: any;
  public skipAdhaarValidationFlag: any = false;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private route: ActivatedRoute, private router: Router) {
    if (SessionHelper.getSession('newRegistrationInfo')){
      this.registrationInfo = JSON.parse(SessionHelper.getSession('newRegistrationInfo'));
    }
    this.skipAdhaarValidationFlag = this.masterService.getSkipAdhaarValidationFlag();
  }
  ngOnInit(): void {
    this.nextLink = this.route.snapshot.data.nextLink;
    this.userInfo = JSON.parse(SessionHelper.getSession('userInfo'));

    $('body').attr('id', '');
    initDocument();
  }

  setDateConfig(startDate, endDate, index) {
    let maxDate = '',
      minDate = '';
    this.todaysDate = this.masterService.getTodaysDate();
    if (startDate !== '') {
      minDate = startDate;
    } else {
      minDate = this.todaysDate;
    }
    if (endDate !== '') {
      maxDate = endDate;
    }
    this.configsMin[index] = {
      format: 'DD-MM-YYYY',
      min: minDate
    };
    this.configsMax[index] = {
      format: 'DD-MM-YYYY',
      max: maxDate,
      min: this.todaysDate
    };
  }



  onSubmit() {
    if (this.registrationInfo.password !== undefined) {
      const sendRegistrationInfo = [];

      let password: any;
      password = this.registrationInfo.password;
      password = sha('sha256').update(password, 'utf8').digest('hex');
      this.registrationInfo.password = '';
      this.registrationInfo.password = password;
      this.registrationInfo.parent = true;
      sendRegistrationInfo.push(this.registrationInfo);

      if (sendRegistrationInfo[0].userId === '') {
        this.masterService.setUserRegistration(sendRegistrationInfo)
          .subscribe(data => {
            const result: any = data;
            this.registrationInfo.userId = result.data[0].ParentId;

            localStorage.setItem('accessToken', result.token);
            Snackbar.show({text: 'Account created successfully.',
            pos: 'bottom-right' ,
           });
          });
      } else {
        // this.userInfo.userName = sendRegistrationInfo[0].firstName.value + ' ' + sendRegistrationInfo[0].middleName + ' '
        //   + sendRegistrationInfo[0].lastName;
        // SessionHelper.setSession('userInfo', JSON.stringify(this.userInfo));
        this.masterService.updateUserRegistration(sendRegistrationInfo)
          .subscribe(data => {
            console.log(data);
          });
      }
      // this.userInfo.userName = sendRegistrationInfo[0].firstName.value + ' ' + sendRegistrationInfo[0].middleName + ' '
      //   + sendRegistrationInfo[0].lastName;
      // SessionHelper.setSession('userInfo', JSON.stringify(this.userInfo));

    }
    SessionHelper.removeSession('newRegistrationInfo');
    this.router.navigateByUrl(this.navUrl.navUrl() + this.nextLink);
  }


  // updateSession() {
  //   SessionHelper.setSession(this.sessionDataProcess, JSON.stringify(this.userSessionInfo));
  // }



  onEditClick() {
    this.router.navigateByUrl(this.navUrl.navUrl() + `/login/create-account`);
  }


}
