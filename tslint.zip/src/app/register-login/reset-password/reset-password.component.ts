import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router, Params } from '@angular/router';
import { NgForm } from '@angular/forms';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import * as sha from 'sha.js';
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  public invalidsubmitted: any;
  public authorized: Boolean;
  public invalidUrl: Boolean;
  public email: string;
  public success: boolean;
  public hideBox: boolean;
  public _primaryComp: any;

  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private route: ActivatedRoute) {
    this.authorized = true;
    this.invalidUrl = true;
    this.success = true;
    this.hideBox = false;
    this._primaryComp = '/' + navUrl.navUrl();
  }

  ngOnInit() {
    this.route.queryParams.subscribe((params: Params) => {
      const urlString = params['for'];
      const passwordInfo: any = {};
      passwordInfo.urlString = urlString;
      
      this.masterService.validateUrl(passwordInfo).subscribe(data => {
        const result: any = data;
        console.log(data);
        console.log(result);
        if (result.response === true) {
          this.email = result.email;
          console.log('true' + result.response);
        } else {
          console.log('false');
          this.invalidUrl = false;

        }
      }, err => {
        console.log(err);
        this.invalidUrl = false;
      });
    });


  }

  resetPasswordSubmit(UserInfo: NgForm, e: Event) {
    e.preventDefault();
    if (this.email) {
      this.invalidsubmitted = UserInfo.invalid;
      const npassword = UserInfo.value.npassword;
      const cpassword = UserInfo.value.cpassword;
      const passwordInfo: any = {};
      if (!this.invalidsubmitted) {
        if (npassword != cpassword) {
          this.authorized = false;
        } else {
          passwordInfo.newPassword = sha('sha256').update(npassword, 'utf8').digest('hex');
          passwordInfo.emailId = this.email;
          this.masterService.resetPassword(passwordInfo).subscribe(data => {
            const result: any = data;
            this.authorized = true;
            this.success = false;
            this.hideBox = true;
          }, err => {
            this.authorized = false;
          });
        }
      }else{
        this.authorized = false;
      }

    }else{
      this.invalidUrl = false;
    }
  }

}
