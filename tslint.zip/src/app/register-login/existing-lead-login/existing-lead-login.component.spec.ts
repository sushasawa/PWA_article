import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingLeadLoginComponent } from './existing-lead-login.component';

describe('ExistingLeadLoginComponent', () => {
  let component: ExistingLeadLoginComponent;
  let fixture: ComponentFixture<ExistingLeadLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingLeadLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingLeadLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
