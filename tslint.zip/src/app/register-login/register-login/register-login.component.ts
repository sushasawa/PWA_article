import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms';
import * as sha from 'sha.js';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;
declare function initDocument(): any;
@Component({
  selector: 'app-register-login',
  templateUrl: './register-login.component.html',
  styleUrls: ['./register-login.component.css']
})
export class RegisterLoginComponent implements OnInit {

  public invalidsubmitted: any;
  public authorized: Boolean;
  public signinmsg: String;
  public _primaryComp: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private location: Location, private route: ActivatedRoute) {
    this.authorized = true;
    this.signinmsg = 'Sign In';
    this._primaryComp = '/' + navUrl.navUrl();
  }

  ngOnInit() {
    initDocument();
  }

  loginSubmit(UserInfo: NgForm, e: Event) {
    e.preventDefault();
    this.invalidsubmitted = UserInfo.invalid;
    const payload: any = {};
    let password = UserInfo.value.upassword;
    const username = UserInfo.value.uname;
    const agentCode = UserInfo.value.agentCode;

    password = sha('sha256').update(password, 'utf8').digest('hex');
    payload.Password = password;
    payload.EmailId = username;
    payload.AgentCode = agentCode;

    console.log(payload);
    if (!this.invalidsubmitted) {
      this.signinmsg = 'Checking ...';
      this.masterService.loginUserAgent(payload).subscribe(data => {
        const result: any = data;
        // console.log('CHECK', result.response[0][0].EmailId);

        this.authorized = true;
        this.signinmsg = 'Success...';
        const userinfo = {
          'loggedin': result.success,
          'uname': result.response[0][0].EmailId,
          'uid': result.response[0][0].Id,
          'userName': result.response[0][0].firstName + ' ' + result.response[0][0].middleName + ' ' + result.response[0][0].lastName
        };
        console.log('USERINFO', userinfo);


        SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
        this.signinmsg = 'Redirecting...';

        if (SessionHelper.getSession('tempNo') === undefined) {
          this.router.navigateByUrl(this.navUrl.navUrl() + '/account');
        } else {
          const tempNo = SessionHelper.removeSession('tempNo');
          this.masterService.getOrderData(tempNo, userinfo.uid)
            .subscribe(data => {
              const sessionData: any = data;

              console.log(sessionData.buyScreen);
              console.log(sessionData.sellScreen);
              console.log(sessionData.reloadCardScreen);
              console.log(sessionData.sendMoneyScreen);

              if (sessionData.buyScreen) {
                SessionHelper.setSession('userSessionInfo', JSON.stringify(sessionData));
              } else if (sessionData.sellScreen) {
                SessionHelper.setSession('userSessionInfoSale', JSON.stringify(sessionData));
              } else if (sessionData.reloadCardScreen) {
                SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(sessionData));
              } else if (sessionData.sendMoneyScreen) {
                SessionHelper.setSession('userSessionInfoSend', JSON.stringify(sessionData));
              }
              this.router.navigateByUrl(this.navUrl.navUrl() + sessionData.nextLink);
            }, err => {
              // swal('Oops', 'Invalid order number !!!', 'error');
              Snackbar.show({
                text: 'Oops ! Invalid order number',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });

              this.router.navigateByUrl(this.navUrl.navUrl() + '/buy');
            });
        }
      }, err => {
        console.log(err);
        this.signinmsg = 'Sign in';
        this.authorized = false;
        Snackbar.show({
          text: err.error.response,
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        const userinfo = { 'loggedin': false };
        // SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
      });
    }
  }

}
