import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms';
import * as sha from 'sha.js';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { AgentMarginService } from '../../services/agent-margin.service';
import { SharedService } from '../../shared/shared.service';
import { DomSanitizer } from '@angular/platform-browser';

declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;
declare function initDocument(): any;
@Component({
  selector: 'app-agent-login',
  templateUrl: './agent-login.component.html',
  styleUrls: ['./agent-login.component.css']
})
export class AgentLoginComponent implements OnInit {
  public showHeader: any = false;
   
  public currentDate = new Date();
  public currentMonth: any;
  public invalidsubmitted: any;
  public authorized: Boolean;
  public signinmsg: String;
  public Months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  public AgentTheme: any = {};
  public loginPage: any;
  public leftPanel: any = {};
  public products: any = [];
  public rightPanel: any = {};
  public backGroungImage: any = 'assets/images/login/agent-login-bg.jpg';
  public extraContents: any;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private location: Location, private route: ActivatedRoute, public agentMargin: AgentMarginService, private _SharedService: SharedService, private sanitizer: DomSanitizer) {
    console.log('route', router.url.split('/')[1]);

    // this.router.navigateByUrl(this.navUrl.navUrl() + '/login');
    this.currentMonth = this.Months[this.currentDate.getMonth()];
    this.authorized = true;
    this.signinmsg = 'Sign In';
    const userInfo = SessionHelper.getSession('userInfo');
    const currentUser = SessionHelper.getSession('currentUser');
    const adm_ctrl = SessionHelper.getSession('adm_ctrl');
    if (userInfo && currentUser && adm_ctrl) {
      this.router.navigateByUrl(this.navUrl.navUrl() + '/account');
    } else {
      SessionHelper.removeSession('agentURLParam');
    }
  }

  ngOnInit() {
    initDocument();
    if (this._SharedService.AgentsTheme) {
      this.AgentTheme = this._SharedService.AgentsTheme.success ? this._SharedService.AgentsTheme.Docs : this._SharedService.AgentsTheme;
      this.applyTheme();
    }
  }

  ngDoCheck() {
    this._SharedService.AgentTheme.subscribe((theme) => {
      this.AgentTheme = theme.success ? theme.Docs : theme;
      this.applyTheme();
    });
  }

  applyTheme() {
    if (this.AgentTheme.loginPage) {
      this.loginPage = this.AgentTheme.loginPage;
      if (this.loginPage.leftPanel) {
        this.leftPanel = this.loginPage.leftPanel;
      }
      if (this.leftPanel.products) {
        this.products = this.leftPanel.products;
      }
      if (this.loginPage.rightPanel) {
        this.rightPanel = this.loginPage.rightPanel;
        if (this.rightPanel.extraContents && this.rightPanel.extraContents.trim()) {
          this.extraContents = this.sanitizer.bypassSecurityTrustHtml(this.rightPanel.extraContents);
        }
      }
      if (this.loginPage.backgroundImage) {
        this.backGroungImage = this.loginPage.backgroundImage;
      }
    }
  }

  loginSubmit(UserInfo: NgForm, e: Event) {
    e.preventDefault();
    this.invalidsubmitted = UserInfo.invalid;
    console.log(UserInfo.value);
    const payload: any = {};
    let password = UserInfo.value.upassword;
    const username = UserInfo.value.uname;
    const agentCode = UserInfo.value.agentCode;

    password = sha('sha256').update(password, 'utf8').digest('hex');
    payload.Password = password;
    payload.EmailId = username;
    payload.AgentCode = agentCode;
    if (!this.invalidsubmitted) {
      this.signinmsg = 'Checking ...';
      this.masterService.loginUserAgent(payload).subscribe(data => {
        const result: any = data;
        if (result.response[0][0].aliasName !== SessionHelper.getSession('AgentWebsiteName')) {
          this.signinmsg = 'Sign in';
          this.authorized = false;
          Snackbar.show({
            text: 'Incorrect URL. Please use the correct URL and Credentials.',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
          // tslint:disable-next-line:no-shadowed-variable
          const userinfo = { 'loggedin': false };
          return;
        }
        // console.log('CHECK', result.response[0][0].EmailId);
        // console.log(result.response[0][0].RoleName + '_' + result.response[0][0].RoleId);
        this.authorized = true;
        this.signinmsg = 'Success...';
        const userinfo = {
          'loggedin': result.success,
          'uname': result.response[0][0].EmailId,
          'uid': result.response[0][0].Id,
          'userName': result.response[0][0].firstName + ' ' + result.response[0][0].lastName
        };
        console.log('USERINFO', result);
        this.navUrl.setNavUrl();
        SessionHelper.setSession('adm_ctrl', result.response[0][0].RoleName + '_' + result.response[0][0].RoleId);
        SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
        SessionHelper.setSession('AgentID', userinfo.uid);
        this.signinmsg = 'Redirecting...';
        this.agentMargin.setAgentMargin();
        this.getUserAccess();
        if (SessionHelper.getSession('tempNo') === undefined) {
          this.router.navigateByUrl(this.navUrl.navUrl() + '/account');
        } else {
          const tempNo = SessionHelper.removeSession('tempNo');
          this.masterService.getOrderData(tempNo, userinfo.uid)
            // tslint:disable-next-line:no-shadowed-variable
            .subscribe(data => {
              const sessionData: any = data;
              console.log('sessionData@@@@@@@@@@@@', sessionData);

              console.log(sessionData.buyScreen);
              console.log(sessionData.sellScreen);
              console.log(sessionData.reloadCardScreen);
              console.log(sessionData.sendMoneyScreen);

              if (sessionData.buyScreen) {
                SessionHelper.setSession('userSessionInfo', JSON.stringify(sessionData));
              } else if (sessionData.sellScreen) {
                SessionHelper.setSession('userSessionInfoSale', JSON.stringify(sessionData));
              } else if (sessionData.reloadCardScreen) {
                SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(sessionData));
              } else if (sessionData.sendMoneyScreen) {
                SessionHelper.setSession('userSessionInfoSend', JSON.stringify(sessionData));
              }
              this.router.navigateByUrl(this.navUrl.navUrl() + sessionData.nextLink);
            }, err => {
              // swal('Oops', 'Invalid order number !!!', 'error');
              Snackbar.show({
                text: 'Oops ! Invalid order number',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });

              this.router.navigateByUrl(this.navUrl.navUrl() + '/buy');
            });
        }
      }, err => {
        console.log(err);
        this.signinmsg = 'Sign in';
        this.authorized = false;
        Snackbar.show({
          text: err.error.response,
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        const userinfo = { 'loggedin': false };
        // SessionHelper.setSession('userInfo', JSON.stringify(userinfo));
      });
    }
  }


  getUserAccess() {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    const role: any = SessionHelper.getSession('adm_ctrl');
    const payload: any = {
      'agentid' : JSON.parse(UserInfo).uid,
      'role' : role
     };
    switch (role) {
      case 'ADMIN_2':
      case 'AGENT_3':
           this._SharedService.getUserAccessCtrl(payload);
        break;



    }
  }
}
