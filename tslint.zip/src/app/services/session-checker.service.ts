import { Injectable } from '@angular/core';
import { SessionHelper } from '../helpers/session-helper';

declare var $: any;

@Injectable()
export class SessionCheckerService {

  constructor() { }

  isLoggedIn() {
    const userInfo = SessionHelper.getSession('userInfo');
    return userInfo ? JSON.parse(userInfo).loggedin : false;
  }

  getUserName() {
    const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
    return userInfo.userName ? userInfo.userName : 'Unknown';
  }
}
