import { TestBed, inject } from '@angular/core/testing';

import { SessionValueResetService } from './session-value-reset.service';

describe('SessionValueResetService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SessionValueResetService]
    });
  });

  it('should be created', inject([SessionValueResetService], (service: SessionValueResetService) => {
    expect(service).toBeTruthy();
  }));
});
