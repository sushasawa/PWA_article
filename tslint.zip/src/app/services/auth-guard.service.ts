import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { Router, CanActivate } from '@angular/router';
import { AuthService } from './auth.service';
import { NavigatePathService } from '../../app/services/navigate-path.service';
@Injectable()
export class AuthGuardService {

  constructor(public auth: AuthService, private navUrl: NavigatePathService, public router: Router, private location: Location) { }

  canActivate(): boolean {
    if (!this.auth.isAuthenticated()) {
      const currentPath = this.location.path().split('/');
      this.router.navigate([this.navUrl.navUrl() + '/' + currentPath[2] + '/register-login']);
      return false;
    }
    return true;
  }

}
