import { TestBed, inject } from '@angular/core/testing';

import { SessionCheckerService } from './session-checker.service';

describe('SessionCheckerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SessionCheckerService]
    });
  });

  it('should be created', inject([SessionCheckerService], (service: SessionCheckerService) => {
    expect(service).toBeTruthy();
  }));
});
