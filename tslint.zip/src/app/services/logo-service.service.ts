import { Injectable, Output, EventEmitter } from '@angular/core';

@Injectable()
export class LogoServiceService {
  constructor() { }
  public shareData: any;

  @Output() changeDataObservable: EventEmitter<any> = new EventEmitter();

  changeData(Msg: any) {
     this.shareData = Msg;
     this.changeDataObservable.emit(this.shareData);
     console.log(Msg);
  }

}
