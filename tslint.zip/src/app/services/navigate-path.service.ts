import { Injectable } from '@angular/core';
import {Router, RouterModule, ActivatedRoute} from '@angular/router';
import { SessionHelper } from '../../app/helpers/session-helper';
import { MasterService } from '../../app/services/master.services';
import { Subject } from 'rxjs/Subject';
@Injectable()
export class NavigatePathService {
  public agentURLParam: any;
  public AgentIdObservable: any;
  public currAgentURLParam: any;
  constructor(private masterService: MasterService, private Routers: Router, private router: ActivatedRoute) {
    this.AgentIdObservable = new Subject();
  }

  navUrl() {
    const baseUrl = this.Routers.url;
    let urlParam;
    if (SessionHelper.getSession('agentURLParam')) {
      urlParam = SessionHelper.getSession('agentURLParam');
    } else {
      urlParam = baseUrl.split('/')[1];
      if (urlParam === 'login') {
        urlParam = 'CNK';
      }
    }
    if (this.currAgentURLParam) {
      if (urlParam !== this.currAgentURLParam) {
        // this.getAgentId(urlParam);
        this.currAgentURLParam = urlParam;
      }
    } else {
      // this.getAgentId(urlParam);
      this.currAgentURLParam = urlParam;
    }
    return urlParam;
  }

  setNavUrl() {
    const baseUrl = this.Routers.url;
    this.agentURLParam = baseUrl.split('/')[1];
    if(this.agentURLParam === 'login') {
      this.agentURLParam = 'CNK';
    }
    SessionHelper.setSession('agentURLParam', this.agentURLParam);
  }

  getAgentId(urlParam, redirectUrl) {
    console.log(urlParam)
    this.masterService.getAgentIdByAliasName(urlParam).subscribe(data => {
      let result: any = data;
      console.log(result, '///////////////////////')
      if (result && result.length > 0) {        
        this.AgentIdObservable.next(result);
      } else {
        redirectUrl();
      }
    });
  }
}
