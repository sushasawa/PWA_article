import { Injectable } from '@angular/core';
import { Constants } from '../../app/helpers/constants';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { AgentMarginService } from '../services/agent-margin.service';
import { SessionHelper } from '../helpers/session-helper';
@Injectable()
export class MasterService {
    constructor(private http: HttpClient, public agentMargin: AgentMarginService) { }
    public branchIdFromOverview;
    public turnerMorrisonBranchId = 25;

    uploadTheme(payload: any) {
        return this.http.post(Constants.uploadTheme(), payload);
    }
    
    sendMailLeadPax(info) {
        return this.http.post(Constants.sendMailLeadPax(), info);
    }

    getBankCorrespondentCharges() {
        return Constants.getBankCorrespondentCharges();
    }

    getSkipAdhaarValidationFlag() {
        return Constants.getSkipAdhaarValidationFlag();
    }

    getAgentMargin(AgentId) {
        return this.http.get(Constants.getAgentMargin(AgentId));
    }

    getSubPurpose(info) {
        return this.http.post(Constants.getSubPurpose(), info);
    }

    setAgentMargin(payload) {
        return this.http.post(Constants.setAgentMargin(), payload);
    }


    ExcelUpload(info) {
        return this.http.post(Constants.ExcelUpload(), info);
    }

    getCurrentLocation() {
        return this.http.get('https://ipapi.co/json/');
    }

    getBranchList(cityName: any) {
        return this.http.get(Constants.getBranchListService(cityName));
    }

    getBranchDetails(val) {
        return this.http.get(Constants.getBranchDetailsService(val));
    }

    getDestinationList() {
        // return this.http.get(Constants.getDestinationListService());
        if (sessionStorage.getItem('destinationList') === null) {
            this.http.get(Constants.getDestinationListService()).subscribe(data => {
                const retObj: any = data;
                sessionStorage.setItem('destinationList', JSON.stringify(retObj));
            });
            return this.http.get(Constants.getDestinationListService());
        } else {
            const subject = new Subject();
            setTimeout(() => {
                subject.next(JSON.parse(sessionStorage.getItem('destinationList')));
            }, 0);
            return subject;
        }
    }

    getNationalityList() {
        return this.http.get(Constants.getNationality());
    }

    getExchangeRate(currencyCode: string, branchId: number, productType: string, operationType: string = null, BankCode: any = 'ICICIMCC') {
        const subject = new Subject(), AgentId = SessionHelper.getSession('AgentID');
        (this.http.get(Constants.getExchangeRateService() + '?currencyCode=' + currencyCode
            + '&branchId=' + branchId + '&productType=' + productType + '&operationType=' + operationType + '&bankCode=' + BankCode + '&agentId=' + AgentId)).subscribe(data => {
                const result: any = data;
                // this.getUpdatedRate(result, currencyCode, productType, operationType);
                subject.next(result);
            });
        return subject;
    }

    getCurrencyList(productId: any, destinationId: number = 239) {
        return this.http.get(Constants.getCurrencyListService() + '?destinationId=' + destinationId + '&productId=' + productId);
    }

    AllCurrency() {
        return this.http.get(Constants.getAllCurrency());
    }

    getAgentIdByAliasName(AliasName: any) {
        return this.http.get(Constants.getAgentIdByAliasName(AliasName));
    }


    getDocumentList() {
        const checkListId = {
            'id': '59c485c30ecf845e2c7da157'
        };
        return this.http.post(Constants.getDocumentListService(), checkListId);
    }

    getDocumentCheckList(list) {
        console.log(Constants.getDocumentListService());
        return this.http.post(Constants.getDocumentListService(), list);
    }

    setUserRegistration(info) {
        return this.http.post(Constants.setUserInfo(), info);
    }

    updateUserRegistration(info) {
        return this.http.post(Constants.updateUserInfo(), info);
    }

    getCityList() {
        return this.http.get(Constants.getCityListService());
    }

    getDeliveryAmt(Mode) {
        const headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${localStorage.getItem('accessToken')}`
        });
        return this.http.get(Constants.getDeliveryAmtService() + '?Mode=' + Mode, { headers: headers });
    }

    setUserRegisterAdhar(jsonData) {
        return this.http.post(Constants.setUserDetailWithAdharService(), jsonData);
    }

    getDeliveryTypeList() {
        return this.http.get(Constants.getDeliveryTypeListService());
    }

    getPurposeList(processId: any) {
        return this.http.get(Constants.getPurposeListService(processId));
    }

    getBankList(currencyCode: string) {
        return this.http.get(Constants.getBanksListService() + '?code=' + currencyCode);
    }

    getBank() {
        return this.http.get(Constants.getBanksService());
    }

    getPinCodeDetails(pinCode: string) {
        return this.http.get(Constants.getPincodeDetailsService() + '?pinCode=' + pinCode);
    }

    getAirlineNames() {
        return this.http.get(Constants.getAirlineNamesService());
    }

    getDocumentSellList() {
        const checkListId = {
            'id': '59d5f3bd0144e44453a5067d'
        };

        const checkListDetail = {
        };
        return this.http.post(Constants.getDocumentListService(), checkListId);
    }

    uploadTravellerDocuments(payload: any) {
        return this.http.post(Constants.getDocUploadApi(), payload);
    }

    loginUser(payload: any) {
        return this.http.post(Constants.getLoginService(), payload);
    }

    forgotPassword(forgotInfo: any) {
        return this.http.post(Constants.getForgotPasswordService(), forgotInfo);
    }

    resetPassword(passwordInfo: any) {
        return this.http.post(Constants.getResetPasswordService(), passwordInfo);
    }

    validateUrl(passwordInfo: any) {
        return this.http.post(Constants.validateResetPasswordService(), passwordInfo);
    }

    getCardDetails(passportNumber: string) {
        return this.http.get(Constants.getCardDetailsService() + '?passportNo=' + passportNumber);
    }

    paymentgateway(paymentInfo) {
        return this.http.post(Constants.callPaymentGateway(), paymentInfo, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'text'
        });
    }

    paymentgatewayPaynimo(paymentInfo) {
        return this.http.post(Constants.callPaymentGatewayPaynimo(), paymentInfo, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'text'
        });
    }


    getEmailValidation(email: string) {
        return this.http.get(Constants.getCheckEmail() + '?emailId=' + email);
    }





    dumpSessionData(sessionData: any) {
        return this.http.post(Constants.sessionDumpService(), sessionData, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'text'
        });
    }

    getLoggedInUserInfo(uid: any) {
        return this.http.get(Constants.getLoggedInUserInfoService(uid));
    }

    getUserProfilePic(payload: any) {
        return this.http.post(Constants.getUserProfilePicService(), payload);
    }

    createAlert(payload: any) {
        return this.http.post(Constants.createAlertService(), payload);
    }

    getTemporaryOrderNumber() {
        return this.http.get(Constants.getTempOrderNumber());
    }

    getOrderData(tempNo: string, userId: number) {
        return this.http.get(Constants.getOrderData() + '?tempNumber=' + tempNo + '&userId=' + userId);
    }

    getOrderDataFromEmail(tempNo: string, emailId: string) {
        return this.http.get(Constants.getOrderDataFromEmail() + '?tempNumber=' + tempNo + '&emailId=' + emailId);
    }

    getLiveForexData() {
        return this.http.get(Constants.getLiveForex());
    }

    getLiveForexDataOverview() {
        return this.http.get(Constants.getLiveForexOverview());
    }

    getLiveForexDataFromBranchId(val) {
        const subject = new Subject();
        (this.http.get(Constants.getLiveForexFromBranchId(val, SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID'))))
            .subscribe(Idata => {
                const results: any = Idata;
                this.calculateLiveRates(results);
                subject.next(results);
            });
        return subject;
    }

    getForexTrend(currencyCode) {
        return this.http.get(Constants.getForexTrend(currencyCode));
    }

    getForexTrendFromBranchId(currencyCode, branchId) {
        return this.http.get(Constants.getForexTrendFromBranchId(currencyCode, branchId, SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID')));
    }

    getForexTrendSell(currencyCode) {
        return this.http.get(Constants.getForexTrendSell(currencyCode));
    }

    getForexTrendSellFromBranchId(currencyCode, branchId) {
        return this.http.get(Constants.getForexTrendSellFromBranchId(currencyCode, branchId, SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID')));
    }

    getForexTrendSellDaywise(currencyCode) {
        return this.http.get(Constants.getForexTrendSellDaywise(currencyCode));
    }

    getForexTrendSellDaywiseFromBranchId(currencyCode, branchId) {
        return this.http.get(Constants.getForexTrendSellDaywiseFromBranchId(currencyCode, branchId, SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID')));
    }

    getForexTrendBuyDaywise(currencyCode) {
        return this.http.get(Constants.getForexTrendBuyDaywise(currencyCode));
    }

    getForexTrendBuyDaywiseFromBranchId(currencyCode, branchId) {
        return this.http.get(Constants.getForexTrendBuyDaywiseFromBranchId(currencyCode, branchId, SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID')));
    }


    getAlert(payload: any) {
        return this.http.post(Constants.getAlertService(), payload);
    }

    deleteAlert(payload: any) {
        return this.http.post(Constants.deleteAlertService(), payload);
    }

    updateAlert(payload: any) {
        return this.http.post(Constants.updateAlertService(), payload);
    }

    getWishList(UserId: any) {
        return this.http.get(Constants.wishListService(UserId));
    }

    getUserDocuments(UserId: any) {
        return this.http.get(Constants.getUserDocumentsService(UserId));
    }

    updateKyc(formdata: FormData) {
        return this.http.post(Constants.updateKycService(), formdata);
    }

    sendOtp(payload: any) {
        return this.http.post(Constants.sendAadhaarOtp(), payload);
    }

    validateOtp(payload: any) {
        return this.http.post(Constants.validateAadhaarOtp(), payload);
    }

    getOrdersList(uid: any) {
        return this.http.get(Constants.getOrdersListService(uid));
    }

    changePassword(payload: any) {
        return this.http.post(Constants.changePasswordService(), payload);
    }

    setGrievances(payload: any) {
        return this.http.post(Constants.setGrievancesService(), payload);
    }

    getTaxes(totalPayable: number) {
        return this.http.get(Constants.getTaxes(totalPayable));
    }

    releaseTempNo(tempNo: number) {
        return this.http.get(Constants.releaseTempNo(tempNo));
    }

    /* checkCardAvailable(cardNo: number) {
         let promise = new Promise((resolve, reject) => {

             this.http.get(Constants.checkCardAvailable(cardNo))
                 .toPromise()
                 .then(
                 res => { // Success
                     console.log('service call');
                     console.log(res);
                     resolve(res);
                 },
                 msg => { // Error
                     reject(msg);
                 }
                 );
         });
         return promise;
     }*/


    /*async checkCardAvailable(cardNo: number): Promise<any> {

        const response = await this.http.get(Constants.checkCardAvailable(cardNo)).toPromise();

        console.log(response);
        return response;
    }*/

    checkCardAvailable(cardNo: number) {
        return this.http.get(Constants.checkCardAvailable(cardNo));
    }

    setFeedback(payload) {
        return this.http.post(Constants.setFeedback(), payload);
    }

    deleteDocument(payload: any) {
        return this.http.post(Constants.deleteDocumentService(), payload);
    }

    RuleTest(sessionData: any) {
        return this.http.post(Constants.RuleTest(), sessionData, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'text'
        });
    }
    getTodaysDate() {
        let monthDateCal = '',
            todaysDate,
            // tslint:disable-next-line:prefer-const
            dateObj = new Date(),
            dayDate: any = +dateObj.getDate(),
            // tslint:disable-next-line:prefer-const
            monthDate = +dateObj.getMonth() + 1;
        if (monthDate.toString().length < 2) {
            monthDateCal = '0' + monthDate;
        } else {
            monthDateCal = monthDate.toString();
        }
        if (dayDate.toString().length < 2) {
            dayDate = '0' + dayDate;
        } else {
            dayDate = dayDate.toString();
        }
        todaysDate = dayDate + '-' + monthDateCal + '-' + dateObj.getFullYear();
        return todaysDate;
    }

    validateAdhaar(info) {
        return this.http.post(Constants.getAdaarValidationService(), info);
    }

    getCharges() {
        return this.http.get(Constants.getChargesService());
    }

    /* adds days, months and years to given date(in DD-MM-YYYY)
    * dateString: date string in 'DD-MM-YYYY' format.
    * count: number of days, months or years.
    * type: this can be 'days', 'months' or 'years'
    */
    addDateMoment(dateString, count, type) {
        const new_date = moment(dateString, 'DD-MM-YYYY').add(type, count);
        const day = new_date.format('DD');
        const month = new_date.format('MM');
        const year = new_date.format('YYYY');
        return day + '-' + month + '-' + year;
    }

    /* subtracts days, months and years to given date(in DD-MM-YYYY)
    * dateString: date string in 'DD-MM-YYYY' format.
    * count: number of days, months or years.
    * type: this can be 'days', 'months' or 'years'
    */
    substractDateMoment(dateString, count, type) {
        const new_date = moment(dateString, 'DD-MM-YYYY').subtract(type, count);
        const day = new_date.format('DD');
        const month = new_date.format('MM');
        const year = new_date.format('YYYY');
        return day + '-' + month + '-' + year;
    }

    getCurrentTime(): any {
        const new_date = moment();
        const hours = new_date.format('HH');
        const mins = new_date.format('mm');
        return { hour: hours, mins: mins };
    }

    getDateDifference(date1, date2) {
        const new_date1 = moment(date1, 'DD-MM-YYYY'), new_date2 = moment(date2, 'DD-MM-YYYY');
        return new_date1.diff(new_date2, 'days');
    }


    newLeadLoginService(payload) {
        return this.http.post(Constants.newLeadLoginService(), payload);
    }

    addNewLead(payload) {
        return this.http.post(Constants.addNewLeadService(), payload);
    }

    updateLeadPassService(payload) {
        return this.http.post(Constants.updateLeadPassService(), payload);
    }

    removeTraveller(payload) {
        return this.http.post(Constants.removeTravellerService(), payload);
    }

    checkActiveUrl(url: any) {
        return this.http.get(Constants.checkActiveUrlService(url));
    }

    getCurrencyRateForRule(branchId: any) {
        return this.http.get(Constants.getCurrencyRateForRuleService(branchId, SessionHelper.getSession('AgentID')));
    }

    loginUserAgent(payload: any) {
        return this.http.post(Constants.getLoginServiceAgent(), payload);
    }

    getLoggedInAgentInfo(uid: any) {
        return this.http.get(Constants.getLoggedInAgentInfoService(uid));
    }

    createUserAgent(payload: any) {
        return this.http.post(Constants.createUserAgentService(), payload, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'text'
        });
    }

    getAgentDocuments(payload: any) {
        return this.http.post(Constants.getAgentDocumentsService(), payload, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'json'
        });
    }

    getAgentCommission(payload) {
        return this.http.get(Constants.getAgentCommissionService(payload));
    }

    getAgentCommissionDetails(payload) {
        return this.http.get(Constants.getAgentCommissionDetailsService(payload));
    }

    saveAgentDocuments(payload: any) {
        return this.http.post(Constants.saveAgentDocumentsService(), payload, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'json'
        });
    }

    uploadAgentDocument(payload: any) {
        return this.http.post(Constants.uploadAgentDocumentService(), payload);
    }

    getTotalLeadsCount(payload) {
        return this.http.post(Constants.getTotalLeadsCountService(), payload, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'json'
        });
    }

    updateExistingUsersLeadProspectsAndUrlActiveStatus(payload) {
        return this.http.post(Constants.updateExistingUsersLeadProspectsAndUrlActiveStatusService(), payload, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'json'
        });
    }

    getAgentOrderList(payload) {
        return this.http.post(Constants.getAgentOrderListService(), payload, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'json'
        });
    }

    getSubAgents(payload) {
        return this.http.post(Constants.getSubAgentsService(), payload);
    }

    getAllBranches() {
        return this.http.get(Constants.getAllBranchService());
    }
    setAgentLogo(payload) {
        return this.http.post(Constants.setAgentLogoService(), payload);
    }

    getAgentThemeDetails(payload) {
        return this.http.post(Constants.getAgentThemeDetailsService(), payload);
    }

    getAgentsLeads(payload) {
        return this.http.post(Constants.getAgentsLeadsService(), payload);
    }

    setuserActiveStatus(payload) {
        return this.http.post(Constants.setuserActiveStatusService(), payload, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'json'
        });
    }

    getUserControl(payload) {
        return this.http.post(Constants.getUserControlService(), payload);
    }

    getAgentUserAccessCtrl(payload) {
        return this.http.post(Constants.getAgentUserAccessCtrlService(), payload);
    }

    getAgentDataService(agentID) {
        return this.http.get(Constants.getAgentDataService(agentID));
    }

    getAgentPlanService(planId) {
        return this.http.get(Constants.getAgentPlanService(planId));
    }

    getAgentTheme(payload) {
        return this.http.post(Constants.getAgentThemeService(), payload);
    }

    checkDomainAvailable(payload) {
        return this.http.post(Constants.checkDomainAvailableServive(), payload);
    }

    changeDomainName(payload) {
        return this.http.post(Constants.changeDomainNameServive(), payload);
    }

    checkLeadCreated(id: any) {
        return this.http.get(Constants.checkLeadCreatedService(id));
    }
    getBulkExchangeRate(payload) {
        return this.http.post(Constants.getBulkExchangeRateService(), payload, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'json'
        });
    }

    currencyNotification(payload: any) {
        console.log(payload);
        return this.http.post(Constants.currencyNotificationService(), payload , {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
            responseType: 'json'
        });
    }

    getUpdatedRate(result: any, currencyCode: any, productType: any, operationType: any) {
        if(!this.agentMargin.agentMarginObj || !this.agentMargin.agentMarginObj.length){
            return result;
        }
        // tslint:disable-next-line:prefer-const
        let agentMarginObj = this.agentMargin.agentMarginObj, value, type,
            // tslint:disable-next-line:prefer-const
            buyProduct = { cash: 'buyCash', prepaid: 'buyPrepaid', dd: 'buyDD' },
            // tslint:disable-next-line:prefer-const
            sellProduct = { cash: 'sellCash', prepaid: 'sellPrepaid' };
        for (let i = 0; i < agentMarginObj.length; i++) {
            if (agentMarginObj[i].currencyName === currencyCode) {
                if (operationType === 'buy') {
                    type = agentMarginObj[i][buyProduct[productType]].type;
                    value = agentMarginObj[i][buyProduct[productType]].value;
                    if (type === '1') {
                        result.rate = this.precisionRound(result.rate + (parseFloat(value) / 100) * result.rate, 2);
                    } else if (type === '2') {
                        result.rate = this.precisionRound(result.rate + parseFloat(value), 2);
                    }
                }
                if (operationType === 'sell') {
                    type = agentMarginObj[i][sellProduct[productType]].type;
                    value = agentMarginObj[i][sellProduct[productType]].value;
                    if (type === '1') {
                        result.rate = this.precisionRound(result.rate - (parseFloat(value) / 100) * result.rate, 2);
                    } else if (type === '2') {
                        result.rate = this.precisionRound(result.rate - parseFloat(value), 2);
                    }
                }
                result.agentMarginType = type;
                result.agentMarginValue = value;
            }
        }
        return result;
    }

    precisionRound(number, precision) {
        const factor = Math.pow(10, precision);
        return Math.round(number * factor) / factor;
    }

    calculateLiveRates(results) {
        const agentMargin = this.agentMargin.agentMarginObj;
        if (!agentMargin) {
            return results;
        }
        for (let i = 0; i <= agentMargin.length - 1; i++) {
            for (let j = 0; j <= results.length - 1; j++) {
                if (results[j].currency === agentMargin[i].currencyName) {
                    if (agentMargin[i].buyCash.type === '1') {
                        // tslint:disable-next-line:max-line-length
                        results[j].buyBankNotesRates = this.precisionRound(results[j].buyBankNotesRates + (parseFloat(agentMargin[i].buyCash.value) / 100) * results[j].buyBankNotesRates, 2);
                    } else if (agentMargin[i].buyCash.type === '2') {
                        // tslint:disable-next-line:max-line-length
                        results[j].buyBankNotesRates = this.precisionRound(results[j].buyBankNotesRates + parseFloat(agentMargin[i].buyCash.value), 2);
                    }
                    if (agentMargin[i].buyPrepaid.type === '1') {
                        // tslint:disable-next-line:max-line-length
                        results[j].buyPrepaidRates = this.precisionRound(results[j].buyPrepaidRates + (parseFloat(agentMargin[i].buyPrepaid.value) / 100) * results[j].buyPrepaidRates, 2);
                    } else if (agentMargin[i].buyPrepaid.type === '2') {
                        // tslint:disable-next-line:max-line-length
                        results[j].buyPrepaidRates = this.precisionRound(results[j].buyPrepaidRates + parseFloat(agentMargin[i].buyPrepaid.value), 2);
                    }
                    if (agentMargin[i].buyDD.type === '1') {
                        // tslint:disable-next-line:max-line-length
                        results[j].buyDDRates = this.precisionRound(results[j].buyDDRates + (parseFloat(agentMargin[i].buyDD.value) / 100) * results[j].buyDDRates, 2);
                    } else if (agentMargin[i].buyDD.type === '2') {
                        results[j].buyDDRates = this.precisionRound(results[j].buyDDRates + parseFloat(agentMargin[i].buyDD.value), 2);
                    }
                    if (agentMargin[i].sellCash.type === '1') {
                        // tslint:disable-next-line:max-line-length
                        results[j].sellBankNotesRates = this.precisionRound(results[j].sellBankNotesRates - (parseFloat(agentMargin[i].sellCash.value) / 100) * results[j].sellBankNotesRates, 2);
                    } else if (agentMargin[i].sellCash.type === '2') {
                        // tslint:disable-next-line:max-line-length
                        results[j].sellBankNotesRates = this.precisionRound(results[j].sellBankNotesRates - parseFloat(agentMargin[i].sellCash.value), 2);
                    }
                    if (agentMargin[i].sellPrepaid.type === '1') {
                        // tslint:disable-next-line:max-line-length
                        results[j].sellPrepaidRates = this.precisionRound(results[j].sellPrepaidRates - (parseFloat(agentMargin[i].sellPrepaid.value) / 100) * results[j].sellPrepaidRates, 2);
                    } else if (agentMargin[i].sellPrepaid.type === '2') {
                        // tslint:disable-next-line:max-line-length
                        results[j].sellPrepaidRates = this.precisionRound(results[j].sellPrepaidRates - parseFloat(agentMargin[i].sellPrepaid.value), 2);
                    }
                }
            }
        }
    }
}
