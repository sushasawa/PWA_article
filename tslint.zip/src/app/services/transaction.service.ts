import { Injectable } from '@angular/core';
import { Constants } from '../../app/helpers/constants';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class TransactionService {

  constructor(private http: HttpClient) { }
  TransactionData(sessionData: any) {
    return this.http.post(Constants.transactionDumpService(), sessionData);
  }
  generateInvoiceNo(travellerNo: number) {
    return this.http.get(Constants.generateInvoiceNoService() + '?travellerNo=' + travellerNo);
  }

  TransactionId() {
    return this.http.get(Constants.generateTransactionIdService());
  }


  initTransactionSaving(session: any) {
   return this.http.post(Constants.initTransactionSavingService(), session);
  }



  getTransactionById(id: any) {
    return this.http.get(Constants.getTransactionByIdService(id));
  }

  sendSellInvoiceData(payload) {  console.log(payload);
         return this.http.post(Constants.sendSellInvoiceDataService(), payload);
  }

}
