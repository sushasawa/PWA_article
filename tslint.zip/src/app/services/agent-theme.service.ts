import { Injectable } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { SessionHelper } from '../../app/helpers/session-helper';
@Injectable()
export class AgentThemeService {
    public agentURLParam: any;
    public overviewContents: any;
    constructor(private Routers: Router) {
        this.overviewContents = {
            "convenienceTitle": "Buying forex have never become easier!",
            "convenienceContents": "Cox & Kings helps you choose the right forex solutions.<br> When you are on the move, just place the order and visit any of the nearest Cox & Kings location to avail our forex solutions.<br> When you are busy, just place the order and relax. We will get you the required forex solutions at your door step.",
            "mainScreenBackGround": "assets/images/forex-bg-img.jpg",
            "specialOffers": [
                {
                    "Title": "Private Visit",
                    "Contents": "Buy forex under Liberalized Remittance Scheme (LRS) when you travel abroad for leisure or on a private visit"
                },
                {
                    "Title": "Overseas Education",
                    "Contents": "Buy forex under Liberalized Remittance Scheme (LRS) when you go overseas for studies!"
                },
                {
                    "Title": "Emigration",
                    "Contents": "Buy forex under Liberalized Remittance Scheme (LRS) when you migrate from India"
                }
            ],
            "products": [
                {
                    "Title": "Foreign Currency Notes",
                    "Contents": `Foreign Exchange Currency Notes of 26 currencies is readily available in all the denomination across the counter. Cox
                    and Kings recommend our customers to carry a little amount of Foreign Currency notes during their travel abroad for
                    petty unforeseen expenses like Taxi Fare to their final destination from airport.`
                },
                {
                    "Title": "Pre-paid Cards",
                    "Contents": `The Prepaid Travel Card comes with a lot of other benefits:
                    <ul>
                        <li> 1. Access to over 34 Million merchant establishments and to 2.1 Million ATM's</li>
                        <li> 2. Free Replacement Card.</li>
                        <li> 3. Global Emergency Toll Free Assistance in over 80 countries</li>
                    </ul>`
                },
                {
                    "Title": "Demand Drafts",
                    "Contents": `Forex DD can be issued in 9 currencies across the counter. This facility of Demand draft is a preferred mode of remittance
                    for various overseas travellers like students, Immigrants, medical tourist etc.`
                },
                {
                    "Title": "Send Money Abroad",
                    "Contents": `<p>Send Money Abroad is TT remittances.</p>
                    <p>Are you going abroad for studies or employment? Is your son or daughter studying abroad and do you want to send money
                        to them to pay their tuition fees and living expenses? Look no further! Cox & Kings offers quick remittance services
                        to ensure that the money reaches to the intended beneficiary.</p>`
                },
                {
                    "Title": "Pre-paid Cards",
                    "Contents": `The Prepaid Travel Card comes with a lot of other benefits:
                    <ul>
                        <li> 1. Access to over 34 Million merchant establishments and to 2.1 Million ATM's</li>
                        <li> 2. Free Replacement Card.</li>
                        <li> 3. Global Emergency Toll Free Assistance in over 80 countries</li>
                    </ul>`
                },
                {
                    "Title": "Demand Drafts",
                    "Contents": `<p>Forex DD can be issued in 9 currencies across the counter. This facility of Demand draft is a preferred mode of remittance
                    for various overseas travellers like students, Immigrants, medical tourist etc.</p>`
                }
            ],
            "testimonials": [
                {
                    "Title": "Rahul Iyer",
                    "Contents": `“You have been right there, helping out wherever and whenever needed for these past few months. Whenever I wanted my forex card to be loaded, I just had to give you a call and you made everything look so easy. I am looking forward to continue to avail Cox & Kings amazing services.”`
                },
                {
                    "Title": "Bharat Gawda",
                    "Contents": `“Being a customer of your company for over two years, I have first-hand experience of your outstanding services. I experienced best customer support in the industry at all times. Your team always did their best to help and give professional advice.”`
                },
                {
                    "Title": "Ramakant Battul",
                    "Contents": `I was really impressed how easy to send money abroad with the help of Cox & Kings compared with my bank. What's more! not only I got simple no jargon explanations and help from your support team, I also saved a lot of money with Cox & Kings compared to the exchange rate that my bank offered me.`
                }
            ]
        };
    }

    setDefaultValues(agentTheme: any){
        // agentTheme = JSON.parse(JSON.stringify(agentTheme));
        agentTheme = this.mergeObject(this.overviewContents, agentTheme);
    }

    mergeObject(overviewContents, agentTheme) {
        var found = [], isNotEmpty;
        for (var property in overviewContents) {
            if (typeof overviewContents[property] == "object") {
                if(!agentTheme[property]){
                    if(overviewContents[property] instanceof Array){
                        agentTheme[property] = [];
                    } else {
                        agentTheme[property] = {};
                    }
                }                
                agentTheme[property] = this.mergeObject(overviewContents[property], agentTheme[property]);
            } else {
                if (!agentTheme[property]) {
                    agentTheme[property] = overviewContents[property];
                }
            }
        }
        return agentTheme;
    }

}