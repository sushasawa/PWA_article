import { Injectable } from '@angular/core';
import { Constants } from '../../app/helpers/constants';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SessionHelper } from '../../app/helpers/session-helper';
@Injectable()
export class AgentMarginService {
    public agentMarginObj;
    public UserInfo: any;
    constructor(private http: HttpClient) { }
    getAgentMargin(AgentId) {
        return this.http.get(Constants.getAgentMargin(AgentId));
    }

    setAgentMargin() {
        if (SessionHelper.getSession('userInfo')) {
            this.UserInfo = JSON.parse(SessionHelper.getSession('userInfo'));
            if (this.UserInfo) {
                const AgentId = this.UserInfo.uid;
                if (AgentId) {
                    this.getAgentMargin(AgentId).subscribe(data => {
                        const retData: any = data;
                        const agentMargin: any = retData.root.element;
                        this.agentMarginObj = agentMargin;
                    });
                }
            }
        }
    }

    setAgentMarginCall(callBack) {
        if (SessionHelper.getSession('userInfo')) {
            this.UserInfo = JSON.parse(SessionHelper.getSession('userInfo'));
            if (this.UserInfo) {
                const AgentId = this.UserInfo.uid;
                if (AgentId) {
                    this.getAgentMargin(AgentId).subscribe(data => {
                        const retData: any = data;
                        const agentMargin: any = retData.root.element;
                        this.agentMarginObj = agentMargin;
                        callBack();
                    });
                }
            }
        }
    }
}
