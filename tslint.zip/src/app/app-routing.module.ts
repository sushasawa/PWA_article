import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  
  { path: ':clientName/buy', loadChildren: './buy/buy.module#BuyModule'},
  { path: ':clientName/send-money', loadChildren: './sendmoney/sendmoney.module#SendmoneyModule'},
  { path: ':clientName/reload-card', loadChildren: './reload-card/reload-card.module#ReloadCardModule'},
  { path: ':clientName/sell', loadChildren: './sell/sell.module#SellModule'},
  
  { path: ':clientName/account', loadChildren: './my-account/my-account.module#MyAccountModule'},
  //{ path: ' /account', loadChildren: './my-account/my-account.module#MyAccountModule'},
  
  { path: ':clientName/forex-live-rates' , loadChildren : './forex-live-rates/forex-live-rates.module#ForexLiveRatesModule' },
    
  { path: ':clientName/login' , loadChildren : './register-login/register-login.module#RegisterLoginModule' },
  { path: 'CNK/login' , loadChildren : './register-login/register-login.module#RegisterLoginModule' },

  { path: ':clientName/footer-components', loadChildren: './footer-components/footer-components.module#FooterComponentsModule' },
  { path: ':clientName/lead-upload' , loadChildren : './lead-upload/lead-upload.module#LeadUploadModule' },
  { path: ':clientName/static-template' , loadChildren : './static-content/static-content.module#StaticContentModule' },
   // otherwise redirect to home  
  { path: ':clientName' , redirectTo : ':clientName/login' },
  {path: '**' , redirectTo: 'CNK/login'}


  //{ path: '**', redirectTo: 'login' }
  //{ path: '**', loadChildren: './register-login/register-login.module#RegisterLoginModule' , pathMatch: 'full'}     
  //{ path: ':clientName' , loadChildren : './register-login/register-login.module#RegisterLoginModule' },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
