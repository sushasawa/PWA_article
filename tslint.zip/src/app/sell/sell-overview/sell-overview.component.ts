import { Component, OnInit, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { UUID } from 'angular2-uuid';
import { Location } from '../../../app/helpers/location';
import { Observable } from 'rxjs/Observable';
import { LocationStrategy } from '@angular/common';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { SharedService } from './../../shared/shared.service';
declare function initDocument(): any;

declare var jquery: any;
declare var $: any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-sell-overview',
  templateUrl: './sell-overview.component.html',
  styleUrls: ['./sell-overview.component.css']
})
export class SellOverviewComponent implements OnInit {
  public userSessionInfoSale: any;
  public branchOptions: any;
  public currencyList: any;
  public currencyListCash: any;
  public CurrentBranchId: any;
  private currentTravellerIndex: number;
  public isLoggedIn: boolean;
  public travellerList: any;
  public newTravellerCount: number;
  public invalidsubmitted: boolean;
  public navigate: any = true;
  public _primaryComp: any;
  public AgentTheme: any;
  public textContents: any = {};
  public overviewPage: any;
  public specialOffers: any = [];
  public products: any = [];
  public testimonials: any = [];
  public backGroungImage: any = 'assets/images/forex-bg-img.jpg';
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _elementRef: ElementRef, private location: LocationStrategy, public _SharedService: SharedService) {
    this.location.onPopState(() => {
      this.navigate = false;
      return false;
    });
    this._primaryComp = '/' + navUrl.navUrl();
    this.userSessionInfoSale = {
      'sessionId': '',
      'mode': 'b2c',
      'type' : 'sellScreen',
      'isActive' : true,
      'LeadID' : SessionHelper.getSession('LeadID') ? SessionHelper.getSession('LeadID') : null ,
      'AgentID' : SessionHelper.getSession('userInfo') ? JSON.parse(SessionHelper.getSession('userInfo')).uid : null ,
      'created_On': new Date(),
      'sellScreen': {
        'budgetAmount': 0,
        'usedAmount': '0',
        'tranId' : '',
        'balanceAmount': '0',
        'currentLocation': '',
        'branch': '',
        'destination': '',
        'deliveryInfo': {
          'Mode': 'Home Delivery',
          'type': 'Standard',
          'DeliverySchedule': {
            'date': '',
            'time': ''
          },
          'rate': 0
        },
        'traveller': [{
          'selected': true,
          'lead': true,
          'prepaidCard': false,
          'purpose': '',
          'serviceCharge' : 0,
          'loadFees' : 0,
          'activationFees' : 0,
          'discount' : 0,
          'charges' : 0,
          'prepaidCardDetails': [{
            'currencyCode': '',
            'forexAmount': '',
            'bankname': '',
            'startTime' : ''
          }],
          'cash': false,
          'cashDetails': [{
            'currencyCode': '',
            'forexAmount': '',
            'startTime' : ''
          }],
          'registrationInfo': {
            'userId': '',
            'invoiceNo' : null,
            'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
            'middleName': '',
            'lastName': '',
            'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
            'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
            'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
            // "nationality": { "id": "", "name": "" } ,
            'nationality': '',
            'mothersMaidenName': {
              'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                + 'event.target.style.background=\'#f8f8f8\'}'
            },
            'PAN': {
              'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
                + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
                + 'event.target.style.background=\'#f8f8f8\'}'
            },
            'passportNumber': '',
            'ParentId': true,
            'dateOfIssue': '',
            'placeOfIssue': '',
            'expiryDate': '',
            'address': '101 5A Galaxy apartment',
            'isPassportAddressAsAdhar': 'yes',
            'adharAddress': {
              'flatNumber': '',
              'buildingName': '',
              'streetName': '',
              'landmark': '',
              'area': '',
              'city': '',
              'state': '',
              'pincode': '',
            },
            'passportAddress': {
              'flatNumber': '',
              'buildingName': '',
              'streetName': '',
              'landmark': '',
              'area': '',
              'city': '',
              'state': '',
              'pincode': '',
            },
            'currentAddressAs': 'asPerAdhar',
            'otherAddress': {
              'flatNumber': '',
              'buildingName': '',
              'streetName': '',
              'landmark': '',
              'area': '',
              'city': '',
              'state': '',
              'pincode': '',
            },
            'contactDetails': {
              'mobileNo': '',
              'emailId': ''
            },
            'alternateContactDetails': {
              'countryCode': '',
              'mobileNo': '',
              'countryCode2': '',
              'cityCode': '',
              'telephoneNo': '',
              'emailId': '',
            },
            'officeAddress': {
              'designation': '',
              'conpanyName': '',
              'companyDivision': '',
              'flatNumber': '',
              'building': '',
              'streetName': '',
              'landmark': '',
              'area': '',
              'city': '',
              'state': '',
              'pincode': ''
            },
            'officeContactDetails': {
              'countryCode': '',
              'telephoneNumber': '',
              'officeExtension': '',
            },
            'password': '',
            'confirmPassword': '',
          },
          'travellingDetails': {
            'dateOfTravel': '',
            'dateOfArrival': '',
            'airlineName': '',
            'ticketNumber': ''
          }
        }
        ]

      }
    };

    // if (SessionHelper.getSession('userInfo')) {
    //   const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));

    //   // Added after Aadhaar implementation
    //   if (userInfo.uid) {
    //     this.isLoggedIn = userInfo.loggedin;
    //     this.masterService.getLoggedInUserInfo(userInfo.uid)
    //       .subscribe(data => {
    //         const result: any = data;
    //         this.travellerList = [];
    //         this.travellerList.push({
    //           name: result.response[0][0].firstName + ' ' + result.response[0][0].lastName,
    //           data: result.response[0][0]
    //         });
    //         this.travellerList[0].data.lead = true;
    //         this.travellerList[0].selected = true;

    //         this.userSessionInfoSale.sellScreen.traveller[0].registrationInfo
    //           = SessionTemplate.getSessionTemplate(this.travellerList[0].data).registrationInfo;

    //         result.response[1].forEach(element => {
    //           this.travellerList.push({ name: element.firstName + ' ' + element.lastName, data: element });
    //           this.newTravellerCount = 0;
    //         });
    //       }, err => {
    //         // swal('Oops', 'Error fetching traveler data!', 'error');
    //         Snackbar.show({text: 'Error fetching traveler data!',
    //         pos: 'bottom-right' ,
    //         actionTextColor: '#ff4444',
    //        });
    //       });
    //   }
    // } else {
    //   this.isLoggedIn = false;
    // }

    // region Logic to restore values from session if present...
    if (SessionHelper.getSession('userSessionInfoSale')) {
      this.userSessionInfoSale = JSON.parse(SessionHelper.getSession('userSessionInfoSale'));
      // this.masterService.getCurrencyList(0)
      //   .subscribe(data => {
      //     this.currencyList = data;
      //     this.currencyListCash = data;
      //   });
    } else {
      this.userSessionInfoSale.sessionId = UUID.UUID();
    }
    // endregion Logic to restore values from session if present...


    this.populateBranch('');
    if (sessionStorage.getItem('currentLocation') === null) {
        this.masterService.getCurrentLocation()
        .subscribe(data => {
          this.userSessionInfoSale.sellScreen.currentLocation = data;
          sessionStorage.setItem('currentLocation', JSON.stringify(this.userSessionInfoSale.sellScreen.currentLocation));
          this.populateBranch(this.userSessionInfoSale.sellScreen.currentLocation.city);
          if (SessionHelper.getLocal('branchIdFromOverviewSell')) {
            const branchIdObj = {BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewSell'))};
            this.selected(branchIdObj);
          } else {
            const branchIdObj = {BranchID: 11910};
            this.selected(branchIdObj);
          }
        }, err => {
          this.populateBranch('');
          Snackbar.show({
              text: 'Unable to detect current location!',
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
          });
      });
  } else {
      this.userSessionInfoSale.sellScreen.currentLocation = JSON.parse(sessionStorage.getItem('currentLocation'));
      this.populateBranch(this.userSessionInfoSale.sellScreen.currentLocation.city);
      if (SessionHelper.getLocal('branchIdFromOverviewSell')) {
          const branchIdObj = { BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewSell')) };
          this.selected(branchIdObj);
      } else {
          const branchIdObj = { BranchID: 11910 };
          this.selected(branchIdObj);
      }
  }

    // this.masterService.getCurrentLocation()
    //   .subscribe(data => {
    //     this.userSessionInfoSale.sellScreen.currentLocation = data;
    //     this.populateBranch(this.userSessionInfoSale.sellScreen.currentLocation.city);
    //     if (SessionHelper.getLocal('branchIdFromOverviewSell')) {
    //       const branchIdObj = {BranchID: JSON.parse(SessionHelper.getLocal('branchIdFromOverviewSell'))};
    //       this.selected(branchIdObj);
    //     } else {
    //       const branchIdObj = {BranchID: 11910};
    //       this.selected(branchIdObj);
    //     }
    //   }, err => {
    //     this.populateBranch('');
    //     Snackbar.show({
    //         text: 'Unable to detect current location!',
    //         pos: 'bottom-right',
    //         actionTextColor: '#ff4444',
    //     });
    // });






    this.CurrentBranchId = Number.parseInt(SessionHelper.getLocal('branchIdFromOverview'));
    this.currentTravellerIndex = 0;
    this.updateSession();
    this.populateCashCurrency();
    this.populatePrepaidCurrency();
    this.populateCurrencyRateForRule(this.CurrentBranchId);
  }

  ngOnInit(): void {
    $('body').attr('id', 'home');
    initDocument();
    this.textContents.convenienceTitle = "Buying forex have never become easier!";
    this.textContents.convenienceContents = "Cox & Kings helps you choose the right forex solutions.<br> When you are on the move, just place the order and visit any of the nearest Cox & Kings location to avail our forex solutions.<br> When you are busy, just place the order and relax. We will get you the required forex solutions at your door step.";
    if (this._SharedService.AgentsTheme) {
        this.AgentTheme = this._SharedService.AgentsTheme.success ? this._SharedService.AgentsTheme.Docs : this._SharedService.AgentsTheme;
        this.applyTheme();
    }
    $('.custom-tabs > .resp-tabs-list > li[aria-controls="hor_1_tab_item-1"]').trigger('click');

    /// temporary number
    if (sessionStorage.getItem('userInfo') !== null) {
      const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
      this.masterService.getTemporaryOrderNumber()
        .subscribe(data => {
          const result: any = data;
          console.log(result);
          this.userSessionInfoSale.temporaryOrderNumber = result.response.OrderNumber;
          this.userSessionInfoSale.userId = userInfo.uid;
        });
    }
    this.selectTraveller(0);
  }

  ngDoCheck() {
    this._SharedService.AgentTheme.subscribe((theme) => {
      this.AgentTheme = theme.success ? theme.Docs : theme;
      this.applyTheme();
    });
  }

  applyTheme() {
    if (this.AgentTheme.overviewPage) {
      this.overviewPage = this.AgentTheme.overviewPage;
      if (this.overviewPage.mainScreenBackGround) {
        this.backGroungImage = this.overviewPage.mainScreenBackGround;
      }
      if (this.overviewPage.specialOffers) {
        this.specialOffers = this.overviewPage.specialOffers;
      }
      if (this.overviewPage.products) {
        this.products = this.overviewPage.products;
      }
      if (this.overviewPage.testimonials) {
        this.testimonials = this.overviewPage.testimonials;
      }
    }
  }


  populateCurrencyRateForRule(branchId) {
    this.masterService.getCurrencyRateForRule(branchId).subscribe(
        (data) => {
            const result: any = data;
               this.userSessionInfoSale.cashRateBuy =  result[0].cashRateBuy;
               this.userSessionInfoSale.prepaidRateBuy =  result[0].prepaidRateBuy;
               this.userSessionInfoSale.ddRateBuy =  result[0].ddRateBuy;
               this.userSessionInfoSale.cashRateSell =  result[0].cashRateSell;
               this.updateSession();
        },
        (error) => {
            console.error('getCurrencyRateForRule');
            console.log(error);
        }
    );

}
  populateBranch(cityname) {
    if(cityname)
    this.masterService.getBranchList(cityname)
          .subscribe(data => {
              this.branchOptions = data;
          });
  }
  addExistingTraveller(data: any, event: any, index: number) {
    if (event.target.checked) {
      if (this.userSessionInfoSale.sellScreen.traveller.length === 4) {
        // swal('Sorry', 'Maximum 4 travelers allowed', 'error');
        Snackbar.show({text: 'Sorry! Maximum 4 travelers allowed',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
        event.target.checked = false;
      } else {
        this.userSessionInfoSale.sellScreen.traveller.push(
          {
              registrationInfo: SessionTemplate.getSessionTemplate(data).registrationInfo,
              travellingDetails: SessionTemplate.getSessionTemplate(data).travellingDetails,
              'serviceCharge' : 0,
              'loadFees' : 0,
              'activationFees' : 0,
              'discount' : 0,
              'charges' : 0,
              'selected': false,
              'lead': false,
              'prepaidCard': false,
              'purpose': '',
              'prepaidCardDetails': [{
                'currencyCode': '',
                'forexAmount': '',
                'bankname': '',
                'startTime' : ''
              }],
              'cash': false,
              'cashDetails': [{
                'currencyCode': '',
                'forexAmount': '',
                'startTime' : ''
              }],
          }
      );
      this.selectTraveller(this.userSessionInfoSale.sellScreen.traveller.length - 1);
      }
    } else {
      if (!this.travellerList[index].data.lead) {
        if (this.userSessionInfoSale.sellScreen.traveller.length > 1) {
          const obj = this.userSessionInfoSale.sellScreen.traveller
            .find(item => item.registrationInfo.contactDetails.emailId === data.emailId);

          this.removeTraveller(this.userSessionInfoSale.sellScreen.traveller.indexOf(obj));
        } else {
          // swal('Sorry', 'Minimum 1 traveler needed', 'error');
          Snackbar.show({text: 'Sorry! Minimum 1 traveler needed',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
          event.target.checked = true;
        }
      } else {
        // swal('Sorry', 'You cannot remove lead pax. Change any other traveler to lead before this operation', 'error');
        Snackbar.show({text: 'Sorry! You cannot remove lead pax. Change any other traveler to lead before this operation',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
        event.target.checked = true;
      }
    }

    this.travellerList[index].selected = event.target.checked;
    this.updateSession();
  }

  addNewTraveller(event: any) {
    if (event.target.checked) {
      if (this.userSessionInfoSale.sellScreen.traveller.length === 4) {
        // swal('Sorry', 'Maximum 4 travelers allowed', 'error');
        Snackbar.show({text: 'Sorry! Maximum 4 travelers allowed',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });

        event.target.checked = false;
      } else {
        this.newTravellerCount++;
        this.addTraveller();
        this.selectTraveller(this.userSessionInfoSale.sellScreen.traveller.length - 1);
      }
    } else {
      if (this.userSessionInfoSale.sellScreen.traveller.length > 1) {
        const obj = this.userSessionInfoSale.sellScreen.traveller
          .find(item => item.registrationInfo.contactDetails.emailId === '');
        this.removeTraveller(this.userSessionInfoSale.sellScreen.traveller.indexOf(obj));
        this.newTravellerCount--;
      } else {
        // swal('Sorry', 'Minimum 1 traveler needed', 'error');
        Snackbar.show({text: 'Sorry! Minimum 1 traveler needed',
        pos: 'bottom-right' ,
        actionTextColor: '#ff4444',
       });
        event.target.checked = true;
      }
    }
    this.updateSession();
  }

  changeLeadPax(event: any, data: any, index: number) {

    this.travellerList.forEach(item => {
      item.data.lead = false;
    });

    this.travellerList[index].data.lead = true;

    this.userSessionInfoSale.sellScreen.traveller.forEach(traveller => {
      traveller.lead = false;
    });
    const obj = this.userSessionInfoSale.sellScreen.traveller
      .find(item => item.registrationInfo.contactDetails.emailId === data.emailId);
    const i = this.userSessionInfoSale.sellScreen.traveller.indexOf(obj);

    this.userSessionInfoSale.sellScreen.traveller[i].lead = true;
    console.log(this.userSessionInfoSale.sellScreen.traveller);
    this.updateSession();
  }

  showTravellerChoice() {
    this._elementRef.nativeElement.querySelector('.trvl-list').style.display = 'block';
  }

  hideTravellerChoice() {
    this._elementRef.nativeElement.querySelector('.trvl-list').style.display = 'none';
  }

  saveBudgetAmount(newValue) {
    this.userSessionInfoSale.sellScreen.budgetAmount = newValue;
    this.updateBalanceAmount();
  }

  updateBalanceAmount() {
    if (this.userSessionInfoSale.sellScreen.budgetAmount !== 0) {
      this.userSessionInfoSale.sellScreen.balanceAmount = (this.userSessionInfoSale.sellScreen.budgetAmount
        - this.userSessionInfoSale.sellScreen.usedAmount).toString();
    }
    this.updateSession();
  }

  updateBranch(newValue: number) {
    this.userSessionInfoSale.sellScreen.branch = newValue;
    this.userSessionInfoSale.sellScreen.traveller.map((traveller, index) => {
      if (traveller.cash) {
          traveller.cashDetails = [];
          traveller.cash = false;
          traveller.cashDetails.push(
              {
                  'currencyCode': '',
                  'forexAmount': '',
                  'startTime': ''
              }
          );
      }
      this.updateSession();
  });
  this.updateUsedAmount();
  this.updateBalanceAmount();
  }

  updateCurrencyCode(prepaidDetailIndex: number, newValue: string) {
    this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
      .currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'prepaid', 'sell', 'ICICIMCC')
      .subscribe(data => {
        const result: any = data;
        this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex]
          .exchangeRate = result;
          if (result.rate !== 0) {
            this.updateUsedAmount();
            this.updateSession();
            this.populateCurrencyRateForRule(this.CurrentBranchId);
        }else {
          this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[prepaidDetailIndex].forexAmount = '';
            Snackbar.show({
                text: 'No Rates Found for <b>' + newValue + '</b>',
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
            });
        }
      });

    this.updateSession();
  }


  updateCashCurrencyCode(cashDetailIndex: number, newValue: string) {
    this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails[cashDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.CurrentBranchId, 'cash', 'sell')
      .subscribe(data => {
        const result: any = data;
        this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails[cashDetailIndex].exchangeRate = data;
        if (result.rate !== 0) {
          this.updateUsedAmount();
          this.updateSession();
          this.populateCurrencyRateForRule(this.CurrentBranchId);
      }else {
        this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails[cashDetailIndex].forexAmount = '';
          Snackbar.show({
              text: 'No Rates Found for <b>' + newValue + '</b>',
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
          });
      }
      });
    this.updateSession();
  }


  updatePrepaidCard(newValue: boolean) {
    this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCard = newValue;

    if (this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails === undefined) {
      this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails = [{}];
    }
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
    if (newValue) {
      const  destination =  this.userSessionInfoSale.sellScreen.destination.split('#')[0];
      this.masterService.getCurrencyList(1, destination)
          .subscribe(data => {
              this.currencyList = data;
          }, err => {
              // swal('Oops...', 'Unable to fetch currency list!', 'error');
              Snackbar.show({text: 'Oops... , Unable to fetch currency list',
              pos: 'bottom-right' ,
              actionTextColor: '#ff4444',
             });
          });

    }
    this.updateUsedAmount();
  }
  populatePrepaidCurrency() {
            // 1	Prepaid Card	    FC
          // 2	Cash	            FCN
          // 3	Traveller's Check	TC
          // 4	Demand Draft	    DD
          // 5	Send money abroad 	TT
          const  destination =  this.userSessionInfoSale.sellScreen.destination.split('#')[0];
          this.masterService.getCurrencyList(1, destination)
              .subscribe(data => {
                  this.currencyList = data;
              }, err => {
                  // swal('Oops...', 'Unable to fetch currency list!', 'error');
                  Snackbar.show({text: 'Oops... , Unable to fetch currency list',
                  pos: 'bottom-right' ,
                  actionTextColor: '#ff4444',
                 });
              });
  }
  updateCash(newValue: boolean) {
    this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cash = newValue;

    if (this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails === undefined) {
      this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails = [{}];
    }
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
    if (newValue) {
      const  destination =  this.userSessionInfoSale.sellScreen.destination.split('#')[0];
      this.masterService.getCurrencyList(2, destination)
          .subscribe(data => {
              this.currencyListCash = data;
          }, err => {
              // swal('Oops...', 'Unable to fetch currency list!', 'error');
              Snackbar.show({text: 'Unable to fetch currency list!',
              pos: 'bottom-right' ,
              actionTextColor: '#ff4444',
             });
          });
       }
    this.updateUsedAmount();
  }

  populateCashCurrency() {
        // 1	Prepaid Card	    FC
        // 2	Cash	            FCN
        // 3	Traveller's Check	TC
        // 4	Demand Draft	    DD
        // 5	Send money abroad 	TT
        const  destination =  this.userSessionInfoSale.sellScreen.destination.split('#')[0];
        this.masterService.getCurrencyList(2, destination)
            .subscribe(data => {
                this.currencyListCash = data;
            }, err => {
                // swal('Oops...', 'Unable to fetch currency list!', 'error');
                Snackbar.show({text: 'Oops...!Unable to fetch currency list',
                pos: 'bottom-right' ,
                actionTextColor: '#ff4444',
               });
            });
  }

  updateValue(newValue, index) {
if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    const checkRateCondition = this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index].exchangeRate.rate !== 0;
    if (checkRateCondition) {
      this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index].forexAmount = parseFloat(newValue);
      this.updateUsedAmount();
    } else {
     // console.log(this.userSessionInfoSale.sellScreen.traveller);
      this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails[index].forexAmount = '';
      (<HTMLInputElement>document.getElementById('prepaid' + this.currentTravellerIndex + index)).value = '';
    }

  }

  updateCashValue(newValue, index) {
  if (newValue === '' || isNaN(newValue)) {
      newValue = '0';
    }
    const checkCashRateCondition = this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails[index].exchangeRate.rate !== 0;
    if (checkCashRateCondition) {
      this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails[index].forexAmount = parseFloat(newValue);
      this.updateUsedAmount();
    } else {
     // console.log(this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails);
      this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails[index].forexAmount = '';
      (<HTMLInputElement>document.getElementById('cash' + this.currentTravellerIndex + index)).value = '';
    }

  }


  updateUsedAmount() {
    let travellerTotal = 0;

    this.userSessionInfoSale.sellScreen.traveller.forEach(currentTraveller => {
      let currentTravellerTotal = 0;
      if (currentTraveller.prepaidCard) {
        currentTraveller.prepaidCardDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      if (currentTraveller.cash) {
        currentTraveller.cashDetails.forEach(element => {
          if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
            currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
          }
        });
      }
      travellerTotal += currentTravellerTotal;
      currentTraveller.usedAmount = currentTravellerTotal;
    });

    this.userSessionInfoSale.sellScreen.usedAmount = travellerTotal;

    if (this.userSessionInfoSale.sellScreen.usedAmount !== 0) {
      this.masterService.getTaxes(this.userSessionInfoSale.sellScreen.usedAmount)
        .subscribe(res => {
          const result: any = res;
          this.userSessionInfoSale.sellScreen.usedAmount -= result.TotalTax; // the amount is subtracted and not added.. plz note
          this.updateBalanceAmount();
        }, err => {
          // swal('Oops', 'Error fetching taxes', 'error');
          Snackbar.show({text: 'Oops...!Error fetching taxes',
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
        });
    }

    this.updateBalanceAmount();
  }

  addMoreCurrency() {
    console.log('Prepaid aaa');
    this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.push({
      'currencyCode': '',
      'forexAmount': '',
      'bankname': '',
      'startTime' : ''
    });
  }

  addMoreCashCurrency() {
    console.log('Cash aaa');
    this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails.push({
      'currencyCode': '',
      'forexAmount': '',
      'startTime' : ''
    });
  }

  removePrepaidRegion(index: number) {
    this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].prepaidCardDetails.splice(index, 1);
    this.updateUsedAmount();
  }

  removeCashRegion(index: number) {
    this.userSessionInfoSale.sellScreen.traveller[this.currentTravellerIndex].cashDetails.splice(index, 1);
    this.updateUsedAmount();
  }

  addTravellerOption() {
    this.isLoggedIn ? this.showTravellerChoice() : this.addTraveller();
    this.selectTraveller(this.userSessionInfoSale.sellScreen.traveller.length - 1);
  }

  addTraveller() {
    if (this.userSessionInfoSale.sellScreen.traveller.length < 4) {
      this.userSessionInfoSale.sellScreen.traveller.push({
        'purpose': '',
        'serviceCharge' : 0,
        'loadFees' : 0,
        'activationFees' : 0,
        'discount' : 0,
        'charges' : 0,
        'registrationInfo': {
          'userId': '',
          'invoiceNo' : null,
          'firstName': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
          'middleName': '',
          'lastName': '',
          'dateOfBirth': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'true' } },
          'adharCardNo': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
          'gender': { 'value': '', 'checkCondition': { 'isRequired': 'true', 'isNumeric': 'false', 'isDate': 'false' } },
          // "nationality": { "id": "", "name": "" } ,
          'nationality': '',
          'mothersMaidenName': {
            'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
              + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
              + 'event.target.style.background=\'#f8f8f8\'}'
          },
          'PAN': {
            'value': '', 'checkCondition': 'if(value.trim()==\'\'){console.log(\'Not ok\');'
              + 'event.target.style.background=\'rgba(255, 205, 205, 0.9)\'}else{console.log(\'Ok\');'
              + 'event.target.style.background=\'#f8f8f8\'}'
          },
          'passportNumber': '',
          'ParentId': true,
          'dateOfIssue': '',
          'placeOfIssue': '',
          'expiryDate': '',
          'address': '101 5A Galaxy apartment',
          'isPassportAddressAsAdhar': 'yes',
          'adharAddress': {
            'flatNumber': '',
            'buildingName': '',
            'streetName': '',
            'landmark': '',
            'area': '',
            'city': '',
            'state': '',
            'pincode': '',
          },
          'passportAddress': {
            'flatNumber': '',
            'buildingName': '',
            'streetName': '',
            'landmark': '',
            'area': '',
            'city': '',
            'state': '',
            'pincode': '',
          },
          'currentAddressAs': 'asPerAdhar',
          'otherAddress': {
            'flatNumber': '',
            'buildingName': '',
            'streetName': '',
            'landmark': '',
            'area': '',
            'city': '',
            'state': '',
            'pincode': '',
          },
          'contactDetails': {
            'mobileNo': '',
            'emailId': ''
          },
          'alternateContactDetails': {
            'countryCode': '',
            'mobileNo': '',
            'countryCode2': '',
            'cityCode': '',
            'telephoneNo': '',
            'emailId': '',
          },
          'officeAddress': {
            'designation': '',
            'conpanyName': '',
            'companyDivision': '',
            'flatNumber': '',
            'building': '',
            'streetName': '',
            'landmark': '',
            'area': '',
            'city': '',
            'state': '',
            'pincode': ''
          },
          'officeContactDetails': {
            'countryCode': '',
            'telephoneNumber': '',
            'officeExtension': '',
          },
          'password': '',
          'confirmPassword': '',
        },
        'travellingDetails': {
          'dateOfTravel': '',
          'dateOfArrival': '',
          'airlineName': '',
          'ticketNumber': ''
        },
      });
    } else {
      // swal('Oops', 'Maximum 4 travellers allowed!', 'error');
      Snackbar.show({text: 'Oops...!Maximum 4 travellers allowed',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
    }
    this.updateSession();
  }


  removeTraveller(index: number) {
    if (!this.userSessionInfoSale.sellScreen.traveller[index].lead) {
      if (this.userSessionInfoSale.sellScreen.traveller[index].selected) {
        this.selectTraveller(index === 0 ? 1 : index - 1);
      }
      if (this.userSessionInfoSale.sellScreen.traveller[index].registrationInfo.contactDetails.emailId === '') {

        if (this._elementRef.nativeElement.querySelector('#chkbox-new-' + this.newTravellerCount) !== null) {
          this._elementRef.nativeElement.querySelector('#chkbox-new-' + this.newTravellerCount).checked = false;
        }
        this.newTravellerCount--;
      }
      this.userSessionInfoSale.sellScreen.traveller.splice(index, 1);
      this.updateUsedAmount();
    } else {
      // swal('Sorry', 'You cannot remove lead pax. Change any other traveler to lead before this operation', 'error');
      Snackbar.show({text: 'Sorry , You cannot remove lead pax. Change any other traveler to lead before this operation',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });

    }
    this.updateSession();
  }


  selectTraveller(travellerIndex) {
    this.currentTravellerIndex = travellerIndex;

    this.userSessionInfoSale.sellScreen.traveller.forEach(traveller => {
      traveller.selected = false;
    });

    this.userSessionInfoSale.sellScreen.traveller[travellerIndex].selected = true;
    this.updateSession();
  }


  submitAndRedirect() {
    // this.populateCurrencyRateForRule(this.CurrentBranchId);
    this.userSessionInfoSale['nextLink'] = '/sell/checklist';
    this.updateSession();
    if (this.validateSession()) {
      this.masterService.dumpSessionData(this.userSessionInfoSale)
        .subscribe(data => {
        }, err => {
          console.log(err);
        });
      this.router.navigateByUrl(this.navUrl.navUrl() + '/sell/checklist');
    }
  }

  selected($event) { //  console.log($event);
    this.CurrentBranchId = $event.BranchID;
    SessionHelper.setLocal('branchIdFromOverview', $event.BranchID);
    SessionHelper.setLocal('branchIdFromOverviewSell', $event.BranchID);
    if ($event.BranchCode) {
      this.userSessionInfoSale.sellScreen.BranchCode = $event.BranchCode;
      this.updateSession();
    }
   this.populateCurrencyRateForRule(this.CurrentBranchId);
  }

  updateSession() {
    SessionHelper.setSession('userSessionInfoSale', JSON.stringify(this.userSessionInfoSale));
    // console.log(SessionHelper.getSession('userSessionInfoSale'));
  }

  // //My Functions
  getCurrencyList() {
    this.masterService.getCurrencyList(1)
      .subscribe(data => {
        this.currencyList = data;
      });
  }

  validateSession() {
    let result = true;

    if (this.userSessionInfoSale.sellScreen.branch === '' || this.userSessionInfoSale.sellScreen.branch === undefined) {
      // swal('Error', 'Please select branch', 'error');
      Snackbar.show({text: 'Error , Please select branch',
      pos: 'bottom-right' ,
      actionTextColor: '#ff4444',
     });
     this.invalidsubmitted = true;
      result = false;
    } else {

      for (let travellerIndex = 0; travellerIndex < this.userSessionInfoSale.sellScreen.traveller.length; travellerIndex++) {
        const traveller = this.userSessionInfoSale.sellScreen.traveller[travellerIndex];

        if (!traveller.prepaidCard && !traveller.cash) {
          // swal('Error', 'You have not provided any data for traveler ' + (travellerIndex + 1), 'error');
          Snackbar.show({text: 'Error , You have not provided any data for traveler ' + (travellerIndex + 1),
          pos: 'bottom-right' ,
          actionTextColor: '#ff4444',
         });
         this.selectTraveller(travellerIndex);
         this.invalidsubmitted = true;
          result = false;
          break;
        }

        if (traveller.prepaidCard) {
          let index = 0;
          for (; index < traveller.prepaidCardDetails.length; index++) {
            const detail = traveller.prepaidCardDetails[index];
            if (detail.currencyCode === '' || detail.currencyCode === undefined) {
              // swal('Error', 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({text: 'Error , Please select currency for prepaid card of traveler ' + (travellerIndex + 1),
              pos: 'bottom-right' ,
              actionTextColor: '#ff4444',
             });
             this.selectTraveller(travellerIndex);
             this.invalidsubmitted = true;
              result = false;
              break;
            }
            if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
              // swal('Error', 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({text: 'Error , Please provide amount for prepaid card of traveler ' + (travellerIndex + 1),
              pos: 'bottom-right' ,
              actionTextColor: '#ff4444',
             });
             this.selectTraveller(travellerIndex);
             this.invalidsubmitted = true;
              result = false;
              break;
            }
          }

          if (index < traveller.prepaidCardDetails.length) {
            break;
          }
        }
        if (traveller.cash) {
          let index = 0;
          for (; index < traveller.cashDetails.length; index++) {
            const detail = traveller.cashDetails[index];
            if (detail.currencyCode === '' || detail.currencyCode === undefined) {
              // swal('Error', 'Please select currency for cash of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({text: 'Error , Please select currency for cash of traveler ' + (travellerIndex + 1),
              pos: 'bottom-right' ,
              actionTextColor: '#ff4444',
             });
             this.selectTraveller(travellerIndex);
             this.invalidsubmitted = true;
              result = false;
              break;
            }
            if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
              // swal('Error', 'Please provide amount for cash of traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({text: 'Error , Please provide amount for cash of traveler ' + (travellerIndex + 1),
              pos: 'bottom-right' ,
              actionTextColor: '#ff4444',
             });
             this.selectTraveller(travellerIndex);
             this.invalidsubmitted = true;
              result = false;
              break;
            }
          }
          if (index < traveller.cashDetails.length) {
            break;
          }
        }
      }
    }

    return result;
  }

  canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
    if (this.navigate === true) {
      return true;
    } else {
      Snackbar.show({
        text: 'You can not go back from this page. Please go through application flow.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
        duration: 3000
      });
      window.scrollTo(0, 0);
      this.navigate = true;
      return false;
    }
  }

}
