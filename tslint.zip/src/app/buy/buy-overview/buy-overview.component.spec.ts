import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyOverviewComponent } from './buy-overview.component';

describe('BuyOverviewComponent', () => {
  let component: BuyOverviewComponent;
  let fixture: ComponentFixture<BuyOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
