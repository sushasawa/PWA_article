import { Component, OnInit } from '@angular/core';

declare var $: any;

@Component({
  selector: 'app-create-account-adhar',
  templateUrl: './create-account-adhar.component.html',
  styleUrls: ['./create-account-adhar.component.css']
})
export class CreateAccountAdharComponent implements OnInit {

  constructor() {
  }


  ngOnInit(): void {
    $('body').attr('id', '');
  }

}
