import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAccountAdharComponent } from './create-account-adhar.component';

describe('CreateAccountAdharComponent', () => {
  let component: CreateAccountAdharComponent;
  let fixture: ComponentFixture<CreateAccountAdharComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateAccountAdharComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateAccountAdharComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
