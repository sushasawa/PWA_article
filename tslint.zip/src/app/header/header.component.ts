import { UserControl } from './../helpers/user-control';
import { SharedService } from './../shared/shared.service';

import { MasterService } from './../services/master.services';
import { NavigatePathService} from './../services/navigate-path.service';

import { Component, OnInit, Input, DoCheck } from '@angular/core';

import { SessionHelper } from '../../app/helpers/session-helper';
import { SessionTemplate } from '../helpers/session-template';
import { SessionCheckerService } from '../services/session-checker.service';



declare var $: any;

declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
@Component({
    // tslint:disable-next-line:component-selector
    selector: 'forex-header',
    templateUrl: 'header.component.html',
    styleUrls: ['header.component.css']
})

export class HeaderComponent implements OnInit, DoCheck {
    public currentUser: any;
    public currentUserId: any;
    public logo: any = 'assets/images/common/nocompanylogo.png';
    public ACCESS_CTRL: any;
    public _UserControl: any = UserControl.getUserRules();
    public _primaryComp: any;

    public LastLoggedIn: any;
    public AgentTheme: any;
    public back: any;
    // tslint:disable-next-line:max-line-length
    constructor(public sessionChecker: SessionCheckerService, public _NavigatePathService: NavigatePathService, public _MasterService: MasterService, public _SharedService: SharedService) {
        this._primaryComp = '/' + _NavigatePathService.navUrl();
        
        
        const UserInfo: any = SessionHelper.getSession('userInfo');
        this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
        if (UserInfo) {
            this.currentUserId = JSON.parse(UserInfo).uid;
            const payload = {
                'UserId': this.currentUserId,
                'Email': JSON.parse(SessionHelper.getSession('userInfo')).uname,
                'AdmType': SessionHelper.getSession('adm_ctrl')
            };
            if (this._SharedService.AgentsTheme) {
                // tslint:disable-next-line:max-line-length
                this.AgentTheme = this._SharedService.AgentsTheme.success ? this._SharedService.AgentsTheme.Docs : this._SharedService.AgentsTheme;
            }
            if (!this.ACCESS_CTRL) {
                SessionHelper.removeSession('userInfo');
                SessionHelper.removeSession('userSessionInfo');
                SessionHelper.removeSession('userSessionInfoSale');
                SessionHelper.removeSession('userSessionInfoRealoadCard');
                SessionHelper.removeSession('userSessionInfoSend');
                SessionHelper.removeSession('pageSessionParam');
                SessionHelper.removeSession('currentUser');
                SessionHelper.removeSession('adm_ctrl');
                window.location.href = this._primaryComp + '/';
            }
        } else {
            SessionHelper.removeSession('userInfo');
            SessionHelper.removeSession('userSessionInfo');
            SessionHelper.removeSession('userSessionInfoSale');
            SessionHelper.removeSession('userSessionInfoRealoadCard');
            SessionHelper.removeSession('userSessionInfoSend');
            SessionHelper.removeSession('pageSessionParam');
            SessionHelper.removeSession('currentUser');
            SessionHelper.removeSession('adm_ctrl');
            window.location.href = this._primaryComp + '/';
        }
        console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
        console.log(this._SharedService.UserControledData);
        console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
        if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
            this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
        }

    }

    ngOnInit() {
        $('body').attr('id', '');
        initDocument();
    }

    ngDoCheck() {
        this._SharedService.LogoSrc.subscribe((src) => {
            this.AgentTheme = src;
        });
        this._SharedService.AgentTheme.subscribe((theme) => {            
            this.AgentTheme = theme.success ? theme.Docs : theme;
        });
        this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
            // console.log(ACCESS_CTRL);
            if (ACCESS_CTRL.success) {
                this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
            }
        });
    }

    logout() {
        SessionHelper.setLocal('LastLoggedIn', Date());
        SessionHelper.removeSession('userInfo');
        SessionHelper.removeSession('userSessionInfo');
        SessionHelper.removeSession('userSessionInfoSale');
        SessionHelper.removeSession('userSessionInfoRealoadCard');
        SessionHelper.removeSession('userSessionInfoSend');
        SessionHelper.removeSession('currentUser');
        SessionHelper.removeSession('adm_ctrl');
        window.location.href = this._primaryComp + '/';
    }

    // getTheme() {
    //     const styles = {
    //         'background': 'url(' + this.AgentTheme.HeaderBackgroundImage + ') center top;',
    //         'background-size': 'cover;'
    //       };
    //       return styles.toString();
    // }

}
