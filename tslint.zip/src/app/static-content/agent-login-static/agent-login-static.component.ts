import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Location } from '@angular/common';
import { NgForm } from '@angular/forms';
import * as sha from 'sha.js';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { Constants } from '../../../app/helpers/constants';
import { SessionHelper } from '../../helpers/session-helper';
import { SessionTemplate } from '../../helpers/session-template';
import { AgentMarginService } from '../../services/agent-margin.service';
import { SharedService } from '../../shared/shared.service';
import { GlobalLoaderService } from './../../services/global-loader.service';

declare var Snackbar: any;
declare var $: any;
declare function initDocument(): any;
@Component({
  selector: 'app-agent-login-static',
  templateUrl: './agent-login-static.component.html',
  styleUrls: ['./agent-login-static.component.css']
})
export class AgentLoginStaticComponent implements OnInit {
  filesToUpload: Array<File> = [];
  public showHeader: any = false;
  public currentDate = new Date();
  public currentMonth: any;
  public Months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  public _primaryComp: any;
  public AgentTheme: any;
  public loginPage: any;
  public loginPageEdit: any;
  public leftPanel: any;
  public rightPanel: any;
  public products: any;
  public backGroungImage: any = 'assets/images/login/agent-login-bg.jpg';
  public productsEdited: any = false;
  public leftContentsEdited: any = false;
  public rightTitleEdited: any = false;
  public leftPanelEdit: any;
  public productsEdit: any;
  public rightPanelEdit: any;
  public loginPageContents: any;
  public currentUserId: any;
  // tslint:disable-next-line:max-line-length
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router, private location: Location, private route: ActivatedRoute, public agentMargin: AgentMarginService, private _SharedService: SharedService, private globalLoaderService: GlobalLoaderService) {
    this._primaryComp = '/' + navUrl.navUrl();
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this.currentMonth = this.Months[this.currentDate.getMonth()];
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserId = JSON.parse(UserInfo).uid;
    } else {
      this.logout();
      window.location.href = '/login';
    }
  }

  ngOnInit() {
    this.setLoginPageContents();
    if (this._SharedService.AgentsTheme) {
      this.AgentTheme = this._SharedService.AgentsTheme.success ? this._SharedService.AgentsTheme.Docs : this._SharedService.AgentsTheme;
      
      if (!this.AgentTheme.loginPage) {
        this.AgentTheme.loginPage = {};
      }
      this.AgentTheme.loginPage = this.mergeObject(this.loginPageContents, this.AgentTheme.loginPage);
      this.loginPage = this.AgentTheme.loginPage;
      if (!this.loginPage.leftPanel) {
        this.loginPage.leftPanel = {};
      }
      this.leftPanel = this.loginPage.leftPanel;
      if (!this.loginPage.rightPanel) {
        this.loginPage.rightPanel = {};
      }
      if (!this.leftPanel.products) {
        this.leftPanel.products = [];
      }
      this.products = this.leftPanel.products;
      this.rightPanel = this.loginPage.rightPanel;
      this.backGroungImage = this.loginPage.backgroundImage;
      this.loginPageEdit = JSON.parse(JSON.stringify(this.loginPage));
      this.leftPanelEdit = JSON.parse(JSON.stringify(this.leftPanel));
      this.productsEdit = JSON.parse(JSON.stringify(this.products));
      this.rightPanelEdit = JSON.parse(JSON.stringify(this.rightPanel));
    }
    initDocument();
  }

  uploadPic(fileInput: any, htmlTagUi: any, type?: any, index?: any) {
    this.globalLoaderService.startLoading();
    this.filesToUpload = <Array<File>>fileInput.target.files;
    const File: any = fileInput;
    const formData = new FormData();
    const docs = File.target.files[0];
    formData.append('agentDocument', docs, docs.name);
    Snackbar.show({
      text: 'Uploading...',
      pos: 'bottom-right',
      actionTextColor: '#00880d',
    });
    this.masterService.uploadAgentDocument(formData)
      .subscribe(files => {
        let result: any = files;
        if (result.documentUrl) {
          switch (type) {
            case 'main':
              this.loginPage.backgroundImage = result.documentUrl;
              this.backGroungImage = this.loginPage.backgroundImage;
              this.saveDocuments();
              break;
            case 'products':
              this.productsEdit[index].imageUrl = result.documentUrl;
              this.saveDocuments();
              break;
          }
        }
        this.globalLoaderService.removeLoading();
      }, err => {
        Snackbar.show({
          text: 'Server issue, Uploading failed.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        this.globalLoaderService.removeLoading();
      });
  }

  ngDoCheck() {
    this._SharedService.AgentTheme.subscribe((theme) => {
      this.AgentTheme = theme.success ? theme.Docs : theme;
      // this.AgentTheme = this.mergeObject(this.loginPageContents, this.AgentTheme);
      if (!this.AgentTheme.loginPage) {
        this.AgentTheme.loginPage = {};
      }
      this.AgentTheme.loginPage = this.mergeObject(this.loginPageContents, this.AgentTheme.loginPage);
      this.loginPage = this.AgentTheme.loginPage;
      if (!this.loginPage.leftPanel) {
        this.loginPage.leftPanel = {};
      }
      this.leftPanel = this.loginPage.leftPanel;
      if (!this.leftPanel.products) {
        this.leftPanel.products = [];
      }
      if (!this.loginPage.rightPanel) {
        this.loginPage.rightPanel = {};
      }
      this.products = this.leftPanel.products;
      this.rightPanel = this.loginPage.rightPanel;
      this.backGroungImage = this.loginPage.backgroundImage;
      this.loginPageEdit = JSON.parse(JSON.stringify(this.loginPage));
      this.leftPanelEdit = JSON.parse(JSON.stringify(this.leftPanel));
      this.productsEdit = JSON.parse(JSON.stringify(this.products));
      this.rightPanelEdit = JSON.parse(JSON.stringify(this.rightPanel));
    });
  }

  saveDocuments() {
    this.AgentTheme.userId = this.currentUserId;
    this.masterService.setAgentLogo(this.AgentTheme).subscribe((data) => {
      const result: any = data;
      Snackbar.show({
        text: 'Data sync completed!',
        pos: 'bottom-right',
        actionTextColor: '#00880d',
      });
    });
  }

  editProductDetails(index) {
    this.productsEdited = true;
  }

  saveProductDetails(saveArr, index) {
    this.leftPanel.title = this.leftPanelEdit.title;
    this.products = this.productsEdit;
    this.productsEdited = false;
    this.saveDocuments();
  }

  cancelProductDetails(index) {
    this.leftPanelEdit.title = this.leftPanel.title;
    this.productsEdit = this.products;
    this.productsEdited = false;
  }

  editLeftContents(index) {
    this.leftContentsEdited = true;
  }

  saveLeftContents(saveArr, index) {
    this.leftPanel.contents = this.leftPanelEdit.contents;
    this.leftContentsEdited = false;
    this.saveDocuments();
  }

  cancelLeftContents(index) {
    this.leftPanelEdit.contents = this.leftPanel.contents;
    this.leftContentsEdited = false;
  }

  editRightTitle(index) {
    this.rightTitleEdited = true;
  }

  saveRightTitle(saveArr, index) {
    this.rightPanel.title = this.rightPanelEdit.title;
    this.rightPanel.subTitle = this.rightPanelEdit.subTitle;
    this.rightTitleEdited = false;
    this.saveDocuments();
  }

  cancelRightTitle(index) {
    this.rightPanelEdit.title = this.rightPanel.title;
    this.rightPanelEdit.subTitle = this.rightPanel.subTitle;
    this.rightTitleEdited = false;
  }

  saveRightExtraContents(saveArr, index) {
    this.rightPanel.extraContents = this.rightPanelEdit.extraContents;
    this.rightTitleEdited = false;
    this.saveDocuments();
  }

  cancelExtraContents(index) {
    this.rightPanelEdit.extraContents = this.rightPanel.extraContents;
    this.rightTitleEdited = false;
  }

  updateSession($event, label) {
    // this.textContents[label] = this.insert_br($event);
  }

  updateSession1(registrationInfo, value, index){
    setTimeout(() => {
      // registrationInfo[index] = this.insert_br(value);
    }, 10);
  }

  /* Detects line breaks in text and inserts <br> tags at line break. */
  insert_br(text) {
    var normalized_Enters = text.replace(/\n/g, '<br>\n');
    return this.fixBR(normalized_Enters);
  }

  fixBR(str) {
    var regex = new RegExp('(<[Bb][Rr]\s*\/?>\s*){2,}', "g");
    return str.replace(regex, "<br>");
  }

  setLoginPageContents() {
    this.loginPageContents = {
      "backgroundImage": "assets/images/login/agent-login-bg.jpg",
      "backgroundColor": "Cox & Kings helps you choose the right forex solutions.<br> When you are on the move, just place the order and visit any of the nearest Cox & Kings location to avail our forex solutions.<br> When you are busy, just place the order and relax. We will get you the required forex solutions at your door step.",
      "leftPanel": {
        "title": "Forex",
        "contents": `<p>Thank you to choose CKFSL as your Foreign exchange solutions provider for your customers. CKFSL is amongst
        the largest retail foreign Exchange company in the retail Foreign exchange industry, helping clients achieve
        their maximum potential by providing professional, effective solutions. CKFSL strategic approach is both
        unique and comprehensive and has been a trend setter within the Industry.</p>
      <p>CKFSL envisage to provide “The Best” online solutions to enable our partners manage Foreign exchange requirement
        of their customers. Our intent is to provide maximum freedom and opportunity for our partners to own this
        product and offer best available solutions through CKFSL. It is basically an amalgamation of our expertise
        to provide cost effective solutions and your information about your customers thereby creating mutual beneficial
        scenario.
      </p>
      <p>We trust this new initiative will provide you the ease of doing business with your customers.</p>
      <br>
      <p>V P Ravindran Menon</p>
      <p>Executive Director</p>`,
        "products": [
          {
            "label": "BUY FOREX"
          },
          {
            "label": "SELL FOREX"
          },
          {
            "label": "SEND MONEY ABROAD"
          }
        ]
      },
      "rightPanel": {
        "title": "Welcome to Cox & Kings - Forex",
        "subTitle": "Agent Member Login"
      },
    };
  }

  mergeObject(overviewContents, agentTheme) {
    var found = [], isNotEmpty;
    for (var property in overviewContents) {
      if (typeof overviewContents[property] == "object") {
        if (!agentTheme[property]) {
          if (overviewContents[property] instanceof Array) {
            agentTheme[property] = [];
          } else {
            agentTheme[property] = {};
          }
        }
        agentTheme[property] = this.mergeObject(overviewContents[property], agentTheme[property]);
      } else {
        if (!agentTheme[property]) {
          agentTheme[property] = overviewContents[property];
        }
      }
    }
    return agentTheme;
  }

  logout() {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
  }
}
