import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { BuyOverviewStaticComponent } from './buy-overview-static/buy-overview-static.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectModule } from 'ng-select';
import { AgentLoginStaticComponent } from './agent-login-static/agent-login-static.component';
const routes: Routes = [
  {
    path: '', children: [
      { path: '', component: BuyOverviewStaticComponent }, 
      { path: 'login-page', component: AgentLoginStaticComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    SelectModule
  ],
  declarations: [BuyOverviewStaticComponent, AgentLoginStaticComponent]
})
export class StaticContentModule { }
