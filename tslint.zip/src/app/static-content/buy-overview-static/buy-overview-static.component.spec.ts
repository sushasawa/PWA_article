import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyOverviewStaticComponent } from './buy-overview-static.component';

describe('BuyOverviewStaticComponent', () => {
  let component: BuyOverviewStaticComponent;
  let fixture: ComponentFixture<BuyOverviewStaticComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyOverviewStaticComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyOverviewStaticComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
