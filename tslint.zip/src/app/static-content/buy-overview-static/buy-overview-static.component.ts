import { Component, OnInit, HostListener } from '@angular/core';
import { MasterService } from '../../../app/services/master.services';
import { SharedService } from './../../shared/shared.service';
import { SessionHelper } from '../../helpers/session-helper';
import { AgentThemeService } from './../../services/agent-theme.service';
import { GlobalLoaderService } from './../../services/global-loader.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function initDocument(): any;
declare var Snackbar: any;

@Component({
    selector: 'app-buy-overview-static',
    templateUrl: './buy-overview-static.component.html',
    styleUrls: ['./buy-overview-static.component.css']
})
export class BuyOverviewStaticComponent implements OnInit {
    filesToUpload: Array<File> = [];
    backGroungImage: any = 'assets/images/forex-bg-img.jpg';
    convenienceEdited: any = false;
    productTitleEdited: any = false;
    textContents: any = {};
    public forexSpecialEdited: any = [];
    public forexProductsEdited: any = [];
    public testimonialsEdited: any = [];
    public overviewPage: any;
    public AgentTheme: any;
    public specialOffers: any = [];
    public specialOffersEdit: any = [];
    public products: any = [];
    public productsEdit: any = [];
    public testimonials: any = [];
    public testimonialsEdit: any = [];
    public currentUserId: any;
    public AgentThemeEdit: any;
    public _primaryComp: any;
    constructor(private masterService: MasterService, private navUrl: NavigatePathService, public _SharedService: SharedService, public defaultJSONService: AgentThemeService, private globalLoaderService: GlobalLoaderService) {
        const UserInfo: any = SessionHelper.getSession('userInfo');
        this._primaryComp = '/' + navUrl.navUrl();
        if (UserInfo != null || UserInfo !== undefined) {
            this.currentUserId = JSON.parse(UserInfo).uid;
        } else {
            this.logout();
            window.location.href = '/login';
        }
    }

    @HostListener("click", ["$event"])
    public onClick(event: any): void {
        let classList: any = event.target.classList;
        if (event.target.classList.contains('product-bubbling')) {
            event.stopPropagation();
        }
    }

    ngOnInit() {
        this.textContents.convenienceTitle = "Buying forex have never become easier!";
        this.textContents.convenienceContents = "Cox & Kings helps you choose the right forex solutions.<br> When you are on the move, just place the order and visit any of the nearest Cox & Kings location to avail our forex solutions.<br> When you are busy, just place the order and relax. We will get you the required forex solutions at your door step.";
        if (this._SharedService.AgentsTheme) {
            this.AgentTheme = this._SharedService.AgentsTheme.success ? this._SharedService.AgentsTheme.Docs : this._SharedService.AgentsTheme;
            if (!this.AgentTheme.overviewPage) {
                this.AgentTheme.overviewPage = {};
            }
            this.overviewPage = this.AgentTheme.overviewPage;
            if (!this.overviewPage.specialOffers) {
                this.overviewPage.specialOffers = [];
            }
            if (!this.overviewPage.products) {
                this.overviewPage.products = [];
            }
            if (!this.overviewPage.testimonials) {
                this.overviewPage.testimonials = [];
            }
            this.specialOffers = this.overviewPage.specialOffers;
            this.specialOffersEdit = JSON.parse(JSON.stringify(this.overviewPage.specialOffers));
            this.products = this.overviewPage.products;
            this.productsEdit = JSON.parse(JSON.stringify(this.overviewPage.products));
            this.testimonials = this.overviewPage.testimonials;
            this.testimonialsEdit = JSON.parse(JSON.stringify(this.overviewPage.testimonials));
            this.applyTheme();
        }
        initDocument();
    }

    setEmptyObj() {
        delete this.AgentTheme.specialOffers;
        this.saveDocuments();
    }

    uploadPic(fileInput: any, htmlTagUi: any, type?: any, index?: any) {
        // console.log(fileInput);
        this.globalLoaderService.startLoading();
        this.filesToUpload = <Array<File>>fileInput.target.files;
        const File: any = fileInput;
        const formData = new FormData();
        const docs = File.target.files[0];
        formData.append('agentDocument', docs, docs.name);
        Snackbar.show({
            text: 'Uploading...',
            pos: 'bottom-right',
            actionTextColor: '#00880d',
        });
        this.masterService.uploadAgentDocument(formData)
            .subscribe(files => {
                let result: any = files;
                if (result.documentUrl) {
                    switch (type) {
                        case 'main':
                            this.overviewPage.mainScreenBackGround = result.documentUrl;
                            this.backGroungImage = this.overviewPage.mainScreenBackGround;
                            this.saveDocuments();
                            break;
                        case 'ForexSpecial':
                            this.setSpecialOffers(result.documentUrl, index);
                            break;
                        case 'products':
                            this.productsOffers(result.documentUrl, index);
                            break;
                    }
                }
                this.globalLoaderService.removeLoading();
            }, err => {
                Snackbar.show({
                    text: 'Server issue, Uploading failed.',
                    pos: 'bottom-right',
                    actionTextColor: '#ff4444',
                });
                this.globalLoaderService.removeLoading();
            });
    }

    productsOffers(documentUrl, index) {
        if (!this.products[index]) {
            this.products[index] = {};
        }
        this.products[index].imageUrl = documentUrl;
        this.saveDocuments();
    }

    setSpecialOffers(documentUrl, index) {
        if (!this.specialOffers[index]) {
            this.specialOffers[index] = {};
        }
        this.specialOffers[index].imageUrl = documentUrl;
        this.saveDocuments();
    }

    saveDocuments() {
        this.AgentTheme.userId = this.currentUserId;
        this.masterService.setAgentLogo(this.AgentTheme).subscribe((data) => {
            const result: any = data;
            Snackbar.show({
                text: 'Data sync completed!',
                pos: 'bottom-right',
                actionTextColor: '#00880d',
            });
        });
    }

    ngDoCheck() {
        this._SharedService.AgentTheme.subscribe((theme) => {
            // console.log(theme);
            this.AgentTheme = theme.success ? theme.Docs : theme;
            if (!this.AgentTheme.overviewPage) {
                this.AgentTheme.overviewPage = {};
            }
            this.overviewPage = this.AgentTheme.overviewPage;
            if (!this.overviewPage.specialOffers) {
                this.overviewPage.specialOffers = [];
            }
            if (!this.overviewPage.products) {
                this.overviewPage.products = [];
            }
            if (!this.overviewPage.testimonials) {
                this.overviewPage.testimonials = [];
            }
            this.specialOffers = this.overviewPage.specialOffers;
            this.specialOffersEdit = JSON.parse(JSON.stringify(this.overviewPage.specialOffers));
            this.products = this.overviewPage.products;
            this.productsEdit = JSON.parse(JSON.stringify(this.overviewPage.products));
            this.testimonials = this.overviewPage.testimonials;
            this.testimonialsEdit = JSON.parse(JSON.stringify(this.overviewPage.testimonials));
            this.applyTheme();
        });
    }

    applyTheme() {
        this.defaultJSONService.setDefaultValues(this.overviewPage);
        this.textContents.convenienceTitle = this.overviewPage.convenienceTitle;
        this.textContents.convenienceContents = this.overviewPage.convenienceContents;
        this.textContents.productTitle = this.overviewPage.productTitle;
        this.backGroungImage = this.overviewPage.mainScreenBackGround;
    }

    editConvenience() {
        this.convenienceEdited = true;
    }

    editProductTitle() {
        this.productTitleEdited = true;
    }

    editForexSpecial(index) {
        if (!this.specialOffersEdit[index]) {
            this.specialOffersEdit[index] = {};
        }
        if (!this.specialOffers[index]) {
            this.specialOffers[index] = {};
        }
        this.forexSpecialEdited[index] = true;
    }

    editProducts(index) {
        if (!this.productsEdit[index]) {
            this.productsEdit[index] = {};
        }
        if (!this.products[index]) {
            this.products[index] = {};
        }
        this.forexProductsEdited[index] = true;
    }

    editTestimonials(index) {
        if (!this.testimonialsEdit[index]) {
            this.testimonialsEdit[index] = {};
        }
        if (!this.testimonials[index]) {
            this.testimonials[index] = {};
        }
        this.testimonialsEdited[index] = true;
    }

    saveProductTitle(saveArr) {
        this.productTitleEdited = false;
        this.overviewPage.productTitle = this.textContents.productTitle;
        this.saveDocuments();
    }

    saveConvenience(saveArr) {
        this.convenienceEdited = false;
        for (let loopVar = 0; loopVar < saveArr.length; loopVar++) {
            this.overviewPage[saveArr[loopVar]] = this.textContents[saveArr[loopVar]];
        }
        this.saveDocuments();
    }

    saveForexSpecial(saveArr, index) {
        this.specialOffers[index] = this.specialOffersEdit[index];
        this.forexSpecialEdited[index] = false;
        this.saveDocuments();
    }

    saveProducts(saveArr, index) {
        this.products[index] = this.productsEdit[index];
        this.forexProductsEdited[index] = false;
        this.saveDocuments();
    }

    saveTestimonials(saveArr, index) {
        this.testimonials[index] = this.testimonialsEdit[index];
        this.testimonialsEdited[index] = false;
        this.saveDocuments();
    }

    cancelProductTitle() {
        this.productTitleEdited = false;
        this.textContents.productTitle = this.overviewPage.productTitle;
    }

    cancelConvenience() {
        this.convenienceEdited = false;
    }

    cancelForexSpecial(index) {
        this.specialOffersEdit[index] = this.specialOffers[index];
        this.forexSpecialEdited[index] = false;
    }

    cancelProducts(index) {
        this.productsEdit[index] = this.products[index];
        this.forexProductsEdited[index] = false;
    }

    cancelTestimonials(index) {
        this.testimonialsEdit[index] = this.testimonials[index];
        this.testimonialsEdited[index] = false;
    }

    updateSession($event, label) {
        this.textContents[label] = this.insert_br($event);
    }

    /* Detects line breaks in text and inserts <br> tags at line break. */
    insert_br(text) {
        var normalized_Enters = text.replace(/\n/g, '<br>\n');
        return this.fixBR(normalized_Enters);
    }

    fixBR(str) {
        var regex = new RegExp('(<[Bb][Rr]\s*\/?>\s*){2,}', "g");
        return str.replace(regex, "<br>");
    }

    logout() {
        SessionHelper.removeSession('userInfo');
        SessionHelper.removeSession('userSessionInfo');
        SessionHelper.removeSession('userSessionInfoSale');
        SessionHelper.removeSession('userSessionInfoRealoadCard');
        SessionHelper.removeSession('userSessionInfoSend');
        SessionHelper.removeSession('pageSessionParam');
        SessionHelper.removeSession('currentUser');
        SessionHelper.removeSession('adm_ctrl');
    }
}
