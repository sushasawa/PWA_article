import { Component, OnInit } from '@angular/core';
import { NavigationCancel, Event, NavigationEnd, NavigationError, NavigationStart, Router, RoutesRecognized } from '@angular/router';
import { Location, PopStateEvent } from '@angular/common';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { AgentMarginService } from './services/agent-margin.service';
import { SessionHelper } from './helpers/session-helper';
import { SharedService } from './shared/shared.service';
import { GlobalLoaderService } from './services/global-loader.service';
import { NavigatePathService } from '../app/services/navigate-path.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';

  private lastPoppedUrl: string;
  private yScrollStack: number[] = [];
  public currentRoute: any;
  public counter: any = 0;
  public currentRouteLogin: any;
  public loading: any = false;
  public wrongURL: any = true;
  // tslint:disable-next-line:max-line-length
  constructor(private _loadingBar: SlimLoadingBarService, private navUrl: NavigatePathService, private router: Router, private location: Location, public agentMargin: AgentMarginService, private _SharedService: SharedService, private globalLoaderService: GlobalLoaderService) { }

  ngOnInit() {
    this.location.subscribe((ev: PopStateEvent) => {
      this.lastPoppedUrl = ev.url;
    });
    this.router.events.subscribe((event: Event) => {
      this.navigationInterceptor(event);
    });
    this.globalLoaderService.subject.subscribe((event: any) => {
      setTimeout(() => {
        this.loading = false;
      }, 300);
    });
    this.globalLoaderService.startLoadingSubject.subscribe((event: any) => {
      setTimeout(() => {
        this.loading = true;
      }, 300);
    });
    this.getUserAccess();
    this.agentMargin.setAgentMargin();
  }

  /**
	* This is used to intercept and show Loading bar based on the current state of our
	* Router navigation
	* @param {Event} event
	*/
  private navigationInterceptor(event: Event): void {
    if(event instanceof RoutesRecognized) {
      this.checkURL(event.urlAfterRedirects);
    }
    if (event instanceof NavigationStart) {  
      this.loading = true;
      setTimeout(() => {
        if(this.globalLoaderService.isLoading === false)
        this.loading = false;
      }, 10000);  
      this._loadingBar.start();
      if (event.url !== this.lastPoppedUrl) {
        this.yScrollStack.push(window.scrollY);
      }
    }
    if (event instanceof NavigationEnd) {
      setTimeout(() => {
        if(this.globalLoaderService.isLoading === false)
        this.loading = false;
      }, 0);      
      this._loadingBar.complete();
      this.currentRoute = this.router.url;
      console.log('this.currentRoute',this.currentRoute);
      //this.currentRouteLogin = this.currentRoute.slice(-6);
      this.currentRouteLogin = this.currentRoute.toLowerCase().split('/').indexOf('login');
      if(this.currentRouteLogin == -1){
        this.currentRouteLogin = this.currentRoute.toLowerCase().split('/').indexOf('login-page');
      }
      //console.log('this.currentRoute.split("/")',this.currentRoute.split('/').indexOf('login'))
      //this.currentRouteLogin =  this.currentRoute.split('/').indexOf('/Login');
      console.log('this.currentRoute',this.currentRoute, this.currentRouteLogin);
      // console.log("Show Header",this.showHeader);
      if (event.url === this.lastPoppedUrl) {
        this.lastPoppedUrl = undefined;
        window.scrollTo(0, this.yScrollStack.pop());
      } else {
        window.scrollTo(0, 0);
      }
    }

    // Set loading state to false in both of the below events to hide the loader in case a request fails
    if (event instanceof NavigationCancel) {
      this._loadingBar.stop();
      setTimeout(() => {
        this.loading = false;
      }, 0);
    }
    if (event instanceof NavigationError) {
      this._loadingBar.stop();
      setTimeout(() => {
        this.loading = false;
      }, 0);
    }
  }

  checkURL(url) {
    let urlArr = url.split('/'), navPath = this.navUrl.navUrl();
    if (!navPath) {
      this.wrongURL = true;
      this.navUrl.getAgentId(urlArr[1], () => {        
        this.wrongURL = false;
      });
      return;
    } else if (navPath !== urlArr[1]) {
      urlArr[1] = navPath;
      this.router.navigateByUrl(urlArr.join('/'));
    }
    this.wrongURL = true;
    this.navUrl.getAgentId(urlArr[1], () => {      
      this.wrongURL = false;
    });
  }


  getUserAccess() {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    const role: any = SessionHelper.getSession('adm_ctrl');
    if (UserInfo && role) {
      this._SharedService.getSubAgents({'id' : JSON.parse(UserInfo).uid});
      const payload: any = {
        'agentid': JSON.parse(UserInfo).uid,
        'role': role
      };
      switch (role) {
        case 'ADMIN_2':
        case 'AGENT_3':
          this._SharedService.getUserAccessCtrl(payload);
          break;
      }
    }
  }
}
