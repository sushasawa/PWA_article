import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';
import { AnonymousSubscription } from 'rxjs/Subscription';
@Pipe({
    name: 'commissionDetailsFilter'
})
export class CommissionDetailsFilterPipe implements PipeTransform {
    transform(items: any[], searchText: any, fromDate: any, toDate: any): any[] {
        // console.log(items, fromDate, toDate);
        if (!items) return [];
        if (!searchText) searchText = '';
        searchText = searchText.toLowerCase();
        return items
            .filter(item => {
                let flags = [], searchFlag = [];
                item.TxnDate = moment(item.TxnDate).format('YYYY-MM-DD');
                const searchParams = ['PartyName', 'PaxName', 'TranType', 'TxnNo', 'OrdeID', 'Currency', 'Amount', 'Rate', 'CommAmount', 'NetAmount'];
                if (fromDate && toDate) {
                    if (moment(item.TxnDate).isSameOrAfter(moment(fromDate, 'DD-MM-YYYY').format('YYYY-MM-DD')) && moment(item.TxnDate).isSameOrBefore(moment(toDate, 'DD-MM-YYYY').format('YYYY-MM-DD'))) {
                        flags.push(true);
                    } else {
                        flags.push(false);
                    }
                }
                if (fromDate && !toDate) {
                    if (moment(item.TxnDate).isSameOrAfter(moment(fromDate, 'DD-MM-YYYY').format('YYYY-MM-DD'))) {
                        flags.push(true);
                    } else {
                        flags.push(false);
                    }
                }
                if (!fromDate && toDate) {
                    if (moment(item.TxnDate).isSameOrBefore(moment(toDate, 'DD-MM-YYYY').format('YYYY-MM-DD'))) {
                        flags.push(true);
                    } else {
                        flags.push(false);
                    }
                }

                for (let it in item) {
                    if (searchParams.indexOf(it) !== -1) {
                        if (item[it].toString().toLowerCase().includes(searchText)) {
                            searchFlag.push(true);
                        }
                    }
                }
                if (searchFlag.indexOf(true) !== -1) {
                    flags.push(true);
                } else if (searchFlag.indexOf(false) === -1) {
                    flags.push(false);
                }
                if (flags.indexOf(false) === -1) {
                    return true;
                }

                return false;
            });
    }
}