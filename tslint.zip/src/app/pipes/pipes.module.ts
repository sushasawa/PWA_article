import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NumberLocalePipe } from './number-locale.pipe';
import { SplitPipe } from './split.pipe';
import { LeadsFilterPipe } from './leads-filter.pipe';
import { OrderFilterPipe } from './order-filter.pipe';
import { StatusFilterPipe } from './status-filter.pipe';
import { OrderDateFilterPipe } from './order-date-filter.pipe';
import { AllOrderFilterPipe } from './all-order-filter.pipe';
import { LimitToPipe } from './limit-to.pipe';
import { CommissionDetailsFilterPipe } from './commission-details-filter.pipe';
@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [NumberLocalePipe, SplitPipe, CommissionDetailsFilterPipe, LeadsFilterPipe, OrderFilterPipe, StatusFilterPipe, OrderDateFilterPipe, AllOrderFilterPipe, LimitToPipe],
  exports: [NumberLocalePipe, SplitPipe, CommissionDetailsFilterPipe, LeadsFilterPipe, OrderFilterPipe , StatusFilterPipe , OrderDateFilterPipe , AllOrderFilterPipe, LimitToPipe]
})
export class PipesModule { }
