import { AllOrderFilterPipe } from './all-order-filter.pipe';

describe('AllOrderFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new AllOrderFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
