import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';
import { AnonymousSubscription } from 'rxjs/Subscription';
@Pipe({
  name: 'leadFilter'
})
export class LeadsFilterPipe implements PipeTransform {
    transform(items: any[], searchText: any, fromDate: any, toDate: any): any[] {
        // console.log(items, fromDate, toDate);
        if (!items) return [];
        if (!searchText) searchText = '';
        searchText = searchText.toLowerCase();
        return items
            .filter(it => {
                if (searchText && it.CreatedBy.toLowerCase().includes(searchText) && fromDate && toDate && moment(it.CreatedDate).isSameOrAfter(moment(fromDate, 'DD-MM-YYYY').format('YYYY-MM-DD')) && moment(it.CreatedDate).isSameOrBefore(moment(toDate, 'DD-MM-YYYY').format('YYYY-MM-DD'))) {
                    
                    return true;
                }
                if (!searchText && fromDate && toDate && moment(it.CreatedDate).isSameOrAfter(moment(fromDate, 'DD-MM-YYYY').format('YYYY-MM-DD')) && moment(it.CreatedDate).isSameOrBefore(moment(toDate, 'DD-MM-YYYY').format('YYYY-MM-DD'))) {
                    
                    return true;
                }
                if (searchText && it.CreatedBy.toLowerCase().includes(searchText) && !fromDate && !toDate) {
                    
                    return true;
                }
                if (searchText && it.CreatedBy.toLowerCase().includes(searchText) && fromDate && !toDate && moment(it.CreatedDate).isSameOrAfter(moment(fromDate, 'DD-MM-YYYY').format('YYYY-MM-DD'))) {
                    
                    return true;
                }
                if (searchText && it.CreatedBy.toLowerCase().includes(searchText) && !fromDate && toDate && moment(it.CreatedDate).isSameOrBefore(moment(toDate, 'DD-MM-YYYY').format('YYYY-MM-DD'))) {
                    
                    return true;
                }
                if (!searchText && fromDate && !toDate && moment(it.CreatedDate).isSameOrAfter(moment(fromDate, 'DD-MM-YYYY').format('YYYY-MM-DD'))) {
                    
                    return true;
                }
                if (!searchText && !fromDate && toDate && moment(it.CreatedDate).isSameOrBefore(moment(toDate, 'DD-MM-YYYY').format('YYYY-MM-DD'))) {
                    
                    return true;
                }
                if(!searchText && !fromDate && !toDate){
                    return true;
                }
                return false;
            });
    }
}