import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'numberLocale'
})
export class NumberLocalePipe implements PipeTransform {

    transform(value: any, desimals: any = undefined, currencyCode: any = undefined): any {

        if (!value) {
            return;
        }
        const userLang = 'en-IN';
        if(desimals && currencyCode.toLowerCase() == 'jpy'){
            return new Intl.NumberFormat(userLang, {minimumFractionDigits: desimals, maximumFractionDigits: desimals}).format(value);
        } else {
            return new Intl.NumberFormat(userLang, {minimumFractionDigits: 2, maximumFractionDigits: 2}).format(value);
        }

    }

}
