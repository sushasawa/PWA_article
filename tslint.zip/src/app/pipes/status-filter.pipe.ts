import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'statusFilter'
})
export class StatusFilterPipe implements PipeTransform {


  transform(Orders: any, status: any): any {
    if (status) {
      return Orders.filter((Order) => JSON.parse(Order.OrderStatus) === JSON.parse(status));
    } else {
      return Orders;
    }
  }

}
