import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendmoneyOveriewComponent } from './sendmoney-overiew.component';

describe('SendmoneyOveriewComponent', () => {
  let component: SendmoneyOveriewComponent;
  let fixture: ComponentFixture<SendmoneyOveriewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendmoneyOveriewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendmoneyOveriewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
