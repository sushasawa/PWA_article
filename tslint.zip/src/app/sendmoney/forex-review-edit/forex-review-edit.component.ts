import { Component, OnInit } from '@angular/core';
import { GenericEntity } from '../../../app/helpers/generic';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { Constants } from '../../../app/helpers/constants';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { DpDatePickerModule } from 'ng2-date-picker';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import * as moment from 'moment';
declare function initDocument(): any;
declare function initForms(): any;
declare var $: any;
declare var Snackbar: any;
declare function swal(headerMessage, message, type): any;

@Component({
  selector: 'app-forex-review-edit',
  templateUrl: './forex-review-edit.component.html',
  styleUrls: ['./forex-review-edit.component.css']
})
export class ForexReviewEditComponent implements OnInit {
  public userSessionInfo: any;
  public userSessionInfoRegistration: any;
  public userSessionInfoTravellingDetails: any;
  public userSessionInfoTravellers: any;
  public userSessionInfoSelectedTraveller: any;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public gst: any = 0;
  public discount: any = 0;
  public currencyList: any;
  public mutitravellerTotalAmount: any;
  public correspondenceCharges: any = 0;
  public currencyLists: any = [];
  public currencyDetail: any;
  public userName: any;
  public HOME_STATNDARD_AMOUNT: any;
  public HOME_EXPRESS_AMOUNT: any;
  public OFFICE_STATNDARD_AMOUNT: any;
  public OFFICE_EXPRESS_AMOUNT: any;
  public config: any;
  public Bank_Correspondent_Bank_Charges: any = 0;
  public TT_Charges: any = 0;
  public todaysDate: any;
  public timeconfig: any;
  public airlineNames: any;
  public isPickUpMode: any;
  public travellingDate: any;
  public _primaryComp: any;
  public correspondentCharges: any;
  constructor(private masterService: MasterService, private navUrl: NavigatePathService, private router: Router) {
    // console.log(JSON.parse(SessionHelper.getSession('userSessionInfoSend')));
    this.userSessionInfo = JSON.parse(SessionHelper.getSession('userSessionInfoSend'));
    this.userSessionInfoRegistration = this.userSessionInfo.sendMoneyScreen.traveller[0].registrationInfo;
    this.userSessionInfoTravellingDetails = this.userSessionInfo.sendMoneyScreen.traveller[0].travellingDetails;

    this.userSessionInfoTravellers = this.userSessionInfo.sendMoneyScreen.traveller;
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.sendMoneyScreen.traveller[0];
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[0];
    this.masterService.getCurrencyList(1).subscribe((data) => {
      this.currencyLists = data;
    });

    this.getCharges();
    // this.syncSession();
    // this.updateUsedAmount();
    this.correspondentCharges = this.userSessionInfo.sendMoneyScreen.bankChargesAdded;
    this.userSessionInfo.sendMoneyScreen.traveller.forEach(element => {

      if (element.lead) {
        // tslint:disable-next-line:max-line-length
        this.userName = element.registrationInfo.firstName.value + ' ' + element.registrationInfo.middleName + ' ' + element.registrationInfo.lastName;

      }
    });

    this.todaysDate = this.masterService.getTodaysDate();
    this.config = {
      format: 'DD-MM-YYYY',
      showMultipleYearsNavigation: true,
      disableKeypress: true,
      min: this.todaysDate,
      max: this.masterService.addDateMoment(this.todaysDate, 10, 'days')
    };
    this.timeconfig = {
      showMultipleYearsNavigation: true,
      min: this.getMinTime(),
      max: '18:30',
      disableKeypress: true,
      format: 'HH:mm'
    };

    this.masterService.getDeliveryAmt(this.userSessionInfo.mode).subscribe((data) => {
      console.log(data);
      const deliveryData: any = data;
      deliveryData.map((delivery) => {
        if (delivery.DeliveryType === 'HomeVisit') {
          this.HOME_STATNDARD_AMOUNT = delivery.StandardDelivery;
          this.HOME_EXPRESS_AMOUNT = delivery.ExpressDelivery;
        }

        if (delivery.DeliveryType === 'OfficeVisit') {
          this.OFFICE_STATNDARD_AMOUNT = delivery.StandardDelivery;
          this.OFFICE_EXPRESS_AMOUNT = delivery.ExpressDelivery;
        }
      });
    });

    const destination = this.userSessionInfo.sendMoneyScreen.destination.split('#')[0];
    this.masterService.getCurrencyList(1, destination)
      .subscribe(data => {
        this.currencyList = data;
      });
      this.userSessionInfoTravellers.forEach(traveller => {
        traveller.selected = false;
      });
      this.userSessionInfoTravellers[0].selected = true;
      this.airlineNames = [
        { Id: 1, Airline: 'Air India', label: 'Air India', value: '1#Air India' },
        { Id: 2, Airline: 'SpiceJet', label: 'SpiceJet', value: '2#SpiceJet' },
        { Id: 3, Airline: 'Jet Airways', label: 'Jet Airways', value: '3#Jet Airways' },
        { Id: 4, Airline: 'IndiGo', label: 'IndiGo', value: '4#IndiGo' }
      ];
      this._primaryComp = '/' + navUrl.navUrl();
  }

  ngOnInit() {
    initDocument();
    // initForms();
    if (this.userSessionInfo.sendMoneyScreen.deliveryInfo.Mode === 'Pick Up') {
      this.isPickUpMode = true;
    }
    $('body').attr('id', '');
  }

  getCharges() {
    this.masterService.getCharges().subscribe((data) => {
      const Charges: any = data;
      this.serviceCharge = Charges.response.serviceCharge;
      this.Bank_Correspondent_Bank_Charges = this.correspondentCharges ? this.userSessionInfo.ddRateBuy * this.masterService.getBankCorrespondentCharges() : 0;
      // this.Bank_Correspondent_Bank_Charges = Charges.response.Bank_Correspondent_Bank_Charges;
      this.TT_Charges = Charges.response.TT_Charges;
      this.syncSession();
      this.updateUsedAmount();
      
    }, (error) => {
      Snackbar.show({
        text: 'Error fetching Charges',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    });
  }

  addBankCharges($event) {
    if ($event === true) {
      this.Bank_Correspondent_Bank_Charges = this.userSessionInfo.ddRateBuy * this.masterService.getBankCorrespondentCharges();
      this.userSessionInfo.sendMoneyScreen.bankChargesAdded = true;
    } else if ($event === false) {
      this.Bank_Correspondent_Bank_Charges = 0;
      this.userSessionInfo.sendMoneyScreen.bankChargesAdded = false;
    }
    this.syncSession();
  }

  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfoTravellers[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
    // console.log(this.userSessionInfoTravellers[travellerIndex]);
  }


  updateReview(editReview: NgForm, e: Event) {
    e.preventDefault();
    //  console.log(this.userSessionInfo);
    if (this.validateSession()) {
      this.masterService.RuleTest(this.userSessionInfo)
        .subscribe(data => {
          const resData: any = JSON.parse(data);
          if (resData.status === 1) {
            SessionHelper.setSession('userSessionInfoSend', JSON.stringify(this.userSessionInfo));
            Snackbar.show({
              text: 'Updated .',
              pos: 'bottom-right',
              actionTextColor: '#05ff01',
            });
            this.router.navigateByUrl(this.navUrl.navUrl() + '/send-money/forex-review');
          } else {
            // swal('error', resData.message, 'error');
            Snackbar.show({
              text: resData.message,
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
            });
          }
        });
    }
  }

  deliveryModes(mode: String) {
    if (this.isPickUpMode === true && mode !== 'Pick Up') {
      this.userSessionInfo.sendMoneyScreen.deliveryInfo.DeliverySchedule.time = '';
    }
    console.log(mode);
    if (mode === 'Pick Up') {
      this.isPickUpMode = true;
      this.deliveryTypeAndRate('', 0);
    }else {
      this.isPickUpMode = false;
      this.deliveryTypeAndRate('Standard', this.HOME_STATNDARD_AMOUNT);
    }
    this.userSessionInfo.sendMoneyScreen.deliveryInfo.Mode = mode;
    console.log(this.userSessionInfo.sendMoneyScreen.deliveryInfo);
  }

  deliveryTypeAndRate(type: String, rate: any) {
    console.log('TYPE :::' + type, 'RATE :::' + rate);
    this.userSessionInfo.sendMoneyScreen.deliveryInfo.type = type;
    this.userSessionInfo.sendMoneyScreen.deliveryInfo.rate = rate;
    console.log(this.userSessionInfo.sendMoneyScreen.deliveryInfo);
    this.syncSession();
    this.updateUsedAmount();
  }

  deliveryDate(event: any) {
    console.log('Delivery Date' + event);
    let additionHours = 3, saturdayCheck: any;
    if (event !== undefined && typeof event !== 'object') {
      if (!this.verifyDateTime(event)) {
        this.updateDateTime();
        return;
      }
      let hourMin = '', hourMax = '';
      if (event === this.todaysDate) {
        if (!this.isPickUpMode) {
          const time = moment().add(additionHours, 'hours');
          if (Number(time.format('HH')) < 10) {
            hourMin = '10:00';
          } else {
            hourMin = time.format('HH') + ':' + time.format('mm');
          }
        }
      } else {
        hourMin = '10:00';
      }
      this.userSessionInfo.sendMoneyScreen.deliveryInfo.DeliverySchedule.time = hourMin;
      saturdayCheck = this.checkForSaturday(event);
      if (saturdayCheck.flag) {
        hourMax = '16:00';
      } else {
        hourMax = '18:30';
      }
      this.timeconfig = {
        format: 'HH:mm',
        min: hourMin,
        max: hourMax
      };
      this.userSessionInfo.sendMoneyScreen.deliveryInfo.DeliverySchedule.date = event;
    }
  }

  verifyDateTime(dateValue) {
    let maxDayTime = 15, maxMins = 30, displayTime = '3:30';
    // tslint:disable-next-line:prefer-const
    let timeHour: any = this.masterService.getCurrentTime(), diff;
    const saturdayCheck: any = this.checkForSaturday(dateValue);
    if (this.isPickUpMode) {
      maxDayTime = 18; maxMins = 30; displayTime = '6:30';
    }
    if (saturdayCheck.flag) {
      maxDayTime = saturdayCheck.hrs;
      maxMins = saturdayCheck.mins;
      displayTime = saturdayCheck.text;
    }
    if (this.travellingDate) {
      diff = this.masterService.getDateDifference(this.travellingDate, dateValue);
      if (diff <= 0) {
        this.showAlert('Delivery date should be at least 1 day before travelling date.');
        return false;
      }
    }
    if (this.isPickUpMode && dateValue === this.todaysDate && +timeHour.hour >= maxDayTime && +timeHour.mins >= maxMins) {
      this.showAlert('Same day pickup available before ' + displayTime + ' PM. Please select next working day.');
      return false;
    } else
    if (!this.isPickUpMode && dateValue === this.todaysDate && +timeHour.hour >= maxDayTime && +timeHour.mins >= maxMins) {
      this.showAlert('Same day delivery available if you book an order before ' + displayTime + ' PM. Please select next working day.');
      return false;
    }
    // if (dateValue !== this.todaysDate) {
    if (this.isNotWrokingDay(dateValue, true) || this.isNextTwoWorkingDays(dateValue)) {
      // this.showAlert('Delivery date should be with in next 2 working days from today.')
      return false;
    }
    // }
    return true;
  }

  checkForSaturday(dateValue) {
    const daySelected = moment(dateValue, 'DD-MM-YYYY').format('ddd');
    if (daySelected === 'Sat') {
      if (this.isPickUpMode) {
        return { flag: true, hrs: 16, mins: 0, text: '4:00' };
      }
      return { flag: true, hrs: 13, mins: 0, text: '1:00' };
    }
    return { flag: false };
  }

  showAlert(message){
    Snackbar.show({
      text: message,
      pos: 'bottom-right',
      actionTextColor: '#ff4444',
      duration: 3000
    });
  }

  updateDateTime() {
    this.userSessionInfo.sendMoneyScreen.deliveryInfo.DeliverySchedule.date = '';
    this.userSessionInfo.sendMoneyScreen.deliveryInfo.DeliverySchedule.time = '';
  }

  isNextTwoWorkingDays(dateValue) {
    let nextDay = this.todaysDate, counter = 0;
    while (nextDay !== dateValue) {
      nextDay = this.masterService.addDateMoment(nextDay, 1, 'days');
      if (!this.isNotWrokingDay(nextDay, false)) {
        counter++;
        if (counter > 2){
          this.showAlert('Delivery date should be within next 2 working days from today.');
          return true;
        }
      }
    }
    return false;
  }

  isNotWrokingDay(dateValue, flag){
    // tslint:disable-next-line:prefer-const
    const daySelected = moment(dateValue, 'DD-MM-YYYY').format('ddd'),
    weekEndDays = ['Sun'],
    holyDaysList = ['15-02-2018', '22-02-2018', '20-02-2018'];
    if (weekEndDays.indexOf(daySelected) !== -1 || holyDaysList.indexOf(dateValue) !== -1) {
      if (flag) {
        switch (daySelected) {
          case 'Sat':
            this.showAlert('Deliveries not possible on Saturdays.');
            break;
          case 'Sun':
            this.showAlert('Deliveries not possible on Sundays.');
            break;
          default:
            this.showAlert(dateValue + ' is non-working day, please select another working day.');
        }
      }
      return true;
    }
    return false;
  }


  travellingStartDate(event, TravellerIndex) {
    console.log(event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfoTravellers[TravellerIndex].travellingDetails.dateOfTravel = event;
    }
  }

  travellingArrivaltDate(event, TravellerIndex) {
    console.log(event);
    if (event !== undefined && typeof event !== 'object') {
      this.userSessionInfoTravellers[TravellerIndex].travellingDetails.dateOfArrival = event;
    }
  }
  deliveryTime(event: any) {
    if (event !== undefined && typeof event !== 'object') { console.log('updated');
       this.userSessionInfo.sendMoneyScreen.deliveryInfo.DeliverySchedule.time = event;
    }
  }

  updateCurrencyCode(TravellerIndex: any, prepaidDetailIndex: number, newValue: string) {
    this.userSessionInfo.sendMoneyScreen.traveller[TravellerIndex]
      .prepaidCardDetails[prepaidDetailIndex].currencyCode = newValue;
    this.masterService.getExchangeRate(newValue, this.userSessionInfo.sendMoneyScreen.branch, 'prepaid', 'buy')
      .subscribe(data => {
        this.userSessionInfo.sendMoneyScreen.traveller[TravellerIndex]
          .prepaidCardDetails[prepaidDetailIndex].exchangeRate = data;
        this.syncSession();
        this.updateUsedAmount();
      });
  }


  syncSession() {
    let totalAmount: any = 0;
    this.mutitravellerTotalAmount = 0;
    this.userSessionInfoTravellers.forEach(traveller => {
     if (traveller.prepaidCard) {
        traveller.prepaidCardDetails.map((prepaidCard) => {
          // console.log(prepaidCard);
          totalAmount += (prepaidCard.forexAmount * prepaidCard.exchangeRate.rate) - this.discount + this.correspondenceCharges;
        });
      }

      const TotalTaxableAmount = totalAmount
        + parseInt(this.userSessionInfo.sendMoneyScreen.deliveryInfo.rate) + this.Bank_Correspondent_Bank_Charges + this.TT_Charges + this.serviceCharge;
      traveller.totalAmount =
        totalAmount
        + parseInt(this.userSessionInfo.sendMoneyScreen.deliveryInfo.rate) + this.Bank_Correspondent_Bank_Charges + this.TT_Charges + this.serviceCharge;

      this.masterService.getTaxes(TotalTaxableAmount).subscribe((data) => {
        const result: any = data;
        traveller.totalAmount += result.TotalTax;
        traveller.gst = result.TotalTax;
        this.mutitravellerTotalAmount += Number.parseInt(traveller.totalAmount);
      });
      totalAmount = 0;

    });
    // console.log(this.mutitravellerTotalAmount);
  }
  updateUsedAmount() {
    let travellerTotal = 0;
    this.userSessionInfo.sendMoneyScreen.traveller.forEach(traveller => {
        let currentTravellerTotal = 0;
        traveller.prepaidCardDetails.forEach(element => {
            if (!(element.forexAmount === undefined || element.exchangeRate === undefined)) {
                currentTravellerTotal += element.forexAmount * element.exchangeRate.rate;
            }
        });
        travellerTotal += currentTravellerTotal;
        traveller.usedAmount = currentTravellerTotal;
    });

    this.userSessionInfo.sendMoneyScreen.usedAmount = travellerTotal;
    if (this.userSessionInfo.sendMoneyScreen.usedAmount !== 0) {
        this.masterService.getTaxes(this.userSessionInfo.sendMoneyScreen.usedAmount)
            .subscribe(res => {
                const result: any = res;
                this.userSessionInfo.sendMoneyScreen.usedAmount += result.TotalTax;
                this.updateBalanceAmount();
            }, err => {
                // swal('Oops', 'Error fetching taxes', 'error');
                Snackbar.show({text: 'Oops! Error fetching taxes',
                pos: 'bottom-right' ,
                actionTextColor: '#ff4444',
               });
            });
    }
    this.updateBalanceAmount();
}

updateBalanceAmount() {
  this.userSessionInfo.sendMoneyScreen.balanceAmount = (this.userSessionInfo.sendMoneyScreen.budgetAmount
      - this.userSessionInfo.sendMoneyScreen.usedAmount).toString();
}

onDataChange(event, travellerIndex: any): void {
  console.log(event);
  if (event !== undefined && typeof event !== 'object') {
    this.userSessionInfo.sendMoneyScreen.traveller[travellerIndex].selfTransaction.beneficiaryTravellerArrivalDate = event;
  }
}

getMinTime() {
  const deliveryDate = this.userSessionInfo.sendMoneyScreen.deliveryInfo.DeliverySchedule.date;
  if (deliveryDate === this.todaysDate) {
    let time;
    if (this.isPickUpMode) {
      time = moment().add(0, 'hours');
    } else {
      time = moment().add(3, 'hours');
    }
    this.userSessionInfo.sendMoneyScreen.deliveryInfo.DeliverySchedule.time = time.format('HH') + ':' + time.format('mm');
    return time.format('HH') + ':' + time.format('mm');
  }
  this.userSessionInfo.sendMoneyScreen.deliveryInfo.DeliverySchedule.time = '10:00';
  return '10:00';
}

validateSession() {
  let result = true;

  if (this.userSessionInfo.sendMoneyScreen.branch === '' || this.userSessionInfo.sendMoneyScreen.branch === undefined) {
      // swal('Error', 'Please select branch', 'error');
      Snackbar.show({
          text: 'Error! Please select branch ',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
      });
      // this.invalidsubmitted = true;
      result = false;
  } else if (this.userSessionInfo.sendMoneyScreen.destination === ''
      || this.userSessionInfo.sendMoneyScreen.destination === undefined) {
      // swal('Error', 'Please select destination', 'error');
      Snackbar.show({
          text: 'Error! Please select destination ',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
      });
      // this.invalidsubmitted = true;
      result = false;
  } else {

      for (let travellerIndex = 0; travellerIndex < this.userSessionInfo.sendMoneyScreen.traveller.length; travellerIndex++) {
          const traveller = this.userSessionInfo.sendMoneyScreen.traveller[travellerIndex];

          if (traveller.purpose === '' || traveller.purpose === undefined) {
              // swal('Error', 'Please select purpose for traveler ' + (travellerIndex + 1), 'error');
              Snackbar.show({
                  text: 'Error!Please select purpose for traveler ' + (travellerIndex + 1),
                  pos: 'bottom-right',
                  actionTextColor: '#ff4444',
              });
              this.selectTraveller(travellerIndex);
              // this.invalidsubmitted = true;
              result = false;
              break;
          }

          let index = 0;
          for (; index < traveller.prepaidCardDetails.length; index++) {
              const detail = traveller.prepaidCardDetails[index];
              if (detail.currencyCode === '' || detail.currencyCode === undefined) {
                  // swal('Error', 'Please select currency for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                  Snackbar.show({
                      text: 'Error! Please select currency for prepaid card of traveler ' + (travellerIndex + 1),
                      pos: 'bottom-right',
                      actionTextColor: '#ff4444',
                  });
                  this.selectTraveller(travellerIndex);
                  // this.invalidsubmitted = true;
                  result = false;
                  break;
              }
              if (detail.forexAmount === '' || detail.forexAmount === undefined || detail.forexAmount <= 0) {
                  // swal('Error', 'Please provide amount for prepaid card of traveler ' + (travellerIndex + 1), 'error');
                  Snackbar.show({
                      text: 'Error! Please provide amount for prepaid card of traveler ' + (travellerIndex + 1),
                      pos: 'bottom-right',
                      actionTextColor: '#ff4444',
                  });
                  this.selectTraveller(travellerIndex);
                  // this.invalidsubmitted = true;
                  result = false;
                  break;
              }
          }

          if (index < traveller.prepaidCardDetails.length) {
              break;
          }
      }
  }
  return result;
}
}

