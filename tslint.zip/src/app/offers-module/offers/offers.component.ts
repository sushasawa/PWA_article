import { Component, OnInit, Inject, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MasterService } from '../../../app/services/master.services';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SessionHelper } from '../../helpers/session-helper';
declare var Snackbar: any;

@Component({
  selector: 'common-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {
  public querySubmited = false;
  public planData: any;
  public agentId: any;
  public UserInfo: any;
  public planDetails: any;
  public showOfferDetails: any = false;
  public selectedPlanDetails: any;
  public noImage: any = 'assets/images/common/nocompanylogo.png';
  @Output() closePopupClicked: EventEmitter<any> = new EventEmitter<any>();
  constructor(private masterService: MasterService, private http: HttpClient) {  }

  ngOnInit() {  
    this.UserInfo = SessionHelper.getSession('userInfo');
    this.agentId = JSON.parse(this.UserInfo).uid;
    this.getAgentPlans();
  }

  getAgentPlans() {
    this.masterService.getAgentDataService(this.agentId)
      .subscribe((data) => {
        this.planData = data;
        this.processPlans();
      }, (err) => {
        Snackbar.show({
          text: 'Error in fetching offers.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  processPlans() {
    let agentsObj = [];
    let counter = 0, agentOfferLength = this.planData.length;
    this.planData.forEach((agentInfo) => {
      this.masterService.getAgentPlanService(agentInfo.planId)
        .subscribe((data) => {
          agentInfo.plans = data[0];
          agentInfo.imagePath = data[1][0].planImage ? data[1][0].planImage : this.noImage;
          agentInfo.planDesc = data[1][0].planDesc;
          agentInfo.planName = data[1][0].planName;
          agentsObj.push(agentInfo);          
          counter++;
          if (counter === agentOfferLength) {
            this.planDetails = Object.keys(agentsObj).map((key) => { return agentsObj[key]; });
          }
        }, (err) => {
          Snackbar.show({
            text: 'Error in fetching offers.',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        });
    });
  }

  offerClicked(agentIndex) {
    this.showOfferDetails = true;
    this.selectedPlanDetails = this.planDetails[agentIndex];
  }

  showMyOffers() {
    this.showOfferDetails = false;
  }
}
