import { Component, OnInit } from '@angular/core';
import { MasterService } from '../../../app/services/master.services';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { SessionHelper } from '../../helpers/session-helper';

// import { Angular2Csv } from 'angular2-csv/Angular2-csv';
declare var Snackbar: any;

import * as XLSX from 'xlsx';

declare function initDocument(): any;
declare var $: any;

@Component({
  selector: 'app-lead-upload',
  templateUrl: './lead-upload.component.html',
  styleUrls: ['./lead-upload.component.css']
})
export class LeadUploadComponent implements OnInit {
  public email: any;
  public cityOptions: any;
  public showView: any = false;
  public Doc: any;
  public formdata: any;
  public fileName: any;
  public file: any;
  public groupName: any;
  public agentId: any;
  public invalidsubmitted: any;
  public selectedTabWin: any;
  public isExcelProcessing: Boolean = false;
  public individualLeadData: any = {
    AgentId: JSON.parse(SessionHelper.getSession('userInfo')).uid,
    Url: '',
    FirstName: '',
    MiddleName: '',
    LastName: '',
    City: '',
    CountryCode: '',
    Mobile: '',
    EmailId: '',
    AlternateCountryCode: '',
    AlternateMobileNo: '',
    AlternateEmailId: '',
  };

  public data: any = [
    {
      'FirstName': '',
      'MiddleName': '',
      'LastName': '',
      'City': '',
      'Country Code': '',
      'Mobile': '',
      'EmailId': '',
      'AlternateCountryCode': '',
      'AlternateMobileNo': '',
      'AlternateEmailId': '',
      'Url': ''
    }
  ];

  constructor(private masterService: MasterService) {
    this.agentId = JSON.parse(SessionHelper.getSession('userInfo')).uid;

  }

  ngOnInit() {
    initDocument();
    setTimeout(function () {
      $('ng-select > div').css('border', '0px solid black');
    }, 5);

    this.masterService.getCityList()
      .subscribe(data => {
        this.cityOptions = data;
        const currentDocument = this;
      });
    $('body').attr('id', '');  // This is added to remove background none and display back ground when page is selected from home.
  }

  updateSession1(registrationInfo, value, index) {
    setTimeout(() => {
      registrationInfo[index] = value.split(/\b/g).map(word => this.titleCaseWord(word)).join('');
    }, 10);
  }

  titleCaseWord(word: string) {
    if (!word) return word;
    return word[0].toUpperCase() + word.substr(1).toLowerCase();
  }

  GenerateLink(userForm: NgForm, event: Event) {

    event.preventDefault();
    this.invalidsubmitted = userForm.invalid;

    if (userForm.valid) {
      const leadDataArr = [];
      leadDataArr.push(this.individualLeadData);
      this.masterService.sendMailLeadPax(leadDataArr)
        .subscribe(data => {
          const retMessage: any = data;
          console.log('retMessage', retMessage);
          if (retMessage[0].Msg === 'Added successfully') {
            Snackbar.show({
              text: 'Submitted Successfully',
              pos: 'bottom-right',
            });
            userForm.reset();
          }
        });
    } else {
      Snackbar.show({
        text: 'Cannot proceed , Please fill required inputs',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }
  }

  selectedTab(tabName) {
    this.selectedTabWin = tabName;
  }

  DownloadExcel() {

    /* generate worksheet */
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.data);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    /* save to file */
    XLSX.writeFile(wb, 'leadUpld.xlsx');



  }

  uploadDoc(ele: any, doc: any, controlIndex: any) {
    let fileNameCompArr = [], fileType = '', maxSizeKB = 500;
    // const docs = ele.target.files[0];
    // this.showView = true;
    // this.Doc = docs.name;
    // this.formdata = new FormData();
    // this.formdata.append('agentId', '331');
    // this.formdata.append('sampleFile', docs, docs.name);
    // this.formdata = new FormData();
    // const doctype = { 'doc': doc };
    // const userid = { 'id': this.currentUserId };
    // this.formdata.append('Doctype', JSON.stringify(doctype));
    // this.formdata.append('userdata', JSON.stringify(userid));
    if (ele.target.files[0] && ele.target.files[0].type) {
      fileNameCompArr = ele.target.files[0].name.split('.');
      fileType = fileNameCompArr[fileNameCompArr.length - 1];
    }
    const fileValidation = (fileType === 'xlsx' && ele.target.files[0].size <= (1000 * maxSizeKB));
    if (fileValidation) {
      this.Doc = ele.target.files[0];
      this.showView = true;
      this.fileName = ele.target.files[0].name;
    } else {
      Snackbar.show({
        text: 'Supports JPEG, PNG and GIF. The file size should not exceed ' + maxSizeKB + ' KB.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      // const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(this.data);
    }
  }

  submitBulkDoc(userbulkForm: NgForm , Event) {
    Event.preventDefault();
    this.formdata = new FormData();
    this.formdata.append('agentId', this.agentId);
    this.formdata.append('groupName', this.groupName);
    this.formdata.append('sampleFile', this.Doc, this.Doc.name);
    this.isExcelProcessing = true;
    this.masterService.ExcelUpload(this.formdata)
      .subscribe(data => {
        const retMessage: any = data;
        console.log(retMessage);
        this.isExcelProcessing = false;
        Snackbar.show({
          text: 'Submitted Successfully',
          pos: 'bottom-right',
        });
        this.showView = false;
        userbulkForm.reset();
      }, error => {
        const erroObj: any = error;
        console.log(erroObj.error);
        this.isExcelProcessing = false;
        Snackbar.show({
          text: erroObj.error,
          pos: 'bottom-right',
          actionTextColor: 'red',
          duration: 100000
        });
        this.showView = false;
        userbulkForm.reset();
      });
  }

  removeDoc() {
    this.showView = false;
    this.Doc = '';
    this.file = '';
  }



}
