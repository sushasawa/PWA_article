import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LeadUploadComponent } from './lead-upload/lead-upload.component';
import { Routes, RouterModule } from '@angular/router';
import { SelectModule } from 'ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


const routes: Routes = [
{
  path: '',
  component: LeadUploadComponent,
}
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SelectModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [LeadUploadComponent]
})
export class LeadUploadModule { }
