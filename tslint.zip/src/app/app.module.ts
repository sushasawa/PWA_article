import { LogoServiceService } from './services/logo-service.service';
import { BulkExchangeRateService } from './services/bulk-exchange-rate.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SlimLoadingBarModule } from 'ng2-slim-loading-bar';
import { SessionValueResetService } from './services/session-value-reset.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MasterService } from './services/master.services';
import { AgentMarginService } from './services/agent-margin.service';
import { GlobalLoaderService } from './services/global-loader.service';
import { LoaderInterceptor } from './interceptors/loader-interceptor.service';
import { SessionCheckerService } from './services/session-checker.service';
import { TransactionService } from './services/transaction.service';
import { NavigatePathService } from './services/navigate-path.service';
import { AgentThemeService } from './services/agent-theme.service';
import { SharedModule } from './shared/shared.module';
// import { OffersComponent } from './offers/offers.component';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    SlimLoadingBarModule
  ],
  // tslint:disable-next-line:max-line-length
  providers: [NavigatePathService, AgentThemeService, TransactionService, MasterService, AgentMarginService, GlobalLoaderService, SessionValueResetService, BulkExchangeRateService, {
    provide: HTTP_INTERCEPTORS,
    useClass: LoaderInterceptor,
    multi: true,
  },
    SessionCheckerService, LogoServiceService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
