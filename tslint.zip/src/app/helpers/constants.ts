import { Url } from '../../assets/config';
import { SessionHelper } from './session-helper';
console.log(Url.server1);
export class Constants {
    static serviceUrl = Url.server1;
    static serviceUrl_Local = 'http://10.21.21.210:4000';
    static skipAdhaarValidationFlag = true;
    static Bank_Correspondent_Bank_Charges = 25;
    static PREPAID_CURRENCY_CODES = ['SAR', 'AED', 'THB', 'NZD' , 'ZAR' , 'HKD'];
    static uploadTheme() {
        return this.serviceUrl + '/theme/fileUpload';
    }

    static sendMailLeadPax() {
        return this.serviceUrl + '/mails/mailQueue';
    }


    static getSubPurpose() {
        return this.serviceUrl + '/master/getSubPurpose';
    }

    static getSkipAdhaarValidationFlag() {
        return this.skipAdhaarValidationFlag;
    }

    static getBankCorrespondentCharges(){
        return this.Bank_Correspondent_Bank_Charges;
    }

    static getAgentMargin(AgentId) {
        return this.serviceUrl + '/master/getAgentMargin?id=' + AgentId;
    }

    static setAgentMargin() {
        return this.serviceUrl + '/master/setAgentMargin';
    }

    static ExcelUpload() {
        return this.serviceUrl + '/leadUpload/Upload';
    }

    static getBranchListService(cityName: any) {
        return this.serviceUrl + '/master/Branch?City=' + cityName;
    }

    static getBranchDetailsService(val) {
        return this.serviceUrl + '/master/BranchDetails?branchId=' + val;
    }

    static getDestinationListService() {
        return this.serviceUrl + '/master/Destination';
    }

    static getNationality() {
        return this.serviceUrl + '/master/nationality';
    }

    static getCurrencyListService() {
        return this.serviceUrl + '/master/Currency';
    }

    static getAllCurrency() {
        return this.serviceUrl + '/master/AllCurrency';
    }

    static getAgentIdByAliasName(AliasName){
        return this.serviceUrl + '/master/getAgentIdByAliasName?AliasName=' + AliasName;
    }

    static getExchangeRateService() {
        console.log('/master/_ExchangeRate');
        return this.serviceUrl + '/master/getExchangeRate_version1';
    }

    static getDocumentListService() {
        return this.serviceUrl + '/document/documentList';
    }

    static getDeliveryTypeListService() {
        return this.serviceUrl + '/master/deliveryType';
    }

    static getPurposeListService(processId: any) {
        return this.serviceUrl + '/master/TravelPurpose?processId=' + processId;
    }

    static getBanksListService() {
        return this.serviceUrl + '/master/Banks';
    }

    static getBanksService() {
        return this.serviceUrl + '/master/getBanksList';
    }

    static getCityListService() {
        return this.serviceUrl + '/master/CityList';
    }

    static getDeliveryAmtService() {
        return this.serviceUrl + '/document/DeliveryAmt';
    }

    static setUserDetailWithAdharService() {
        return this.serviceUrl + '/register/registerAdhar';
    }

    static getPincodeDetailsService() {
        return this.serviceUrl + '/register/getPincodeDetails';
    }

    static getDocUploadApi() {
        return this.serviceUrl + '/upload';
    }

    static setUserInfo() {
        return this.serviceUrl + '/users/userInfo';
    }

    static updateUserInfo() {
        return this.serviceUrl + '/UpdateUser/UpdateUserInfo';
    }


    static getLoginService() {
        return this.serviceUrl + '/master/login';
    }

    static getForgotPasswordService() {
        return this.serviceUrl + '/master/forgotPassword';
    }

    static getResetPasswordService() {
        return this.serviceUrl + '/master/resetPassword';
    }

    static validateResetPasswordService() {
        return this.serviceUrl + '/master/validateResetPasswordUrl';
    }

    static getCardDetailsService() {
        return this.serviceUrl + '/users/cardDetails';
    }

    static sessionDumpService() {
        return this.serviceUrl + '/mongodump/sessiondump';
    }

    static transactionDumpService() {
        return this.serviceUrl + '/transaction/SaveRequestData';
    }
    static callPaymentGateway() {
        return this.serviceUrl + '/master/paymentGatewayService';
        // return "http://10.21.20.86:8001/api/values";
    }

    static callPaymentGatewayPaynimo() {
        return this.serviceUrl + '/master/paymentGatewayServicePaynimo';
        // return "http://10.21.20.86:8001/api/values";
    }

    static getLoggedInUserInfoService(val) {
        return this.serviceUrl + '/account/userInfo?uid=' + val;
    }

    static getUserProfilePicService() {
        return this.serviceUrl + '/profile';
    }

    static createAlertService() {
        return this.serviceUrl + '/createAlert';
    }

    static getTempOrderNumber() {
        return this.serviceUrl + '/master/OrderNumber';
    }

    static generateInvoiceNoService() {
        return this.serviceUrl + '/transaction/generateInvoiceNo';
    }

    static getOrderData() {
        return this.serviceUrl + '/mongoDump/getSessionFromMongo';
    }

    static getOrderDataFromEmail() {
        return this.serviceUrl + '/mongoDump/getSessionFromMongoCheckEmail';
    }

    static getLiveForex() {
        return this.serviceUrl + '/liveForex/LiveForexRates_C';
    }

    static getLiveForexOverview() {
        return this.serviceUrl + '/liveForex/LiveForexRatesOverview_C';
    }

    static getLiveForexFromBranchId(val, agentID) {
        return this.serviceUrl + '/liveForex/LiveForexRatesFromBranchId_Version1?branchId=' + val + '&agentId=' + agentID;
    }


    static getForexTrend(val) {
        return this.serviceUrl + '/liveForex/ForexTrend_C?currencyCode=' + val;
    }

    static getForexTrendFromBranchId(currencyCode, branchId, agentId) {
        return this.serviceUrl + '/liveForex/D_getTrend_Weekwise?currencyCode=' + currencyCode + '&branchId=' + branchId + '&agentId=' + agentId;
    }


    static getForexTrendSell(val) {
        return this.serviceUrl + '/liveForex/ForexTrendSell_C?currencyCode=' + val;
    }

    static getForexTrendSellFromBranchId(currencyCode, branchId, agentId) {
        return this.serviceUrl + '/liveForex/D_getTrend_Weekwise?currencyCode=' + currencyCode + '&branchId=' + branchId + '&agentId=' + agentId;
    }

    static getCheckEmail() {
        return this.serviceUrl + '/CheckEmail';
    }



    static getForexTrendSellDaywise(val) {
        return this.serviceUrl + '/liveForex/ForexTrendSellDaywise?currencyCode=' + val;
    }

    static getForexTrendSellDaywiseFromBranchId(currencyCode, branchId, agentId) {
        return this.serviceUrl + '/liveForex/D_getTrend_Daywise?currencyCode=' + currencyCode + '&branchId=' + branchId + '&agentId=' + agentId;
    }


    static getForexTrendBuyDaywise(val) {
        return this.serviceUrl + '/liveForex/ForexTrendBuyDaywise?currencyCode=' + val;
    }

    static getForexTrendBuyDaywiseFromBranchId(currencyCode, branchId, agentId) {
        return this.serviceUrl + '/liveForex/D_getTrend_Daywise?currencyCode=' + currencyCode + '&branchId=' + branchId + '&agentId=' + agentId;
    }

    static getAlertService() {
        return this.serviceUrl + '/createAlert/getAlert';
    }

    static deleteAlertService() {
        return this.serviceUrl + '/createAlert/delete';
    }

    static updateAlertService() {
        return this.serviceUrl + '/createAlert/update';
    }

    static wishListService(UserId) {
        return this.serviceUrl + '/WishList?userId=' + UserId;
    }

    static getUserDocumentsService(UserId) {
        return this.serviceUrl + '/Document/getUserDocuments?uid=' + UserId;
    }

    static updateKycService() {
        return this.serviceUrl + '/Document/kyc';
    }

    static sendAadhaarOtp() {
        return this.serviceUrl + '/adharAuth/sendOtp';
    }

    static validateAadhaarOtp() {
        return this.serviceUrl + '/adharAuth/validateOtp';
    }

    static getOrdersListService(uid) {
        return this.serviceUrl + '/orders/GetOrdersList?uid=' + uid;
    }

    static changePasswordService() {
        return this.serviceUrl + '/users/ChangePassword';
    }

    static setGrievancesService() {
        return this.serviceUrl + '/createAlert/Grievances';
    }

    static getTaxes(totalPayable: number) {
        return this.serviceUrl + '/master/Taxes?totalPayable=' + totalPayable;
    }

    static releaseTempNo(tempNo: number) {
        return this.serviceUrl + '/master/releaseTempNo?tempNo=' + tempNo;
    }

    static setFeedback() {
        return this.serviceUrl + '/footerAssets/feedback';
    }

    static checkCardAvailable(cardNo: number) {
        return this.serviceUrl + '/master/checkCardAvailable?cardNo=' + cardNo;
    }

    static deleteDocumentService() {
        return this.serviceUrl + '/DeleteDoc';
    }

    static RuleTest() {
        return this.serviceUrl + '/master/setData';
    }

    static getAdaarValidationService() {
        return this.serviceUrl + '/adharAuth/validateAdharDemo';
    }

    static getAirlineNamesService() {
        return this.serviceUrl + '/master/AirlineName';
    }

    static getChargesService() {
        return this.serviceUrl + '/Charges/';
    }

    static newLeadLoginService() {
        return this.serviceUrl + '/account/newLeadLogin';
    }

    static addNewLeadService() {
        return this.serviceUrl + '/account/addNewLead';
    }

    static updateLeadPassService() {
        return this.serviceUrl + '/account/updateLeadPass';
    }

    static checkActiveUrlService(url) {
        return this.serviceUrl + '/account/checkUrlServie?url=' + url;
    }

    static removeTravellerService() {
        return this.serviceUrl + '/account/removeTraveller';
    }


    static generateTransactionIdService() {
        return this.serviceUrl + '/transaction/generateTransactionId';
    }

    static initTransactionSavingService() {
        return this.serviceUrl + '/transaction/saveTransactionRequest';
    }

    static getTransactionByIdService(id) {
        return this.serviceUrl + '/transaction/transactionById?transactionId=' + id;
    }

    static sendSellInvoiceDataService() {
        return this.serviceUrl + '/transaction/sellIexchnagePOST';
    }


    static getCurrencyRateForRuleService(branchId, AgentId) {
        return this.serviceUrl + '/master/getCurrencyRateForRule_version1?branchId=' + branchId + '&agentId=' + AgentId;
    }

    static getLoginServiceAgent() {
        return this.serviceUrl + '/agent/agentLogin';
    }

    static getLoggedInAgentInfoService(val) {
        return this.serviceUrl + '/Agent/getAgent?UserId=' + val;
    }

    static createUserAgentService() {
        return this.serviceUrl + '/agent/createUserAgents';
    }

    static getAgentDocumentsService() {
        return this.serviceUrl + '/agent/getAgentDocuments';
    }

    static saveAgentDocumentsService() {
        return this.serviceUrl + '/agent/saveAgentDocuments';
    }

    static uploadAgentDocumentService() {
        return this.serviceUrl + '/AgentDocumentUpload';
    }

    static getTotalLeadsCountService() {
        return this.serviceUrl + '/orders/getAgentsOrdersCounts';
    }

    static updateExistingUsersLeadProspectsAndUrlActiveStatusService() {
        return this.serviceUrl + '/agent/existingLeadUpdate';
    }

    static getAgentOrderListService() {
        return this.serviceUrl + '/orders/getAgentsOrdersDetails';
    }

    static getSubAgentsService() {
        return this.serviceUrl + '/orders/getAgentsById';
    }

    static getAllBranchService() {
        return this.serviceUrl + '/orders/getAllBranches';
    }

    static setAgentLogoService() {
        return this.serviceUrl + '/agent/saveAgentsLogo';
    }

    static getAgentThemeDetailsService() {
        return this.serviceUrl + '/agent/getAgentsThemeDetails';
    }

    static getAgentsLeadsService() {
        return this.serviceUrl + '/agent/getAgentsLeadsDetails';
    }

    static setuserActiveStatusService() {
        return this.serviceUrl + '/orders/setuserActiveStatus';
    }

    static getUserControlService() {
        return this.serviceUrl + '/userctrl/';
    }

    static getAgentUserAccessCtrlService() {
        return this.serviceUrl + '/userctrl/getUserAccessCtrls';
    }

    static getAgentDataService(val) {
        return this.serviceUrl + '/transaction/getAgentPlanFromId?agentId=' + val;
    }

    static getAgentCommissionService(payload) {
        return this.serviceUrl + '/commission/getCommissionMonthly?userId='+payload.UserId+'&year='+payload.year;
    }

    static getAgentCommissionDetailsService(payload) {
        return this.serviceUrl + '/commission/getCommissionDetails?userId='+payload.UserId+'&month='+payload.month+'&year='+payload.year;
    }

    static getAgentPlanService(val) {
        return this.serviceUrl + '/transaction/getPlanDetailsFromId?planId=' + val;
    }

    static getAgentThemeService() {
        return this.serviceUrl + '/agent/AgentTemplate';
    }

    static checkDomainAvailableServive() {
        return this.serviceUrl + '/master/checkDomainAvailable';
    }

    static changeDomainNameServive() {
        return this.serviceUrl + '/master/changeDomainName';
    }

    static checkLeadCreatedService(id: any) {
        return this.serviceUrl + '/master/checkLeadCreated?UserId=' + id;
    }

    static getBulkExchangeRateService() {
        const AgentId: any = SessionHelper.getSession('AgentID') || SessionHelper.getSession('AgentWebsiteID');
        return this.serviceUrl + '/master/bulkExchangeRate?AgentId=' + AgentId;
    }

    static currencyNotificationService() {
        return this.serviceUrl + '/mails/sendCurrencyNotification';
    }
}

