export class UserControl {

    static getUserRules() {
        return {
            'SUPER_USER_1': {
                'MY_OVERVIEW': {
                    'ALLOWED': true,
                    'MY_ORDERS_WIDGET': true,
                    'MY_OFFERS_WIDGET': true,
                    'MY_COMMISION_WIDGET': true,
                    'MY_GRIEVANCES_WIDGET': true
                },
                'MY_PROFILE': {
                    'ALLOWED': true,
                    'PERSONAL_INFORMATION': true
                },
                'MY_PROFILE_EDIT': {
                    'ALLOWED': true,
                    'REGISTERED_OFFICE_ADDRESS': true,
                    'CORPORATE_OFFICE_ADDRESS': true,
                    'BRANCH_ADDRESS': true
                },
                'MY_OFFERS': {
                    'ALLOWED': true,
                },
                'MY_ORDERS': {
                    'ALLOWED': true,
                    'GENERATE_REPORT': true
                },
                'MY_COMMISSION': {
                    'ALLOWED': true,
                },
                'MY_DOCUMENTS': {
                    'ALLOWED': true,
                },
                'MY_DOCUMENTS_EDIT': {
                    'ALLOWED': true,
                },
                'MY_WISHLIST': {
                    'ALLOWED': true
                },
                'USER_ACCOUNT_CREATION': {
                    'ALLOWED': true,
                },
                'MY_SUPPORT': {
                    'ALLOWED': true,
                    'PAYMENT_OPTIONS': true,
                    'FAQ': true,
                    'TERMS_CONDITIONS': true,
                    'CONTACT_US': true,
                    'PRIVACY_POLICY': true
                },
                'MY_SETTINGS': {
                    'ALLOWED': true,
                    'CHANGE_PASSWORD': true,
                    'UPLOAD_LOGO': true,
                    'USER_CONTROL': true,
                    'URL_SETTINGS': true

                },
                'MY_GRIEVANCE': {
                    'ALLOWED': true
                },
                'MY_SET_RATE': {
                    'ALLOWED': true
                },
                'STATIC_TEMPLATE' : {
                    'ALLOWED': true
                }
            },
            'ADMIN_2': {
                'MY_OVERVIEW': {
                    'ALLOWED': true,
                    'MY_ORDERS_WIDGET': true,
                    'MY_OFFERS_WIDGET': true,
                    'MY_COMMISION_WIDGET': true,
                    'MY_GRIEVANCES_WIDGET': true
                },
                'MY_PROFILE': {
                    'ALLOWED': true,
                    'PERSONAL_INFORMATION': true
                },
                'MY_PROFILE_EDIT': {
                    'ALLOWED': true,
                    'REGISTERED_OFFICE_ADDRESS': false,
                    'CORPORATE_OFFICE_ADDRESS': false,
                    'BRANCH_ADDRESS': false
                },
                'MY_OFFERS': {
                    'ALLOWED': true,
                },
                'MY_ORDERS': {
                    'ALLOWED': true,
                    'GENERATE_REPORT': true
                },
                'MY_COMMISSION': {
                    'ALLOWED': true,
                },
                'MY_DOCUMENTS': {
                    'ALLOWED': false,
                },
                'MY_DOCUMENTS_EDIT': {
                    'ALLOWED': false,
                },
                'MY_WISHLIST': {
                    'ALLOWED': true
                },
                'USER_ACCOUNT_CREATION': {
                    'ALLOWED': true,
                },
                'MY_SUPPORT': {
                    'ALLOWED': true,
                    'PAYMENT_OPTIONS': true,
                    'FAQ': true,
                    'TERMS_CONDITIONS': true,
                    'CONTACT_US': true,
                    'PRIVACY_POLICY': true
                },
                'MY_SETTINGS': {
                    'ALLOWED': true,
                    'CHANGE_PASSWORD': true,
                    'UPLOAD_LOGO': true,
                    'USER_CONTROL': false,
                    'URL_SETTINGS': false
                },
                'MY_GRIEVANCE': {
                    'ALLOWED': true
                },
                'MY_SET_RATE': {
                    'ALLOWED': false
                },
                'STATIC_TEMPLATE' : {
                    'ALLOWED': false
                }
            },
            'AGENT_3': {
                'MY_OVERVIEW': {
                    'ALLOWED': true,
                    'MY_ORDERS_WIDGET': true,
                    'MY_OFFERS_WIDGET': true,
                    'MY_COMMISION_WIDGET': false,
                    'MY_GRIEVANCES_WIDGET': true
                },
                'MY_PROFILE': {
                    'ALLOWED': true,
                    'PERSONAL_INFORMATION': true
                },
                'MY_PROFILE_EDIT': {
                    'ALLOWED': true,
                    'REGISTERED_OFFICE_ADDRESS': false,
                    'CORPORATE_OFFICE_ADDRESS': false,
                    'BRANCH_ADDRESS': false
                },
                'MY_OFFERS': {
                    'ALLOWED': true,
                },
                'MY_ORDERS': {
                    'ALLOWED': true,
                    'GENERATE_REPORT': false
                },
                'MY_COMMISSION': {
                    'ALLOWED': false,
                },
                'MY_DOCUMENTS': {
                    'ALLOWED': false,
                },
                'MY_DOCUMENTS_EDIT': {
                    'ALLOWED': false,
                },
                'MY_WISHLIST': {
                    'ALLOWED': true
                },
                'USER_ACCOUNT_CREATION': {
                    'ALLOWED': false,
                },
                'MY_SUPPORT': {
                    'ALLOWED': true,
                    'PAYMENT_OPTIONS': false,
                    'FAQ': true,
                    'TERMS_CONDITIONS': true,
                    'CONTACT_US': true,
                    'PRIVACY_POLICY': true
                },
                'MY_SETTINGS': {
                    'ALLOWED': true,
                    'CHANGE_PASSWORD': true,
                    'UPLOAD_LOGO': false,
                    'USER_CONTROL': false,
                    'URL_SETTINGS': false
                },
                'MY_GRIEVANCE': {
                    'ALLOWED': true
                },
                'MY_SET_RATE': {
                    'ALLOWED': false
                },
                'STATIC_TEMPLATE' : {
                    'ALLOWED': false
                }
            }
        };
    }

}
