export class SessionHelper {

    static setSession(key: string, value: string) {
        const encryptedString: any = btoa(value).split('').reverse().join('')
        .slice(btoa(value).split('').reverse().join('').length / 2 , btoa(value).split('').reverse().join('').length)
        .concat(btoa(value).split('').reverse().join('').slice(0, btoa(value).split('').reverse().join('').length / 2)) ;
        sessionStorage.setItem(key, encryptedString);
        // sessionStorage.setItem(key, btoa(value));
    }

    static getSession(key: string): string {
        try {
            return  sessionStorage.getItem(key) ? atob(sessionStorage.getItem(key).split('').reverse().join('')
            .slice(sessionStorage.getItem(key).split('').reverse().join('').length / 2
            , sessionStorage.getItem(key).split('').reverse().join('').length)
            .concat(sessionStorage.getItem(key).split('').reverse().join('')
            .slice(0, sessionStorage.getItem(key).split('').reverse().join('').length / 2))
            ) : undefined;
            // return sessionStorage.getItem(key) ? atob(sessionStorage.getItem(key)) : undefined;
        } catch (err) {
            sessionStorage.removeItem(key);
            return undefined;
        }
    }

    static removeSession(key: string): string {
        try {
            const result = sessionStorage.getItem(key) ? atob(sessionStorage.getItem(key)) : undefined;
            sessionStorage.removeItem(key);
            return result;
        } catch (err) {
            sessionStorage.removeItem(key);
            return undefined;
        }
    }

    static setLocal(key: string, value: string) {
        sessionStorage.setItem(key, btoa(value));
    }


    static getLocal(key: string): string {
        // return localStorage.getItem(key) ? atob(localStorage.getItem(key)) : undefined;
        try {
            return sessionStorage.getItem(key) ? atob(sessionStorage.getItem(key)) : undefined;
        } catch (err) {
            sessionStorage.removeItem(key);
            return undefined;
        }
    }

    static removeLocal(key: string): string {
        try {
            const result = sessionStorage.getItem(key) ? atob(sessionStorage.getItem(key)) : undefined;
            sessionStorage.removeItem(key);
            return result;
        } catch (err) {
            sessionStorage.removeItem(key);
            return undefined;
        }
    }
}
