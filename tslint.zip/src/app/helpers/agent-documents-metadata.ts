export class AgentDocumentsMetadata {

    static getUserDocumentUploadDocumentStructure() {
        return {
            'Documents': {
                'ID_PROOF': {
                    'Type': 'ID_PROOF',
                    'Label': 'Id Proof',
                    'MetaData': {
                        'PAN_CARD': {
                            'Label': 'Pan Card',
                            'DocumentUrl': 'assets/images/my-account/doc-thumb2.jpg',
                            'IsMetaData': true,
                            'MetaData': [
                                {
                                    'label': 'Pan card Number',
                                    'value': 'PIRA02017T'
                                }
                            ]
                        },
                        'PASSPORT': {
                            'Label': 'Passport',
                            'DocumentUrl': 'assets/images/my-account/doc-thumb2.jpg',
                            'IsMetaData': true,
                            'MetaData': [
                                {
                                    'label': 'Passport Number',
                                    'value': ''
                                }
                            ]
                        },
                        'DRIVING_LICENSE': {
                            'Label': 'Driving License',
                            'DocumentUrl': 'assets/images/my-account/doc-thumb2.jpg',
                            'IsMetaData': true,
                            'MetaData': [
                                {
                                    'label': 'Driving Licence Number',
                                    'value': ''
                                }
                            ]
                        }
                    }
                },
                'ADDRESS_PROOF': {
                    'Type': 'ADDRESS_PROOF',
                    'Label': 'Address Proof',
                    'MetaData': {
                        'ELECTRICITY_BILL': {
                            'Label': 'Electricity Bill',
                            'DocumentUrl': 'assets/images/my-account/doc-thumb4.jpg',
                            'IsMetaData': true,
                            'MetaData': [
                                {
                                    'label': 'Electricity Bill Date',
                                    'value': '',
                                    'type': 'date'
                                }
                            ]
                        },
                        'TELEPHONE_BILL': {
                            'Label': 'Telephone Bill',
                            'DocumentUrl': 'assets/images/my-account/doc-thumb4.jpg',
                            'IsMetaData': true,
                            'MetaData': [
                                {
                                    'label': 'Telephone Bill Date',
                                    'value': '',
                                    'type': 'date'
                                }
                            ]
                        }
                    }
                },
                'BANK_INFORMATION': {
                    'Type': 'BANK_INFORMATION',
                    'Label': 'Bank Information',
                    'MetaData': {
                        'BANK_DETAILS': {
                            'Label': 'Bank Details',
                            'DocumentUrl': 'assets/images/my-account/doc-thumb2.jpg',
                            'IsMetaData': true,
                            'MetaData': [
                                {
                                    'label': 'Beneficiary Name',
                                    'value': ''
                                },
                                {
                                    'label': 'Beneficiary Bank Name',
                                    'value': ''
                                },
                                {
                                    'label': 'Bank Address',
                                    'value': ''
                                },
                                {
                                    'label': 'Bank Ac number',
                                    'value': ''
                                },
                                {
                                    'label': 'IFSC Code',
                                    'value': ''
                                }
                            ]
                        }
                    }
                }
            },
            'UploadedDocuments': []
        };
    }

    static getSubDocuments() {
        return {
            'ID_PROOF': [
                { label: 'Pan Card', value: 'PAN_CARD' },
                { label: 'Passport', value: 'PASSPORT' },
                { label: 'Driving License', value: 'DRIVING_LICENSE' }
            ],
            'ADDRESS_PROOF': [
                { label: 'Electricity Bill', value: 'ELECTRICITY_BILL' },
                { label: 'Telephone Bill', value: 'TELEPHONE_BILL' }
            ],
            'BANK_INFORMATION': [
                { label: 'Bank Details', value: 'BANK_DETAILS' }
            ]
        };
    }

    static getDocumentTypes() {
        return [
            { label: 'Id Proof', value: 'ID_PROOF' },
            { label: 'Address Proof', value: 'ADDRESS_PROOF' },
            { label: 'Bank Information', value: 'BANK_INFORMATION' }
        ];
    }
}
