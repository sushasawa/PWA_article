import { SharedService } from './../../shared/shared.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { Component, OnInit, Output, EventEmitter, HostListener, DoCheck } from '@angular/core';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { ActivatedRoute, NavigationEnd, Router, Event } from '@angular/router';
import { SessionHelper } from '../../helpers/session-helper';
import { MasterService } from '../../services/master.services';
import { UserControl } from './../../helpers/user-control';
import * as sha from 'sha.js';
import { Location } from '@angular/common';

declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare function initAccord(): any;

@Component({
  selector: 'app-my-settings',
  templateUrl: './my-settings.component.html',
  styleUrls: ['./my-settings.component.css']
})
export class MySettingsComponent implements OnInit, DoCheck {
  public uid: any;
  public invalidsubmitted: any;
  public subAgents: any = [];
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public currentUserId;
  public AgentTheme: any;
  public formdata: any;
  public currentUser: any;
  public AgentIDs: any = [];
  public SubUsers: any = [];
  public lastUpdatedBy: any;
  public _primaryComp: any;
  public currentURL: any;
  public concertinaStatus: any = '';
  public SiteMsg: any = 'This feature will be disabled once lead is generated from this account or it\'s sub accounts . ';
  public SiteMsgBoxShow: Boolean = true;
  public checkLeadCreated: Boolean = false;
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, public _SharedService: SharedService, private location: Location) {
    this.currentURL = window.location.href.split('/');
    console.log(this.currentURL);
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    this.invalidsubmitted = false;
    this.SiteMsgBoxShow = true;
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      this.logout();
      window.location.href = this._primaryComp + '/';
    }
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserId = JSON.parse(UserInfo).uid;
    } else {
      this.logout();
      window.location.href = this._primaryComp + '/login';
    }

    if (SessionHelper.getSession('currentUser')) {
      this.currentUser = JSON.parse(SessionHelper.getSession('currentUser'));
    }

    if (this._SharedService.AgentsTheme) {
      this.AgentTheme = this._SharedService.AgentsTheme.success ? this._SharedService.AgentsTheme.Docs : this._SharedService.AgentsTheme;
      this.currentUser.AgentLogo = this.AgentTheme.logo;
      this._SharedService.updateLogoSrc(this.AgentTheme);
      // tslint:disable-next-line:no-unused-expression
      this._SharedService.AgentsTheme.success ? this.saveDocuments() : ' ';
    }

    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }

    this._MasterService.checkLeadCreated(this.currentUserId).subscribe((data) => {
      console.log(data);
      const result: any = data;
      this.checkLeadCreated = JSON.parse(result.status);
    });
    const loggedInAgentPayload: any = {
      id: this.currentUserId
    };
    this._MasterService.getSubAgents(loggedInAgentPayload).subscribe((data) => {
      const result: any = data;
      this.AgentIDs = [];
      if (result.status) {
        this.subAgents = result.data[0];
        this.subAgents.map((agent, index) => {
          this.AgentIDs.push(agent.value);
          agent.ACCESS_CTRL = this._UserControl[agent.RoleName + '_' + agent.RoleId];
        });
        console.log(this.subAgents);
        console.log(this.AgentIDs);
        setTimeout(function () {
          initAccord();
        }, 200);
      }
      // tslint:disable-next-line:no-unused-expression
      this.AgentIDs.length > 0 ? this.mapAgentCtrs() : '';
    }, (error) => {
      setTimeout(function () {
        initAccord();
      }, 200);
    });


  }

  ngOnInit() {
  }
  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
    this._SharedService.AgentTheme.subscribe((theme) => {
      this.AgentTheme = theme.success ? theme.Docs : theme;
    });

  }
  changePassword(changePasswordForm: NgForm, e) {
    e.preventDefault();
    const payload: any = {};
    let oldPass: any = changePasswordForm.value.oldPass;
    let newPass: any = changePasswordForm.value.newPass;
    let confirmPass: any = changePasswordForm.value.confirmPass;
    this.invalidsubmitted = changePasswordForm.invalid;
    newPass = sha('sha256').update(newPass, 'utf8').digest('hex');
    oldPass = sha('sha256').update(oldPass, 'utf8').digest('hex');
    confirmPass = sha('sha256').update(confirmPass, 'utf8').digest('hex');
    payload.newPass = newPass;
    payload.oldPass = oldPass;
    payload.confirmPass = confirmPass;
    const uid = JSON.parse(SessionHelper.getSession('userInfo')).uid;
    if (uid != null || uid !== undefined) {
      payload.uid = uid;
    } else {
      sessionStorage.removeItem('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    if (changePasswordForm.valid) {
      if (newPass === confirmPass) {
        this._MasterService.changePassword(payload)
          .subscribe((data) => {
            console.log(data);
            const result: any = data;
            if (result.code) {
              Snackbar.show({
                text: result.msg,
                pos: 'bottom-right',
                actionTextColor: '#05ff01',
              });
            } else {
              Snackbar.show({
                text: result.msg,
                pos: 'bottom-right',
                actionTextColor: '#ff4444',
              });
            }
          }, (error) => {
            console.log(error);
          });
      } else {
        Snackbar.show({
          text: 'Password not matched',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }
    }

  }

  loadDocument(file: File) {
    const File: any = file;
    this.formdata = new FormData();
    const docs = File.target.files[0];
    this.formdata.append('agentDocument', docs, docs.name);
    Snackbar.show({
      text: 'Uploading...',
      pos: 'bottom-right',
      actionTextColor: '#00880d',
    });
    this._MasterService.uploadAgentDocument(this.formdata).subscribe((data) => {
      Snackbar.show({
        text: 'Uploaded...',
        pos: 'bottom-right',
        actionTextColor: '#00880d',
      });
      this.formdata = {};
      const result: any = data;
      this.AgentTheme.logo = result.documentUrl;
      console.log(this.AgentTheme);
      console.log(this.currentUser);
      this.currentUser.AgentLogo = this.AgentTheme.logo;
      this._SharedService.updateLogoSrc(this.AgentTheme);
      SessionHelper.setSession('currentUser', JSON.stringify(this.currentUser));
      this.saveDocuments();
    }, (error) => {
    });
  }

  logout() {
    SessionHelper.removeSession('userInfo');
    SessionHelper.removeSession('userSessionInfo');
    SessionHelper.removeSession('userSessionInfoSale');
    SessionHelper.removeSession('userSessionInfoRealoadCard');
    SessionHelper.removeSession('userSessionInfoSend');
    SessionHelper.removeSession('pageSessionParam');
    SessionHelper.removeSession('currentUser');
    SessionHelper.removeSession('adm_ctrl');
  }

  saveDocuments() {
    this.AgentTheme.userId = this.currentUserId.toString();
    this._MasterService.setAgentLogo(this.AgentTheme).subscribe((data) => {
      const result: any = data;
      Snackbar.show({
        text: result.message,
        pos: 'bottom-right',
        actionTextColor: '#00880d',
      });
      //  location.reload();
    });
  }

  switchAgent(agent) {
    //    console.log(agent);
    const payload: any = agent;
    payload.agentId = agent.value;
    payload.userAccessChangedById = this.currentUserId;
    payload.role = payload.RoleName + '_' + payload.RoleId;
    console.log(payload);
    switch (payload.role) {
      case 'ADMIN_2':
      case 'AGENT_3':
        console.log('save to DB');
        this._MasterService.setuserActiveStatus(payload).subscribe((data) => {
          console.log(data);
          const result: any = data;
          if (result.success) {
            Snackbar.show({
              text: result.msg,
              pos: 'bottom-right',
              actionTextColor: '#00880d',
            });
          } else {
            Snackbar.show({
              text: result.msg,
              pos: 'bottom-right',
              actionTextColor: '#fe0909',
            });
          }
        });
        break;
    }

  }


  mapAgentCtrs() {
    const payload = {
      IDs: this.AgentIDs
    };
    this._MasterService.getAgentUserAccessCtrl(payload).subscribe((data) => {
      const result: any = data;
      // console.log(agents);
      //  this.subAgents.map((CurrentAgent , CurrentIndex) => {

      //  });
      if (result.success) {
        const AGENTS: any = result.msg;
        console.log(AGENTS);
        this.subAgents.map((agent, index) => {
          AGENTS.map((AGENT, AGENTINDEX) => {
            if (AGENT.value === agent.value) {
              console.log('MATCHED!!!!');
              agent.ACCESS_CTRL = AGENT.ACCESS_CTRL;
            }
          });
        });
      }
    });
  }

  isSuperUser() {
    const role: any = SessionHelper.getSession('adm_ctrl');
    let IsSuperUser: Boolean = false;
    if (role) {
      switch (role) {
        case 'SUPER_USER_1':
          IsSuperUser = true;
          break;
      }
    }
    return IsSuperUser;
  }

  public async changeSiteName(sitename: NgForm, event) {
    event.preventDefault();
    console.log(sitename, event);
    if (sitename.valid && sitename.value.sitename) {
      this.SiteMsg = 'Checking please wait...';
      const payload: any = {
        name: sitename.value.sitename
      };
      this.SiteMsgBoxShow = true;
      const checkDomain = await this._MasterService.checkDomainAvailable(payload).toPromise();
      const result: any = await checkDomain;
      console.log(result);
      if (result.status === 'false') {
        this.SiteMsg = result.Message;
      } else {
        this.SiteMsg = 'Updating please wait...';
        const DomainPayload: any = {
          UserId: this.currentUserId,
          AliasName: sitename.value.sitename,
          AliasUrl: 'http://10.21.21.210:4200/' + sitename.value.sitename
        };
        console.log(DomainPayload);
        const checkDomainResult: any = await this._MasterService.changeDomainName(DomainPayload).toPromise();
        const DomainResult: any = await checkDomainResult;
        this.SiteMsg = DomainResult.message;
        if (JSON.parse(DomainResult.status)) {
              console.log('initiate routing...');
              SessionHelper.setSession('agentURLParam', sitename.value.sitename);
           //   this.router.navigateByUrl(this._primaryComp + '/account');
              window.location.reload();
        }
      }
    } else {
      Snackbar.show({
        text: 'Please enter site name',
        pos: 'bottom-right',
        actionTextColor: 'red',
      });
    }
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
