import { SharedService } from './../../shared/shared.service';
import { UserControl } from './../../helpers/user-control';
import { Component, OnInit, DoCheck } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { SessionValueResetService } from '../../services/session-value-reset.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
@Component({
  selector: 'app-my-wishlist',
  templateUrl: './my-wishlist.component.html',
  styleUrls: ['./my-wishlist.component.css']
})
export class MyWishlistComponent implements OnInit, DoCheck {
  public tempNo: any;
  public userSessionInfo: any;
  public userId: any;
  public whishListAvailable: Boolean;
  public whishLists: Array<any>;
  public DeliveryCharges;
  public Gst;
  public discount;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _SessionValueResetService: SessionValueResetService, private _SharedService: SharedService) {
    this.DeliveryCharges = 150;
    this.Gst = 72;
    this.discount = 0;
    this._primaryComp = '/' + navUrl.navUrl();
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    if (UserInfo != null || UserInfo !== undefined) {
      this.userId = JSON.parse(UserInfo).uid; console.log(this.userId);
      this._MasterService.getWishList(this.userId).subscribe((data) => {
        const result: any = data; console.log(result);
        if (result.success) {
          this.whishListAvailable = result.success;
          result.response.map((wishlist) => {
            wishlist.travellerTabSelected = false;
            wishlist.deliveryTabSelected = false;
          });
          this.whishLists = result.response;
          console.log(this.whishLists);
        } else {
          this.whishListAvailable = false;
        }
      });
    } else {
      sessionStorage.removeItem('currentUser');
      window.location.href = this._primaryComp + '/login';
    }

    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
  }

  ngOnInit() {

  }
  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }
  selectedTravellerTab(wishListIndex: any) {
    console.log(wishListIndex);
    this.whishLists.map((wishlist) => {
      wishlist.travellerTabSelected = false;
      wishlist.deliveryTabSelected = false;
    });
    this.whishLists[wishListIndex].travellerTabSelected = true;
  }

  selectedDeliveryTab(wishListIndex: any) {
    console.log(wishListIndex);
    this.whishLists.map((wishlist) => {
      wishlist.travellerTabSelected = false;
      wishlist.deliveryTabSelected = false;
    });
    this.whishLists[wishListIndex].deliveryTabSelected = true;
  }


  processTempNo(wishList) {
    switch (wishList.type) {
      case 'buyScreen':
        this._SessionValueResetService.getUserSessionInfo('userSessionInfo', wishList);
        this.router.navigateByUrl(this.navUrl.navUrl() + wishList.nextLink);
        break;
      case 'sellScreen':
        this._SessionValueResetService.getUserSessionInfo('userSessionInfoSale', wishList);
        this.router.navigateByUrl(this.navUrl.navUrl() + wishList.nextLink);
        break;
      case 'reloadCardScreen':
        this._SessionValueResetService.getUserSessionInfo('userSessionInfoRealoadCard', wishList);
        this.router.navigateByUrl(this.navUrl.navUrl() + wishList.nextLink);
        break;
      case 'sendMoneyScreen':
        this._SessionValueResetService.getUserSessionInfo('userSessionInfoSend', wishList);
        this.router.navigateByUrl(this.navUrl.navUrl() + wishList.nextLink);
        break;
    }
    // this.tempNo = wishList.temporaryOrderNumber;
    // console.log('tempNo: ' + this.tempNo);
    // if (SessionHelper.getSession('userInfo')) {
    //   const userInfo = JSON.parse(SessionHelper.getSession('userInfo'));
    //   this._MasterService.getOrderData(this.tempNo, userInfo.uid)
    //     .subscribe(data => {
    //       const sessionData: any = data;

    //       if (sessionData.buyScreen) {
    //         SessionHelper.setSession('userSessionInfo', JSON.stringify(sessionData));
    //       } else if (sessionData.sellScreen) {
    //         SessionHelper.setSession('userSessionInfoSale', JSON.stringify(sessionData));
    //       } else if (sessionData.reloadCardScreen) {
    //         SessionHelper.setSession('userSessionInfoRealoadCard', JSON.stringify(sessionData));
    //       } else if (sessionData.sendMoneyScreen) {
    //         SessionHelper.setSession('userSessionInfoSend', JSON.stringify(sessionData));
    //       }
    //       this.router.navigateByUrl(this.navUrl.navUrl() + sessionData.nextLink);
    //     }, err => {

    //     });
    // } else {
    //   // TODO: redirect to login with next values set..
    //   SessionHelper.setSession('tempNo', this.tempNo);
    //   this.router.navigateByUrl(this.navUrl.navUrl() + '/login');
    // }
  }



  cancelOrder(wishList: any) {
    wishList.isActive = false;
    this._MasterService.dumpSessionData(wishList)
      .subscribe(resD => {
        this._MasterService.getWishList(this.userId).subscribe((data) => {
          const result: any = data;
          if (result.success) {
            this.whishListAvailable = result.success;
            result.response.map((wishlist) => {
              wishlist.travellerTabSelected = false;
              wishlist.deliveryTabSelected = false;
            });
            this.whishLists = result.response;

          } else {
            this.whishListAvailable = false;
            this.whishLists = null;
          }
        });
      }, err => {
        console.log(err);
      });

  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
