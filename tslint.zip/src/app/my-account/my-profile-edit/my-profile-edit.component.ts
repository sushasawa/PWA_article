import { UserControl } from './../../helpers/user-control';
import { Component, OnInit, ViewChild, AfterViewInit, EventEmitter, HostListener, DoCheck } from '@angular/core';
import { MasterService } from '../../../app/services/master.services';
import { CanComponentDeactivate } from '../../../app/services/can-deactivate-guard.service';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { DpDatePickerModule } from 'ng2-date-picker';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';
import { MyAccountBannerComponent } from '../my-account-banner/my-account-banner.component';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { SharedService } from '../../shared/shared.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare var $: any;
@Component({
  selector: 'app-my-profile-edit',
  templateUrl: './my-profile-edit.component.html',
  styleUrls: ['./my-profile-edit.component.css'],

})


export class MyProfileEditComponent implements OnInit, AfterViewInit, CanComponentDeactivate, DoCheck {
  @ViewChild(UserBannerInfoComponent) UserBannerInfoComponent;
  @ViewChild(MyAccountBannerComponent) MyAccountBannerComponent;
  public checkCurrentUserSession: any;
  public currentUserInfo: any;
  public currentTraveller: any;
  public formdata: any;
  public userInfo: any;
  public nationalityOptions: any;
  public cityOptions: any;
  public sessionUpdater: EventEmitter<any> = new EventEmitter<any>();
  public config: any;
  public todaysDate: any;
  public configDob: any;
  public configsMin: any = [];
  public configsMax: any = [];
  public userSessionInfoTravellers: any;
  public termsAcceptance: any = false;
  public leadTraveller: any;
  public coTraveller: any;
  public travellerSelected: any = 'main';
  public hasCoTraveller: any = true;
  public leadIndex: any;
  public coTravellerIndex: any;
  public travellerInfo: any;
  public navigate: any = false;
  public invalidsubmitted: any;
  public termsAcceptanceAdhar: any;
  public currentUserId: any;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  public skipAdhaarValidationFlag: any = false;
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private routerA: ActivatedRoute, private _SharedService: SharedService) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this.currentUserId = JSON.parse(UserInfo).uid;
    this._primaryComp = '/' + navUrl.navUrl();
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    this.skipAdhaarValidationFlag = this._MasterService.getSkipAdhaarValidationFlag();
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    if (UserInfo == null || UserInfo === undefined) {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    this.currentUserInfo.traveller[0].selected = true;
    this.userInfo = {};
    this.currentTraveller = this.currentUserInfo.traveller[0];
    this.leadIndex = 0;
    this._MasterService.getNationalityList()
      .subscribe(data => {
        this.nationalityOptions = data;
      });

    this._MasterService.getCityList()
      .subscribe(data => {
        // console.log(data)
        this.cityOptions = data;

      });

    this.config = {
      format: 'DD-MM-YYYY'
    };

    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
  }

  ngOnInit() {
    this.todaysDate = this._MasterService.getTodaysDate();
    this.configDob = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.userSessionInfoTravellers = this.currentUserInfo.traveller;
    this.currentUserInfo.traveller.forEach((traveller, index) => {
      this.setDateConfig(traveller.registrationInfo.dateOfIssue, traveller.registrationInfo.expiryDate, index);
    });
  }

  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }

  ngAfterViewInit() {
    // console.log(this.UserBannerInfoComponent);
  }

  selectedTraveller(index: any) {
    this.currentUserInfo.traveller.map((traveller) => {
      traveller.selected = false;
    });
    this.currentUserInfo.traveller[index].selected = true;
  }
  callPinCodeService(event, type, index) {
    const pinCode = event.target.value;

    // this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['city'] = '##Service offline##';
    // this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['state'] = '##Service offline##';
    // this.userSessionInfoTravellers[this.selIndex].registrationInfo[type]['area'] = '##Service offline##';

    this._MasterService.getPinCodeDetails(pinCode)
      .subscribe(data => {
        const Retdata: any = data;
        if (Retdata.Status === 'Success') {
          this.currentUserInfo.traveller[index].registrationInfo[type]['city'] = Retdata.PostOffice[0].District;
          this.currentUserInfo.traveller[index].registrationInfo[type]['state'] = Retdata.PostOffice[0].State;
          this.currentUserInfo.traveller[index].registrationInfo[type]['area'] = Retdata.PostOffice[0].Name;
        } else {
          this.currentUserInfo.traveller[index].registrationInfo[type]['city'] = '';
          this.currentUserInfo.traveller[index].registrationInfo[type]['state'] = '';
          this.currentUserInfo.traveller[index].registrationInfo[type]['area'] = '';
        }
      });
  }
  uploadPic(type: any, traveller: any, travellerIndex: any, photo: any) {
    const photos = photo.target.files;
    this.userInfo.parent = true;
    this.userInfo.type = type;
    this.userInfo.index = travellerIndex;
    this.userInfo.parent_id = this.currentUserId;
    this.formdata = new FormData();
    this.formdata.append('userInfo', JSON.stringify(this.userInfo));

    for (let i = 0; i < photos.length; i++) {
      const fileValidation = (photos[i].type.indexOf('jpeg') !== -1
        || photos[i].type.indexOf('png') !== -1
        || photos[i].type.indexOf('gif') !== -1) && photos[i].size <= 500000;

      if (fileValidation) {
        this.formdata.append('profile', photos[i], photos[i].name);

        this._MasterService.getUserProfilePic(this.formdata)
          .subscribe((data) => {

            const result: any = data;
            if (result.response.userinfo.type === 'profile') {
              this.currentUserInfo.traveller[result.response.userinfo.index].profileInfo.picture = result.response.imgUrl;
            } else {
              this.currentUserInfo.traveller[result.response.userinfo.index].profileInfo.cover = result.response.imgUrl;
            }
            this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
            this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
            SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
            // this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
            this.formdata = {};

          });
      } else {
        Snackbar.show({
          text: 'Invalid File, Supports JPEG, PNG and GIF. The file size should not exceed 500 KB.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        console.log('Invalid file');
      }

    }
  }

  updateSession1(registrationInfo, value, index) {
    setTimeout(() => {
      registrationInfo[index] = value.split(/\b/g).map(word => this.titleCaseWord(word)).join('');
    }, 10);
  }

  titleCaseWord(word: string) {
    // tslint:disable-next-line:curly
    if (!word) return word;
    return word[0].toUpperCase() + word.substr(1).toLowerCase();
  }

  Gender(index, newValue: any) {
    this.currentUserInfo.traveller[index].registrationInfo.gender.value = newValue;
    console.log(this.currentUserInfo.traveller[index].registrationInfo.gender.value);
  }

  skipAdhaarValidation() {

    const travellerRegistrationInfo = [];
    const indexOfArray = 0;
    travellerRegistrationInfo.push(this.leadTraveller.registrationInfo);

    this._MasterService.updateUserRegistration(travellerRegistrationInfo)
      .subscribe((response) => {
        const result: any = response;
        if (JSON.parse(result.response[0].success)) {

          Snackbar.show({
            text: 'Success, Profile Updated...',
            pos: 'bottom-right',
            actionTextColor: '#05ff01',
          });
        }
        this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
        this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
        SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
        this.navigate = true;
        $.magnificPopup.close();
        this.router.navigate([this.navUrl.navUrl() + '/account/my-profile'], { queryParams: { traveller: this.leadIndex } });
      });
  }

  ValidateAdhar() {
    if (!this.termsAcceptanceAdhar) {
      // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
      Snackbar.show({
        text: 'Cannot proceed!, Please accept Adhaar terms and conditions to proceed',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
      return;
    }
    const travellerRegistrationInfo = [];
    let indexOfArray = 0;
    travellerRegistrationInfo.push(this.leadTraveller.registrationInfo);
    if (this.coTraveller) {
      indexOfArray = 1;
      travellerRegistrationInfo.push(this.coTraveller.registrationInfo);
    }

    // tslint:disable-next-line:max-line-length
    this._MasterService.validateAdhaar({ 'adharNo': travellerRegistrationInfo[indexOfArray].adharCardNo.value, 'name': travellerRegistrationInfo[indexOfArray].firstName.value })
      .subscribe(data => {
        const returnDate: any = data;
        console.log(returnDate);
        // tslint:disable-next-line:one-line
        if (returnDate.ReturnType !== 'Error') {
          this._MasterService.updateUserRegistration(travellerRegistrationInfo)
            .subscribe((response) => {
              const result: any = response;
              if (JSON.parse(result.response[0].success)) {
                // swal('Success', 'Profile Updated...', 'success');
                Snackbar.show({
                  text: 'Success, Profile Updated...',
                  pos: 'bottom-right',
                  actionTextColor: '#05ff01',
                });
              }
              this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
              this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
              SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
              this.navigate = true;
              $.magnificPopup.close();
              this.router.navigate([this.navUrl.navUrl() + '/account/my-profile'], { queryParams: { traveller: this.leadIndex } });
            });
        } else {
          Snackbar.show({
            text: 'Cannot proceed , Adhar validation failed. Please enter correct adhar details.',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        }
      });
  }

  updateRegister(userForm: NgForm, currentUserInfo) {
    console.log(userForm);
    console.log(currentUserInfo);
    const travellerRegistrationInfo = [];
    this.invalidsubmitted = userForm.invalid;
    if (userForm.valid) {
      if (!this.termsAcceptance) {
        // swal('Cannot proceed', 'Please accept terms and conditions to proceed', 'error');
        Snackbar.show({
          text: 'Please fill the mandatory fields highlighted.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      } else {
        // if (this.skipAdhaarValidationFlag) {
          this.skipAdhaarValidation();
        // } else {
        //   setTimeout(() => {
        //     $.magnificPopup.open({
        //       items: {
        //         src: '#consent-popup'
        //       },
        //       type: 'inline'
        //     });
        //   }, 100);
        // }
      }
    } else {
      // swal('Cannot proceed', 'Please fill required inputs', 'error');
      Snackbar.show({
        text: 'Cannot proceed, Please fill the mandatory fields highlighted.',
        pos: 'bottom-right',
        actionTextColor: '#ff4444',
      });
    }
    console.log(travellerRegistrationInfo);
  }

  //  date picker code starts
  dataChangeBirth(travellerIndex: any, event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.currentUserInfo.traveller[travellerIndex].registrationInfo.dateOfBirth.value = event;
      SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
    }
  }

  dataChangeStart(travellerIndex: any, event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.currentUserInfo.traveller[travellerIndex].registrationInfo.dateOfIssue = event;
      SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
      this.configsMin[travellerIndex] = {
        format: 'DD-MM-YYYY',
        min: this._MasterService.addDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    }
  }

  dataChangeEnd(travellerIndex: any, event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.currentUserInfo.traveller[travellerIndex].registrationInfo.expiryDate = event;
      SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
      this.configsMax[travellerIndex] = {
        format: 'DD-MM-YYYY',
        max: this._MasterService.substractDateMoment(event, 5, 'years'),
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    }
  }

  cancelEdit() {
    let currentIndex;
    this.navigate = true;
    currentIndex = this.leadIndex;
    //  this.router.navigate([this.navUrl.navUrl() + '/account/my-profile'], {queryParams: {traveller: this.leadIndex}});
  }

  setDateConfig(startDate, endDate, index) {
    let maxDate = '',
      minDate = '';
    this.todaysDate = this._MasterService.getTodaysDate();
    if (startDate !== '') {
      minDate = startDate;
    }
    if (endDate !== '') {
      maxDate = endDate;
    }
    this.configsMin[index] = {
      format: 'DD-MM-YYYY',
      min: minDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.configsMax[index] = {
      format: 'DD-MM-YYYY',
      max: maxDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }
  //  date picker code ends

  // RADIO FUNCTION FOR CURRENT ADDRESS SELECTION
  radioCurrentAddress(statusName, index) {
    // this.userSessionInfoTravellers[index].registrationInfo.currentAddressAs = statusName;
    this.currentUserInfo.traveller[index].registrationInfo.currentAddressAs = statusName;
    SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
  }

  canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
    // if(this.navigate === true){
    return true;
    // } else{
    //   Snackbar.show({
    //     text: 'Please save or cancel currently edited form.',
    //     pos: 'bottom-right',
    //     actionTextColor: '#ff4444',
    //   });
    //   return false;
    // }
  }

  termsConditions() {
    $.magnificPopup.close();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#terms-conditions'
        },
        type: 'inline'
      });
    }, 100);
  }

  checkEmail(event, userForm: NgForm, travellerIndex) {
    if (event.target.value) {
      this._MasterService.getEmailValidation(event.target.value)
        .subscribe(data => {
          const retData: any = data;
          if (retData.message.status === 'emailNotExists') {
            this.currentUserInfo.traveller[travellerIndex] = this.userSessionInfoTravellers[travellerIndex];
            SessionHelper.setSession('currentUser', JSON.stringify(this.currentUserInfo));
            $('.confirmEmailId0 > div > ul > li').css('background-color', 'rgb(0, 255, 0)');
          } else if (retData.message.status === 'emailExists') {
            this.currentUserInfo.traveller[travellerIndex].registrationInfo.contactDetails.emailId = '';
            $('.confirmEmailId0 > div > ul > li').css('background-color', 'red');
            Snackbar.show({
              text: 'This email ID already exists, please log-in with your email ID.',
              pos: 'bottom-right',
              actionTextColor: '#ff4444',
            });
          }
        });
    }
  }

  privacyPolicy() {
    $.magnificPopup.close();
    setTimeout(() => {
      $.magnificPopup.open({
        items: {
          src: '#privacy-policy'
        },
        type: 'inline'
      });
    }, 100);
  }



  // ngOnDestroy() {
  //   console.log('this is working');
  // }

  @HostListener('window:beforeunload')
  doSomething() {
    this.cancelEdit();
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
