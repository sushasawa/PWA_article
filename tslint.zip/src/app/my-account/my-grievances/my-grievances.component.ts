import { Component, OnInit, DoCheck } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { UserControl } from './../../helpers/user-control';
import { SharedService } from '../../shared/shared.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-my-grievances',
  templateUrl: './my-grievances.component.html',
  styleUrls: ['./my-grievances.component.css']
})
export class MyGrievancesComponent implements OnInit, DoCheck {
  public services: Array<any>;
  public products: Array<any>;
  public Products: Array<any>;
  public reloadProducts: Array<any>;
  public send: Array<any>;
  public invalidsubmitted: Boolean;
  public userId: any;
  public selectedProduct: any;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _SharedService: SharedService) {
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    this._primaryComp = '/' + navUrl.navUrl();
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    this.userId = JSON.parse(SessionHelper.getSession('userInfo')).uid;
    if (this.userId == null && this.userId === undefined) {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    this.products = [
      { value: 'Prepaid Card', label: 'Prepaid Card' },
      { value: 'Cash', label: 'Cash' },
      { value: 'Traveller\'s Cheque', label: 'Traveller\'s Cheque' },
      { value: 'Demand Draft', label: 'Demand Draft' }
    ];

    this.reloadProducts = [
      { value: 'PPC', label: 'PPC' },
    ];

    this.send = [
      { value: 'Telegraphic Transfer', label: 'Telegraphic Transfer' },
    ];



    this.services = [
      { value: 'Buy', label: 'Buy Forex' },
      { value: 'Sell', label: 'Sell Forex' },
      { value: 'Reload', label: 'Reload PPC' },
      { value: 'send', label: 'Send money abroad' }
    ];
    this.Products = this.products;
    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
  }

  ngOnInit() {

  }
  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }
  createComplain(grievances: any) {
    this.invalidsubmitted = grievances.invalid;
    console.log(grievances);
    const payload = grievances.value;
    payload.complaintId = Math.floor(Date.now() / 1000);
    payload.userId = this.userId;
    if (grievances.valid) {
      this._MasterService.setGrievances(payload)
        .subscribe((data) => {
          const result: any = data;
          console.log(result);
          //swal('Complaint Created.', 'Complaint id is ' + payload.complaintId, 'success');
          Snackbar.show({
            text: 'Complaint Created. Complaint id is ' + payload.complaintId,
            pos: 'bottom-right',
            actionTextColor: '#05ff01',
          });
        }, (error) => {
          //swal('Error creating complaint', '', 'error');
          Snackbar.show({
            text: 'Error creating complaint',
            pos: 'bottom-right',
            actionTextColor: '#ff4444',
          });
        });
    }
  }

  changeProducts(event) {


    switch (event) {
      case 'Buy':
        this.Products = this.products;
        break;
      case 'Sell':
        this.Products = this.products;
        break;
      case 'Reload':
        this.Products = this.reloadProducts;
        break;
      case 'send':
        this.Products = this.send;
        break;
    }
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
