import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyGrievancesComponent } from './my-grievances.component';

describe('MyGrievancesComponent', () => {
  let component: MyGrievancesComponent;
  let fixture: ComponentFixture<MyGrievancesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyGrievancesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyGrievancesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
