import { SharedService } from './../shared/shared.service';
import { LogoServiceService } from './../services/logo-service.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SelectModule } from 'ng-select';
import { NumberLocalePipe } from '../pipes/number-locale.pipe';
import { OrderFilterPipe } from '../pipes/order-filter.pipe';
import { OrderDateFilterPipe } from '../pipes/order-date-filter.pipe';
import { StatusFilterPipe } from '../pipes/status-filter.pipe';
import { AllOrderFilterPipe } from './../pipes/all-order-filter.pipe';
import { LimitToPipe } from './../pipes/limit-to.pipe';
import { PipesModule } from '../pipes/pipes.module';
import { DpDatePickerModule } from 'ng2-date-picker';
import { MasterService } from '../services/master.services';
import { CanDeactivateGuard } from '../services/can-deactivate-guard.service';
import { SessionValueResetService } from '../services/session-value-reset.service';
import { MyAccountBannerComponent } from './my-account-banner/my-account-banner.component';
import { MyOverviewComponent } from './my-overview/my-overview.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { MyOffersComponent } from './my-offers/my-offers.component';
import { MyOrdersComponent } from './my-orders/my-orders.component';
import { MyEnquiriesComponent } from './my-enquiries/my-enquiries.component';
import { MyWishlistComponent } from './my-wishlist/my-wishlist.component';
import { MyDocumentsComponent } from './my-documents/my-documents.component';
import { MyGrievancesComponent } from './my-grievances/my-grievances.component';
import { SupportComponent } from './support/support.component';
import { OffersModule } from '../offers-module/offers-module.module';
import { MySettingsComponent } from './my-settings/my-settings.component';
import { UserBannerInfoComponent } from './user-banner-info/user-banner-info.component';
import { MyProfileEditComponent } from './my-profile-edit/my-profile-edit.component';
import { MyEnquiriesEditComponent } from './my-enquiries-edit/my-enquiries-edit.component';
import { MyOrderConfirmationComponent } from './my-order-confirmation/my-order-confirmation.component';
import { AgmCoreModule } from '@agm/core';
import { UserAgentAccountCreationComponent } from './user-agent-account-creation/user-agent-account-creation.component';
import { MyCommissionComponent } from './my-commission/my-commission.component';
import { MyDocumentsEditComponent } from './my-documents-edit/my-documents-edit.component';

import { MyOrdersReportComponent } from './my-orders-report/my-orders-report.component';
import { DataSharingService } from './../services/data-sharing.service';
import { MyLeadsComponent } from './my-leads/my-leads.component';
import { SetRateComponent } from './set-rate/set-rate.component';
import { SessionHelper } from '../helpers/session-helper';
import { MyCommissionDetailsComponent } from './my-commission-details/my-commission-details.component';


const routes: Routes = [{
  path: '',
  children: [
    { path: '', component: MyOverviewComponent },
    { path: 'my-profile', component: MyProfileComponent },
    { path: 'my-offers', component: MyOffersComponent },
    { path: 'my-orders', component: MyOrdersComponent },
    { path: 'my-enquiries', component: MyEnquiriesComponent },
    { path: 'my-wishlist', component: MyWishlistComponent },
    { path: 'my-documents', component: MyDocumentsComponent },
    { path: 'my-grievances', component: MyGrievancesComponent },
    { path: 'support', component: SupportComponent },
    { path: 'my-settings', component: MySettingsComponent },
    { path: 'my-profile-edit', component: MyProfileEditComponent, canDeactivate: [CanDeactivateGuard] },
    { path: 'my-enquiries-edit', component: MyEnquiriesEditComponent },
    { path: 'my-commission', component: MyCommissionComponent },
    { path: 'my-commission-details', component: MyCommissionDetailsComponent },
    { path: 'user-agent-creation', component: UserAgentAccountCreationComponent },
    { path: 'my-documents-edit', component: MyDocumentsEditComponent },
    { path: 'my-orders-report', component: MyOrdersReportComponent },
    { path: 'my-leads', component: MyLeadsComponent },
    { path: 'set-margin', component: SetRateComponent },
    { path: 'set-rate' , redirectTo : 'set-margin' }
  ]
}];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    FormsModule,
    SelectModule,
    PipesModule,
    OffersModule,
    DpDatePickerModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAQaeIKoWfFMxZJxN3m4Bs1SJe4w-FX4Mk'
    })
  ],
  // tslint:disable-next-line:max-line-length
  declarations: [MyAccountBannerComponent, MyOverviewComponent, MyProfileComponent, MyOffersComponent, MyOrdersComponent, MyEnquiriesComponent, MyWishlistComponent, MyDocumentsComponent, MyGrievancesComponent, SupportComponent, MySettingsComponent, UserBannerInfoComponent, MyProfileEditComponent, MyEnquiriesEditComponent, MyOrderConfirmationComponent, UserAgentAccountCreationComponent, MyCommissionComponent, MyDocumentsEditComponent, MyOrdersReportComponent, MyLeadsComponent, SetRateComponent, MyCommissionDetailsComponent],
  providers: [MasterService, SessionValueResetService, CanDeactivateGuard, DataSharingService, LogoServiceService]
})
export class MyAccountModule {
  constructor(private _SharedService: SharedService) {
    this.getUserAccess();
    this._SharedService.getAgentTheme();
   }

  getUserAccess() {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    const role: any = SessionHelper.getSession('adm_ctrl');
    if (UserInfo && role) {
      const payload: any = {
        'agentid': JSON.parse(UserInfo).uid,
        'role': role
      };
      switch (role) {
        case 'ADMIN_2':
        case 'AGENT_3':
          this._SharedService.getUserAccessCtrl(payload);
          break;
      }
    }

  }
}
