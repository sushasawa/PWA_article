import { UserControl } from './../../helpers/user-control';
import { Component, OnInit, ViewChild, AfterViewInit, transition, DoCheck } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { SessionTemplate } from '../../../app/helpers/session-template';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';
import { MyAccountBannerComponent } from '../my-account-banner/my-account-banner.component';
import { NgForm } from '@angular/forms';
import { AgentMarginService } from '../../services/agent-margin.service';
import { SharedService } from '../../shared/shared.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare function initAccord(): any;

@Component({
  selector: 'app-set-rate',
  templateUrl: './set-rate.component.html',
  styleUrls: ['./set-rate.component.css']
})
export class SetRateComponent implements OnInit, AfterViewInit, DoCheck {
  @ViewChild(UserBannerInfoComponent) UserBannerInfoComponent;
  @ViewChild(MyAccountBannerComponent) MyAccountBannerComponent;

  public currentUserEmail: any;
  public currentUserId: any;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';

  public currencyList: Array<any>;
  public marginSet: Array<any>;



  // tslint:disable-next-line:max-line-length
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, public agentMargin: AgentMarginService, private _SharedService: SharedService) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserEmail = JSON.parse(UserInfo).uname;
      this.currentUserId = JSON.parse(UserInfo).uid;

    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }




    // Get currency details start
    this._MasterService.getAgentMargin(this.currentUserId).subscribe((data) => {
     console.log(data);
      const retData: any = data;
      // this.currencyList = retData.xml.config;
      this.currencyList = retData.root.element;
      console.log(this.currencyList);
      setTimeout(function () {
        initAccord();
      }, 200);
    }, (error) => {

      this._MasterService.AllCurrency().subscribe((res) => {
        const currancyListArray: any = [];
        const resultData: any = res;
        resultData.forEach(e => {
        //   console.log(e.Code);
          const CurrencyJson = {
            'buyCash': {
              'type': '2',
              'value': 0
            },
            'buyDD': {
              'type': '2',
              'value': 0
            },
            'buyPrepaid': {
              'type': '2',
              'value': 0
            },
            'currencyName': e.Code,
            'sellCash': {
              'type': '2',
              'value': 0
            },
            'sellPrepaid': {
              'type': '2',
              'value': 0
            }
          };
         // console.log(CurrencyJson);
          currancyListArray.push(CurrencyJson);
        });

        
        this.currencyList = currancyListArray;
        console.log(this.currencyList);
        setTimeout(function () {
          initAccord();
        }, 200);
      });
    });
    // GEt currency details end
    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
  }


  ngAfterViewInit() {

  }

  ngOnInit() {
    
  }

  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }


  // saveMargin() {


  //   const elementArray: any = [];
  //   this.currencyList.forEach(element => {
  //     elementArray.push(element);
  //   });

  //   console.log(elementArray);
  //   const payload = {
  //     'agentId': this.currentUserId,
  //     'xml': { 'element': elementArray }
  //   };


  //   this._MasterService.setAgentMargin(payload).subscribe((data) => {
  //     Snackbar.show({
  //       text: 'Margin set successfully.',
  //       pos: 'bottom-right',
  //       actionTextColor: '#00880d',
  //     });
  //     this.agentMargin.setAgentMargin();
  //     console.log(data);
  //   }, (err) => {
  //     console.log('Something went wrong.');
  //   });

  // }


  saveMargin() {

    const elementArray: any = [];
    let isValid = true;

    this.currencyList.some(element => {
      // console.log('element', element.buyCash);

      if (element.buyCash.type == 2) {
        if (Number(element.buyCash.value) > Number(element.buyCash.inrTh)) {          
          Snackbar.show({
            text: 'Buy Cash Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      } else if (element.buyCash.type == 1) {
        if (Number(element.buyCash.value) > Number(element.buyCash.perTh)) {
          Snackbar.show({
            text: 'Buy Cash Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      }

      if (element.buyDD.type == 2) {
        if (Number(element.buyDD.value) > Number(element.buyDD.inrTh)) {
          Snackbar.show({
            text: 'Buy DD/TT Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      } else if (element.buyDD.type == 1) {
        if (Number(element.buyDD.value) > Number(element.buyDD.perTh)) {
          Snackbar.show({
            text: 'Buy DD/TT Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      }

      if (element.buyPrepaid.type == 2) {
        if (Number(element.buyPrepaid.value) > Number(element.buyPrepaid.inrTh)) {
          Snackbar.show({
            text: 'Buy Prepaid Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      } else if (element.buyPrepaid.type == 1) {
        if (Number(element.buyPrepaid.value) > Number(element.buyPrepaid.perTh)) {
          Snackbar.show({
            text: 'Buy Prepaid Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      }


      if (element.sellCash.type == 2) {
        if (Number(element.sellCash.value) > Number(element.sellCash.inrTh)) {
          Snackbar.show({
            text: 'Sell Cash Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      } else if (element.sellCash.type == 1) {
        if (Number(element.sellCash.value) > Number(element.sellCash.perTh)) {
          Snackbar.show({
            text: 'Sell Cash Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      }


      if (element.sellPrepaid.type == 2) {
        if (Number(element.sellPrepaid.value) > Number(element.sellPrepaid.inrTh)) {
          Snackbar.show({
            text: 'Sell Prepaid Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      } else if (element.sellPrepaid.type == 1) {
        if (Number(element.sellPrepaid.value) > Number(element.sellPrepaid.perTh)) {
          Snackbar.show({
            text: 'Sell Prepaid Margin Exceded for ' + element.currencyName,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
          isValid = false;
          return true;
        }
      }



      elementArray.push(element);
      // console.log("elementArray",elementArray);
    });

    console.log(elementArray);


    if (isValid == true) {
      const payload = {
        'agentId': this.currentUserId,
        'xml': { 'element': elementArray }
      };


      this._MasterService.setAgentMargin(payload).subscribe((data) => {
        Snackbar.show({
          text: 'Margin set successfully.',
          pos: 'bottom-right',
          actionTextColor: '#00880d',
        });
        this.agentMargin.setAgentMargin();
        console.log(data);
      }, (err) => {
        console.log('Something went wrong.');
      });
    }



  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

  isNumberKeyWithDecimals(registrationInfo, value: any, index) {
    let oldValue,
      patt,
      res;
    oldValue = registrationInfo[index];
    value = value.toString();
    patt = new RegExp("^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$");
    res = patt.test(value);
    if (!res && value !== '') {
      setTimeout(() => {
        registrationInfo[index] = oldValue;
      }, 0);
    }
  }

  setDefaultZero(registrationInfo, index) {
    if(registrationInfo[index] === '' || registrationInfo[index] === '.'){
      registrationInfo[index] = 0;
    }
  }

}
