
import { NgForm } from '@angular/forms';
import { Component, OnInit, ViewChildren, AfterViewInit, QueryList, ViewChild, DoCheck } from '@angular/core';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';
import { MyAccountBannerComponent } from '../my-account-banner/my-account-banner.component';
import { UserControl } from './../../helpers/user-control';
import { DataSharingService } from './../../services/data-sharing.service';
import { SharedService } from '../../shared/shared.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
declare function initMyAccountJS(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})
export class MyOrdersComponent implements OnInit, AfterViewInit, AfterViewInit, DoCheck {
  public uid: any;
  public UserInfo: any;
  public currentUserInfo: any;
  public Transactions: any;
  public IsOrdersNotAvailable: Boolean = false;
  public Orders: Array<any>;
  public OrderFilter: Array<any>;
  public StatusFilter: Array<any>;
  public OrderSelected: any;
  public OrderType = '';
  public taskDetails: any;
  public StatusType = '';
  public Branches: any;
  public OrderSort = {
    OrderType: 'buy',
    StatusType: false
  };
  public todaysDate: any;
  public Offset: any = 0;
  public Limit: any = 15;
  public invalidsubmitted: any;
  public subAgents: any = [];
  public AllOrders: any = [];
  public TotalAvailableOrders: any;
  public PaginationButtons: any = [];
  public OrdersMsg: any;
  public Fetching: Boolean = false;
  public FetchingMsg: any;
  public fromDate: any = '';
  public toDate: any = '';
  public frmdateConfig: any;
  public todateConfig: any;
  @ViewChildren('OrderLoaded') OrderLoaded: QueryList<any>;
  @ViewChild(UserBannerInfoComponent) UserBannerInfoComponent;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public traveller: any;
  public _primaryComp: any;
  public fromDateInvoice: any = '';
  public todateConfigInvoice: any;
  public toDateInvoice: any = '';
  public frmdateConfigInvoice: any;
  public concertinaStatus: any = '';
  // tslint:disable-next-line:max-line-length
  constructor(private _MasterSevice: MasterService, private navUrl: NavigatePathService, private router: Router, private _DataSharingService: DataSharingService, private _SharedService: SharedService) {
    this.Offset = 0;
    this._primaryComp = '/' + navUrl.navUrl();
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    console.log(this.currentUserInfo);
    this.OrderFilter = [
      { 'label': 'Buy Forex', 'value': 'buy' },
      { 'label': 'Reload Card', 'value': 'reload' },
      { 'label': 'SendMoney Abroad', 'value': 'send' },
      { 'label': 'Sell Forex', 'value': 'sell' }
    ];
    this.StatusFilter = [
      { 'label': 'OPEN', 'value': 0 },
      { 'label': 'CLOSED', 'value': 1 }
    ];
    this.UserInfo = SessionHelper.getSession('userInfo');
    this.Orders = [];
    this.Transactions = [];
    if (this.UserInfo !== undefined || this.UserInfo != null) {
      this.uid = JSON.parse(this.UserInfo).uid;
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }


    const loggedInAgentPayload: any = {
      id: this.uid
    };

    this._MasterSevice.getSubAgents(loggedInAgentPayload).subscribe((data) => {
      const result: any = data;
      if (result.status) {
        this.subAgents = result.data[0];
      }
    });


    this._MasterSevice.getAllBranches().subscribe((data) => {
      const result: any = data;
      if (result.status) {
        this.Branches = result.data[0];
      }
    });
    this.OrdersMsg = 'Fetching Orders Please Wait...';
    const payload = {
      'AgentId': this.uid,
      'OffSet': this.Offset,
      'Limit': 15,
      'OrderDateFrom': null,
      'OrderDateTo': null,
      'BranchCode': null,
      'OrderType': null,
      'OrderStatus': null,
      'SubUserId': null
    };
    this._MasterSevice.getAgentOrderList(payload).subscribe((data) => {
      const result: any = data;
      if (result.status) {
        if (result.data[1][0].TotalRecords > 0) {
          this.TotalAvailableOrders = result.data[1][0].TotalRecords;
          this.AllOrders.push(result.data[0]);
          this.Orders = this.AllOrders[0];
          this.getPaginationButtons();
        } else {
          this.OrdersMsg = 'No Orders Found...';
        }

      } else {
        this.OrdersMsg = 'No Orders Found...';
      }

    });
    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
    this.setDateConfig();
  }

  ngOnInit() {
    initDocument();
    setTimeout(() => {
      initMyAccountJS();
    }, 500);


    this._DataSharingService.currentMessage.subscribe((data) => {
      console.log('DATA SHARED TO ORDERS MAIN COMPONENT');
      console.log(data);
    });
  }
  ngAfterViewInit() {
    initMyAccountJS();
  }
  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }
  removeFilter() {
    this.OrderType = '';
    this.StatusType = '';
  }

  reInitMyaccountJs() {
    initMyAccountJS();
  }



  public generateReport(report: NgForm) {

    this.invalidsubmitted = report.invalid;
    if (!this.invalidsubmitted) {
      const payload = report.value;
      payload.AgentId = this.uid;
      payload.OffSet = this.Offset;
      payload.Limit = this.Limit;
      this._DataSharingService.changeMessage(report.value);
      this.router.navigateByUrl(this.navUrl.navUrl() + '/account/my-orders-report');
    }

  }

  public getOrders(Index: any = 0) {
    if (this.AllOrders[Index]) {
      this.Orders = this.AllOrders[Index];
    } else {
      this.Fetching = true;
      this.FetchingMsg = 'Fetching Orders Please Wait...';
      this.Offset = this.Offset + 15;
      const payload = {
        'AgentId': this.uid,
        'OffSet': this.Limit * Index,
        'Limit': this.Limit,
        'OrderDateFrom': null,
        'OrderDateTo': null,
        'BranchCode': null,
        'OrderType': null,
        'OrderStatus': null,
        'SubUserId': null
      };
      this._MasterSevice.getAgentOrderList(payload).subscribe((data) => {
        const result: any = data;
        if (result.status) {
          if (result.data[1][0].TotalRecords > 0) {
            this.TotalAvailableOrders = result.data[1][0].TotalRecords;
            this.AllOrders[Index] = result.data[0];
            //  this.AllOrders.push(result.data[0]);
            this.Orders = this.AllOrders[Index];
            this.getPaginationButtons();
            this.Fetching = false;
            this.FetchingMsg = '...';
          } else {
            this.Fetching = true;
            this.FetchingMsg = 'No Orders Found.';
          }

        } else {
          this.Fetching = true;
          this.FetchingMsg = 'No More Orders.';
        }
      });
    }
  }

  public getPaginationButtons() {
    this.PaginationButtons = [];
    let index: any = 0;
    for (let i = 0; i <= this.TotalAvailableOrders; i += 15) {
      index = index + 1;
      this.PaginationButtons.push(index);
    }
    //  initMyAccountJS();
  }


  orderDetail(order) {
    this.taskDetails = 'display';
    this.OrderSelected = order;
    $.magnificPopup.open({
      items: {
        src: '#order-details-popup'
      },
      type: 'inline'
    });
  }

  setDateConfig(): void {
    const maxDate = '',
      minDate = '';
    this.todaysDate = this._MasterSevice.getTodaysDate();

    this.todateConfig = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.frmdateConfig = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }

  dataChangeStart(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.fromDate = event;
      this.todateConfig = {
        format: 'DD-MM-YYYY',
        min: event,
        max: this.todaysDate,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    } else if (!event) {
      this.fromDate = '';
    }
  }

  dataChangeEnd(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.toDate = event;
      this.frmdateConfig = {
        format: 'DD-MM-YYYY',
        max: event,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    } else if (!event) {
      this.toDate = '';
    }
  }

  setDateConfigInvoice(): void {
    const maxDate = '',
      minDate = '';
    this.todaysDate = this._MasterSevice.getTodaysDate();
    this.todateConfigInvoice = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.frmdateConfigInvoice = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }

  dataChangeStartInvoice(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.fromDateInvoice = event;
      this.todateConfigInvoice = {
        format: 'DD-MM-YYYY',
        min: event,
        max: this.todaysDate,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    } else if (!event) {
      this.fromDateInvoice = '';
    }
  }

  dataChangeEndInvoice(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.toDateInvoice = event;
      this.frmdateConfigInvoice = {
        format: 'DD-MM-YYYY',
        max: event,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    } else if (!event) {
      this.toDateInvoice = '';
    }
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
