
import { Component, OnInit, DoCheck } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { UserControl } from './../../helpers/user-control';
import { AgentDocumentsMetadata } from './../../helpers/agent-documents-metadata';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { NgForm } from '@angular/forms';
import { SharedService } from '../../shared/shared.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare function initAccord(): any;
declare function initMyAccountJS(): any;
@Component({
  selector: 'app-my-documents',
  templateUrl: './my-documents.component.html',
  styleUrls: ['./my-documents.component.css']
})
export class MyDocumentsComponent implements OnInit, DoCheck {
  public currentUserId;
  public Documents: any;
  public currentUserInfoTravellers: any;
  public formdata: any;
  public SelectedTravellerIndex: any;
  public close = document.getElementsByClassName('close')[0];
  public documentScr: any;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public DocumentTypes: any;
  public SubDocuments: any;
  public SelectedDocumentType: any;
  public SelectedSubDocumentType: any;
  public UserDocumentUploadDocumentStructure: any;
  public createUserDocsMetaData: any;
  public SubDocumentsTypes: any;
  public showModal: Boolean;
  public DocumentsMsg: any;
  public selectedDocument: any;
  public subAgents: any = [];
  public showInfo: Boolean = false;
  public displayBlockMsg: any = 'Uploading...';
  public _primaryComp: any;
  public concertinaStatus: any = '';
  public uploadedDocumentsStructure: any = {
    'DocumentType': '',
    'DocumentTypeLabel': '',
    'DocumentSubType': '',
    'DocumentSubTypeLabel': '',
    'DocumentUrl': 'assets/images/my-account/doc-thumb2.jpg',
    'MetaData': []
  };
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _SharedService: SharedService) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    this._primaryComp = '/' + navUrl.navUrl();
    this.SelectedDocumentType = '';
    this.SelectedSubDocumentType = '';
    this.currentUserInfoTravellers = JSON.parse(SessionHelper.getSession('currentUser'));
    this.SubDocuments = AgentDocumentsMetadata.getSubDocuments();
    this.DocumentTypes = AgentDocumentsMetadata.getDocumentTypes();
    this.UserDocumentUploadDocumentStructure = AgentDocumentsMetadata.getUserDocumentUploadDocumentStructure();
    if (!this.ACCESS_CTRL) {
      this.logout();
    }
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserId = JSON.parse(UserInfo).uid;
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    this.Documents = {
      'UserId': this.currentUserId,
      'Email': JSON.parse(UserInfo).uname,
      'AdmType': SessionHelper.getSession('adm_ctrl'),
      'uploaded': [],
      'pending': [],
      'expired': [],
      'lastUpdatedBy': null,
      'LastViewedBy': null
    };
    this.showInfo = false;
    this.displayBlockMsg = '';
    this.getAgentsDocument();
    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log(this._SharedService.subAgents);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }

    if (this._SharedService.subAgents && this.isSuperUser()) {
      this.subAgents = this._SharedService.subAgents;
      this.Documents.SubAgents = this.subAgents;
    }
  }

  ngOnInit() {
    $('body').attr('id', '');
    setTimeout(function () {
      initDocument();
      initAccord();
      initMyAccountJS();
    }, 0.2);
  }
  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
    this._SharedService.subAgentsEmitter.subscribe((Agents) => {
      this.subAgents = Agents;
      this.Documents.SubAgents = (this.isSuperUser() === true && this.subAgents) ? this.subAgents : [];
    });
  }
  updateDocumentType(type) {
    this.SelectedDocumentType = type;
    this.SubDocumentsTypes = this.SubDocuments[type];
  }

  selectSubDocumentType(type) {
    this.SelectedSubDocumentType = type;
    this.uploadedDocumentsStructure.DocumentSubType = type;
    this.uploadedDocumentsStructure.DocumentType = this.SelectedDocumentType;
    this.uploadedDocumentsStructure.DocumentTypeLabel = this.UserDocumentUploadDocumentStructure.Documents[this.SelectedDocumentType].Label;
    // tslint:disable-next-line:max-line-length
    this.uploadedDocumentsStructure.DocumentSubTypeLabel = this.UserDocumentUploadDocumentStructure.Documents[this.SelectedDocumentType].MetaData[type].Label;
    this.uploadedDocumentsStructure.MetaData = this.UserDocumentUploadDocumentStructure.Documents[this.SelectedDocumentType].MetaData[type].MetaData;
    // tslint:disable-next-line:max-line-length
    this.createUserDocsMetaData = this.UserDocumentUploadDocumentStructure.Documents[this.SelectedDocumentType].MetaData[this.SelectedSubDocumentType].MetaData;
  }




  logout() {
    SessionHelper.removeSession('userInfo');
    SessionHelper.removeSession('userSessionInfo');
    SessionHelper.removeSession('userSessionInfoSale');
    SessionHelper.removeSession('userSessionInfoRealoadCard');
    SessionHelper.removeSession('userSessionInfoSend');
    SessionHelper.removeSession('pageSessionParam');
    SessionHelper.removeSession('currentUser');
    SessionHelper.removeSession('adm_ctrl');
    window.location.href = this._primaryComp + '/';
  }

  closeDocpopup() {
    this.showModal = false;
  }

  viewDoc(uploadedDocument) {
    if (uploadedDocument.DocumentUrl != null || uploadedDocument.DocumentUrl !== undefined) {
      if (uploadedDocument.DocumentUrl.indexOf('.pdf') !== -1) {
        const documentScr = uploadedDocument.DocumentUrl;
        const newtab = window.open(documentScr, '_blank');
        newtab.focus();
      } else {
        this.documentScr = uploadedDocument.DocumentUrl;
        this.showModal = true;
      }


    }
  }


  getAgentsDocument() {
    this.DocumentsMsg = 'Fetching Documents Please Wait...';
    const payload: any = {
      'UserId': this.currentUserId,
      'Email': JSON.parse(SessionHelper.getSession('userInfo')).uname,
      'AdmType': SessionHelper.getSession('adm_ctrl')
    };
    this._MasterService.getAgentDocuments(payload)
      .subscribe((data) => {
        const result: any = data;
        if (result.success) {
          this.Documents = result.Docs;
          this.DocumentsMsg = 'You have not Uploaded any doument.';
        } else {
          this.DocumentsMsg = result.message;
        }
        this.getPendingDocuments();
      },
        (error) => {
          const result: any = error;
          this.DocumentsMsg = 'Something went wrong while fetching the documents.';
          // Snackbar.show({
          //   text: result.message,
          //   pos: 'bottom-right',
          //   actionTextColor: '#00880d',
          // });
        });
  }

  saveDocuments() {
    const userInfo = {
      'UserId': this.currentUserId,
      'Email': JSON.parse(SessionHelper.getSession('userInfo')).uname,
      'AdmType': SessionHelper.getSession('adm_ctrl'),
      'UserName': JSON.parse(SessionHelper.getSession('userInfo')).userName,
      'ViewedTime': new Date()
    };
    this.Documents.LastViewedBy = userInfo;
    if (this._SharedService.subAgents && this.isSuperUser()) {
      this.subAgents = this._SharedService.subAgents;
      this.Documents.SubAgents = this.subAgents;
    }
    this._MasterService.saveAgentDocuments(this.Documents)
      .subscribe((data) => {
        const result: any = data;
        this.showInfo = false;
        Snackbar.show({
          text: result.message,
          pos: 'bottom-right',
          actionTextColor: '#00880d',
        });
      },
        (error) => {
          const result: any = error;
          Snackbar.show({
            text: result.message,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
        });
  }

  loadDocument(file: any) {
    this.formdata = new FormData();
    const docs = file.target.files[0];
    const userInfo = {
      'UserId': this.currentUserId,
      'Email': JSON.parse(SessionHelper.getSession('userInfo')).uname,
      'AdmType': SessionHelper.getSession('adm_ctrl')
    };
    this.formdata.append('agentDocument', docs, docs.name);
    this.formdata.append('agentInfo', JSON.stringify(userInfo));
  }


  uploadDocument(e: Event) {
    const userInfo = {
      'UserId': this.currentUserId,
      'Email': JSON.parse(SessionHelper.getSession('userInfo')).uname,
      'AdmType': SessionHelper.getSession('adm_ctrl'),
      'UserName': JSON.parse(SessionHelper.getSession('userInfo')).userName,
      'UpdateTime': new Date()
    };
    e.preventDefault();
    if (this.uploadedDocumentsStructure.DocumentType && this.uploadedDocumentsStructure.DocumentSubType && this.selectedDocument) {
      if (this.Documents.uploaded.length > 0) {
        this.Documents.uploaded.map((document, index) => {
          if (document.DocumentType === this.uploadedDocumentsStructure.DocumentType) {
            this.Documents.uploaded.splice(index, 1);
          }
        });
      }
      this.showInfo = true;
      this.displayBlockMsg = 'Uploading...';
      this._MasterService.uploadAgentDocument(this.formdata).subscribe((data) => {
        Snackbar.show({
          text: 'Uploaded...',
          pos: 'bottom-right',
          actionTextColor: '#00880d',
        });
        this.displayBlockMsg = 'saving...';
        this.formdata = {};
        const result: any = data;
        this.uploadedDocumentsStructure.DocumentUrl = result.documentUrl;
        this.Documents.uploaded.push(this.uploadedDocumentsStructure);
        this.Documents.lastUpdatedBy = userInfo;
        this.uploadedDocumentsStructure = {};
        this.selectedDocument = '';
        this.SelectedDocumentType = '';
        this.SelectedSubDocumentType = '';
        this.getPendingDocuments();
      }, (error) => {
        this.displayBlockMsg = 'Something went wrong while uploading the document.Please try again later.';
      });
    } else {
      Snackbar.show({
        text: 'All Fields Are Required.',
        pos: 'bottom-right',
        actionTextColor: '#00880d',
      });
    }


  }

  getPendingDocuments() {
    this.Documents.pending = [];
    const Documents: any = this.UserDocumentUploadDocumentStructure.Documents;
    const StructureKeys: any = [];
    for (const document in Documents) {
      if (Documents.hasOwnProperty(document)) {
        StructureKeys.push(document);
      }
    }
    if (this.Documents.uploaded.length > 0) {
      this.Documents.uploaded.map((UDoc, UIndex) => {
        const RemoveElementIndex: any = StructureKeys.indexOf(UDoc.DocumentType);
        StructureKeys.splice(RemoveElementIndex, 1);
      });


    }
    if (StructureKeys.length > 0) {
      StructureKeys.map((remainingItem, remainingIndex) => {
        this.Documents.pending.push(Documents[remainingItem]);
      });
    } else {
      this.Documents.pending = [];
    }
    this.saveDocuments();
  }

  isSuperUser() {
    const role: any = SessionHelper.getSession('adm_ctrl');
    let IsSuperUser: Boolean = false;
    if (role) {
      switch (role) {
        case 'SUPER_USER_1':
          IsSuperUser = true;
          break;
      }
    }
    return IsSuperUser;
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
