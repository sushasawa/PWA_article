import { SharedService } from './../../shared/shared.service';
import { MasterService } from './../../services/master.services';
import { Component, OnInit, DoCheck } from '@angular/core';
import { UserControl } from './../../helpers/user-control';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
declare function initAccord(): any;
@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.css']
})
export class SupportComponent implements OnInit, DoCheck {
  public branchOptions: any;
  public cityOptions: any;
  public name: any;
  public email: any;
  public mobileNumber: any;
  public cityName: any;
  public feedback: any;
  public CityDetails: any;
  public mymap: any;
  public BranchDetails: any;
  public BranchDetailsEnable: any;
  public branchPickupDetails: any;
  public userCity: any;
  public userBranch: any;
  public lat: number;
  public lng: number;
  public zoom: any = 15;
  public maploaded: any = false;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  // tslint:disable-next-line:no-shadowed-variable
  constructor(private MasterService: MasterService, private navUrl: NavigatePathService, private _SharedService: SharedService) {

    this.updateBranch(this.MasterService.turnerMorrisonBranchId);
    this._primaryComp = '/' + navUrl.navUrl();
    this.MasterService.getBranchList('mumbai')
      .subscribe(data => {
        this.branchOptions = data;

      });

    this.MasterService.getCityList()
      .subscribe(data => {
        this.cityOptions = data;

      });
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
  }

  ngOnInit() {

    setTimeout(function () {
      //initDocument();
      initAccord();
    }, 200);
  }

  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }
  updateCity(newValue: string) {
    this.MasterService.getBranchList(newValue.split('#')[1])
      .subscribe(data => {
        this.branchOptions = data;
      });
  }

  updateBranch(newValue: number) {
    this.MasterService.getBranchDetails(newValue)
      .subscribe(data => {
        this.BranchDetails = data;
        this.BranchDetailsEnable = true;
        // const currentDocument = this;
        // setTimeout(function () {
        // if (currentDocument.mymap === undefined) {
        //   currentDocument.mymap = L.map('mapidContactUs', { attributionControl: false });
        //   L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
        //     attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors,'
        //       + ' <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>,'
        //       + ' Imagery © <a href="http://mapbox.com">Mapbox</a>',
        //     maxZoom: 18,
        //     id: 'mapbox.streets',
        //     accessToken: 'pk.eyJ1Ijoia2FtbGVzaC1jbmsiLCJhIjoiY2phN3d5bGRsMDB1MzM3cW1iOHYzbHN3ZCJ9.sy4v_2XvDe4zm1peJeSCXQ'
        //   }).addTo(currentDocument.mymap);
        // }
        // L.marker([currentDocument.BranchDetails[0].latitude, currentDocument.BranchDetails[0].longitude]).addTo(currentDocument.mymap);

        this.lat = +this.BranchDetails[0].latitude;
        this.lng = +this.BranchDetails[0].longitude;
        if (this.BranchDetails[0].latitude && this.BranchDetails[0].longitude) {
          this.maploaded = true;
        } else {
          this.maploaded = false;
        }
        this.branchPickupDetails = this.BranchDetails[0].branchPickupDetails;
        // currentDocument.mymap.setView([currentDocument.BranchDetails[0].latitude, currentDocument.BranchDetails[0].longitude], 15);
        // }, 5);
      });
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
