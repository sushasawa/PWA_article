
import { NgForm } from '@angular/forms';
import * as moment from 'moment';
import { Component, OnInit, ViewChildren, AfterViewInit, QueryList, ViewChild, DoCheck } from '@angular/core';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';
import { MyAccountBannerComponent } from '../my-account-banner/my-account-banner.component';
import { UserControl } from './../../helpers/user-control';
import { DataSharingService } from './../../services/data-sharing.service';
import { SharedService } from '../../shared/shared.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { ChangeDetectorRef } from '@angular/core';
declare var $: any;
declare function initDocument(): any;
declare function initMyAccountJS(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-my-leads',
  templateUrl: './my-leads.component.html',
  styleUrls: ['./my-leads.component.css']
})
export class MyLeadsComponent implements OnInit, DoCheck {
  public uid: any;
  public UserInfo: any;
  public currentUserInfo: any;
  public fromDate: any = '';
  public toDate: any = '';
  public TotalLeads: any = [];
  public Prospects: any = [];
  public Conversions: any = [];
  public Transactions: any = [];
  public selectedOfficer: any;
  public todaysDate: any;
  public subAgents: any = [];
  public fromSixMonth: any;
  public fromOneMonth: any;
  public Fetching: Boolean = true;
  public frmdateConfig: any;
  public todateConfig: any;
  public selectedSalesOfficer: any;
  public invalidsubmitted: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  // public countNumber: any = 0;
  public FetchingMsg: any = 'Fetching Leads Wait...';
  @ViewChildren('OrderLoaded') OrderLoaded: QueryList<any>;
  @ViewChildren('TotalLeadsEle') TotalLeadsEle: any;
  @ViewChildren('ProspectsEle') ProspectsEle: any;
  @ViewChildren('ConversionsEle') ConversionsEle: any;
  @ViewChildren('TransactionsEle') TransactionsEle: any;
  @ViewChild(UserBannerInfoComponent) UserBannerInfoComponent;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  // tslint:disable-next-line:max-line-length


  constructor(private _MasterSevice: MasterService, private cdRef:ChangeDetectorRef, private navUrl: NavigatePathService, private router: Router, private _DataSharingService: DataSharingService, private _SharedService: SharedService) {
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    this._primaryComp = '/' + navUrl.navUrl();
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    console.log(this.currentUserInfo);

    this.UserInfo = SessionHelper.getSession('userInfo');
    if (this.UserInfo !== undefined || this.UserInfo != null) {
      this.uid = JSON.parse(this.UserInfo).uid;
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    const payload = { 'AgentId': this.uid };
    const loggedInAgentPayload: any = {
      id: this.uid
    };
    this._MasterSevice.getSubAgents(loggedInAgentPayload).subscribe((data) => {
      const result: any = data;
      if (result.status) {
        this.subAgents = result.data[0];
        // this.subAgents.push({AgentCode:"CNKAG123550", IsActive:true, RoleId:2, RoleName:"ADMIN", label:"Dummy Testokok", value:331})
        // console.log(this.subAgents, '>>>>>>>>>>>>>>>>>>>');
      }
    });
    this._MasterSevice.getAgentsLeads(payload).subscribe((leads) => {
      const result: any = leads;
      if (result.status) {
        console.log(result.data);
        this.Fetching = false;
        this.Prospects = result.data[0];
        this.TotalLeads = result.data[1];
        this.Conversions = result.data[2];
        this.Transactions = [];
      } else {
        this.Fetching = true;
        this.FetchingMsg = result.message;
        alert('no records');
      }
    }, (error) => {
      this.Fetching = true;
      this.FetchingMsg = 'Some Error occured please try again later';
    });
    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
    this.setDateConfig();
  }

  ngOnInit() {
  }

  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }

  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  offerNameChanged(event) {
    this.subAgents.forEach((agentData) => {
      if (agentData.value === event) {
        this.selectedOfficer = agentData.label;
      }
    })
  }

  showAllLeads() {
    this.selectedSalesOfficer = '';
    this.fromDate = '';
    this.toDate = '';
    this.selectedOfficer = '';
    this.fromSixMonth = false;
    this.fromOneMonth = false;
  }

  setDateConfig(): void{
    const maxDate = '',
        minDate = '';
    this.todaysDate = this._MasterSevice.getTodaysDate();

    this.todateConfig = {
      format: 'DD-MM-YYYY',
      max : this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.frmdateConfig = {
      format: 'DD-MM-YYYY',
      max : this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }

  dataChangeStart(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.fromDate = event;
      this.todateConfig = {
        format: 'DD-MM-YYYY',
        min: event,
        max: this.todaysDate,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    } else if (!event) {
      this.fromDate = '';
    }
  }

  dataChangeEnd(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.toDate = event;
      this.frmdateConfig = {
        format: 'DD-MM-YYYY',
        max: event,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    } else if (!event) {
      this.toDate = '';
    }
  }

  lastOneMonth() {
    this.fromDate = moment().subtract(1, 'months').format('DD-MM-YYYY');
    this.fromSixMonth = false;
    this.fromOneMonth = true;
  }

  lastSixMonth(){
    this.fromDate = moment().subtract(6, 'months').format('DD-MM-YYYY');
    this.fromSixMonth = true;
    this.fromOneMonth = false;
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
