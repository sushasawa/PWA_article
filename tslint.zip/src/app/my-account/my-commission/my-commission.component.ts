import { Component, OnInit, DoCheck } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserControl } from './../../helpers/user-control';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { SharedService } from '../../shared/shared.service';
import { MasterService } from '../../services/master.services';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import * as moment from 'moment';
declare var $: any;
declare var Snackbar: any;
@Component({
  selector: 'app-my-commission',
  templateUrl: './my-commission.component.html',
  styleUrls: ['./my-commission.component.css']
})
export class MyCommissionComponent implements OnInit, DoCheck {
  public currentUserId;
  public agentCommission: any;
  public agentCommissionDetails: any;  
  public agentCommissionTotal: any;
  public CommissionSelected: any;
  public taskDetails: any;
  public currentSelectedYear: any;
  public yearOptions: any;
  public noData: any;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  constructor(private _SharedService: SharedService, private navUrl: NavigatePathService, private router: Router, private _router: ActivatedRoute, private _MasterService : MasterService) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }

    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserId = JSON.parse(UserInfo).uid;
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
    this.setYears();
    this.getAgentCommission();
  }

  ngOnInit() {
    $('body').attr('id', '');
  }

  setYears() {
    let currentYear = moment().year();
    let yearsArr = [], toYear = 1950, yearNotEqual = true;
    this.currentSelectedYear = currentYear + '';
    let loopVar = 0;
    while (yearNotEqual) {
      let loopYear = currentYear--;
      yearsArr.push({ Id: loopVar + 1 + '', label: loopYear + '', value: loopYear + '' });
      if (toYear === loopYear) {
        yearNotEqual = false;
      }
      loopVar++;
    }
    this.yearOptions = yearsArr;
  }

  yearChanged($event) {
    this.getAgentCommission();
  }
  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }

  getAgentCommission() {
    const payload: any = {
      'UserId': this.currentUserId,
      'year': this.currentSelectedYear
    };

    this._MasterService.getAgentCommission(payload)
      .subscribe((data) => {
        const result: any = data;
        this.agentCommission = result[0];
        this.agentCommission = this.processJSON(this.agentCommission);
        this.agentCommissionTotal = result[1];
        this.noData = false;
      },
      (error) => {
        const result: any = error;
        this.noData = true;
      });
  }

  processJSON(rData) {
    let rDataLength = rData.length, transactions = {};
    for (let loopVar = 0; loopVar < rDataLength; loopVar++) {
      if(transactions[rData[loopVar].month]){
        transactions[rData[loopVar].month].transactions.push(JSON.parse(JSON.stringify(rData[loopVar])))
      } else {
        transactions[rData[loopVar].month] = rData[loopVar];
        transactions[rData[loopVar].month].transactions = [JSON.parse(JSON.stringify(rData[loopVar]))];        
      }
    }
    rData = Object.keys(transactions).map((key) => { return transactions[key]; });
    return rData;
  }

  commissionDetail(commissioninfo) {

    const payload: any = {
      'UserId': this.currentUserId,
      'year': this.currentSelectedYear,
      'month': commissioninfo.month
    };

    this._MasterService.getAgentCommissionDetails(payload)
      .subscribe((data) => {
        const result: any = data;
        SessionHelper.setSession('commissionDetails', JSON.stringify(result[0]));
        SessionHelper.setSession('commissioninfo', JSON.stringify(payload));
        this.router.navigateByUrl(this.navUrl.navUrl() + '/account/my-commission-details');
        // this.agentCommissionDetails = result[0];
        // console.log(this.agentCommissionDetails)
      },
      (error) => {
        const result: any = error;
        Snackbar.show({
          text: 'Commission details are not available for selected month.',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
