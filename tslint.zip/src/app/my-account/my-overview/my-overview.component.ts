import { SharedService } from './../../shared/shared.service';
import { UserControl } from './../../helpers/user-control';
import { Component, OnInit, ViewChild, AfterViewInit, transition, DoCheck } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../../app/services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { SessionTemplate } from '../../../app/helpers/session-template';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';
import { MyAccountBannerComponent } from '../my-account-banner/my-account-banner.component';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-my-overview',
  templateUrl: './my-overview.component.html',
  styleUrls: ['./my-overview.component.css']
})
export class MyOverviewComponent implements OnInit, AfterViewInit, DoCheck {
  @ViewChild(UserBannerInfoComponent) UserBannerInfoComponent;
  @ViewChild(MyAccountBannerComponent) MyAccountBannerComponent;
  public travellersRegistrationInfo: any;
  public loggedInTraveller: any; // session template
  public registrationTemplate: any;
  public checkCurrentUserSession: any;
  public currentUserInfo: any;
  public Enquiries: Array<any>;
  public EnquiriesAvailable: Boolean;
  public currentUserEmail: any;
  public currentUserId: any;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public _primaryComp: any;
  public monthlyCommData: any;
  public concertinaStatus: any = '';
  public OrderNumbers: any = {
    'TotalLeads': 0,
    'TotalProspects': 0,
    'TotalConversions': 0,
    'TotalTransactions': 0
  };
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router, private _SharedService: SharedService) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserEmail = JSON.parse(UserInfo).uname;
      this.currentUserId = JSON.parse(UserInfo).uid;
      this.getAlerts();
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }

    this.checkCurrentUserSession = SessionHelper.getSession('currentUser');
    this.travellersRegistrationInfo = [];
    this.loggedInTraveller = {
      'traveller': [],
      'recentOrders': '',
      'AgentLogo': 'assets/images/common/nocompanylogo.png'
    };
    // check if logged in user session exists or not
    if (this.checkCurrentUserSession === undefined || this.checkCurrentUserSession == null) {
      // call user service by logged in user id
      this._MasterService.getLoggedInAgentInfo(this.currentUserId).subscribe(result => {
        const AgentData: any = result;
        this.loggedInTraveller.traveller.push(SessionTemplate.getSessionTemplate(AgentData[0]));
        this.updateLoggedinTravellerInfo(this.currentUserId);
      }, error => {
        console.log(error);
      });
    } else {
      this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    }
    const payload = {
      id: this.currentUserId
    };
    this._MasterService.getTotalLeadsCount(payload).subscribe((data) => {
      const orderResult: any = data;
      if (orderResult.status) {
        console.log(orderResult);
        this.OrderNumbers.TotalLeads = orderResult.data[1][0].TotalLeads ? orderResult.data[1][0].TotalLeads : 0;
        this.OrderNumbers.TotalProspects = orderResult.data[0][0].ProspectNumber ? orderResult.data[0][0].ProspectNumber : 0;
        // tslint:disable-next-line:max-line-length
        this.OrderNumbers.TotalConversions = orderResult.data[2][0].ConversionNumber ? orderResult.data[2][0].ConversionNumber : 0;
        console.log(this.OrderNumbers);
      }
      //  console.log(this.OrderNumbers);
    });
    this._SharedService.getSubAgents(payload);
    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success ) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }


   

  }


  ngAfterViewInit() {

  }

  ngOnInit() {
    this.getUserAccess();

    this.getCommDetails();
  }

  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }
  updateLoggedinTravellerInfo(userId) {
    // code to update cover and profile picture of parent and child traveller
    this._MasterService.getUserDocuments(userId)
      .subscribe((data) => {
        const documents: any = data;
        // in case of success setting the response profile and cover photo
        documents.response.map((doc) => {
          if (doc.type === 'profile') {
            this.loggedInTraveller.traveller[0].profileInfo.picture = doc.imageUrl;
          } else if (doc.type === 'cover') {
            this.loggedInTraveller.traveller[0].profileInfo.cover = doc.imageUrl;
          }
        });
        SessionHelper.setSession('currentUser', JSON.stringify(this.loggedInTraveller));
        this.currentUserInfo = this.loggedInTraveller;
        // calling child components passsing current user  session
        this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
        this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
      }, (err) => {
        // in case of error set the profile and cover photo to default
        SessionHelper.setSession('currentUser', JSON.stringify(this.loggedInTraveller));
        this.currentUserInfo = this.loggedInTraveller;
        this.UserBannerInfoComponent.updateSession(this.currentUserInfo);
        this.MyAccountBannerComponent.updateSession(this.currentUserInfo);
      });

  }

  // ENQUIREIS CODE STARTS
  getAlerts() {
    const payload = { email: this.currentUserEmail };
    this._MasterService.getAlert(payload).subscribe((enquiries) => {
      const result: any = enquiries;
      if (result.response.length > 0) {
        this.EnquiriesAvailable = true;
        this.Enquiries = result.response;
      } else {
        this.Enquiries = result.response;
        this.EnquiriesAvailable = false;
      }
    });
  }
  // delete alerts code
  deleteAlert(EnquiryNum: any) {
    const payload = { 'EnquiryNum': EnquiryNum };
    this._MasterService.deleteAlert(payload).subscribe((data) => {
      // swal('Success', 'Alert Deleted', 'success');
      Snackbar.show({
        text: 'Alert Deleted',
        pos: 'bottom-right',
        actionTextColor: '#05ff01',
      });
      this.getAlerts();
    });
  }

  // ENQUIREIS CODE ENDS
  getUserAccess() {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    const role: any = SessionHelper.getSession('adm_ctrl');
    if (UserInfo && role) {
      const payload: any = {
        'agentid': JSON.parse(UserInfo).uid,
        'role': role
      };
      switch (role) {
        case 'ADMIN_2':
        case 'AGENT_3':
          this._SharedService.getUserAccessCtrl(payload);
          break;
      }
    }
  }


  getCommDetails() {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    const payload: any = {
      UserId: JSON.parse(UserInfo).uid,
      year: 0
    };
    this._MasterService.getAgentCommission(payload)
      .subscribe((data)=>{
        const retData: any = data;
        this.monthlyCommData = data[0];
        //this.monthlyCommData = [[{'monthName':'-','commissionAmount':'-'}]]
        console.log('monthlyCommData',this.monthlyCommData);
      });
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
