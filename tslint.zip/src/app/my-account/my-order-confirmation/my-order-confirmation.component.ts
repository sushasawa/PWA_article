import { TransactionService } from './../../services/transaction.service';
import { Component, OnInit, ViewChild, ElementRef, Input, EventEmitter, Output } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { SessionHelper } from '../../helpers/session-helper';
import { MasterService } from '../../../app/services/master.services';
import { SessionTemplate } from '../../helpers/session-template';
import { DatePipe } from '@angular/common';
import * as jsPDF from 'jspdf';
import * as d3 from 'd3';
import * as html2canvas from 'html2canvas';
import { parse } from 'querystring';
declare var Snackbar: any;
@Component({
  selector: 'my-order-confirmation',
  templateUrl: './my-order-confirmation.component.html',
  styleUrls: ['./my-order-confirmation.component.css']
})
export class MyOrderConfirmationComponent implements OnInit {
  public deliveryMode: any;
  public cardType: any;
  // public deliveryTxt: any;
  public purpose: any;
  public currentSession: any;
  public pageSession: any;
  public deliverycharge: any;
  public discount: any = 0;
  public serviceCharge: any = 0;
  public activationFees: any = 0;
  public loadFees: any = 0;
  public gst: any;
  public userSessionInfo: any;
  public userSessionInfoSelectedTraveller: any;
  public userSessionInfoTravellers: any;
  public travellersAmount: any = [];
  public SessionInfo: any;
  public orderStatus: any;
  public Switch: any;
  public exchangeRates: any = {};
  public sessionDataProcessScreen: any;
  public processType: any;
  public nextLink: any;
  public orderType: any;
  public grantTotalAmount: any = 0;
  public temporaryOrderNumber;
  public travellerTotalAmount: any;
  public travellerOfficeAddress: any = [];
  public transactionId: any;
  public hiddenLogo: any = false;
  public reloadTotalIntArray: any = [];
  public orderDate: any;
  public travellerInfo: any;
  @Output() taskComplete = new EventEmitter<boolean>();
  @ViewChild('printsection') element: ElementRef;
  @Input('orderInfo') orderInfo: any;
  @Input('taskDetails') taskDetails: any;
  // tslint:disable-next-line:max-line-length
  constructor(public masterService: MasterService, private route: ActivatedRoute, private router: Router, public _TransactionService: TransactionService) {
    console.log('reached here>>>>>>>>', this.orderInfo);
    
    // SessionHelper.removeSession('userSessionInfo');
    // SessionHelper.removeSession('userSessionInfoSale');
    // SessionHelper.removeSession('userSessionInfoRealoadCard');
    // SessionHelper.removeSession('userSessionInfoSend');
    this.serviceCharge = 10;
    this.activationFees = 10;
    this.loadFees = 10;
    this.gst = 72;


  }

  ngOnChanges() {
    console.log('reached here>>>>>>>>', this.orderInfo);
    this.travellerInfo = JSON.parse(this.orderInfo.RequestDataJson);
    this.transactionId = this.orderInfo.TransactionId; console.log(this.transactionId);
    this.sessionDataProcessScreen = JSON.parse(this.orderInfo.UserSessionJson).type;
    this.processType = this.getProcessType(this.sessionDataProcessScreen);
    this.orderStatus = this.orderInfo.OrderStatus;
    // this.deliveryMode = this.orderInfo.deliveryInfo.Mode;
    this.purpose = this.travellerInfo.purpose;
    // this.deliveryTxt = this.route.snapshot.data.deliveryTxt;
    // this.pageSession = result[0].UserSessionJson;
    this.orderDate = this.orderInfo.OrderDate;
    this.currentSession = JSON.parse(this.orderInfo.UserSessionJson).type;
    this.SessionInfo = JSON.parse(this.orderInfo.UserSessionJson);
    this.userSessionInfo = this.SessionInfo[this.currentSession];
    this.userSessionInfoTravellers = this.SessionInfo[this.currentSession].traveller;
    this.userSessionInfoSelectedTraveller = this.SessionInfo[this.currentSession].traveller[0];

    this.temporaryOrderNumber = this.SessionInfo.temporaryOrderNumber;
    this.userSessionInfo.tranId = '';
    this.SessionInfo['is_complete'] = true;
    this.grantTotalAmount = this.userSessionInfo.usedAmount;
    console.log(this.userSessionInfo);



    if (this.processType === 'Reload') {
      console.log('this.userSessionInfoSelectedTraveller.prepaidCardDetail', this.userSessionInfoSelectedTraveller.prepaidCardDetails)
      this.userSessionInfoSelectedTraveller.prepaidCardDetails.forEach(prepaidDetail => {
        let reloadInternal: any = 0;
        prepaidDetail.currencyDetails.forEach(currencyDetail => {
          reloadInternal += currencyDetail.forexAmount * currencyDetail.exchangeRate.rate;
        });
        this.reloadTotalIntArray.push(reloadInternal)
      })
      console.log('this.reloadTotalIntArray', this.reloadTotalIntArray);
    }


  }

  ngOnInit() {
    this.setOrderType();
  }


  selectTraveller(travellerIndex) {
    this.userSessionInfoSelectedTraveller = this.userSessionInfo.traveller[travellerIndex];
    this.userSessionInfoTravellers.forEach(traveller => {
      traveller.selected = false;
    });
    this.userSessionInfoTravellers[travellerIndex].selected = true;
  }




  // calculateGTotalAmount() {
  //   if (this.processType === 'Sell') {
  //     this.grantTotalAmount = this.getSellTotalAmount();
  //   } else {
  //     this.grantTotalAmount = this.getOtherTotalAmount();
  //   }
  // }

  // getCharges() {
  //   this.masterService.getCharges().subscribe((data) => {
  //     const Charges: any = data;
  //     this.serviceCharge = Charges.response.serviceCharge;
  //     this.loadFees = Charges.response.LoadFee;
  //     this.activationFees = Charges.response.ActivationCharge;
  //   }, (error) => {
  //     Snackbar.show({
  //       text: 'Error fetching Charges',
  //       pos: 'bottom-right',
  //       actionTextColor: '#ff4444',
  //     });
  //   });
  // }

  // getSellTotalAmount() {
  //   this.masterService.getTaxes(this.travellerTotalAmount).subscribe((data) => {
  //     const result: any = data;
  //     this.travellerTotalAmount -= (result.TotalTax + this.serviceCharge + this.loadFees + this.activationFees);
  //     this.gst = result.TotalTax;
  //     this.grantTotalAmount = this.travellerTotalAmount;
  //   });
  // }

  // getOtherTotalAmount() {
  //   this.masterService.getTaxes(this.travellerTotalAmount).subscribe((data) => {
  //     const result: any = data;
  //     this.travellerTotalAmount += (result.TotalTax + this.serviceCharge + this.loadFees + this.activationFees);
  //     this.gst = result.TotalTax;
  //     this.grantTotalAmount = this.travellerTotalAmount;
  //   });
  // }

  setOrderType() {
    switch (this.processType) {
      case 'Buy':
        this.orderType = 'Buy Forex';
        break;
      case 'Sell':
        this.orderType = 'Sell Forex';
        break;
      case 'Reload':
        this.orderType = 'Reload Card';
        break;
      case 'Send':
        this.orderType = 'Send Money Abroad';
        break;
    }
  }

  concatOfficeAddress() {
    let nonAdressParam = ['conpanyName', 'companyName', 'designation', 'companyDivision', 'pincode'];
    this.travellerOfficeAddress = [];
    this.userSessionInfo.traveller.forEach((traveller, index) => {
      let addressText = '', officeAddress = traveller.registrationInfo.officeAddress, counter = 0, pincodeAdded = false;
      for (let travellerData in officeAddress) {
        if (nonAdressParam.indexOf(travellerData) === -1 && officeAddress[travellerData]) {
          addressText += officeAddress[travellerData] + ', ';
          counter++;
        }
        if (travellerData === 'pincode' && officeAddress[travellerData]) {
          if (counter > 0) {
            addressText = this.replaceLastCommaWith(addressText, '-') + officeAddress[travellerData];
          } else {
            addressText += officeAddress[travellerData]
          }
          pincodeAdded = true;
        }
      }
      if ((counter > 0 && pincodeAdded) || pincodeAdded) {
        addressText += '.';
      } else if (counter > 0) {
        addressText += this.replaceLastCommaWith(addressText, '.')
      }
      this.travellerOfficeAddress[index] = addressText;
    });
  }

  replaceLastCommaWith(text, element) {
    var pos = text.lastIndexOf(',');
    return text.substring(0, pos) + ' ' + element + ' ' + text.substring(pos + 1);
  }

  


  print(): void {
    this.hiddenLogo = true;
    setTimeout(() => {
      let printContents = '', popupWin;

      printContents += document.getElementById('print-section').innerHTML;

      popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
      popupWin.document.open();
      popupWin.document.write(`
            <html>
              <head>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link href="/assets/css/bootstrap.css" rel="stylesheet">
                <!-- Bootstrap core CSS -->
                <link href="/assets/css/plugin.min.css" rel="stylesheet" type="text/css" media="all">
                <!-- icons -->
                <!-- Custom styles for this template -->
                <link href="/assets/css/style.min.css" rel="stylesheet">
                <link href="/assets/css/media.min.css" rel="stylesheet">
                <script>
                    function clearSignSpace() {
                      var elements = document.getElementsByClassName('sign-space');
                      for(var i = 0; i < elements.length; i++) {
                        elements[i].innerHTML = '';
                      }
                    }
                </script>
              </head>
              <body onload="clearSignSpace();window.print();window.close();">${printContents}</body>
            </html>`
      );
      popupWin.document.close();
      this.taskComplete.emit();
      this.hiddenLogo = false;
    }, 100);

  }

  download(): void {
    this.hiddenLogo = true;
    
    setTimeout(() => {
      let timeNow,
        pageDimentions = [595, 841],
        imageWidth = 570,
        imageHeight = 820,
        pagePadding = 5,
        qualityParam = 1.0,
        fileName;
      timeNow = (new DatePipe('en-US').transform(new Date(), 'MMM d y h mma')).replace(/ /g, '_');
      fileName = 'confirmation_' + '_' + timeNow;
      html2canvas(this.element.nativeElement).then((canvas: HTMLCanvasElement) => {
        var img = canvas.toDataURL('image/png', qualityParam);
        let canvasWidth = +canvas.getAttribute('width'),
          canvasHeight = +canvas.getAttribute('height');
        let imageDimantions = this.calculateHeightWidth(pageDimentions, canvasWidth, canvasHeight);
        var doc = new jsPDF('p', 'pt', pageDimentions);
        doc.addImage(img, 'JPEG', imageDimantions.pagePadding, pagePadding, imageDimantions.imageWidth, imageDimantions.imageHeight);
        doc.save(fileName + '.pdf');
        this.hiddenLogo = false;
        this.taskComplete.emit();
      });
    }, 100);

  }

  calculateHeightWidth(pageDimentions, imageWidth, imageHeight) {
    let pageWidth = pageDimentions[0] - 20,
      pageHeight = pageDimentions[1] - 20,
      imageRatio,
      newImageHeight,
      newImageWidth,
      paddingValue = 5,
      pageRatio;
    imageRatio = imageHeight / imageWidth;
    pageRatio = pageHeight / pageWidth;
    if (imageRatio < pageRatio && imageWidth > pageWidth) {
      newImageWidth = pageWidth;
      newImageHeight = imageRatio * pageWidth;
    } else if (imageRatio > pageRatio && imageHeight > pageHeight) {
      newImageHeight = pageHeight;
      newImageWidth = pageHeight / imageRatio;
      paddingValue = (pageWidth - newImageWidth) / 2;
    } else if (imageWidth < pageWidth && imageHeight < pageHeight) {
      newImageHeight = imageWidth;
      newImageWidth = imageHeight;
    }
    return { imageWidth: newImageWidth, imageHeight: newImageHeight, pagePadding: paddingValue };
  }

  // getExchangeRates(traveller) {
  //   let prepaidCardDetails = traveller.prepaidCardDetails;
  //   if (traveller.prepaidCard) {
  //     for (let prepaidCard in prepaidCardDetails) {
  //       this.exchangeRates[prepaidCardDetails[prepaidCard].currencyCode] = prepaidCardDetails[prepaidCard].exchangeRate.rate;
  //     }
  //   }
  // }

  // getTransactionCount(traveller) {
  //   let transactionCount = 0;
  //   if (this.processType === 'Sell') {
  //     if (traveller.prepaidCard) {
  //       traveller.cardData.forEach((prepaidCardDetails) => {
  //         let balanceCount = 0;
  //         prepaidCardDetails.balance.forEach((balance) => {
  //           if (balance.cashout && balance.cashoutAmount) {
  //             transactionCount++;
  //             balanceCount++;
  //           }
  //         });
  //         prepaidCardDetails.balanceCount = balanceCount;
  //       });
  //     }
  //     transactionCount += traveller.cashDetails.length;
  //     traveller.transactionCount = transactionCount;
  //   }
  // }



  // ngOnDestroy() {
  //   // this.SessionInfo = JSON.parse(SessionHelper.getSession(this.pageSession));
  //   SessionHelper.removeSession(this.pageSession);
  //   this.router.navigateByUrl('/buy');
  // }

  getProcessType(type) {
    let processType: any = '';
    switch (type) {
      case 'buyScreen':
        processType = 'Buy';
        break;
      case 'sellScreen':
        processType = 'Sell';
        break;
      case 'reloadCardScreen':
        processType = 'Reload';
        break;
      case 'sendMoneyScreen':
        processType = 'Send';
        break;
    }

    return processType;
  }

}
