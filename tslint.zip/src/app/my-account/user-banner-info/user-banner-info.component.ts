import { Component, OnInit, Input } from '@angular/core';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { SessionHelper } from '../../../app/helpers/session-helper';
@Component({
  selector: 'app-user-banner-info',
  templateUrl: './user-banner-info.component.html',
  styleUrls: ['./user-banner-info.component.css']
})
export class UserBannerInfoComponent implements OnInit {
  public currentUserInfo: any;
  public LastLoggedIn: any;
  public _primaryComp: any;

  constructor(private navUrl: NavigatePathService) {
    this._primaryComp = '/' + navUrl.navUrl();
    if (SessionHelper.getSession('currentUser') != null || SessionHelper.getSession('currentUser') !== undefined) {
      this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    }
    if (SessionHelper.getLocal('LastLoggedIn')) {
      this.LastLoggedIn = SessionHelper.getLocal('LastLoggedIn');
    } else {
      SessionHelper.setLocal('LastLoggedIn', Date());
      this.LastLoggedIn = SessionHelper.getLocal('LastLoggedIn');
    }
  }

  ngOnInit() {
  }

  updateSession(session: any) {
   // console.log("called from parent");
    this.currentUserInfo = session;  console.log(this.currentUserInfo);
  }

}
