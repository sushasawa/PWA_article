import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyCommissionDetailsComponent } from './my-commission-details.component';

describe('MyCommissionDetailsComponent', () => {
  let component: MyCommissionDetailsComponent;
  let fixture: ComponentFixture<MyCommissionDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyCommissionDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyCommissionDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
