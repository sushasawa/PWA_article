import { Component, OnInit, DoCheck, ViewChild, ElementRef } from '@angular/core';
import { UserControl } from './../../helpers/user-control';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { SharedService } from '../../shared/shared.service';
import { MasterService } from '../../services/master.services';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { DatePipe } from '@angular/common';
import * as jsPDF from 'jspdf';
import * as d3 from 'd3';
import * as html2canvas from 'html2canvas';
declare var Snackbar: any;
declare var $: any;
@Component({
  selector: 'app-my-commission-details',
  templateUrl: './my-commission-details.component.html',
  styleUrls: ['./my-commission-details.component.css']
})
export class MyCommissionDetailsComponent implements OnInit, DoCheck {
  public currentUserId;
  public agentCommission: any;
  public agentCommissionDetails: any;
  public agentCommissionTotal: any;
  public CommissionSelected: any;
  public taskDetails: any;
  public totalSaleAmount: any;
  public totalCommissionAmount: any;
  public commissionDtl: any;
  public currencyDetails: any;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public todaysDate: any;
  public frmdateConfig: any;
  public todateConfig: any;
  public fromDate: any = '';
  public toDate: any = '';
  public searchTransaction: any;
  public _primaryComp: any;
  public commissionInfo: any;
  public showButton: any = true;
  public concertinaStatus: any = '';
  @ViewChild('printsection') element: ElementRef;
  public monthsMap: any = ['January', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
  constructor(private _SharedService: SharedService, private navUrl: NavigatePathService, private _MasterService: MasterService) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    const commissionDetails: any = SessionHelper.getSession('commissionDetails');
    if (SessionHelper.getSession('commissioninfo')) {
      this.commissionInfo = JSON.parse(SessionHelper.getSession('commissioninfo'));
    }    
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }

    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserId = JSON.parse(UserInfo).uid;
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }

    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }

    this.agentCommissionDetails = JSON.parse(commissionDetails);
    this.currencyDetails = [];
    this.totalSaleAmount = 0;
    this.totalCommissionAmount = 0;
    let currencyObj = {};
    this.agentCommissionDetails.forEach((agentCommissionDetail) => {
      if (!currencyObj[agentCommissionDetail.Currency]) {
        currencyObj[agentCommissionDetail.Currency] = 0;
      }
      this.totalSaleAmount += agentCommissionDetail.NetAmount;
      this.totalCommissionAmount += agentCommissionDetail.CommAmount;
      currencyObj[agentCommissionDetail.Currency] += agentCommissionDetail.FeAmount;
    });
    this.currencyDetails = Object.keys(currencyObj).map((key) => { return { currency: key, amount: currencyObj[key] }; });
    // this._MasterService.getAgentCommissionDetails(this.commissionDtl)
    // .subscribe((data) => {
    //   const result: any = data;
    //   console.log(result);
    //   this.agentCommissionDetails = result[0];
    //   console.log(this.agentCommissionDetails)
    // },
    //   (error) => {
    //     const result: any = error;

    //   });

  }

  ngOnInit() {
    $('body').attr('id', '');
  }

  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }

  setDateConfig(): void {
    const maxDate = '',
      minDate = '';
    this.todaysDate = this._MasterService.getTodaysDate();
    this.todateConfig = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.frmdateConfig = {
      format: 'DD-MM-YYYY',
      max: this.todaysDate,
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
  }

  dataChangeStart(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.fromDate = event;
      this.todateConfig = {
        format: 'DD-MM-YYYY',
        min: event,
        max: this.todaysDate,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    } else if (!event) {
      this.fromDate = '';
    }
  }

  dataChangeEnd(event): void {
    if (event !== undefined && typeof event !== 'object') {
      this.toDate = event;
      this.frmdateConfig = {
        format: 'DD-MM-YYYY',
        max: event,
        showMultipleYearsNavigation: true,
        disableKeypress: true,
      };
    } else if (!event) {
      this.toDate = '';
    }
  }

  searchTextChanged(event) {
    this.searchTransaction = event;
  }

  getBranchDetails(newValue) {
    this._MasterService.getBranchDetails('HO')
      .subscribe(data => {
        let BranchDetails: any = data;
        // console.log('working');
        // this.branchName = BranchDetails[0].BranchName;
      }, error => {
        // console.log('not found');
      });
  }

  print(): void {
    this.showButton = false;
    setTimeout(() => {
      let printContents = '', popupWin;
      printContents += document.getElementById('print-section').innerHTML;
      popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
      popupWin.document.open();
      popupWin.document.write(`
            <html>
              <head>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link href="/assets/css/bootstrap.css" rel="stylesheet">
                <!-- Bootstrap core CSS -->
                <link href="/assets/css/plugin.min.css" rel="stylesheet" type="text/css" media="all">
                <!-- icons -->
                <!-- Custom styles for this template -->
                <link href="/assets/css/style.min.css" rel="stylesheet">
                <link href="/assets/css/media.min.css" rel="stylesheet">
                <script>
                    function clearSignSpace() {
                      var elements = document.getElementsByClassName('sign-space');
                      for(var i = 0; i < elements.length; i++) {
                        elements[i].innerHTML = '';
                      }
                    }
                </script>
              </head>
              <body onload="clearSignSpace();window.print();window.close();">${printContents}</body>
            </html>`
      );
      popupWin.document.close();
      this.showButton = true;
    }, 100);
  }

  download(): void {
    this.showButton = false;
    setTimeout(() => {
      let timeNow,
        pageDimentions = [595, 841],
        imageWidth = 570,
        imageHeight = 820,
        pagePadding = 5,
        qualityParam = 1.0,
        fileName;
      timeNow = (new DatePipe('en-US').transform(new Date(), 'MMM d y h mma')).replace(/ /g, '_');
      fileName = 'commission_' + '_' + timeNow;
      html2canvas(this.element.nativeElement).then((canvas: HTMLCanvasElement) => {
        const img = canvas.toDataURL('image/png', qualityParam);
        const canvasWidth = +canvas.getAttribute('width'),
          canvasHeight = +canvas.getAttribute('height');
        const imageDimantions = this.calculateHeightWidth(pageDimentions, canvasWidth, canvasHeight);
        const doc = new jsPDF('p', 'pt', pageDimentions);
        doc.addImage(img, 'JPEG', imageDimantions.pagePadding, pagePadding, imageDimantions.imageWidth, imageDimantions.imageHeight);
        doc.save(fileName + '.pdf');
        this.showButton = true;
      });
    }, 100);

  }

  calculateHeightWidth(pageDimentions, imageWidth, imageHeight) {
    let pageWidth = pageDimentions[0] - 20,
      pageHeight = pageDimentions[1] - 20,
      imageRatio,
      newImageHeight,
      newImageWidth,
      paddingValue = 5,
      pageRatio;
    imageRatio = imageHeight / imageWidth;
    pageRatio = pageHeight / pageWidth;
    if (imageRatio < pageRatio && imageWidth > pageWidth) {
      newImageWidth = pageWidth;
      newImageHeight = imageRatio * pageWidth;
    } else if (imageRatio > pageRatio && imageHeight > pageHeight) {
      newImageHeight = pageHeight;
      newImageWidth = pageHeight / imageRatio;
      paddingValue = (pageWidth - newImageWidth) / 2;
    } else if (imageWidth < pageWidth && imageHeight < pageHeight) {
      newImageHeight = imageWidth;
      newImageWidth = imageHeight;
      paddingValue = (pageWidth - newImageWidth) / 2;
    }
    return { imageWidth: newImageWidth, imageHeight: newImageHeight, pagePadding: paddingValue };
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
  
}
