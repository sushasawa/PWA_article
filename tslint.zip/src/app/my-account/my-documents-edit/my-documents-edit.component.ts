import { SharedService } from './../../shared/shared.service';
import { Component, OnInit, DoCheck } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { UserControl } from './../../helpers/user-control';
import { AgentDocumentsMetadata } from './../../helpers/agent-documents-metadata';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { NgForm } from '@angular/forms';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;
declare function initAccord(): any;
declare function initMyAccountJS(): any;
@Component({
  selector: 'app-my-documents-edit',
  templateUrl: './my-documents-edit.component.html',
  styleUrls: ['./my-documents-edit.component.css']
})
export class MyDocumentsEditComponent implements OnInit, DoCheck {
  public currentUserId;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public Documents: any;
  public documentScr: any;
  public showModal: any;
  public displayBlockMsg: any = 'Saving...';
  public showInfo: any = false;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  constructor(private _MasterService: MasterService, private router: Router, private navUrl: NavigatePathService, private _SharedService: SharedService) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      this.logout();
    }
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserId = JSON.parse(UserInfo).uid;
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
    this.Documents = {
      'UserId': this.currentUserId,
      'Email': JSON.parse(UserInfo).uname,
      'AdmType': SessionHelper.getSession('adm_ctrl'),
      'uploaded': [],
      'pending': [],
      'expired': []
    };

    this.getAgentsDocument();
    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
  }

  ngOnInit() {
    $('body').attr('id', '');
  }
  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }
  logout() {
    SessionHelper.removeSession('userInfo');
    SessionHelper.removeSession('userSessionInfo');
    SessionHelper.removeSession('userSessionInfoSale');
    SessionHelper.removeSession('userSessionInfoRealoadCard');
    SessionHelper.removeSession('userSessionInfoSend');
    SessionHelper.removeSession('pageSessionParam');
    SessionHelper.removeSession('currentUser');
    SessionHelper.removeSession('adm_ctrl');
    window.location.href = this._primaryComp + '/';
  }

  getAgentsDocument() {
    //   this.DocumentsMsg = 'Fetching Documents Please Wait...';
    const payload: any = {
      'UserId': this.currentUserId,
      'Email': JSON.parse(SessionHelper.getSession('userInfo')).uname,
      'AdmType': SessionHelper.getSession('adm_ctrl')
    };
    this._MasterService.getAgentDocuments(payload)
      .subscribe((data) => {
        const result: any = data;
        if (result.success) {
          this.Documents = result.Docs;
          //       this.DocumentsMsg = 'You have not Uploaded any doument.';
        } else {
          //      this.DocumentsMsg = result.message;
        }
        //      this.getPendingDocuments();
      },
        (error) => {
          const result: any = error;
          //        this.DocumentsMsg = 'Something went wrong while fetching the documents.';
          // Snackbar.show({
          //   text: result.message,
          //   pos: 'bottom-right',
          //   actionTextColor: '#00880d',
          // });
        });
  }

  closeDocpopup() {
    this.showModal = false;
  }

  viewDoc(uploadedDocument) {
    this.documentScr = uploadedDocument.DocumentUrl;
    this.showModal = true;
  }


  saveDocuments() {
    this.showInfo = true;
    let IsFormOk: Boolean = true;
    console.log('saveDocuments');
    for (let index: any = 0; index < this.Documents.uploaded.length; index++) {
      console.log('CAPITAL' + index);
      for (let subIndex: any = 0; subIndex < this.Documents.uploaded[index].MetaData.length; subIndex++) {
        console.log('SUB CAPITAL' + index);
        // tslint:disable-next-line:max-line-length
        // console.log(this.Documents.uploaded[index].MetaData[subIndex].label + ' === > '+ this.Documents.uploaded[index].MetaData[subIndex].value);
        if (this.Documents.uploaded[index].MetaData[subIndex].value === '') {
          console.log('MISSING VALUE');
          IsFormOk = false;
          break;
        }
      }
    }

    if (IsFormOk) {
      this._MasterService.saveAgentDocuments(this.Documents)
        .subscribe((data) => {
          const result: any = data;
          this.showInfo = false;
          Snackbar.show({
            text: result.message,
            pos: 'bottom-right',
            actionTextColor: '#00880d',
          });
        },
          (error) => {
            const result: any = error;
            Snackbar.show({
              text: result.message,
              pos: 'bottom-right',
              actionTextColor: '#00880d',
            });
          });
    } else {
      Snackbar.show({
        text: 'All Fields Are Required.',
        pos: 'bottom-right',
        actionTextColor: '#d30000',
      });
    }

  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
