import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyDocumentsEditComponent } from './my-documents-edit.component';

describe('MyDocumentsEditComponent', () => {
  let component: MyDocumentsEditComponent;
  let fixture: ComponentFixture<MyDocumentsEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyDocumentsEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyDocumentsEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
