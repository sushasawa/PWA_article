import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { NavigatePathService } from '../../../app/services/navigate-path.service';

declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-my-enquiries',
  templateUrl: './my-enquiries.component.html',
  styleUrls: ['./my-enquiries.component.css']
})
export class MyEnquiriesComponent implements OnInit {
  public Enquiries: Array<any>;
  public EnquiriesAvailable: Boolean;
  public currentUserEmail: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    if (UserInfo != null || UserInfo !== undefined) {
      this.currentUserEmail = JSON.parse(UserInfo).uname;
      this.getAlerts();
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
  }

  getAlerts() {
    const payload = { email: this.currentUserEmail };
    this._MasterService.getAlert(payload).subscribe((enquiries) => {
      const result: any = enquiries;
      if (result.response.length > 0) {
        this.EnquiriesAvailable = true;
        this.Enquiries = result.response;
      } else {
        this.Enquiries = result.response;
        this.EnquiriesAvailable = false;
      }
    });
  }

  deleteAlert(EnquiryNum: any) {
    console.log(EnquiryNum);
    const payload = { 'EnquiryNum': EnquiryNum };
    this._MasterService.deleteAlert(payload).subscribe((data) => {
      //swal('Success', 'Alert Deleted', 'success');
      Snackbar.show({
        text: 'Alert Deleted',
        pos: 'bottom-right',
        actionTextColor: '#05ff01',
      });
      this.getAlerts();
      console.log(data);
    });
  }

  ngOnInit() {

  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
