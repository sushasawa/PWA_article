import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyOrdersReportComponent } from './my-orders-report.component';

describe('MyOrdersReportComponent', () => {
  let component: MyOrdersReportComponent;
  let fixture: ComponentFixture<MyOrdersReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyOrdersReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyOrdersReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
