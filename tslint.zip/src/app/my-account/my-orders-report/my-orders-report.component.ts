import { NgForm } from '@angular/forms';
import { Component, OnInit, ViewChildren, AfterViewInit, QueryList, ViewChild } from '@angular/core';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../helpers/session-helper';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { UserBannerInfoComponent } from '../user-banner-info/user-banner-info.component';
import { MyAccountBannerComponent } from '../my-account-banner/my-account-banner.component';
import { UserControl } from './../../helpers/user-control';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
import { DataSharingService } from './../../services/data-sharing.service';
declare var $: any;
declare function initDocument(): any;
declare function initMyAccountJS(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-my-orders-report',
  templateUrl: './my-orders-report.component.html',
  styleUrls: ['./my-orders-report.component.css']
})
export class MyOrdersReportComponent implements OnInit {
  public uid: any;
  public UserInfo: any;
  public currentUserInfo: any;
  public Transactions: any;
  public IsOrdersNotAvailable: Boolean = false;
  public Orders: Array<any>;
  public OrderFilter: Array<any>;
  public StatusFilter: Array<any>;
  public OrderSelected: any;
  public OrderType = '';
  public taskDetails: any;
  public StatusType = '';
  public Branches: any;
  public OrderSort = {
    OrderType: 'buy',
    StatusType: false
  };
  public Offset: any = 0;
  public Limit: any = 15;
  public invalidsubmitted: any;
  public subAgents: any = [];
  public AllOrders: any = [];
  public TotalAvailableOrders: any;
  public PaginationButtons: any = [];
  public OrdersMsg: any;
  public Fetching: Boolean = false;
  public FetchingMsg: any;
  public payload: any;
  public _primaryComp: any;
  @ViewChildren('OrderLoaded') OrderLoaded: QueryList<any>;
  @ViewChild(UserBannerInfoComponent) UserBannerInfoComponent;
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  constructor(private _MasterSevice: MasterService, private navUrl: NavigatePathService, private router: Router, private _DataSharingService: DataSharingService) {
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    this.UserInfo = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }

    if (this.UserInfo) {
      this.uid = JSON.parse(this.UserInfo).uid;
    } else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }
  }

  ngOnInit() {
    this._DataSharingService.currentMessage.subscribe((OrderPayload) => {
      console.log('DATA SHARED TO ORDERS REPORT COMPONENT');
      console.log(OrderPayload);
      this.OrdersMsg = 'Fetching Orders Please Wait...';
      const payload = OrderPayload;
      this._MasterSevice.getAgentOrderList(payload).subscribe((data) => {
        const result: any = data;
        if (result.status) {
          this.TotalAvailableOrders = result.data[1][0].TotalRecords;
          this.AllOrders.push(result.data[0]);
          this.Orders = this.AllOrders[0];
          this.getPaginationButtons();
        } else {
          this.OrdersMsg = 'No Orders Found...';
        }
      });
    });
  }


  public getOrders(Index: any = 0) {
    if (this.AllOrders[Index]) {
      this.Orders = this.AllOrders[Index];
    } else {
      this.Fetching = true;
      this.FetchingMsg = 'Fetching Orders Please Wait...';
     // this.Offset = this.Offset + 15;
      this.payload.OffSet = this.Limit * Index;
      this.payload.Limit = this.Limit;
      this._MasterSevice.getAgentOrderList(this.payload).subscribe((data) => {
        const result: any = data;
        if (result.status) {
          this.TotalAvailableOrders = result.data[1][0].TotalRecords;
          this.AllOrders[Index] = result.data[0];
          //  this.AllOrders.push(result.data[0]);
          this.Orders = this.AllOrders[Index];
          this.getPaginationButtons();
          this.Fetching = false;
          this.FetchingMsg = '...';
        } else {
          this.Fetching = true;
          this.FetchingMsg = 'No More Orders.';
        }
      });
    }
  }

  public getPaginationButtons() {
    this.PaginationButtons = [];
    let index: any = 0;
    for (let i = 0; i <= this.TotalAvailableOrders; i += 15) {
      index = index + 1;
      this.PaginationButtons.push(index);
    }
    //  initMyAccountJS();
  }

}
