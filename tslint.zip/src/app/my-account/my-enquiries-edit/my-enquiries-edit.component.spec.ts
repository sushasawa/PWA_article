import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyEnquiriesEditComponent } from './my-enquiries-edit.component';

describe('MyEnquiriesEditComponent', () => {
  let component: MyEnquiriesEditComponent;
  let fixture: ComponentFixture<MyEnquiriesEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyEnquiriesEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyEnquiriesEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
