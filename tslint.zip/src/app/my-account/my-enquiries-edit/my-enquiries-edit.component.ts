import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MasterService } from '../../services/master.services';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
declare function swal(headerMessage, message, type): any;
declare var Snackbar: any;

@Component({
  selector: 'app-my-enquiries-edit',
  templateUrl: './my-enquiries-edit.component.html',
  styleUrls: ['./my-enquiries-edit.component.css']
})
export class MyEnquiriesEditComponent implements OnInit {
  public Enquiries: Array<any>;
  public EnquiriesAvailable: Boolean;
  public currentUserEmail: any;
  public products: any;
  public services: any;
  public currencyList: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private router: Router) {
    const UserInfo: any = SessionHelper.getSession('userInfo');
    this._primaryComp = '/' + navUrl.navUrl();
    if (UserInfo !== null || UserInfo !== undefined) {
      this.currentUserEmail = JSON.parse(UserInfo).uname;
      this.getAlerts();
    }else {
      SessionHelper.removeSession('currentUser');
      window.location.href = this._primaryComp + '/login';
    }

    this.products = [
      { value: 'Prepaid Card', label: 'Prepaid Card' },
      { value: 'Cash', label: 'Cash' },
      { value: 'Traveller\'s Chaque', label: 'Traveller\'s Chaque' },
      { value: 'Demand Draft', label: 'Demand Draft' }
    ];

    this.services = [
      { value: 'Buy Forex', label: 'Buy Forex' },
      { value: 'Sell Forex', label: 'Sell Forex' }
    ];

    this._MasterService.getCurrencyList(1)
      .subscribe(data => {
        this.currencyList = data;
      }, err => {
        //swal('Oops...', 'Unable to fetch currency list!', 'error');
        Snackbar.show({
          text: 'Unable to fetch currency list!',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      });
  }


  getAlerts() {
    const payload = { email: this.currentUserEmail };
    this._MasterService.getAlert(payload).subscribe((enquiries) => {
      const result: any = enquiries;
      if (result.response.length > 0) {

        this.EnquiriesAvailable = true;
        this.Enquiries = result.response;

      } else {
        this.Enquiries = result.response;
        this.EnquiriesAvailable = false;
      }
    });
  }
  updateEnquiry(enquiry: any) {
    const payload = enquiry;
    payload.frmdate = new Date(payload.frmdate).getTime();
    payload.todate = new Date(payload.todate).getTime();
    this._MasterService.updateAlert(payload).subscribe((data) => {
      const result: any = data;
      if (result.success) {
        //swal('Success', 'Alert Updated.', 'success');
        Snackbar.show({
          text: 'Alert Updated.',
          pos: 'bottom-right',
          actionTextColor: '#05ff01',
        });
      } else {
        //swal('Error', 'Error Updating alert', 'error');
        Snackbar.show({
          text: 'Error Updating alert',
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
      }
    });
  }
  ngOnInit() {
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
