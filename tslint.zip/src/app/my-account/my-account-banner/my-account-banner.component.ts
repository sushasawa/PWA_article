import { Component, OnInit } from '@angular/core';


import { SessionHelper } from '../../../app/helpers/session-helper';

declare var $: any;
declare function initDocument(): any;
@Component({
  selector: 'app-my-account-banner',
  templateUrl: './my-account-banner.component.html',
  styleUrls: ['./my-account-banner.component.css']
})
export class MyAccountBannerComponent implements OnInit {
  public currentUserInfo: any;
  constructor() {
    console.log('banner components');
    if (SessionHelper.getSession('currentUser') != null || SessionHelper.getSession('currentUser') !== undefined) {
      this.currentUserInfo = JSON.parse(SessionHelper.getSession('currentUser'));
    }
 }

  ngOnInit() {

  }

  updateSession(session: any) {
    // console.log("called from parent");
    this.currentUserInfo = session;
  }

}
