import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyAccountBannerComponent } from './my-account-banner.component';

describe('MyAccountBannerComponent', () => {
  let component: MyAccountBannerComponent;
  let fixture: ComponentFixture<MyAccountBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyAccountBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyAccountBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
