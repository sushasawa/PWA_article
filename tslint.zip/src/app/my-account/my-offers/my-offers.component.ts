import { SharedService } from './../../shared/shared.service';
import { Component, OnInit, DoCheck } from '@angular/core';
import { UserControl } from './../../helpers/user-control';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var $: any;
declare function initDocument(): any;
@Component({
  selector: 'app-my-offers',
  templateUrl: './my-offers.component.html',
  styleUrls: ['./my-offers.component.css']
})
export class MyOffersComponent implements OnInit, DoCheck {
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public planData: any;
  public planDetails: any;
  public showOfferDetails: any = false;
  public selectedPlanDetails: any;
  public _primaryComp: any;
  public concertinaStatus: any = '';
  constructor(private http: HttpClient, private navUrl: NavigatePathService, private _SharedService: SharedService) {
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    this._primaryComp = '/' + navUrl.navUrl();
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
  }

  ngOnInit() {
  }
  
  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }
}
