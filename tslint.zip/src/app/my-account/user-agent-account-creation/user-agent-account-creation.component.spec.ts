import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAgentAccountCreationComponent } from './user-agent-account-creation.component';

describe('UserAgentAccountCreationComponent', () => {
  let component: UserAgentAccountCreationComponent;
  let fixture: ComponentFixture<UserAgentAccountCreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserAgentAccountCreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAgentAccountCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
