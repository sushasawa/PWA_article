import { MasterService } from './../../services/master.services';
import * as sha from 'sha.js';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Component, OnInit, DoCheck } from '@angular/core';
import { UserControl } from './../../helpers/user-control';
import { SessionHelper } from '../../../app/helpers/session-helper';
import { SharedService } from '../../shared/shared.service';
import { NavigatePathService } from '../../../app/services/navigate-path.service';
declare var Snackbar: any;
@Component({
  selector: 'app-user-agent-account-creation',
  templateUrl: './user-agent-account-creation.component.html',
  styleUrls: ['./user-agent-account-creation.component.css']
})
export class UserAgentAccountCreationComponent implements OnInit, DoCheck {
  public _UserControl: any = UserControl.getUserRules();
  public ACCESS_CTRL: any;
  public _primaryComp: any;
  public uid = JSON.parse(SessionHelper.getSession('userInfo')).uid;
  public AgentInfo: any = {
    FirstName: '',
    LastName: '',
    Email: '',
    Mobile: '',
    DOB: '',
    Designation: '',
    RoleType: '',
    password: '',
    AgentCode: '',
    CreatedBy: ''
  };
  public AccountTypes = [
    { value: '2', label: 'ADMIN' },
    { value: '3', label: 'AGENT' }
  ];
  public configDob = {
    format: 'DD-MM-YYYY',
    showMultipleYearsNavigation: true,
    disableKeypress: true,
  };
  
  public invalidsubmitted: Boolean;
  public dateOfBirth: any = '';
  public frmdateConfig: any;
  public concertinaStatus: any = '';
  constructor(private _MasterService: MasterService, private navUrl: NavigatePathService, private _SharedService: SharedService) {
    //   console.log(JSON.parse(SessionHelper.getSession('userInfo')).uid);
    this.invalidsubmitted = false;
    this._primaryComp = '/' + navUrl.navUrl();
    this.frmdateConfig = {
      format: 'DD-MM-YYYY',
      showMultipleYearsNavigation: true,
      disableKeypress: true,
    };
    this.ACCESS_CTRL = this._UserControl[SessionHelper.getSession('adm_ctrl')];
    if (!this.ACCESS_CTRL) {
      SessionHelper.removeSession('userInfo');
      SessionHelper.removeSession('userSessionInfo');
      SessionHelper.removeSession('userSessionInfoSale');
      SessionHelper.removeSession('userSessionInfoRealoadCard');
      SessionHelper.removeSession('userSessionInfoSend');
      SessionHelper.removeSession('pageSessionParam');
      SessionHelper.removeSession('currentUser');
      SessionHelper.removeSession('adm_ctrl');
      window.location.href = this._primaryComp + '/';
    }
    console.log('initial and after data VVVVVVVVVVVVVVVVVVV');
    console.log(this._SharedService.UserControledData);
    console.log('initial and after data ^^^^^^^^^^^^^^^^^^^');
    if (this._SharedService.UserControledData && this._SharedService.UserControledData.success) {
      this.ACCESS_CTRL = this._SharedService.UserControledData.msg.ACCESS_CTRL;
    }
  }

  ngOnInit() {
  }
  ngDoCheck() {
    this._SharedService.ACCESS_CTRL.subscribe((ACCESS_CTRL) => {
      console.log(ACCESS_CTRL);
      if (ACCESS_CTRL.success) {
        this.ACCESS_CTRL = ACCESS_CTRL.msg.ACCESS_CTRL;
      }
    });
  }
  public createUser(createUser: NgForm) {
    console.log(createUser);
    // tslint:disable-next-line:max-line-length
    console.log(sha('sha256').update(createUser.value.email.split('@')[0] + '' + this.dateOfBirth.split('-').join(''), 'utf8').digest('hex'));
    this.invalidsubmitted = createUser.invalid;
    this.AgentInfo.FirstName = createUser.value.fname,
      this.AgentInfo.LastName = createUser.value.lname,
      this.AgentInfo.Email = createUser.value.email,
      this.AgentInfo.Mobile = createUser.value.mobile,
      this.AgentInfo.DOB = this.dateOfBirth;
    this.AgentInfo.Designation = createUser.value.designation;
    this.AgentInfo.RoleType = Number.parseInt(createUser.value.accounttype);
    // tslint:disable-next-line:max-line-length
    this.AgentInfo.password = sha('sha256').update(createUser.value.email.split('@')[0] + '' + this.dateOfBirth.split('-').join(''), 'utf8').digest('hex');
    this.AgentInfo.AgentCode = '';
    this.AgentInfo.CreatedBy = JSON.parse(SessionHelper.getSession('userInfo')).uid;

    if (this.uid && !this.invalidsubmitted) {
      this._MasterService.createUserAgent(this.AgentInfo).subscribe((data) => {
        console.log(data);
        Snackbar.show({
          text: data,
          pos: 'bottom-right',
          actionTextColor: '#008000',
        });
        createUser.reset();
      }, err => {
        console.log(err);

        Snackbar.show({
          text: err,
          pos: 'bottom-right',
          actionTextColor: '#ff4444',
        });
        createUser.reset();
      });
    }

  }

  public dataChangeStart(event): void {
    if (event !== undefined && typeof event !== 'object') {
      console.log(event);
      this.dateOfBirth = event;
    }
  }

  showHideConcertina() {
    if (this.concertinaStatus === '') {
      this.concertinaStatus = 'open';
    } else {
      this.concertinaStatus = '';
    }
  }

}
