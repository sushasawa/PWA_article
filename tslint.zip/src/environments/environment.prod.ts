
export const environment = {
  production: true,
  API_URL: 'https://forex.coxandkings.com:8080',
  MERCHANT_ID: 'L218263'
};
