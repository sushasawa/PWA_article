
export const environment = {
    production: false,
    API_URL: 'http://172.21.203.224:8094',
    MERCHANT_ID: 'T218263'
  };
