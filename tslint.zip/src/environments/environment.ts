// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
console.log('DEVELOPMENT RUNNING');
// export const environment = {
//   production: false,
//   API_URL: 'http://10.21.21.210:5000',
//   MERCHANT_ID: 'T218263'
// };

export const environment = {
  production: false,
  API_URL: 'http://forex.coxandkings.com:8070',
  MERCHANT_ID: 'T218263'
};
console.log(environment);
